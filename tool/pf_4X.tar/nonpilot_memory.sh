#!/bin/bash

for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort` 
do
        #In case there are more than one top file for one station, we use the latest one.
        #top_file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'`
        #In case there is no top file for some station, we ignore it.
        if [ `ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'|wc -l` -eq 0 ]
        then
           echo " top_${sta}  doesn't exist!" 
        else
           top_file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'`
       	   echo Station_${sta} >> station 
           grep Mem: $top_file|tail -1|awk '{print $4}'|sed -n -e 's/k//p' >> used_mem 
           grep Mem: $top_file|tail -1|awk '{print $8}'|sed -n -e 's/k//p' >> buffer
           grep Swap: $top_file|tail -1|awk '{print $8}'|sed -n -e 's/k//p' >> cache        
        fi
done
 
paste station used_mem buffer cache > tmp     
awk 'BEGIN {print "Station    Memory(G)"} { mem=($2-$3-$4); printf "%s  %.2f\n", $1, mem/1024/1024; next} ' tmp >> memory.result
rm  station  used_mem buffer cache tmp 
awk 'BEGIN {print "MEM(G)"; max=0; } NR==1 {next;} { if ($2 > max) max=$2; next } END { printf "%.2f\n", max }' memory.result > memory.xls 
