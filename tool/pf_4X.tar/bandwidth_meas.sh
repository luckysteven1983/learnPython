#!/bin/bash

# including switches configuration file
tool_dir=$(cd "$(dirname "$0")"; pwd)
. $tool_dir/bandwidth_meas.conf

HW=`grep -w "HARDWARE" /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `
if [[ "$HW" =~ "HP" ]];then
    HW="HP"
elif [[ "$HW" =~ "BONO" ]];then
        HW="BONO"
elif [[ "$HW" =~ "ROUZIC" ]]; then
        HW="ROUZIC"
fi

NE=`grep -w "CONFIGURATION" /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `

#Dump MS_IP_DATA_MEAS measurement table data
/platdb/bin/pg_dump -h pglocalhost -U meas -a -t MS_IP_DATA_MEAS -f ms_ip_data_meas.txt -F p

#MS_IP_DATA_MEAS(schedtime, actualtime, duration, machine_name, intf_name, ipackets, ierrors, opackets, oerrors, ibytes, obytes, collisions, i_bandwidth, o_bandwidth, i_error_rate, o_error_rate) like following:
#1413317700 1413317701 300 0-0-1 0-0-8-SWITCH.GE0 18543 0 18059 0 1319 1288 0 35 34 0 0
#1413317700 1413317701 300 0-0-1 0-0-8-SWITCH.GE1 2397 0 8 0 1139 0 0 30 0 0 0
#1413317700 1413317701 300 0-0-1 0-0-7-SWITCH.GE0 19207 0 19623 0 1511 1517 0 40 40 0 0
#1413317700 1413317701 300 0-0-1 0-0-7-SWITCH.GE1 2380 0 8 0 1137 0 0 30 0 0 0

#Time that is used to filter invalid data
begin_time=`sed -n '2p' ../log.ini|awk '{print $1}'`
#echo "BeginTime is $begin_time"
if [ `cat ../log.ini|wc -l` -eq 3 ]; then
    end_time=`sed -n '3p' ../log.ini|awk '{print $1}'`
else
    end_time=`date +%s`
fi
#echo "EndTime is $end_time"

#Get the valid bandwidth data

awk '{ if ( $1 ~ /^[1-9]/ ) { print $0 } }' ms_ip_data_meas.txt |grep SWITCH|awk -v bgTime=$begin_time -v edTime=$end_time '{ if ($1>=bgTime && $1<=edTime) { print $1, $3, $4, $5, $13, $14 } }' > ms_ip_data_meas.data
#ms_ip_data_meas.data contents like following:
#1413317700 300 0-0-1 0-0-8-SWITCH.GE0 35 34
#1413317700 300 0-0-1 0-0-8-SWITCH.GE1 30 0
#1413317700 300 0-0-1 0-0-7-SWITCH.GE0 40 40
#1413317700 300 0-0-1 0-0-7-SWITCH.GE1 30 0 

bandwidth_raw=ms_ip_data_meas.data

#This function is to analysis bandwidth data.
#Its inputs are 2 parameters:
#  Parameter1 bandwidth_data_file
#  Parameter2 switch_port_array like TSWITCHFEHP, TSWITCHBEHP, TSWITCHFEBONO, TSWITCHBEBONO, TSWITCHPROVFEHP, TSWITCHFEROUZIC
function bandwidth_parser {
    bandwidth_data_file=$1
    switch_port_array="$2"
    #Use time as keyword to sort every type of bandwidth data
    cat $bandwidth_data_file|awk '{ print $1 }' |sort | uniq > time
    for t in `cat time`
    do
      #According time, calculate each switch port incoming and outgoing bandwidth data
      for switch in ${switch_port_array[*]}
      do
          grep $t $bandwidth_data_file|grep ${switch}  > /dev/null
          if [[ $? -eq 0 ]]; then
                line_n=`grep $t $bandwidth_data_file|grep ${switch}|wc -l`
                #Most of the time, both switches can work well, there will be 2 switch data in the moment;
                if [[ $line_n -eq 2 ]]; then
                   grep $t $bandwidth_data_file|grep ${switch} |awk '{ time=$1; bin += $5; bout += $6; } END { printf("%d\t%10d\t%10d\n", time, bin, bout) }' >> ${switch}.txt
                #Sometimes, only one switch works well, there will be 1 switch data in the moment.
                elif [[ $line_n -eq 1 ]]; then
                    grep $t $bandwidth_data_file|grep ${switch} |awk '{  printf("%d\t%10d\t%10d\n", $1, $5 , $6) }' >> ${switch}.txt
                fi 
          fi
      done

      #No matter when, there will be one total bandwidth data in this moment
      grep $t $bandwidth_data_file|awk '{ time=$1; bin += $5; bout += $6; } END { printf("%d\t%10d\t%10d\n", time, bin, bout) }' >> total.txt
   done
   rm time
}

if [[ "$NE" = "FE" ]];then
      if [[ "$HW" = "HP" ]]; then
        bandwidth_parser $bandwidth_raw "${TSWITCHFEHP[*]}" 
        for type in ${!TSWITCHFEHP[@]}; do
           switch=${TSWITCHFEHP[$type]} 
           if [ -f ${switch}.txt ]; then
              cat ${switch}.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "'"$type"'", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
              rm ${switch}.txt
           fi  
        done         
         
        cat total.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "TOTAL", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt

	elif [[ "$HW" = "BONO" ]]; then
             bandwidth_parser $bandwidth_raw "${TSWITCHFEBONO[*]}"
             for type in ${!TSWITCHFEBONO[*]}; do
               switch=${TSWITCHFEBONO[$type]}
               if [ -f ${switch}.txt ]; then
                    cat ${switch}.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "'"$type"'", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
                 rm  ${switch}.txt
               fi
             done
             
             cat total.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "TOTAL", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt 
   
	elif [[ "$HW" = "ROUZIC" ]]; then
             bandwidth_parser $bandwidth_raw "${TSWITCHFEROUZIC[*]}"
             for type in ${!TSWITCHFEROUZIC[*]}; do
               switch=${TSWITCHFEROUZIC[$type]}
               if [ -f ${switch}.txt ]; then
                    cat ${switch}.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "'"$type"'", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
                   rm ${switch}.txt 
               fi
             done
              
             cat total.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "TOTAL", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
	else
	    echo "The performance tool doesn't support $HW log analysis. You can contact Baosheng(mail:baosheng.liang@alcatel-lucent.com) for support!"
	fi
elif [[ "$NE" = "BE" ]];then
	if [[ "$HW" = "HP" ]]; then
        bandwidth_parser $bandwidth_raw "${TSWITCHBEHP[*]}"
        for type in ${!TSWITCHBEHP[@]}; do
           switch=${TSWITCHBEHP[$type]} 
           if [ -f ${switch}.txt ]; then
              cat ${switch}.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "'"$type"'", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
              rm ${switch}.txt
           fi  
        done         
         
        cat total.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "TOTAL", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
	elif [[ "$HW" = "BONO" ]]; then
             bandwidth_parser $bandwidth_raw "${TSWITCHBEBONO[*]}"
             for type in ${!TSWITCHBEBONO[*]}; do
               switch=${TSWITCHBEBONO[$type]}
               if [ -f ${switch}.txt ]; then
                    cat ${switch}.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "'"$type"'", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
                    rm ${switch}.txt
               fi
             done
             
             cat total.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "TOTAL", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt 
   
	elif [[ "$HW" = "ROUZIC" ]]; then
             bandwidth_parser $bandwidth_raw "${TSWITCHBEROUZIC[*]}"
             for type in ${!TSWITCHBEROUZIC[*]}; do
               switch=${TSWITCHBEROUZIC[$type]}
               if [ -f ${switch}.txt ]; then
                    cat ${switch}.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "'"$type"'", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
                    rm ${switch}.txt
               fi
             done
              
             cat total.txt | awk '{  if(max_in=="") {max_in=$2;max_out=$3}; if($2>=max_in) {max_in=$2;max_in_time=$1}; if($3>=max_out) {max_out=$3;max_out_time=$1}; total_in+=$2; total_out+=$3; count+=1} END {printf "%8s\t%11d\t%11d\t%10d\t%11d\t%11d\t%10d\n", "TOTAL", total_in/count, max_in, max_in_time,total_out/count,max_out,max_out_time }' >> bandwidth.rpt
	else
	    echo "The performance tool doesn't support $HW log analysis. You can contact Baosheng(mail:baosheng.liang@alcatel-lucent.com) for support!"
	fi
else
     echo "The performance tool doesn't support $NE log analysis. You can contact Baosheng(mail:baosheng.liang@alcatel-lucent.com) for support!"
fi

cat bandwidth.rpt |awk '{printf("%10s\t%10d\t%10d\n", $1, $2, $3)}' > 1.tmp
 
function translate {
  echo  `date +"%Y-%m-%d-%H:%M:%S"  -d@$1`
} 

for data in `cat bandwidth.rpt|awk '{ print $4 }'`
do 
  translate $data >> 2.tmp
done

cat bandwidth.rpt |awk '{printf("%10d\t%10d\n", $5,$6)}' > 3.tmp

for data in `cat bandwidth.rpt|awk '{ print $7 }'`
do 
  translate $data >> 4.tmp
done

paste 1.tmp 2.tmp 3.tmp 4.tmp > bandwidth.tmp
cat bandwidth.tmp |awk 'BEGIN {printf "%10s\t%10s\t%10s\t%17s\t%10s\t%10s\t%17s\n","Type","AvgInBd","MaxInBd","MaxInTime","AvgOutBd","MaxOutBd","MaxOutTime" } { printf "%-10s\t%-10d\t%-10d\t%-17s\t%-10d\t%-10d\t%-17s\n",$1,$2,$3,$4,$5,$6,$7 }' > bandwidth.report
mv ms_ip_data_meas.data ms_ip_data_meas.txt
rm 1.tmp 2.tmp 3.tmp 4.tmp bandwidth.tmp total.txt bandwidth.rpt

cat bandwidth.report |sed -n '2,$p'| awk '{ printf("%-18s\t%-19s\t", $1"_AvgInBd", $1"_AvgOutBd") }' > bandwidth.summary
cat bandwidth.summary |awk '{ print $0 }' > bandwidth.tmp; mv bandwidth.tmp bandwidth.summary
cat bandwidth.report |sed -n '2,$p'| awk '{ printf("%-18d\t%-19d\t", $2, $5) }' > bandwidth.tmp
cat bandwidth.tmp |awk '{ print $0 }' >> bandwidth.summary
rm bandwidth.tmp
