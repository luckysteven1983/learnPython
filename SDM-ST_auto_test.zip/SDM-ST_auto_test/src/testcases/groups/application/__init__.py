"""
This package will contain all applications-related test cases:
HSS, LTE, CDMA, HLR, multi-app, SS7, EIr, MNP
"""
