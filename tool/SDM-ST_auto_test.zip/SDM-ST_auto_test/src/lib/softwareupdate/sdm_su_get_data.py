"""
@file sdm_su_get_data.py
@ingroup SDMSQA
@author Jiaxi Jin
@date 2015-09-01
@brief call getData.sh with provided arguments
@detail
Jira ticket: SDMSQA-891
provide the function to call getData.sh tool for collection configuration data
"""

from lib.ssh.ssh_manager import SshManager
from lib.logging.logger import Logger

class SdmSUGetDataError(BaseException):
    """If error, raise it."""
    pass

LOGGER = Logger.getLogger(__name__)

class SdmSUGetData(object):
    """ class to prepare object """

    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def runGetData(self, hostIP, hostUser, hostPw, pathToShell, option='-a', fePort='61133'):
        """
        SSH to server and run the getData.sh with provided info

        @param hostIP : the address of server
        @param hostUser : the user name on server
        @param hostPw : password
        @param pathToShell : the path to the getData.sh file on the server
        @param option : option provided for getData.sh
        @param fePort: FEport provided for getData.sh

        SdmSUGetData().runGetData(hostIP, hostUser, hostPw, pathToShell, option, fePort)

        or if gateway is needed

        obj = SdmSUGetData(SshManager(sshGateway, sshUser, sshPassword))
        obj.runGetData(hostIP, hostUser, hostPw, pathToShell, option, fePort)
        """

        try:

            if self.sshManager is not None:
                sshManager = self.sshManager
            else:
                sshManager = SshManager()

            ssh = sshManager.getClient(hostIP, hostUser, hostPw)

            cmd = pathToShell + ' ' + option + ' ' + fePort

            ssh.exec_command(cmd)

            sshManager.closeClient(hostIP)

            LOGGER.debug('execute getData.sh on %s\tOK\n', hostIP)

            return True

        except SdmSUGetDataError:

            LOGGER.debug('execute getData.sh on %s\tError\n', hostIP)

            return False
