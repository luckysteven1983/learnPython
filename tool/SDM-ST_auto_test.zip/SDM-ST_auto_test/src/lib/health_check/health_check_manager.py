"""
@file health_check_manager.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-13
@brief health check

Health check for system.
"""

import lib.exceptions_messages as eMsgs
from lib.logging.logger import Logger
from framework.testenv.backend import Backend
from framework.testenv.frontend import Frontend

LOGGER = Logger.getLogger(__name__)

class HealthCheckManagerError(BaseException):
    """If error, raise it."""
    pass

class HealthCheckManager(object):
    """@verbatim Health check for system

    All public methods in this class wrap the same functions provided by the health check tool.

    Usage:
        Let's take lab 135.251.83.201 as an example on how to get a
        HealthCheckManager instance.

        import SshManager, HealthCheckManager
        sshManager = SshManager()
        myCheck = HealthCheckManager(sshManager)

        So then we can use instance myCheck to call the methods provided by this
        class. On how to call the method, please check doc string in each
        method.
    @endverbatim
    """

    def __init__(self, sshManager, multiTasksManager, toolDir='/cust_use/healthTools'):
        """Init HealthCheckManager instance with sshManager and toolDir.

        @param sshManager  an instance of SshManager used for remote command execution.
        @param toolDir  health check tool installation directory (default '/cust_use/healthTools')
        """
        self.multiTasksManager = multiTasksManager
        self._sshManager = sshManager
        self._toolCmd = toolDir + "/bin/health"
        self._toolLog = toolDir + "/log/healthcheck/all.log"

    def verifyToolInstalled(self, lab, toolDir=None):
        """@verbatim Check whether the health check tool has been installed.

        If the health check tool is not installed, an exception will be raised.
        @endverbatim

        @param lab  one Lab object
        @param toolDir  health check tool directory
        """
        if lab.healthCheckAvailable:
            return
        if toolDir:
            self._toolCmd = toolDir + "/bin/health"
            self._toolLog = toolDir + "/log/healthcheck/all.log"
        # rc is not 0
        if self._runShellCmd(lab, '%s -h' % self._toolCmd, True):
            errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_TOOL_NOK)
            LOGGER.error(errorMsg)
            raise HealthCheckManagerError, errorMsg
        lab.healthCheckAvailable = True

    def runToolCmd(self, lab, cmd):
        """Run the health check tool command and return the result

        @param lab  one Lab object
        @param cmd  the health check tool command.
        """
        return self._runShellCmd(lab, '%s %s' % (self._toolCmd, cmd))

    def _runShellCmd(self, lab, cmd, rc=False):
        """Run remote shell command and return stdout or return code

        @param lab  one Lab object
        @param cmd  the command to be executed on remote lab.
        @param rc  return return code if it is True, or return stdout
        @param debugLog  indicate whether print debug log
        """
        response = self._sshManager.run(lab.oamIpAddress, cmd)
        return response[0] if rc else response[1]

    def runCheckSpa(self, lab):
        """@verbatim Check spa state

        If spa state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for all SDM types
        @endverbatim

        @param lab  one Lab object
        @exception msg  spa state NOK

        @verbatim
        Usage:
            myCheck.runCheckSpa(lab)
        @endverbatim
        """
        if self.runToolCmd(lab, 'spas').find('status ok') == -1:
            self._runShellCmd(lab, 'cat %s' % self._toolLog)
            errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_SPA_NOK)
            LOGGER.error(errorMsg)
            raise HealthCheckManagerError, errorMsg

    def runCheckMachine(self, lab):
        """@verbatim Check machine state

        If machine state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for all SDM types
        @endverbatim

        @param lab  one Lab object
        @exception msg  machine state NOK

        @verbatim
        Usage:
            myCheck.runCheckMachine(lab)
        @endverbatim
        """
        if self.runToolCmd(lab, 'machines').find('status ok') == -1:
            self._runShellCmd(lab, 'cat %s' % self._toolLog)
            errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_MACHINE_NOK)
            LOGGER.error(errorMsg)
            raise HealthCheckManagerError, errorMsg

    def runCheckStation(self, lab):
        """@verbatim Check station state

        If station state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for all SDM types
        @endverbatim

        @param lab  one Lab object
        @exception msg  station state NOK

        @verbatim
        Usage:
            myCheck.runCheckStation(lab)
        @endverbatim
        """
        if self.runToolCmd(lab, 'stations').find('status ok') == -1:
            self._runShellCmd(lab, 'cat %s' % self._toolLog)
            errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_STATION_NOK)
            LOGGER.error(errorMsg)
            raise HealthCheckManagerError, errorMsg

    def runCheckSigtran(self, lab):
        """@verbatim Check sigtran link state

        If sigtran link state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for SDM FE type
        @endverbatim

        @param lab  one Lab object
        @exception msg  sigtran link state NOK

        @verbatim
        Usage:
            myCheck.runCheckSigtran(lab)
        @endverbatim
        """
        if isinstance(lab.productRole, Frontend):
            response = self.runToolCmd(lab, 'sigtran')
            if response.find('status ok') == -1:
                # Here we need to check whether the sigtran link is configured or not.
                if response.find('No SIGTRAN Associations') == -1:
                    self._runShellCmd(lab, 'cat %s' % self._toolLog)
                    errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_SIGTRAN_NOK)
                    LOGGER.error(errorMsg)
                    raise HealthCheckManagerError, errorMsg
        else:
            LOGGER.debug('Lab %s - Not FE so skip the sigtran check', lab.id)

    def runCheckSsnlink(self, lab):
        """@verbatim Check ssn link state

        If ssn link state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for SDM FE type
        @endverbatim

        @param lab  one Lab object
        @exception msg  ssn link state NOK

        @verbatim
        Usage:
            myCheck.runCheckSsnlink(lab)
        @endverbatim
        """
        if isinstance(lab.productRole, Frontend):
            response = self.runToolCmd(lab, 'ssnlink')
            if response.find('status ok') == -1:
                # Here we need to check whether the ssn link is configured or not.
                if response.find('No Signaling Links') == -1:
                    self._runShellCmd(lab, 'cat %s' % self._toolLog)
                    errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_SSNLINK_NOK)
                    LOGGER.error(errorMsg)
                    raise HealthCheckManagerError, errorMsg
        else:
            LOGGER.debug('Lab %s - Not FE so skip the ssnlink check', lab.id)

    def runCheckNdb(self, lab):
        """@verbatim Check ndb state

        If ndb state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for SDM BE type
        @endverbatim

        @param lab  one Lab object
        @exception msg  ndb state NOK

        @verbatim
        Usage:
            myCheck.runCheckNdb(lab)
        @endverbatim
        """
        if isinstance(lab.productRole, Backend):
            response = self.runToolCmd(lab, 'ndb_status')
            if response.find('status ok') == -1:
                self._runShellCmd(lab, 'cat %s' % self._toolLog)
                errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_NDB_NOK)
                LOGGER.error(errorMsg)
                raise HealthCheckManagerError, errorMsg
        else:
            LOGGER.debug('Lab %s - Not BE so skip the ndb status check', lab.id)

    def runCheckProc(self, lab):
        """@verbatim Check process state

        If process state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for all SDM types
        @endverbatim

        @param lab  one Lab object
        @exception msg  process state NOK

        @verbatim
        Usage:
            myCheck.runCheckProc(lab)
        @endverbatim
        """
        response = self.runToolCmd(lab, 'procstat')
        if response.find('status ok') == -1:
            self._runShellCmd(lab, 'cat %s' % self._toolLog)
            errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_PROC_NOK)
            LOGGER.error(errorMsg)
            raise HealthCheckManagerError, errorMsg

    def runCheckConn(self, lab):
        """@verbatim Check connection state between FE and BE

        If connection state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for SDM FE and BE types
        @endverbatim

        @param lab  one Lab object
        @exception msg  connection state NOK

        @verbatim
        Usage:
            myCheck.runCheckConn(lab)
        @endverbatim
        """
        if isinstance(lab.productRole, Backend) or isinstance(lab.productRole, Frontend):
            response = self.runToolCmd(lab, 'febe_conn')
            if response.find('status ok') == -1:
                self._runShellCmd(lab, 'cat %s' % self._toolLog)
                errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_CONN_NOK)
                LOGGER.error(errorMsg)
                raise HealthCheckManagerError, errorMsg
        else:
            LOGGER.debug('Lab %s - Not FE or BE so skip the conn between fe and be check', lab.id)

    def runCheckDiamlink(self, lab):
        """@verbatim Check diameter link state

        If diameter link state is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for SDM FE type
        @endverbatim

        @param lab  one Lab object
        @exception msg  diameter link state NOK

        @verbatim
        Usage:
            myCheck.runCheckDiamlink(lab)
        @endverbatim
        """
        if isinstance(lab.productRole, Frontend):
            response = self.runToolCmd(lab, 'diamlink')
            if response.find('status ok') == -1:
                self._runShellCmd(lab, 'cat %s' % self._toolLog)
                errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_DIAMLINK_NOK)
                LOGGER.error(errorMsg)
                raise HealthCheckManagerError, errorMsg
        else:
            LOGGER.debug('Lab %s - Not FE so skip the diamlink check', lab.id)

    def runCheckAll(self, lab, checkPoints=None, toolDir=None):
        """
        Do health check according to checkPoints.

        checkPoints is a list of strings. Each
        string is a mapping to the corresponding health check module. Here are the strings
        to provide and their corresponding health check module name:

        * 'Spa': spas,
        * 'Machine': machines,
        * 'Station': stations,
        * 'Sigtran': sigtran,
        * 'Ssnlink': ssnlink,
        * 'Ndb': ndb_status,
        * 'Proc': procstat,
        * 'Conn': febe_conn,
        * 'Diamlink': diamlink.

        The strings provided in the checkPoints list are case insensitive.

        The default check points will include spa, machine, station, ndb, proc between fe
        and be


        Do health check according to checkPoints. The checkPoints is list consists of supported
        check point. The supported modules are spas, machines, stations, sigtran,
        ssnlink, ndb_status, procstat, febe_conn and diamlink.

        The default check points will include the following health check modules: spas,
        machines, stations, ndb_status, procstat

        @param lab  one Lab object
        @param checkPoints a check point list (default 'None')
        @param toolDir string health check custom location
        @exception msg  diameter link state NOK

        @verbatim
        Usage:
            myCheck.runCheckDiamlink(lab)
            myCheck.runCheckDiamlink(lab, ['Spa', 'Machine'])
        @endverbatim
        """

        self.verifyToolInstalled(lab, toolDir)
        supportedCheckPoints = ['Spa', 'Machine', 'Station', 'Sigtran',
                                'Ssnlink', 'Ndb', 'Proc', 'Conn', 'Diamlink']
        defaultCheckPoinits = ['Spa', 'Machine', 'Station', 'Ndb', 'Proc']
        if checkPoints is None:
            checkPoints = defaultCheckPoinits
        else:
            oLen = len(checkPoints)
            checkPoints = [cPoint.title() for cPoint in checkPoints
                           if cPoint.title() in supportedCheckPoints]
            if oLen != len(checkPoints):
                LOGGER.debug('Supported check points %s', supportedCheckPoints)
                errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_POINT_NOK)
                LOGGER.error(errorMsg)
                raise HealthCheckManagerError, errorMsg
        for cPoint in checkPoints:
            getattr(self, 'runCheck' + cPoint)(lab)


    def runCheckAllOnTestBed(self, testBed, checkPoints=None, toolDir=None):
        """ Call runCheckAll on a whole test bed

        @param testBed        testBed on which check core files
        @param checkPoints    a check point list (default 'None')
        @param toolDir        string health check custom location
        """
        # Check core on all labs in parallel
        LOGGER.debug("Check status on all Labs in progress")
        for labID in testBed.labs:
            threadName = self.multiTasksManager.register(self.runCheckAll, testBed.labs[labID], checkPoints, toolDir)
            LOGGER.debug("Check status on Lab '%s' in progress -> thread ID '%s'", labID, threadName)
        LOGGER.debug("Wait check status complete on all Labs")
        return self.multiTasksManager.runMultiTasks()

    def runCheckHelpme(self, lab, helpmeOption):
        """@verbatim Run the helpme command wirh the corresponding option

        If If helpme command is OK, no operations.
        Else raise an exception and print debug log

        This check should be used for SDM FE and SDM BE type
        @endverbatim

        @param lab  one Lab object
        @param helpmeOption  one String. For more information about the helpme command,
                                          see "SDM Health tool user guide" (3BL-98364-HAAA-RJZZA)
        @exception msg  helpme command result NOK

        @verbatim
        Usage:
            myCheck.runCheckHelpme(lab, helpmeOption)
        @endverbatim
        """
        if isinstance(lab.productRole, Backend) or isinstance(lab.productRole, Frontend):
            response = self.runToolCmd(lab, 'helpme -w ' + helpmeOption)
            if response.find('status ok') == -1:
                self._runShellCmd(lab, 'cat %s' % self._toolLog)
                errorMsg = '%s: %s' % (lab.id, eMsgs.HEALTH_CHECK_HELPME_NOK)
                LOGGER.error(errorMsg)
                raise HealthCheckManagerError, errorMsg
            else:
                LOGGER.debug('%s: health check helpme OK', lab.id)
        else:
            LOGGER.debug('Lab %s - No FE or BE so this part (helpme -w ' + \
                            helpmeOption + ') is skipped', lab.id)
