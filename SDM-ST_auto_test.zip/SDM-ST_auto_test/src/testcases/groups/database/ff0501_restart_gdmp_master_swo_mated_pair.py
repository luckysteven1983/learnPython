"""
Created on November 17, 2015

@author: Cassandra Lajeunie

# no test sheet found
"""
import os
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils
from lib.database.ddm.database_manager import PROCESS_GDMP_SERVER, SCRIPT_GDMP_SERVER

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0501_restart_gdmp_master_swo_mated_pair(SDMTestCase):
    "Test restart gdmpServer process on master and perform SWO mated pair"

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.success = True
        self.exceptMsg = ""
        self.expectedAlarmsSpecific = []
        self.acceptedAlarmsSpecific = []
        self.expectedAlarms4BE = []
        self.acceptedAlarms4BE = []
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.databaseManager = self.sdmManager.databaseManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_restart_gdmp_master_swo_mated_pair(self):
        """
        ' Test restart restart GDMP Server on master BE and do BE SWO mated pair '
        What it does :
        1- restart GDMP Server process on the master BE of a NRG
        2- perform SWO mated pair
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case ...")

        LOGGER.info("start to restart gdmpserver on master BE of NRG1")
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getLabIdInNRG("1")
        masterBE = self.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.debug("Start to restart gdmps on master BE at: " + startTime)

        stations = masterBE.getAllBlade().keys()
        LOGGER.debug("the station list is: "+str(stations))

        LOGGER.debug("check the gdmps process on all stations is alive")
        self.platformAsserts.assertProcessAliveOnStations(masterBE, PROCESS_GDMP_SERVER, stations)

        LOGGER.debug("restart gdmps on all stations")
        self.databaseManager.runScriptOperation(masterBE, SCRIPT_GDMP_SERVER, ddmOperation='restart',
                                     station=stations)

        LOGGER.debug("check the gdmps process on all stations can be recover")
        self.platformAsserts.assertProcessAliveOnStations(masterBE, PROCESS_GDMP_SERVER, stations)

        LOGGER.info("Perform a swo mated pair")
        self.databaseManager.matedPairSwo(belist)

        return startTime

    def _postcheck(self, startTime):
        """Test case postcheck"""
        LOGGER.debug("test case post check")
        LOGGER.debug("check the alarm")
        exceptMsg = str()
        myAlarmsConfig4BE = AlarmsConfig(self.expectedAlarms4BE, self.acceptedAlarms4BE, startTime)
        for labIndex in self.allBEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                exceptMsg += str(msg) + os.linesep
        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
