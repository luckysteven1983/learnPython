"""
Created on Nov 19, 2015

@author: Zheng Yuan

#weblink_id=3KJ-00117-0827-QPZZA
"""
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.common import Utils
from lib.alarm.alarms_config import AlarmsConfig
import lib.exceptions_messages as msgs
import random

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class es4807_check_ssnlink_status(SDMTestCase):
    """
    Note:
        This case needs to run on FE which have all ssnlink active like below,
        otherwise it will be skipped by Automation Framewrok:
        < op:slk=eqp; PF
           +++ HP27 2015-11-19 21:28:19 MAINT   #004047 0-0-1 >
           OP SLK=eqp COMPLETED
           +-----------------------------+----------------------+--------+-----------+
           |        LINK DATA            |     STATUS FLAGS     |  LINK  |    LINK   |
           +-----------------------------+----------------------+ACTIVITY|AVAILABILTY|
           |  No.   |LS|SLC|Cg|LFC|CLASS |FAIL|BLK|RBLK|INH|RINH|  STATE |    STATE  |
           +--------+--+---+--+---+------+----+---+----+---+----+--------+-----------+
           |   0-1-1| 1|  1| 0|   |M2PA  |    |   |    |   |    | ACTIVE | AVAILABLE |
           +--------+--+---+--+---+------+----+---+----+---+----+--------+-----------+
           |   1-1-1| 1|  2| 0|   |M2PA  |    |   |    |   |    | ACTIVE | AVAILABLE |
           +--------+--+---+--+---+------+----+---+----+---+----+--------+-----------+

    Case Description:
        Use health check tool to check ssnlink association status
    Automation Test Procedure:
        1. Test case pre-check
        2. Run health check tool ssnlink check command
        3. Check the output of the result of the ssnlink check command
        4. Check whether the logs have been generated
        5. Check logs content generated correctly
        6. Show the case running result
        7. Lab check and recovery: Since Health check tool won't impact the lab status, so no need to recovery Lab
    """

    def setUp(self):
        """Init the managers this case need"""
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.myHCM = self.sdmManager.healthCheckManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mySshManager = self.sdmManager.sshManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.fe = random.choice(self.allFEs)
        self.exceptMsg = str()
        self.expectedAlarms = []
        self.acceptedAlarms = []

        # Skip this test case if some associations not active on FE
        try:
            self.myHCM.runCheckSsnlink(self.fe)
        except BaseException:
            errorMsg = "This TC needs all ssnlink active, TC skipped due to some ssnlink not active on FE:" + self.fe.id
            LOGGER.warning(errorMsg)
            self.skipTest(errorMsg)

        LOGGER.debug("Test case es4807_check_ssnlink_status started")


    def _precheck(self):
        """Test case pre-check and return current active alarm list """
        checkQoS = False

        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0], checkQoS)


    def test_check_ssnlink_status(self):
        """Use health check tool to check association status"""
        healthCommand = "ssnlink"
        expectCheckOutput = ["Completed ssnlink check with status ok", "health completed"]
        toolDir = "/cust_use/healthTools"
        checkLogDir = toolDir + "/log/healthcheck"
        checkLogCommand = "ls " + checkLogDir + ";ls " + checkLogDir + "/per_module"
        checkLogs = ["all.log", "progress.log", "per_module", "ssnlink.log"]
        logContents = ["Start ssnlink check", "Completed ssnlink check with status ok", "health completed",
                      "ssnlink progress", "ssnlink information"]  # What contents the log should contain
        logFiles = [checkLogDir + "/all.log", checkLogDir + "/progress.log", checkLogDir + "/per_module/ssnlink.log"]
        checkQoS = False

        # Test case pre-check
        self._precheck()

        # get the start time of the TC
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)

        # Run health check tool ssnlink check command
        LOGGER.debug("Run health check tool ssnlink check command ")
        checkOutput = self.myHCM.runToolCmd(self.fe, healthCommand)

        # Check the output of the result of the ssnlink check command
        LOGGER.debug("Check the output of the result of the ssnlink check command")
        for output in expectCheckOutput:
            if output not in checkOutput:
                LOGGER.error(msgs.HEALTH_CHECK_TOOL_OUTPUT_NOK)
                raise Exception(msgs.HEALTH_CHECK_TOOL_OUTPUT_NOK)

        # Check whether the logs have generated
        LOGGER.debug("Check whether log files have generated")
        checkLogOutput = self.mySshManager.run(self.fe.oamIpAddress, checkLogCommand)
        for logName in checkLogs:
            if logName not in checkLogOutput[1]:
                LOGGER.error(msgs.HEALTH_CHECK_TOOL_LOGS_GEN_NOK)
                raise Exception(msgs.HEALTH_CHECK_TOOL_LOGS_GEN_NOK)

        # Check logs contains the specified content
        LOGGER.debug("Check logs contains the specified content")
        try:
            self.platformAsserts.assertFileContainsExpectedContents(self.fe.oamIpAddress,
                                                                    logFiles[0], logContents[0], logContents[1],
                                                                    logContents[2], logContents[3], logContents[4])
            self.platformAsserts.assertFileContainsExpectedContents(self.fe.oamIpAddress, logFiles[1], logContents[0],
                                                                    logContents[1], logContents[2])
            self.platformAsserts.assertFileContainsExpectedContents(self.fe.oamIpAddress, logFiles[2], logContents[0],
                                                                    logContents[1], logContents[3], logContents[4])
        except BaseException:
            LOGGER.error(msgs.HEALTH_CHECK_TOOL_LOGS_CONTENT_NOK)
            raise Exception(msgs.HEALTH_CHECK_TOOL_LOGS_CONTENT_NOK)

        # Check the alarms at the end
        LOGGER.debug("check the alarms")
        # check the alarms on ONE node, make sure that all expect alarm are raised, and no abnormal alarms, eg:
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared (done in assertEndState)
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(self.fe, myAlarmsConfig, logFile=LOGFILE[1])
            # LOGFILE[1] is a csv file used to save alarms raised since test case is running
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.exception("%s: alarm check fail", self.fe.id)

        # Check the end status of the test env
        LOGGER.debug("Check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkQoS)
        LOGGER.debug("es4807_check_ssnlink_status success!\n")
