'''
Created on Mar 17, 2015

@author: Xia Zhao
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.alarm.alarm import Alarm
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0494_restart_spa_master(SDMTestCase):
    '''test restart oambe spa on master be'''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self._mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self._databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = [Alarm(917201, "Major")]
        self.success = True
        self.exceptMsg = ""

    def test_restart_spa_master(self):
        '''test restart spas on master be'''

        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("get master be")
        belist = self.testEnv.testBed.getNRG("1")
        masterBE = self._databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is " + masterBE.id)
        LOGGER.info("start to restart spas on master BE: " + str(masterBE.id))

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.debug("Start to restart spas on master BE at: " + startTime)

        spaName = "OAMBE"
        LOGGER.debug("start to restart SPA " + spaName + " on BE: " + str(masterBE.id))
        try:
            self._mcasApplicationManager.restartSPA(masterBE, spaName)
            LOGGER.debug("Restart SPA " + spaName + " on BE: " + str(masterBE.id) + " successful")
        except BaseException, msg:
            self.exceptMsg += str(msg)
            self.success = False
            LOGGER.error("Restart SPA " + spaName + " on BE: " + str(masterBE.id) + " fail")

        LOGGER.debug("check the alarm")
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(masterBE, myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: alarm check fail", masterBE.id)

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: end state of test env check fail", masterBE.id)

        if self.success:
            LOGGER.debug("ff0494 restart spa on master BE success!\n")
        else:
            LOGGER.error("ff0494 restart spa on master BE fail!\n")
            LOGGER.error(self.exceptMsg)
            # spa recover done in jenkins worker
            raise Exception(self.exceptMsg)
