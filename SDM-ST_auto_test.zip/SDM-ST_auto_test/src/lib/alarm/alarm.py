"""
@file alarm.py
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines the Alarm class
@details
"""
from lxml import etree
from lib.common.multi_tasks_manager import MultiTasksManager
from lib.logging.logger import Logger
import csv
import os

LOGGER = Logger.getLogger(__name__)

class Alarm(object):
    """
    @details This class describes an snmp alarm as it appears in snmplog files.
    An alarm is unique by ObjectName, SpecificProblem and ProbableCause

    A valid mCAS alarm xml format should be like below.
    <Alarm>
         <AlarmIndex>213</AlarmIndex>
         <ObjectName>0-0-1#HOST=HP26-0-0-1 INTERFACE=eth0.1304,eth1.1304</ObjectName>
         <SpecificProblem>Lost connectivity between interfaces eth0.1304,eth1.1304</S
    pecificProblem>
         <ProbableCause>LANError</ProbableCause>
         <NotificationIdentifier>213</NotificationIdentifier>
         <Severity>Major</Severity>
         <AlarmType>CommunicationAlarm</AlarmType>
         <AdditionalText></AdditionalText>
         <OMText>REPT LAN EVENT - External Connectivity Test Failed    OBJECT: MACHIN
    E=0-0-1 INTERFACE eth0.1304,eth1.1304    ENTITY: {RACK,0}{SYSTEM_CHASSIS,0}{S
    YSTEM_BLADE,1}    INFO:   Lost connectivity between eth0.1304 and eth1.1304</
    OMText>
         <AlarmCode>954001</AlarmCode>
         <AlarmSource>PLATFORM</AlarmSource>
         <AlarmTime>Thu May 21 09:31:40 2015</AlarmTime>
         <RepeatCount>0</RepeatCount>
         <OMDBKey>/LAN01</OMDBKey>
         <AutoClear>1</AutoClear>
    </Alarm>
    """

    ALARM_INDEX = 'AlarmIndex'
    OBJECT_NAME = 'ObjectName'
    SPECIFIC_PROBLEM = 'SpecificProblem'
    PROBABLE_CAUSE = 'ProbableCause'
    NOTIFICATION_IDENTIFIER = 'NotificationIdentifier'
    SEVERITY = 'Severity'
    ALARM_TYPE = 'AlarmType'
    ADDITIONAL_TEXT = 'AdditionalText'
    OM_TEXT = 'OMText'
    ALARM_CODE = 'AlarmCode'
    ALARM_SOURCE = 'AlarmSource'
    ALARM_TIME = 'AlarmTime'
    REPEAT_COUNT = 'RepeatCount'
    OM_DB_KEY = 'OMDBKey'
    AUTO_CLEAR = 'AutoClear'

    def __init__(self, alarmCode=None, severity=None, specificProblem=None, probableCause=None,
                 notificationIdentifier=None, objectName=None, alarmType=None, additionalText=None,
                 omText=None, alarmIndex=None, alarmSource=None, alarmTime=None, repeatCount=None,
                 omDBKey=None, autoClear=None):
        """
        Alarm defination
        @param alarmIndex    AlarmIndex in xml log file (int)
        @param objectName    ObjectName in xml log file (str)
        @param specificProblem    SpecificProblem in xml log file (str)
        @param probableCause    ProbableCause in xml log file (str)
        @param notificationIdentifier    NotificationIdentifier in xml log file (int)
        @param severity    Severity in xml log file (str)
        @param AlarmType   Severity in xml log file (str)
        @param additionalText    AdditionalText in xml log file (str)
        @param omText    OMText in xml log file (str)
        @param alarmCode    AlarmCode in xml log file (int)
        @param alarmSource    AlarmSource in xml log file (str)
        @param alarmTime    AlarmTime in xml log file (str)
        @param repeatCount    RepeatCount in xml log file (int)
        @param omDBKey    OMDBKey in xml log file (str)
        @param autoClear      AutoClear in xml log file (int)
        """
        self.alarmIndex = alarmIndex
        self.objectName = objectName
        self.specificProblem = specificProblem
        self.probableCause = probableCause
        self.notificationIdentifier = notificationIdentifier
        self.severity = severity
        self.alarmType = alarmType
        self.additionalText = additionalText
        self.omText = omText
        self.alarmCode = alarmCode
        self.alarmSource = alarmSource
        self.alarmTime = alarmTime
        self.repeatCount = repeatCount
        self.omDBKey = omDBKey
        self.autoClear = autoClear

    def __eq__(self, alarm):
        """
        Method overwriting "==" operator to compare two Alarm objects
        @param alarm  Alarm object to be compared to self
        """
        # Compare each member in alarm object if its value is non default.
        for attr in ('alarmIndex', 'objectName', 'specificProblem', 'probableCause',
                     'notificationIdentifier', 'severity', 'alarmType', 'additionalText', 'omText',
                     'alarmCode', 'alarmSource', 'alarmTime', 'repeatCount', 'omDBKey',
                     'autoClear'):
            value1 = getattr(self, attr)
            value2 = getattr(alarm, attr)
            if value1 is None or value2 is None:
                continue
            # Need to filter the any blank, newline and change them into lowercase before
            # comparation
            if ''.join(str(value1).split()).lower() != ''.join(str(value2).split()).lower():
                return False
        return True

    @classmethod
    def getAlarmByString(cls, xlmFormatString):
        """Return an alarm object with the given xmlFormatString.

        @param xlmFormatString    xml format string like below

        <Alarm>
             <AlarmIndex>213</AlarmIndex>
             <ObjectName>0-0-1#HOST=HP26-0-0-1 INTERFACE=eth0.1304,eth1.1304</ObjectName>
             <SpecificProblem>Lost connectivity between interfaces eth0.1304,eth1.1304</S
        pecificProblem>
             <ProbableCause>LANError</ProbableCause>
             <NotificationIdentifier>213</NotificationIdentifier>
             <Severity>Major</Severity>
             <AlarmType>CommunicationAlarm</AlarmType>
             <AdditionalText></AdditionalText>
             <OMText>REPT LAN EVENT - External Connectivity Test Failed    OBJECT: MACHIN
        E=0-0-1 INTERFACE eth0.1304,eth1.1304    ENTITY: {RACK,0}{SYSTEM_CHASSIS,0}{S
        YSTEM_BLADE,1}    INFO:   Lost connectivity between eth0.1304 and eth1.1304</
        OMText>
             <AlarmCode>954001</AlarmCode>
             <AlarmSource>PLATFORM</AlarmSource>
             <AlarmTime>Thu May 21 09:31:40 2015</AlarmTime>
             <RepeatCount>0</RepeatCount>
             <OMDBKey>/LAN01</OMDBKey>
             <AutoClear>1</AutoClear>
        </Alarm>
        """
        # Sometimes, the tag in snmplog will go across multiple lines. So before parser, need to
        # join each line after removing whitespace on both ends
        root = etree.fromstring(''.join([line.strip() for line in xlmFormatString.split()])) # pylint: disable=no-member
        return cls.getAlarmByXmlRoot(root)

    @classmethod
    def getAlarmByXmlRoot(cls, xmlRoot):
        """Return an alarm object with the given xml root pointing to <Alarm> tag.

        @param xmlRoot  xml root pointing to <Alarm> tag returned by lxml.etree
        """
        return cls(alarmIndex=int(xmlRoot.find(cls.ALARM_INDEX).text),
                   objectName=xmlRoot.find(cls.OBJECT_NAME).text,
                   specificProblem=xmlRoot.find(cls.SPECIFIC_PROBLEM).text,
                   probableCause=xmlRoot.find(cls.PROBABLE_CAUSE).text,
                   notificationIdentifier=int(xmlRoot.find(cls.NOTIFICATION_IDENTIFIER).text),
                   severity=xmlRoot.find(cls.SEVERITY).text,
                   alarmType=xmlRoot.find(cls.ALARM_TYPE).text,
                   additionalText=xmlRoot.find(cls.ADDITIONAL_TEXT).text,
                   omText=xmlRoot.find(cls.OM_TEXT).text,
                   alarmCode=int(xmlRoot.find(cls.ALARM_CODE).text),
                   alarmSource=xmlRoot.find(cls.ALARM_SOURCE).text,
                   alarmTime=xmlRoot.find(cls.ALARM_TIME).text,
                   repeatCount=int(xmlRoot.find(cls.REPEAT_COUNT).text),
                   omDBKey=xmlRoot.find(cls.OM_DB_KEY).text,
                   autoClear=int(xmlRoot.find(cls.AUTO_CLEAR).text))

    @classmethod
    def writeAlarms2CSV(cls, lab, alarmList, fileName):
        """Write alarms to a csv file.

        @param lab  one Lab object that will saved to the csv file
        @param alarmList  Alarm object list to be writed to the csv file
        @param fileName   the csv file name
        """
        fileExist = os.path.isfile(fileName)
        with open(fileName, 'a') as fileHandler:
            csvWriter = csv.writer(fileHandler)
            # First writing so need to write csv header
            if not fileExist:
                row = ('LabName', cls.ALARM_INDEX, cls.OBJECT_NAME, cls.SPECIFIC_PROBLEM,
                       cls.PROBABLE_CAUSE, cls.NOTIFICATION_IDENTIFIER, cls.SEVERITY,
                       cls.ALARM_TYPE, cls.ADDITIONAL_TEXT, cls.OM_TEXT, cls.ALARM_CODE,
                       cls.ALARM_SOURCE, cls.ALARM_TIME, cls.REPEAT_COUNT, cls.OM_DB_KEY,
                       cls.AUTO_CLEAR)
                csvWriter.writerow(row)
            # Write the alarms for the following writing.
            for alm in alarmList:
                row = (lab.id, alm.alarmIndex, alm.objectName, alm.specificProblem,
                       alm.probableCause, alm.notificationIdentifier, alm.severity, alm.alarmType,
                       alm.additionalText, alm.omText, alm.alarmCode, alm.alarmSource,
                       alm.alarmTime, alm.repeatCount, alm.omDBKey, alm.autoClear)
                csvWriter.writerow(row)

    @classmethod
    def writeAlarmsOnAllLabs2CSV(cls, testBed, currentAlarmManager, fileName):
        """Write alarms on the whole testBed to a csv file.

        @param testBed    the whole test bed on which, get the alarms
        @param fileName   the csv file name
        """
        multiTasksManager = MultiTasksManager()
        labs = testBed.labs.values()
        LOGGER.debug("Get alarms on all Labs in progress")
        for lab in labs:
            threadName = multiTasksManager.register(currentAlarmManager.getActiveAlarmList, lab)
            LOGGER.debug("Get alarms on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        LOGGER.debug("Wait get alarms complete on all Labs")
        alarms = multiTasksManager.runMultiTasks(multiTasksManager.TASK_RETURN_VALUES)
        for lab, alarmList in zip(labs, alarms):
            if alarmList is None:
                LOGGER.warning("Can't get alarms on Lab %s", lab.id)
            else:
                cls.writeAlarms2CSV(lab, alarmList, fileName)

    def __str__(self):
        """get a readable string.
        """
        alarmStr = "%s: %s" %(self.__class__.ALARM_INDEX, self.alarmIndex)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.OBJECT_NAME, self.objectName)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.SPECIFIC_PROBLEM, self.specificProblem)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.PROBABLE_CAUSE, self.probableCause)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.NOTIFICATION_IDENTIFIER,
                                  self.notificationIdentifier)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.SEVERITY, self.severity)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.ALARM_TYPE, self.alarmType)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.ADDITIONAL_TEXT, self.additionalText)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.OM_TEXT, self.omText)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.ALARM_CODE, self.alarmCode)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.ALARM_SOURCE, self.alarmSource)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.ALARM_TIME, self.alarmTime)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.REPEAT_COUNT, self.repeatCount)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.OM_DB_KEY, self.omDBKey)
        alarmStr = "%s\n%s: %s" %(alarmStr, self.__class__.AUTO_CLEAR, self.autoClear)
        return alarmStr

    @staticmethod
    def display(alarmList):
        """Just display alarm code and severity in this alarm list.

        @param alarmList    to be printed alarm list
        """
        return "(alarm code, severity): " + str([(al.alarmCode, al.severity) for al in alarmList])
