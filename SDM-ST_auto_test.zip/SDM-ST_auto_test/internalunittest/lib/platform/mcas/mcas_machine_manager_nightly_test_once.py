"""
@file mcas_machine_manager_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-10
@brief unit test for mcas machine manager
"""

import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MCASMachineManagerError

LOGGER = Logger.getLogger(__name__)

class mcas_machine_manager_nightly_test_once(SDMTestCase):
    """Unit test for MCASMachineManager class.
    """
    def setUp(self):
        LOGGER.info("TestMCASMachineManager Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()

    def test_01_getMachineInfo(self):
        """test method getMachineInfo
        """
        LOGGER.info('[Test case 01] test method getMachineInfo')

        mach = self.sdmManager.mcasMachineManager.getMachineInfo(self.fe)
        LOGGER.debug('for FE: %s', str(mach))

        mach = self.sdmManager.mcasMachineManager.getMachineInfo(self.be)
        LOGGER.debug('for BE: %s', str(mach))

    def test_02_getVhostsInfo(self):
        """test method getVhostsInfo
        """
        LOGGER.info('[Test case 02] test method getVhostsInfo')

        mach = self.sdmManager.mcasMachineManager.getVhostsInfo(self.fe)
        LOGGER.debug('for FE: %s', str(mach))

        mach = self.sdmManager.mcasMachineManager.getVhostsInfo(self.be)
        LOGGER.debug('for BE: %s', str(mach))

    def test_03_checkMachineStatus(self):
        """test method checkMachineStatus
        """
        LOGGER.info('[Test case 03] test method checkMachineStatus')

        self.sdmManager.mcasMachineManager.checkMachineStatus(self.fe)
        self.sdmManager.mcasMachineManager.checkMachineStatus(self.be)

    def test_04_checkVhostsStatus(self):
        """test method checkVhostsStatus
        """
        LOGGER.info('[Test case 04] test method checkVhostsStatus')

        self.assertTrue(self.sdmManager.mcasMachineManager.checkVhostsStatus(self.fe))
        self.assertFalse(self.sdmManager.mcasMachineManager.checkVhostsStatus(self.be))

    def test_05_getMachinesList(self):
        """test method getMachinesList
        """
        LOGGER.info('[Test case 05] test method getMachinesList')

        mach = self.sdmManager.mcasMachineManager.getMachinesList(self.fe)
        LOGGER.debug('for FE:' + str(mach))
        mach = self.sdmManager.mcasMachineManager.getMachinesList(self.be)
        LOGGER.debug('for BE:' + str(mach))

    def test_06_getVhostsList(self):
        """test method getVhostsList
        """
        LOGGER.info('[Test case 06] test method getVhostsList')

        mach = self.sdmManager.mcasMachineManager.getVhostsList(self.fe)
        LOGGER.debug('for FE: %s', str(mach))

        mach = self.sdmManager.mcasMachineManager.getVhostsList(self.be)
        LOGGER.debug('for BE: %s', str(mach))

    def test_07_getActivePilot(self):
        """test method getActivePilot
        """
        LOGGER.info('[Test case 07] test method getActivePilot')
        LOGGER.debug("Active pilot: %s", self.sdmManager.mcasMachineManager.getActivePilot(self.fe))

    def test_08_getActiveVhost(self):
        """test method getActiveVhost
        """
        LOGGER.info('[Test case 08] test method getActiveVhost')
        lab = self.fe
        vhostList = self.sdmManager.mcasMachineManager.getVhostsList(lab)
        for vhost in vhostList:
            LOGGER.debug("Active vhost: %s",
                         self.sdmManager.mcasMachineManager.getActiveVhost(lab, vhost))


    def test_10_getVhostsStatus(self):
        """test method getVhostsInfo
        """
        LOGGER.info('[Test case 10] test method test_10_getVhostsStatus')

        # request the status of one VHOST . Return a string
        mach = self.sdmManager.mcasMachineManager.getVhostsStatus(self.fe, machine=2)
        LOGGER.debug('1- >>> 2 >>> for FE: %s', str(mach))

        # request the status of all VHOST of a lab . Return a dict { blade_as_string : status_as_string }
        mach = self.sdmManager.mcasMachineManager.getVhostsStatus(self.fe)
        LOGGER.debug('2- >>> ALL >>> for FE: %s', str(mach))

        # request the status of a VHOST with wrong blade . must raises exception
        try:
            mach = self.sdmManager.mcasMachineManager.getVhostsStatus(self.fe, machine='0-0-33')
            LOGGER.error('3- >>> NO EXPECTED ERROR >>> for FE: %s', str(mach))
        except MCASMachineManagerError:
            LOGGER.debug('3- >>> GOT EXPECTED Exception MCASMachineManagerError >>> for FE')

        # request the status of a VHOST with BE (instead of FE) . must raises exception
        try:
            mach = self.sdmManager.mcasMachineManager.getVhostsStatus(self.be, machine=2)
            LOGGER.error('4- >>> NO EXPECTED ERROR >>> for BE: %s', str(mach))
        except MCASMachineManagerError:
            LOGGER.debug('4- >>> GOT EXPECTED Exception MCASMachineManagerError >>> for BE')


if __name__ == "__main__":
    unittest.main()

