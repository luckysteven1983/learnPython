"""
Created on Oct 22, 2015

@author: Zheng Yuan

#weblink_id=3KJ-00117-0820-QPZZA
"""
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.common import Utils
from lib.alarm.alarms_config import AlarmsConfig
import lib.exceptions_messages as msgs
import random

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class es4793_check_CPU_usage(SDMTestCase):
    """
    Case Description:
       Use health check tool to check CPU usage per board
    Manual Test Steps:
       1. Run the health check command and check the log file
       2. The output should be:
          Completed cpu_usage check with status ok
          health completed
       3.check the log, there should be logs generated correctly.
    """

    def setUp(self):
        """Init the managers this case need"""
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.myHCM = self.sdmManager.healthCheckManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mySshManager = self.sdmManager.sshManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.fe = random.choice(self.allFEs)
        self.be = random.choice(self.allBEs)
        self.lab = random.choice([self.fe, self.be])
        self.exceptMsg = str()
        self.expectedAlarms = []
        self.acceptedAlarms = []
        LOGGER.debug("Test case es4793_check_CPU_usage started")


    def _precheck(self):
        """Test case pre-check and return current active alarm list """
        checkQoS = False

        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0], checkQoS)


    def test_check_CPU_usage(self):
        """Use health check tool to check CPU usage"""
        healthCommand = "cpu_usage"
        expectCheckOutput = ["Completed cpu_usage check with status ok", "health completed"]
        labEnvNokKeyWord = "nok"
        toolDir = "/cust_use/healthTools"
        checkLogDir = toolDir + "/log/healthcheck"
        checkLogCommand = "ls " + checkLogDir + ";ls " + checkLogDir + "/per_module"
        checkLogs = ["all.log", "progress.log", "summary.log", "per_module", "cpu_usage.log"]
        logContents = ["cpu_usage summary", "health completed", "Start cpu_usage check",
                      "Completed cpu_usage check with status ok"]  # What contents the log should contain
        logFiles = [checkLogDir + "/all.log", checkLogDir + "/progress.log",
                       checkLogDir + "/summary.log", checkLogDir + "/per_module/cpu_usage.log"]
        checkQoS = False

        # Lab Health check
        self._precheck()

        # get the start time of the TC
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.lab)

        # Run health check tool CPU check command
        LOGGER.debug("Run health check tool CPU check command ")
        checkOutput = self.myHCM.runToolCmd(self.lab, healthCommand)

        # Check the output of the result of the CPU check command
        LOGGER.debug("Check the output of the result of the CPU check command")
        if labEnvNokKeyWord in checkOutput:
            LOGGER.error(msgs.HEALTH_CHECK_TOOL_LAB_ENV_NOK)
            raise Exception(msgs.HEALTH_CHECK_TOOL_LAB_ENV_NOK)

        for output in expectCheckOutput:
            if output not in checkOutput:
                LOGGER.error(msgs.HEALTH_CHECK_TOOL_OUTPUT_NOK)
                raise Exception(msgs.HEALTH_CHECK_TOOL_OUTPUT_NOK)

        # Check whether the logs have generated
        LOGGER.debug("Check whether log files have generated")
        checkLogOutput = self.mySshManager.run(self.lab.oamIpAddress, checkLogCommand)
        for logName in checkLogs:
            if logName not in checkLogOutput[1]:
                LOGGER.error(msgs.HEALTH_CHECK_TOOL_LOGS_GEN_NOK)
                raise Exception(msgs.HEALTH_CHECK_TOOL_LOGS_GEN_NOK)

        # Check logs contains the specified content
        LOGGER.debug("Check logs contains the specified content")
        try:
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[0], logContents[0], logContents[1])
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[1], logContents[3], logContents[1])
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[2], logContents[0])
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[3], logContents[0], logContents[3])
        except BaseException:
            LOGGER.error(msgs.HEALTH_CHECK_TOOL_LOGS_CONTENT_NOK)
            raise Exception(msgs.HEALTH_CHECK_TOOL_LOGS_CONTENT_NOK)

        # Check the alarms at the end
        LOGGER.debug("check the alarms")
        # check the alarms on ONE node, make sure that all expect alarm are raised, and no abnormal alarms, eg:
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared (done in assertEndState)
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(self.lab, myAlarmsConfig, logFile=LOGFILE[1])
            # LOGFILE[1] is a csv file used to save alarms raised since test case is running
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.exception("%s: alarm check fail", self.lab.id)

        # Check the end status of the test env
        LOGGER.debug("Check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkQoS)
        LOGGER.debug("es4793_check_CPU_usage success!\n")
