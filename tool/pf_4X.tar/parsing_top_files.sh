#!/bin/bash
########################################################
## Version 0.2
## This is to cut top_$STATION_xx.log files which
## will only contain GD reload start to stop timeframe
##
## Author: Da Li (Da.D.Li@alcatel-lucent.com)
## Nov. 5th, 2015
########################################################
help(){
    echo -e "./test.sh DoneDataPath all|pilot|nonpilot [startTime] [stopTime]"
    echo -e "Example: ./test.sh /PLATsoftware/pt_result/fm1936_1102_atca55/Done all 17:52:4[67] 17:54:1[67]"
}

if [ ! -x "$1" ];then
    echo "Done data path: $1 does not exist!"
    exit 1
else
    cd $1
fi

case $2 in
    pilot)
        fileToBeParsed=`ls | grep ^top_[A-L] | grep -v [C-L]`
        if [ -z "$fileToBeParsed" ];then
            echo "There is no PILOT top files for parsing!"
            exit 1
        fi
    ;;
    nonpilot)
        fileToBeParsed=`ls | grep ^top_[A-L] | grep -v [A-B]`
        if [ -z "$fileToBeParsed" ];then
            echo "There is no NONPILOT top file for parsing!"
            exit 1
        fi
    ;;
    all)
        fileToBeParsed=`ls | grep ^top_[A-L]`
        if [ -z "$fileToBeParsed" ];then
            echo "There is not any top file for parsing!"
            exit 1
        fi
        ;;
    *)
        echo "Parameter input wrong!"
        help
        exit 1
    ;;
esac

debugFileName=`/bin/ls | grep debug_A`
if [ -z "$debugFileName" ];then
    echo "There is no debug_A file for parsing!"
    exit 1
fi

if [ $# == 4 ];then
    startTime=$3
    stopTime=$4
else
    ## 17:01:02
    gdReloadStartTime=`grep -b2 'GlobalDataManager: start load all GD tables'  $debugFileName | grep +++ | head -1 | cut -d ' ' -f 7`
    gdReloadStopTime=`grep -b2 'GlobalDataManager: finish load all GD tables'  $debugFileName | grep +++ | tail -1 | cut -d ' ' -f 7`
    
    startHour=`echo $gdReloadStartTime | cut -d ':' -f 1`
    startMin=`echo $gdReloadStartTime | cut -d ':' -f 2`
    startSecond=`echo $gdReloadStartTime | cut -d ':' -f 3`
    
    stopHour=`echo $gdReloadStopTime | cut -d ':' -f 1`
    stopMin=`echo $gdReloadStopTime | cut -d ':' -f 2`
    stopSecond=`echo $gdReloadStopTime | cut -d ':' -f 3`
    
    startSecondFirstPart=`echo $gdReloadStartTime | cut -b 1-7`
    startSecondSecondPart=`echo $gdReloadStartTime | cut -b 8`
    startMinFirstPart=`echo $gdReloadStartTime | cut -b 4`
    startMinSecondPart=`echo $gdReloadStartTime | cut -b 5`
    startHourFirstPart=`echo $gdReloadStartTime | cut -b 1`
    startHourSecondPart=`echo $gdReloadStartTime | cut -b 2`    
    if [ $startSecondSecondPart -lt 9 ]; then
        startTime="$startSecondFirstPart[$startSecondSecondPart`expr $startSecondSecondPart + 1`]"
    elif [ $startSecond -lt 59 ]; then
        startTime="$startHour:$startMin:[($startSecond)(`expr $startSecond + 1`)]"
    elif [ $startMinFirstPart -eq 0 ] && [ $startMinSecondPart -lt 9 ]; then
        startTime="$startHour:[(0$startMinSecondPart:59)(0`expr $startMinSecondPart + 1`:00)]"
    elif [ $startMin -lt 59 ]; then
        startTime="$startHour:[($startMin:59)(`expr $startMin + 1`:00)]"
    elif [ $startHourFirstPart -eq 0 ] && [ $startHourSecondPart -lt 9 ]; then
        startTime="[(0$startHourSecondPart:59:59)(0`expr $startHourSecondPart + 1`:00:00)]"
    elif [ $startHour -lt 23 ]; then
        startTime="[($startHour:59:59)(`expr $startHour + 1`:00:00)]"
    else
        startTime="[(23:59:59)(00:00:00)]"
    fi
            
    stopSecondFirstPart=`echo $gdReloadStopTime | cut -b 1-7`
    stopSecondSecondPart=`echo $gdReloadStopTime | cut -b 8`
    stopMinFirstPart=`echo $gdReloadStopTime | cut -b 4`
    stopMinSecondPart=`echo $gdReloadStopTime | cut -b 5`
    stopHourFirstPart=`echo $gdReloadStopTime | cut -b 1`
    stopHourSecondPart=`echo $gdReloadStopTime | cut -b 2`        
    if [ $stopSecondSecondPart -lt 9 ]; then
        stopTime="$stopSecondFirstPart[$stopSecondSecondPart`expr $stopSecondSecondPart + 1`]"
    elif [ $stopSecond -lt 59 ]; then
        stopTime="$stopHour:$stopMin:[($stopSecond)(`expr $stopSecond + 1`)]"
    elif [ $stopMinFirstPart -eq 0 ] && [ $stopMinSecondPart -lt 9 ]; then
        stopTime="$stopHour:[(0$stopMinSecondPart:59)(0`expr $stopMinSecondPart + 1`:00)]"
    elif [ $stopMin -lt 59 ]; then
        stopTime="$stopHour:[($stopMin:59)(`expr $stopMin + 1`:00)]"
    elif [ $stopHourFirstPart -eq 0 ] && [ $stopHourSecondPart -lt 9 ]; then
        stopTime="[(0$stopHourSecondPart:59:59)(0`expr $stopHourSecondPart + 1`:00:00)]"
    elif [ $stopHour -lt 23 ]; then
        stopTime="[($stopHour:59:59)(`expr $stopHour + 1`:00:00)]"
    else
        stopTime="[(23:59:59)(00:00:00)]"
    fi
fi

echo "GD Reload start time: "$startTime
echo "GD Reload stop time: "$stopTime

for x in $fileToBeParsed
do
    echo "Parsing file: "$x" to file: parsed_$x"
    sed -n "/top - $startTime/,/top - $stopTime/p" $x > parsed_$x
    if [ ! -s "$parsed_$x" ];then
        echo "WARNING: Parsed file: $parsed_$x is empty!"
    fi
fi
done