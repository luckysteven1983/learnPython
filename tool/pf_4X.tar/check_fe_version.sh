echo "------/sn/sps/SDM*/bin/showversion----------" > fe_version_info.result
/sn/sps/SDM*/bin/showversion >> fe_version_info.result
echo "--------------fw lsta ----------------------" >> fe_version_info.result
/usr/dhafw/tools/fw lsta >> fe_version_info.result
echo "--------------fw llsta ----------------------" >> fe_version_info.result
/usr/dhafw/tools/fw llsta >> fe_version_info.result
echo "--------------mppread ----------------------" >> fe_version_info.result
/usr/dhafw/bin/mppread >> fe_version_info.result


