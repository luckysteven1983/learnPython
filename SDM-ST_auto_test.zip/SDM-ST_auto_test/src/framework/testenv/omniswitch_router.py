"""
Created on Sept 30, 2015
@author: Claude Le Du
"""

from framework.testenv.router import Router
import lib.exceptions_messages as eMsgs
from lib.logging.logger import Logger


logger = Logger.getLogger(__name__)

ROUTER_TYPE_6850 = "6850"
ROUTER_TYPE_6900 = "6900"

GDMP_FLOW = "GDMP"

class OmniswitchRouter(Router):
    """
    @details This class implements Router interface for Omniswitch routers (6850, 6900)
    """
    OMNISWITCH_TYPES = [ROUTER_TYPE_6850, ROUTER_TYPE_6900]

    def __init__(self, sshManager, routerId, routerIp, routerType, account, prompt):
        super(OmniswitchRouter, self).__init__(routerId, routerIp, routerType, account, prompt)
        self.sshManager = sshManager
        self.channel = None


    def _sendCmd(self, cmd):
        """ Run <cmd> command on router
        @parameter cmd command to execute
        @return stdout, stderr standard and error outputs from the command """

        # fist attempt with an empty command because sometimes the first character is lost
        self.sshManager.sendStringRoutine(self.channel, "", self.prompt)
        (stdout, stderr) = self.sshManager.sendStringRoutine(self.channel, cmd, self.prompt)
        return stdout, stderr


    def clearARPTables(self):
        """ Run "clear arp-cache" command on router
        "clear arp-cache" returns nothing.
        @return stdout, stderr standard and error outputs from the command """

        cmd = "clear arp-cache"
        return self._sendCmd(cmd)


    def showVlan(self, port=False):
        """ Run "show vlan [port] or [members]" command on router
        @verbatim
        "show vlan" returns:

        on 6850 type
                                             stree                       mble   src
        vlan  type  admin   oper   1x1   flat   auth   ip   ipx   tag   lrn   name
        -----+------+------+------+------+------+----+-----+-----+-----+-----+----------
          1    std   on    off     on    on     off    on   NA   off     on   vlan1
         11    std   on     on    off   off     off    on   NA   off     on   NODE1_LANIO1
         12    std   on     on    off   off     off    on   NA   off     on   NODE1_LANIO2a
        ...
        100    std   on     on     on    on     off   off   NA   off     on   EdgeRouter1
        117    std   on     on     on    on     off    on   NA   off     on   vlan_SIG
        118    std   on     on     on    on     off    on   NA   off     on   vlan_OAM
        119    std   on     on     on    on     off    on   NA   off     on   vlan_GDMP
        120    std   on     on     on    on     off    on   NA   off     on   vlan_HSS

        on 6900 type

        vlan  type  admin  oper  ip   mtu   name
        -----+------+-----+-----+-----+-----+------------
           1   std    Dis   Dis   Dis  1500   VLAN 1
           2   std    Ena   Ena   Ena  1500   Network OAM
          19   std    Ena   Ena   Ena  1500   Network GDMP1
          20   std    Ena   Ena   Ena  1500   Network REP1
          22   std    Ena   Ena   Ena  1500   Network OAM2
          50   std    Ena   Ena   Ena  1500   HP3 OAM
          51   std    Ena   Ena   Ena  1500   HP3 GDMP
          52   std    Ena   Ena   Ena  1500   HP3 REP

        "show vlan port" (6850) or "show vlan members" (6900)
        vlan   port     type      status
        ------+-------+---------+-------------
        1    1/9    default     inactive
        1    1/10   default     inactive
        1    1/11   default     inactive
        ...
        @endverbatim
        @parameter port port option
        @return stdoutDict standard output from the command in a dictionary
        @return stderr error output from the command """

        cmd = "show vlan"
        if port:
            cmd = "show vlan port" if self.type == ROUTER_TYPE_6850 else "show vlan members"
        stdout, stderr = self._sendCmd(cmd)
        stdoutList = [l.split() for l in stdout.split("\n")]
        return stdoutList, stderr


    def interfaceUp(self, interface):
        """ Set given interface up on router
        "interfaces <interface> admin up/enable" returns nothing.
        @parameter interface name of interface to set up
        @return stdout, stderr standard and error outputs from the command """

        if self.type == ROUTER_TYPE_6850:
            cmd = "interfaces " + str(interface) + " admin up"
        elif self.type == ROUTER_TYPE_6900:
            cmd = "interfaces " + str(interface) + " admin enable"
        else:
            logger.error(eMsgs.ROUTER_UNKNOWN_TYPE)
            raise Exception(eMsgs.ROUTER_UNKNOWN_TYPE)
        return self._sendCmd(cmd)


    def interfaceDown(self, interface):
        """ Set given interface down on router
        "interfaces <interface> admin down/disable" returns nothing.
        @parameter interface name of interface to set down
        @return stdout, stderr standard and error outputs from the command """

        if self.type == ROUTER_TYPE_6850:
            cmd = "interfaces " + str(interface) + " admin down"
        elif self.type == ROUTER_TYPE_6900:
            cmd = "interfaces " + str(interface) + " admin disable"
        else:
            logger.error(eMsgs.ROUTER_UNKNOWN_TYPE)
            raise Exception(eMsgs.ROUTER_UNKNOWN_TYPE)
        return self._sendCmd(cmd)


    def enableVlan(self, vlan):
        """ Enable given vlan on router
        "vlan <vlan> [admin-state] enable" returns nothing.
        @parameter vlan name of vlan to enable
        @return stdout, stderr standard and error outputs from the command """

        if self.type == ROUTER_TYPE_6850:
            cmd = "vlan " + str(vlan) + " enable"
        elif self.type == ROUTER_TYPE_6900:
            cmd = "vlan " + str(vlan) + " admin-state enable"
        else:
            logger.error(eMsgs.ROUTER_UNKNOWN_TYPE)
            raise Exception(eMsgs.ROUTER_UNKNOWN_TYPE)
        return self._sendCmd(cmd)


    def disableVlan(self, vlan):
        """ Disable given vlan on router
        "vlan <vlan> [admin-state] disable" returns nothing.
        @parameter vlan name of vlan to disable
        @return stdout, stderr standard and error outputs from the command """

        if self.type == ROUTER_TYPE_6850:
            cmd = "vlan " + str(vlan) + " disable"
        elif self.type == ROUTER_TYPE_6900:
            cmd = "vlan " + str(vlan) + " admin-state disable"
        else:
            logger.error(eMsgs.ROUTER_UNKNOWN_TYPE)
            raise Exception(eMsgs.ROUTER_UNKNOWN_TYPE)
        return self._sendCmd(cmd)


    def showInterfaces(self):
        """ Run "show interfaces port/alias" command on router

        "show interfaces port" (6850) returns:

        Slot/    Admin     Link    Violations                 Alias
        Port     Status   Status
        -----+----------+---------+----------+-----------------------------------------
         1/1    enable      up        none    ""
         1/2    enable      up        none    ""
         1/3    enable      up        none    ""
         1/4    enable      up        none    ""

        "show interfaces alias" (6900) returns:

        Slot/    Admin     Link      WTR         WTS     Alias
        Port     Status   Status    (sec)        (msec)
        ------+----------+---------+----------+-----------+--------------------
         1/1    enable      up          0               0           "HP3 OAM"
         1/2    enable      up          0               0           "Network OAM"
         1/3    enable      up          0               0           "HP3 GDMP"
         1/4    enable      up          0               0           "HP3 REP"

        @return stdoutDict standard output from the command in a dictionary
        @return stderr error output from the command """

        if self.type == ROUTER_TYPE_6850:
            cmd = "show interfaces port"
        elif self.type == ROUTER_TYPE_6900:
            cmd = "show interfaces alias"
        else:
            logger.error(eMsgs.ROUTER_UNKNOWN_TYPE)
            raise Exception(eMsgs.ROUTER_UNKNOWN_TYPE)
        stdout, stderr = self._sendCmd(cmd)
        stdoutList = [l.split() for l in stdout.split("\n")]
        return stdoutList, stderr
