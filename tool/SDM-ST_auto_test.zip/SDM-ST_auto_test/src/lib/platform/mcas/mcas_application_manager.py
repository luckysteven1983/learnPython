'''
Created on Apr 29, 2015

@author: xzhao015
'''
from collections import Counter
import os
import re
import time

from framework.asserts.common_asserts import CommonAssert
from framework.testenv.backend import Backend
from framework.testenv.frontend import Frontend
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
import pprint

SPA_TIMEOUT = 1200
SPA_TIMEOUT_SMALL = 300
SPA_STATE_ASSERT_TIME = 60

#Time out to avoid automatic defense mechanism when restart oam process
#15W45 - Tested with 10min but automatic swo detected so will go with 15min
MCAS_OAM_RESTART_PROCESS_TIMEOUT = 15*60

LOGGER = Logger.getLogger(__name__)

class McasApplicationManagerError(BaseException):
    """If error, raise it."""
    pass

class McasApplicationManager(object):
    '''
    McasApplicationManager is used to make operation on SPA.
    3 timers are defined
    SPA_TIMEOUT = 1200
    SPA_TIMEOUT_SMALL = 300
    SPA_STATE_ASSERT_TIME = 60
    The timeout for operation like remove restart is set to 20 minutes
    The 5 minutes timeout can be used in test cases if
        -OAM SPA is restarted without OAMBE
        -SDM SPA is restarted only on one blade
     The timeout to assert is set to 1min, so we don't send too many request to the lab
     These values come from FFRD-193652-932
    '''

    def __init__(self, sshManager, subshlManager, linuxProcessManager):
        '''
        Constructor
        '''
        self._sshManager = sshManager
        self._subshl = subshlManager
        self._CA = CommonAssert
        self._linuxProcessManager = linuxProcessManager

    def getSPAVersion(self, lab, spaName):
        '''
        according to the part of the spa name get the full name.
        @param lab: lab type
        @param spaName: string, part name or fullname will be OK. eg:SDM, SDM422
        @return: string, spa full name
        @author: Xia zhao

        @verbatim
        getSPAName(lab, 'SDM')
        return: SDM422
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to get the version of spa " + spaName)
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.GET_SPA_VERSION_FAILED
        spaName = str(spaName.upper())
        if isinstance(lab.productRole, Backend) and re.match(spaName, 'OAM'):
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        cmd = '/sn/sps/' + spaName + '*/bin/showversion'
        try:
            result = self._sshManager.run(lab.oamIpAddress, cmd)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        if not result[0]:
            version = result[1].split(os.linesep)[-1]
        else:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        LOGGER.debug(lab.id + ": version is: " + version)
        return version

    def getSPAStatus(self, lab, spaName):
        '''
        get spa status.
        @param lab: lab type
        @param spaName: string, part name or fullname will be OK. eg:SDM, SDM422
        @return: directory
        @author: Xia Zhao

        @verbatim
        getStatusSPA(hp27, 'SDM')
        for SDM:
        return: {'SPA STATE': 'IS',
        'SSN': {'313': 'IS', '311': 'IS', '6': 'IS', '9': 'IS', '250': 'IS', '257': 'IS'},
        '0-0-2': 'IS', '0-0-6': 'IS', '0-0-5': 'IS',
        '0-0-8': 'IS', '0-0-4': 'IS', '0-0-15': 'IS', '0-0-14': 'IS',
        '0-0-7': 'IS', '0-0-16': 'IS', '0-0-10': 'IS', '0-0-13': 'IS',
        '0-0-12': 'IS'}
        for OAM:
        return:{'0-0-1': 'IS', 'SSN': {'256': 'IS'}, 'SPA STATE': 'IS', '0-0-9': 'OOS'}
        for OAMBE:
        return:
        {'0-0-1': 'IS', 'SSN': {'256': 'IS'}, 'SPA STATE': 'IS', '0-0-9': 'OOS'}
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to get spa status: " + str(spaName))
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.GET_SPA_STATUS_FAILED
        statusSPA = dict()

        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error(exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        cmd = "op:status,spa=" + str(spaName.upper())
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        if re.search('NOT FOUND', response):
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        spaInfo = [line.strip() for line in response.split(os.linesep)]
        LOGGER.debug(lab.id + ": get spa information output: " + pprint.pformat(spaInfo))
        pattern = re.compile('0-0-')
        for line in spaInfo:
            if re.match('SPA STATE', line):
                statusSPA['SPA STATE'] = line.split(':')[-1].strip()
            if re.match('SSN', line):
                ssnDict = dict()
                ssnStatus = line.split(':')[-1].strip().replace('[', '').replace(']', '')
                for ssn in ssnStatus.strip(';').split(';'):
                    ssnNumber = ssn.split()[0]
                    ssnState = ssn.split()[1]
                    ssnDict[ssnNumber] = ssnState
                statusSPA['SSN'] = ssnDict
            if pattern.match(line):
                station = line.split()[0].strip()
                statusProcess = line.split()[-1].strip()
                statusSPA[station] = statusProcess
        if not statusSPA:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        LOGGER.debug(lab.id + ": spa status is: " + pprint.pformat(statusSPA))
        return statusSPA

    def getAllSPAStatus(self, lab):
        '''
        get all spa status.
        @param lab: lab type
        @return: directory, key is the spa name
        @author: Xia Zhao

        @verbatim
        getStatusSPAall(hp27)

        return:
        for BE:
        {'OAMBE': [{'SPA NAME': 'OAMBE422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '256'}]}

        for FE:
        {'SDM': [{'SPA NAME': 'SDM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '250'},
        {'SPA NAME': 'SDM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '257'},
        {'SPA NAME': 'SDM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '311'},
        {'SPA NAME': 'SDM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '313'},
        {'SPA NAME': 'SDM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '6'},
        {'SPA NAME': 'SDM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '9'}],
        'OAM': [{'SPA NAME': 'OAM422', 'SPA STATE': 'IS', 'SSN STATE': 'IS', 'SSN': '256'}]}
        @endverbatim
        '''

        LOGGER.debug(lab.id + ": try to get all spa status")
        exceptionMessage = lab.id + ": " + msgs.GET_SPA_STATUS_FAILED
        result = False
        statusSPA = dict()
        statusSDMSPA = dict()
        statusOAMSPA = dict()
        statusOAMBESPA = dict()
        if isinstance(lab.productRole, Frontend):
            statusSPA = {'OAM':statusOAMSPA, 'SDM':statusSDMSPA}
        elif isinstance(lab.productRole, Backend):
            statusSPA = {'OAMBE':statusOAMBESPA}
        else:
            LOGGER.error(lab.id + ": " + msgs.DO_NOT_SUPPORT_LAB_TYPE)
            raise McasApplicationManagerError, "%s : %s" % (lab.id, msgs.DO_NOT_SUPPORT_LAB_TYPE)

        cmd = "op:status,spa=all"
        LOGGER.debug("cmd is " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        spaInfo = [line.strip() for line in response.split(os.linesep)]
        LOGGER.debug(lab.id + ": spa information output: " + str(spaInfo))
        pattern = re.compile('OAM[0-9]*|SDM*|OAMBE*|PMGW*|PROXY*')
        for line in spaInfo:
            if pattern.match(line):
                result = True
                spaName = line.split()[0].strip()
                spaState = line.split()[1].strip()
                ssn = line.split()[2].strip()
                ssnState = line.split()[3].strip()
                spaStateEach = {'SPA NAME': spaName, 'SPA STATE': spaState, \
                                'SSN': ssn, 'SSN STATE': ssnState}
                if re.search('OAM[0-9]', spaName):
                    statusOAMSPA[ssn] = spaStateEach
                if re.search('SDM', spaName):
                    statusSDMSPA[ssn] = spaStateEach
                if re.search('OAMBE', spaName):
                    statusOAMBESPA[ssn] = spaStateEach
        if not result:
            LOGGER.error("%s: get spa state failed: spa not found", lab.id)
            raise McasApplicationManagerError, "%s: get spa state failed: spa not found" % (lab.id)
        LOGGER.debug(lab.id + ": spa status is: " + str(statusSPA))
        return statusSPA

    def assertNoSPA(self, lab, spaName):
        '''
        assert no SPA whose name is spaName installed on lab
        @param lab: Lab type
        @param spaName: String
        '''
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.ASSERT_NO_SPA_FAIL
        LOGGER.debug(lab.id + ": Try to assert there is no spa whose name is " + spaName)
        try:
            self.getSPAVersion(lab, spaName)
        except BaseException:
            LOGGER.debug(lab.id + ": There is no spa whose name is " + spaName)
        else:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def assertSPAState(self, lab, spaName, spaState, logLevel='error'):
        '''
        assert spa status is the given
        @param lab: Lab type
        @param spaName: string
        @param spaState: String, ['IS', 'EQP', MOOS', 'OOS']
        @param logLevel if "error" display as error logger message, else debug level
        '''
        LOGGER.debug(lab.id + ": Try to assert " + spaName + " is in state of " + spaState)
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.ASSERT_SPA_STATE_FAIL
        try:
            state = self.getSPAStatus(lab, spaName)
        except:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMessage)
            else:
                LOGGER.debug(exceptionMessage)
            raise AssertionError(exceptionMessage)
        if state['SPA STATE'] == spaState:
            LOGGER.debug(lab.id + ": The global state of " + spaName + " is " + spaState)
        else:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMessage)
            else:
                LOGGER.debug(exceptionMessage)
            raise AssertionError(exceptionMessage)

    def assertLocalProcessState(self, lab, spaName, procState, logLevel='error'):
        '''
        assert the status of spaName on stations status is the given
        if SDM, stations is RT blades
        if OAM or OAMBE, stations is pilots
        @param lab: Lab type
        @param spaName: string
        @param procState: String, ['IS', MOOS', 'OOS']
        @param logLevel if "error" display as error logger message, else debug level
        '''
        LOGGER.debug(lab.id + ": Try to assert " + spaName + " is in state of " + procState)
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.ASSERT_LOCAL_PROCESS_STATE_FAIL
        if re.search('SDM', spaName.upper()):
            rtStations = lab.getStationListbyProductRole('RT').values()
            try:
                self.assertSPAStateOnStations(lab, spaName, procState, rtStations, 'debug')
            except BaseException:
                if logLevel.lower() == 'error':
                    LOGGER.error(exceptionMessage)
                else:
                    LOGGER.debug(exceptionMessage)
                raise AssertionError(exceptionMessage)
        else:
            try:
                pilots = lab.getBladeListbymiddlewareRole('pilot').values()
                if procState.upper() == 'IS':
                    spaState = self.getSPAStatus(lab, spaName)
                    procStateList = [spaState[pilot.rcsHostname] for pilot in pilots]
                    self._CA.assertListAlmostEqual(procStateList, ['OOS', 'IS'], logLevel='debug')
                else:
                    self.assertSPAStateOnStations(lab, spaName, procState, pilots, 'debug')
            except BaseException:
                if logLevel.lower() == 'error':
                    LOGGER.error(exceptionMessage)
                else:
                    LOGGER.debug(exceptionMessage)
                raise AssertionError(exceptionMessage)

    def assertSPAStateOnStations(self, lab, spaName, spaState, stationsToCheck, logLevel='error'):
        '''
        @function: assert spa status is the given for all stations given in arg
        @param lab: Lab type
        @param spaName: string
        @param spaState: String, ['IS', 'EQP', MOOS', 'OOS']
        @param stationsToCheck : list of stations to check
        @usage :
           sdmManager.mcasApplicationManager.assertSPAStateOnBlades(
                                 fe, "SDM", "IS", fe.getStationListbyProductRole('RT'))
           sdmManager.mcasApplicationManager.assertSPAStateOnBlades(
                                 be, "OAMBE", "IS", be.getStationListbyProductRole('RT'))
        '''
        # build list of blades
        lBlades = [station.rcsHostname for station in stationsToCheck]

        LOGGER.debug(lab.id + ": Try to assert " + spaName + " is in state of " + spaState)
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.ASSERT_SPA_STATE_FAIL
        try:
            state = self.getSPAStatus(lab, spaName)  # get the status of all blades of the lab
        except:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMessage)
            else:
                LOGGER.debug(exceptionMessage)
            raise AssertionError(exceptionMessage)

        # clean the dictionary by removing unused key for the current method
        del state['SPA STATE']
        del state['SSN']

        # --- substract the 2 list to see if all blades exists in lab. Result list must be empty.
        diffList = list(set(lBlades) - set(state.keys()))
        if diffList != []:
            raise McasApplicationManagerError + ' Dont find station on lab ' + lab.id

        # --- keep only blades from lab that are in lBlades
        statFiltered = {blad:status for blad, status in state.iteritems() if blad in lBlades}

        statusCounter = Counter(statFiltered.values())[spaState]
        if statusCounter == len(lBlades):
            LOGGER.debug(lab.id + ": All " + spaName + " are " + spaState)
        else:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMessage)
            else:
                LOGGER.debug(exceptionMessage)
            raise AssertionError(exceptionMessage)


    def removeSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME, simplexSuSoak=False):
        '''
        remove spa, "rmv:spa=spaName"
        @param lab: lab type
        @param spaName: string
        @param simplexSuSoak: if True, this function is used for SU cases and will not call assertLocalProcessState
        @author: Xia Zhao

        @verbatim
        removeSPA(lab,'sdm')
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to remove spa : " + str(spaName))
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.RMV_SPA_FAIL
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error("%s: get spa version fail", exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        try:
            self.assertSPAState(lab, spaName, 'IS', 'debug')
        except:
            LOGGER.error("%s: spa's pre-state is not IS", exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        cmd = "rmv:spa=" + spaName + ";Y;"
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": remove spa output : " + str(response))
            LOGGER.debug(lab.id + ": waiting spa to be MOOS ......")
            self._CA.timedAssert(timeout, interval, self.assertSPAState, lab, spaName, 'MOOS', 'debug')
            if not simplexSuSoak:
                self._CA.timedAssert(timeout, interval, self.assertLocalProcessState, lab, spaName, 'MOOS', 'debug')
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def restoreSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME, simplexSuSoak=False):
        '''
        restore spa, "rst:spa=spaName"
        @param lab: lab type
        @param spaName: string
        @param simplexSuSoak: if True, this function is used for SU cases and will not call assertLocalProcessState
        @author: Xia Zhao

        @verbatim
        restoreSPA(lab, 'SDM422')
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to restore spa : " + str(spaName))
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.RST_SPA_FAIL
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error("%s: get spa version fail", exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        try:
            self.assertSPAState(lab, spaName, 'MOOS', 'debug')
        except:
            LOGGER.error("%s: spa's pre-state is not MOOS", exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        cmd = "rst:spa=" + spaName
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": restore spa output : " + str(response))
            LOGGER.debug(lab.id + ": waiting spa to be IS ......")
            self._CA.timedAssert(timeout, interval, self.assertSPAState, lab, spaName, 'IS', 'debug')
            if not simplexSuSoak:
                self._CA.timedAssert(timeout, interval, self.assertLocalProcessState, lab, spaName, 'IS', 'debug')
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def deleteSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME):
        '''
        delete proc spa, "delete:proc,spa=spaName"
        @param lab: lab type
        @param spaName: string
        @author: Xia Zhao

        @verbatim
        deleteSPA(lab, 'SDM422')
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to delete process of spa : " + str(spaName))
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.DEL_PROC_SPA_FAIL
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error("%s: get spa version fail", exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        try:
            self.assertSPAState(lab, spaName, 'MOOS', 'debug')
        except:
            LOGGER.error("%s: spa's pre-state is not MOOS", exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        cmd = "delete:proc,spa=" + spaName + ";Y;"
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": delete process of spa output: " + response)
            LOGGER.debug(lab.id + ": waiting spa to be EQP ......")
            self._CA.timedAssert(timeout, interval, self.assertSPAState, lab, spaName, 'EQP', 'debug')
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def abortSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME):
        '''
        @function: abort spa, "abt:spa=spaName"
        @param lab: lab type
        @spaName: string
        @author: Qinqin FAN
        @Usage:
        abortSPA(lab, 'SDM422')
        '''
        LOGGER.debug(lab.id + ": try to abort process of spa : " + str(spaName))
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.ABT_SPA_FAIL
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error("%s: get spa version fail", exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        cmd = "abt:spa=" + spaName + ";Y;"
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": abort of spa output: " + response)
            LOGGER.debug(lab.id + ": waiting spa to be EQP ......")
            self._CA.timedAssert(timeout, interval, self.assertSPAState, lab, spaName, 'EQP', 'debug')
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def installSPA(self, lab, spaName, sleepTime=60, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME, simplexSuSoak=False):
        '''
        install process spa, "install:proc,spa=spaName"
        @param lab: lab type
        @param spaName: string
        @param timeout: int, sleep timeout seconds before install OAM process, default value is 60s.
        @param simplexSuSoak: if True, this function is used for SU cases and will not call assertLocalProcessState
        '''
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.INSTALL_PROC_SPA_FAIL
        LOGGER.debug(lab.id + ": try to install process of spa : " + str(spaName))
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error("%s: get spa version fail", exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        try:
            self.assertSPAState(lab, spaName, 'EQP', 'debug')
        except:
            LOGGER.error("%s: spa's pre-state is not EQP", exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        if sleepTime and re.match('OAM[0-9]{3}', spaName):
            LOGGER.debug(lab.id + ": before install process of OAM spa sleep 1 minute")
            time.sleep(sleepTime)
        cmd = "install:proc,spa=" + spaName
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": install process of spa output: " + response)
            LOGGER.debug(lab.id + ": waiting spa to be MOOS ......")
            self._CA.timedAssert(timeout, interval, self.assertSPAState, lab, spaName, 'MOOS', 'debug')
            if not simplexSuSoak:
                self._CA.timedAssert(timeout, interval, self.assertLocalProcessState, lab, spaName, 'MOOS', 'debug')
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def deleteConfigSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME):
        '''
        delete config spa, "delete:config,spa=spaName"
        @param lab: lab type
        @param spaName: string
        '''
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.DEL_CONF_SPA_FAIL
        LOGGER.debug(lab.id + ": try to delete config of spa : " + str(spaName))
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            try:
                version = self.getSPAVersion(lab, spaName)
            except:
                LOGGER.error("%s: get spa version fail", exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
            spaName = spaName + version
        try:
            self.assertSPAState(lab, spaName, 'EQP', 'debug')
        except:
            LOGGER.error("%s: spa's pre-state is not EQP", exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        cmd = "delete:config,spa=" + spaName + ";Y;"
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": delete config of spa output: " + response)
            LOGGER.debug(lab.id + ": waiting there is no spa named " + spaName)
            self._CA.timedAssert(timeout, interval, self._assertNoSPA, lab, spaName)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage


    def installConfigSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME):
        '''
        install config spa, "install:config,spa=spaName"
        @param lab: lab type
        @param spaName: string
        '''
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.INSTALL_CONF_SPA_FAIL
        LOGGER.debug(lab.id + ": try to install configure of spa : " + str(spaName))
        spaName = str(spaName.upper())
        try:
            self.assertNoSPA(lab, spaName)
        except:
            LOGGER.error("%s: There is spa on lab, cannot install again", exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        cmd = "install:config,spa=" + spaName
        LOGGER.debug("cmd: " + cmd)
        try:
            response = self._subshl.run(lab, cmd)
            LOGGER.debug(lab.id + ": install config of spa output: " + response)
            LOGGER.debug(lab.id + ": waiting there is no spa named " + spaName)
            self._CA.timedAssert(timeout, interval, self.assertSPAState, lab, spaName, 'EQP', 'debug')
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def restartSPA(self, lab, spaName, timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME):
        '''
        restart spa
        @param lab: lab type
        @param spaName: string
        '''
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.RESTART_SPA_FAIL
        LOGGER.debug(lab.id + ": try to restart spa : " + str(spaName))
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            version = self.getSPAVersion(lab, spaName)
            spaName = spaName + version
        try:
            self.removeSPA(lab, spaName, timeout, interval)
            self.deleteSPA(lab, spaName, timeout, interval)
            self.installSPA(lab, spaName, 60, timeout, interval)
            self.restoreSPA(lab, spaName, timeout, interval)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def _assertNoSPA(self, lab, spaName):
        '''
        assert no SPA whose name is spaName installed on lab
        @param lab: Lab type
        @param spaName: String
        '''
        exceptionMessage = lab.id + ": " + spaName + ": " + msgs.ASSERT_NO_SPA_FAIL
        LOGGER.debug(lab.id + ": Try to assert there is no spa whose name is " + spaName)
        try:
            self.getSPAVersion(lab, spaName)
        except BaseException:
            LOGGER.debug(lab.id + ": There is no spa whose name is " + spaName)
        else:
            LOGGER.debug(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def getOAMService(self, lab):
        '''
        get OAM service list on lab
        The service which should be start is defined in /sn/sps/OAMXXX/bin/service-addon
        @param lab: Lab type

        @verbatim
        serviceList = getOAMService(lab)
        return example:
        ['OamCOMM', 'OamGLOAD', 'OamGSUITE', 'OamGAUC',
        'OamACTL', 'OamLIMGNT', 'OamGNOTF', 'OamEIR', 'OamMNP']
        @endverbatim
        '''
        LOGGER.debug("%s: try to get Oam service list", lab.id)
        exceptionMessage = lab.id + ": get Oam service list failed"
        oamSPA = "OAM"
        try:
            version = self.getSPAVersion(lab, 'OAM')
            oamSPA = oamSPA + version
        except BaseException:
            exceptionMessage = lab.id + ": There is no spa whose name is OAMXXX"
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

        configFile = "/sn/sps/" + oamSPA + "/bin/service-addon"
        cmd = "grep NUM_OF " + configFile + " | grep -v \'#\'"
        LOGGER.debug("%s: %s", lab.id, cmd)

        [cmdStatus, serviceListOutput] = self._sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            serviceListOut = [line.split()[-1] for line in serviceListOutput.split(os.linesep) if re.search('=1', line)]
            serviceList = [service.rstrip("=1").split("_")[-1] for service in serviceListOut]
            serviceList = ["Oam" + service for service in serviceList]
            LOGGER.debug("%s: Oam service list: %s", lab.id, str(serviceList))
            return serviceList
        else:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def checkOamProcess(self, lab, station, logLevel='error', process='all', processPIDdict=None):
        """@verbatim check oam process on a specified station is OK.

        No return value for the method and raise exception if error.

        The method will check oam process on a specified station is OK.
        If fail, raise an exception.

        the Oam process name and number on different lab is different
        The process which should be start is defined in /sn/sps/OAMXXX/bin/service-addon

        if parameter process is 'all', will check all oam process
        if it is a specified process name, will check this process

        if processPIDdict is not None, will get the current pid and compare wich the input one.

        @endverbatim

        @param lab: the Lab object
        @param station: the rcs-hostname of the station, eg: '0-0-1'
        @param logLevel: if 'error', log level is error, otherwise, is debug
        @param process: if 'all', will check all process, if not all, will check the specified process
        @param processPIDdict: the process pid dictionary, key is process name, value is pid

        @verbatim
        McasApplicationManager.killOam(lab)
        @endverbatim
        """

        exceptMsg = lab.id + ": check OAM Process Fail!"
        targetBlade = station
        serviceList = []
        if process.lower() == 'all':
            serviceList = self.getOAMService(lab)
        else:
            serviceList = [process]

        LOGGER.debug("%s: %s: check Oam process started", lab.id, targetBlade)
        for service in serviceList:
            LOGGER.debug("%s: %s: check %s started", lab.id, targetBlade, service)
            self._linuxProcessManager.isAlive(lab, ".", service, [targetBlade], logLevel)

        if processPIDdict:
            LOGGER.debug("%s: %s: check Oam process pid is different", lab.id, targetBlade)
            pidAfter = dict()
            for service in serviceList:
                pidList = self._linuxProcessManager.getPid(lab, service, targetBlade)
                pidAfter[service] = pidList[0]
            for service in serviceList:
                try:
                    errorMsg = lab.id + ": " + service + ": pid is " + pidAfter[service] + ": same with the previous"
                    CommonAssert.assertNotEqual(pidAfter[service], processPIDdict[service], errorMsg)
                    LOGGER.debug("%s: %s: %s: pid is different", lab.id, targetBlade, service)
                except:
                    LOGGER.debug("%s: %s: %s: pid is same", lab.id, targetBlade, service)
                    LOGGER.error(exceptMsg + ": pid is the same with pre one")
                    raise McasApplicationManagerError, exceptMsg

    def killOam(self, lab, station, process='all'):
        """@verbatim kill oam process on a specified station.

        No return value for the method and raise exception if error.

        The method will kill oam process on a specified station.
        If fail, raise an exception.

        the Oam process name and number on different lab is different
        The process which should be start is defined in /sn/sps/OAMXXX/bin/service-addon
        @endverbatim

        @param lab: the Lab object
        @param station: the rcs-hostname of the station, eg: '0-0-1'
        @param process: if 'all', will kill all process, if not all, will kill the specified process

        @verbatim
        McasApplicationManager.killOam(lab)
        @endverbatim
        """

        targetBlade = station
        serviceList = []
        if process.lower() == 'all':
            serviceList = self.getOAMService(lab)
        else:
            serviceList = [process]

        pidPre = dict()
        for service in serviceList:
            pidList = self._linuxProcessManager.getPid(lab, service, targetBlade)
            pidPre[service] = pidList[0]

        LOGGER.debug("%s: %s: restart process: %s", lab.id, targetBlade, str(serviceList))
        self._linuxProcessManager.killProcessbyPid(lab, pidPre.values(), targetBlade)

        LOGGER.debug("wait 1s to make sure the process has been killed")
        time.sleep(1)

        return pidPre

    def killOamAndWaitRecover(self, lab, station, process='all', timeout=SPA_TIMEOUT, interval=SPA_STATE_ASSERT_TIME):
        """@verbatim kill oam process on a specified station. Then wait it recover.

        No return value for the method and raise exception if error.

        The method will kill oam process on a specified station.
        Then check the process can be recover, and spa is OK.
        If fail, raise an exception.

        the Oam process name and number on different lab is different
        The process which should be start is defined in /sn/sps/OAMXXX/bin/service-addon
        @endverbatim

        @param lab: the Lab object
        @param station: the rcs-hostname of the station, eg: '0-0-1'
        @param process: if 'all', will reboot all process, if not all, will reboot the specified process
        @param timeout: int, unit is second, default is 1200
        @param interval: int, unit is second, value range >0, default is 10

        @verbatim
        McasApplicationManager.killOam(lab)
        @endverbatim
        """

        #Add sleep time to avoid automatic defense mechanism when killing oam process
        LOGGER.info("Wait %s seconds before killing OAM process to avoid automatic defense mechanism", str(MCAS_OAM_RESTART_PROCESS_TIMEOUT))
        time.sleep(MCAS_OAM_RESTART_PROCESS_TIMEOUT)

        LOGGER.debug("%s: %s: start to kill process: %s", lab.id, station, str(process))
        pidPre = self.killOam(lab, station, process)

        LOGGER.debug("%s: %s: wait process: %s recover", lab.id, station, str(process))
        CommonAssert.timedAssert(timeout, interval,
                                 self.checkOamProcess,
                                 lab, station, 'debug', process, pidPre)

        LOGGER.debug("%s: wait OAM spa recover", lab.id)
        CommonAssert.timedAssert(timeout, interval,
                                 self.assertSPAState, lab, 'OAM', 'IS', 'debug')
