'''
Created on Sep 15, 2015

@author: Qinqin FAN
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0488_restart_platform_proxy_master(SDMTestCase):
    '''test restart platform proxy on master be'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.databaseManager = self.sdmManager.databaseManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.linuxProcessManager = self.sdmManager.linuxProcessManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []

    def test_restart_Platform_Proxy_master(self):
        '''test restart Platform Proxy on master be'''

        process = "PlatformProxy"
        processRestart = "DDM_PlatProxy"
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.info("start to restart Platform Proxy on master BE")
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getLabsInNRG("1")
        masterBE = self.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        LOGGER.debug("get active pilot of the master BE")
        activePilotPre = self.mcasMachineManager.getActivePilot(masterBE)
        LOGGER.debug("%s: active pilot is %s", masterBE.id, activePilotPre)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.debug("Start to restart Platform Proxy on master BE at: " + startTime)

        LOGGER.debug("check the Platform Proxy on all stations is alive")
        self.platformAsserts.assertProcessAlive(masterBE, process)

        LOGGER.debug("restart Platform Proxy on active pilot")
        self.databaseManager.runScriptOperation(masterBE, processRestart, ddmOperation='restart')

        LOGGER.debug("check the Platform Proxy process on master BE can be recover")
        self.platformAsserts.assertProcessAlive(masterBE, process)

        LOGGER.debug("check the alarm")
        # Compares alarms from snmp log file to expected and accepted lists
        # but doesn't check all raised alarms are cleared
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(masterBE, myAlarmsConfig,
                                                               logFile=LOGFILE[1])


        LOGGER.debug("check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        LOGGER.debug("ff0488 restart platform proxy on master BE success!\n")
