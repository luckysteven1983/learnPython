'''
Created on Apr 7, 2015
@author: FrankZh

the module is used to retrieve and parse OAMSUAgent.xml which has been installed on SDM lab.
the detail information of this file is defined in RDS (specification) which is avalible
in weblib with the following id: 3BL95970 GCDA UAZZA.
'''

import os
from scp import SCPClient
#from xml.dom import minidom
from lxml import etree
import re

from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class SdmSuAgent(object):
    '''
    the class is to retrive and parse OAMSUAgent.xml which has been installed on SDM lab
    '''

    #xmlAgentNameSpace = "{http://XMC/XmcOamSWDescriptor}"
    xmlAgentNameSpace = ""

    @staticmethod
    def getRemoteFile(sshMngr, peerHost, srcFile, localDir, usr=None, pw=None):
        '''
        get OAMSUAgent.xml file from the destination lab
        '''
        client = sshMngr.getClient(peerHost, usr, pw)

        if not client:
            LOGGER.error("failed to get client on %s as user[%s]", peerHost, usr)
            return ''

        suTransport = client.get_transport()

        if not suTransport.is_alive():
            sshMngr.closeClient(peerHost, usr)
            LOGGER.error("connection to %s is broken as user[%s]", peerHost, usr)
            return ''

        scpClient = SCPClient(suTransport)

        if not os.path.isdir(localDir):
            os.mkdir(localDir)

        if localDir[-1] != os.sep:
            localPath = localDir + os.sep + os.path.basename(srcFile)
        else:
            localPath = localDir + os.path.basename(srcFile)

        scpClient.get(srcFile, localPath)

        return localPath

    @staticmethod
    def rmvLocalSUAgentXml(localXml):
        '''
        delete the old OAMSUAgent.xml in the local machine
        '''
        if os.path.isfile(localXml):
            os.remove(localXml)
            LOGGER.debug("have removed %s successfully", localXml)

    @staticmethod
    def getNameSpace(xmlRoot):
        '''
        get Namespace in xml
        '''
        ns = None
        try:
            nm = re.compile('({.+})')
            if nm.search(xmlRoot.tag) != None:
                ns = nm.search(xmlRoot.tag).group(1)
        except re.error as ex:
            LOGGER.exception(ex)
           # raise ex

        return ns

    @staticmethod
    def getActionDataWithLxml(localXml, actionName):
        """
        get the data related to this action which are defined in OAMSUAgent.xml.
        """
        dictActData = {}.fromkeys(('timeout', 'estimatedTime', 'name', 'label', 'tooltip', 'script', \
            'defaultErrorMsg', 'arg', 'statusFileName', 'polling', 'failedThreshold', 'lossSSHTimeout', \
            'inventoryFile', 'autoActionRelaunch'))

        tree = etree.parse(localXml)  # pylint: disable=no-member
        root = tree.getroot()
        SdmSuAgent.xmlAgentNameSpace = SdmSuAgent.getNameSpace(root)

        #print etree.tostring(root)  #just for verification
        try:
            for nameEl in root.iter(SdmSuAgent.xmlAgentNameSpace + "name"):
                if nameEl.text.strip() == actionName:
                    ppNameEl = nameEl.getparent().getparent()
                    dictActData['name'] = actionName
                    dictActData['timeout'] = int(SdmSuAgent._getElementText(ppNameEl, 'timeout'))
                    dictActData['estimatedTime'] = int(SdmSuAgent._getElementText(ppNameEl, 'estimatedTime'))
                    dictActData['script'] = SdmSuAgent._getElementText(ppNameEl, 'script')
                    dictActData['defaultErrorMsg'] = SdmSuAgent._getElementText(ppNameEl, 'defaultErrorMsg')

                    if actionName != 'SOFTWARE_INVENTORY':
                        dictActData['arg'] = SdmSuAgent._getElementText(ppNameEl, 'arg')
                    else:
                        dictActData['inventoryFile'] = SdmSuAgent._getElementText(ppNameEl, 'inventoryFile')

                    if actionName not in('INSTALL_AGENT', 'SOFTWARE_INVENTORY'):
                        statusEl = SdmSuAgent._getElement(ppNameEl, 'statusFile')
                        dictActData['statusFileName'] = SdmSuAgent._getElementText(statusEl, 'name')
                        dictActData['polling'] = int(SdmSuAgent._getElementText(statusEl, 'polling'))
                        dictActData['failedThreshold'] = int(SdmSuAgent._getElementText(statusEl, 'failedThreshold'))

                    if actionName not in ('DOWNLOAD', 'INSTALL_AGENT', 'SOFTWARE_INVENTORY'):
                        actEl = SdmSuAgent._getElement(ppNameEl, 'autoActionRelaunch')
                        if actEl is not None:
                            dictActData['autoActionRelaunch'] = int(actEl.get('attemptNb'))

                        lossSSHEl = SdmSuAgent._getElement(ppNameEl, 'lossSSHTimeout')
                        if lossSSHEl is not None:
                            dictActData['lossSSHTimeout'] = int(lossSSHEl.text)

                    pNameEl = nameEl.getparent()
                    dictActData['label'] = SdmSuAgent._getElementText(pNameEl, 'label')
                    dictActData['tooltip'] = SdmSuAgent._getElementText(pNameEl, 'tooltip')

                    break
        except IndexError as ex:
            #LOGGER.error("invalid tag name, %s", e)
            LOGGER.exception(ex)
            raise ex

        return dictActData

    @staticmethod
    def _getElementText(parentEl, tag):
        '''
        get child element text with tag
        '''
        elText = ''
        childEl = SdmSuAgent._getElement(parentEl, tag)
        if childEl is not None:
            elText = childEl.text.strip() if childEl.text else childEl.text

        return elText

    @staticmethod
    def _getElement(parentEl, tag):
        '''
        get child element with tat
        '''
        childEl = parentEl.find(SdmSuAgent.xmlAgentNameSpace + tag)
        if childEl is None:
            childEl = parentEl.find(tag)

        return childEl
