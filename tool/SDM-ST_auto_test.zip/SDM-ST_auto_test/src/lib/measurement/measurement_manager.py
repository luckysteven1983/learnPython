'''
Created on July 24, 2015

@author: Xia Zhao
'''
import time
import os
import re
import csv
from framework.asserts.common_asserts import CommonAssert
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class MeasurementManagerError(BaseException):
    """If error, raise it."""
    pass

class MeasurementManager(object):
    '''
    classdocs
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def updateMeas(self, lab, table, inhibit=False, measInterval=15, generateFile=True):
        '''
        this function is to update measurement table
        The script on lab /cust_use/SDM/SDM_tools/update_meas/updateMeas is used to update measurement table
        Command on lab: ./updateMeas -f /tmp/meas_auto -i N -I measInterval
        Command on lab usage: updateMeas [-f file] [-i inhibit -g generate -I interval]
        -i: Y|N.                 Activate the measurement(N) or deactivate the measurements(Y)
        -g: Y|N.                 Whether generate data file or not
        -I: 5|15|30|HR|24.       Specify the new measurement interval
        -f: input file.          Contain list of measurement tables you want to operate (1 entry per line).
                         Make sure the measurement tables are correct before execution.
        For example:  ./updateMeas -f /cust_use/SDM/SDM_tools/update_meas/OAM_active_meas_list -i N -I 5

        @author: Xia zhao
        @param lab: the Lab object
        @param table: string, the table name
        @param inhibit: boolean, the value should be True or False
                       False means active the measurement, True means deactivate the measurement
        @param measInterval: the measurement interval, default is 15 minutes
                        accept values are: 5|15|30|60|24
                        5 means 5 minutes; 15 means 15minutes; 30 means 30 minutes; 60 means 1 hour; 24 means 1 day
        @param generateFile: boolean, the value should be True or False,
                       True means generate data file, False means do not generate
        @verbatim
        measurementManager = MeasurementManager()
        measurementManager.updateMeas(lab, 'OAM_MEAS_DB_NRG')
        @endverbatim
        '''
        acceptMeasInterval = [5, 15, 30, 60, 24]
        CommonAssert.assertIn(measInterval, acceptMeasInterval,
                              'measInterval should in list [5, 15, 30, 60, 24]')
        inhibitStr = 'Y' if inhibit else 'N'
        generateFileStr = 'Y' if generateFile else 'N'
        measIntervalStr = 'HR' if measInterval == 60 else str(measInterval)

        exceptionMessage = lab.id + ": " + table + ": " + msgs.UPDATE_MEAS_TABLE_FAILED
        LOGGER.debug(lab.id + ": " + table +": try to get measurement table configure ")
        try:
            preConfig = self.getMeasConfig(lab, table)
            if preConfig['ms_gen_file'] == generateFile\
                    and preConfig['inhibited'] == inhibit\
                    and preConfig['ms_intvl_v'] == measInterval:
                LOGGER.debug("%s: %s: configuration has no change, no need to update", lab.id, table)
                return
        except BaseException, msg:
            LOGGER.error(exceptionMessage +": " + str(msg))
            raise MeasurementManagerError, exceptionMessage +": " + str(msg)
        LOGGER.debug(lab.id + ": try to update measurement table " + table)
        table = str(table.upper())
        tableFile = "/tmp/tableToUpdateForAuto"
        generateFilecmd = "echo \'" + table + "\' > " + tableFile
        try:
            LOGGER.debug(lab.id + ": try to generate file which contains the measurement tables")
            LOGGER.debug(lab.id + ": command is " + generateFilecmd)
            self.sshManager.run(lab.oamIpAddress, generateFilecmd)
        except BaseException, msg:
            exceptionMessage = lab.id + ": generate file which contains the measurement tables fail"
            LOGGER.error(exceptionMessage+" : "+str(msg))
            raise MeasurementManagerError, exceptionMessage

        cmd = "cd /cust_use/SDM/SDM_tools/update_meas/; ./updateMeas -f "\
                +tableFile+" -i " + inhibitStr + " -I " + str(measIntervalStr) + " -g " + generateFileStr
        try:
            LOGGER.debug(lab.id + ": try to update measurement tables")
            LOGGER.debug(lab.id + ": command is " + cmd)
            _, _ = self.sshManager.sendStringAndExpect(lab.oamIpAddress, cmd, "updateMeas.log")
        except BaseException, msg:
            self.sshManager.run(lab.oamIpAddress, 'rm -f /tmp/tableToUpdateForAuto')
            LOGGER.error(exceptionMessage+" : "+str(msg))
            raise MeasurementManagerError, exceptionMessage
        self.sshManager.run(lab.oamIpAddress, 'rm -f /tmp/tableToUpdateForAuto')
        LOGGER.debug(lab.id + ": check measurement tables has been updated")
        config = self.getMeasConfig(lab, table)
        CommonAssert.assertEqual(config['ms_gen_file'], generateFile, 'measurement update fail for ms_gen_file')
        CommonAssert.assertEqual(config['inhibited'], inhibit, 'measurement update fail for inhibited')
        CommonAssert.assertEqual(config['ms_intvl_v'], measInterval, 'measurement update fail for inhibited')

    def openMeas(self, lab, table, measInterval=15, generateFile=True):
        '''
        this function is to open measurement table
        use method in this class to updateMeas to open measurement table
        @author: Xia zhao
        @param lab: the Lab object
        @param table: string, the table name
        @param measInterval: the measurement interval, default is 15 minutes
                        accept values are: 5|15|30|60|24
                        5 means 5 minutes; 15 means 15minutes; 30 means 30 minutes; 60 means 1 hour; 24 means 1 day
        @param generateFile: boolean, the value should be True or False,
                       True means generate data file, False means do not generate
        @verbatim
        measurementManager = MeasurementManager()
        measurementManager.openMeas(lab, 'OAM_MEAS_DB_NRG', 5)
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to open measurement table " + table)
        exceptionMessage = lab.id + ": " + table + ": " + msgs.OPEN_MEAS_TABLE_FAILED
        try:
            self.updateMeas(lab, table, False, measInterval, generateFile)
        except:
            LOGGER.error(exceptionMessage)
            raise MeasurementManagerError, exceptionMessage

    def closeMeas(self, lab, table):
        '''
        this function is to close measurement table
        use method in this class to updateMeas to close measurement table
        @author: Xia zhao
        @param lab: the Lab object
        @param table: string, the table name

        @verbatim
        measurementManager = MeasurementManager()
        measurementManager.closeMeas(lab, 'OAM_MEAS_DB_NRG')
        @endverbatim
        '''
        LOGGER.debug(lab.id + ": try to close measurement table " + table)
        exceptionMessage = lab.id + ": " + table + ": " + msgs.CLOSE_MEAS_TABLE_FAILED
        try:
            self.updateMeas(lab, table, True)
        except:
            LOGGER.error(exceptionMessage)
            raise MeasurementManagerError, exceptionMessage

    def getMeasConfig(self, lab, table):
        '''
        this function is to get measurement table configuration
        On lab below command is used to get measurement table configuration
        psql -U scncraft -c "select * from meas_mstr where ms_tbl='MS_PERF_MEAS'"

        @author: Xia zhao
        @param lab: the Lab object
        @param table: string, the table name

        @verbatim
        measurementManager = MeasurementManager()
        measurementManager.getMeasConfig(lab, 'OAM_MEAS_DB_NRG')

        output will be like below:
        {'ms_gen_file': True,
        'ms_intvl_v': 15,
        'proc_name': 'MEASMT',
        'ms_rpt_file': 'MSperfRpt.sql',
        'ms_tbl': 'MS_PERF_MEAS',
        'ms_col_all_hosts': 'Y',
        'inhibited': True}

        @endverbatim
        '''
        LOGGER.debug("%s: %s: try to get measurement table configuration", lab.id, table)
        exceptionMessage = lab.id + ": " + table + ": " + msgs.GET_MEAS_TABLE_CONFIG_FAILED

        measConfig = dict()
        cmd = '/platdb/bin/psql -U scncraft -c "select * from meas_mstr where ms_tbl=\''+table+'\'"\r'
        try:
            LOGGER.debug(lab.id + ": command is " + cmd)
            for index in range(10):
                LOGGER.debug("%s: the %s try to get measurement table configuration", lab.id, str(index+1))
                stateOutput, _ = self.sshManager.sendStringAndExpect(lab.oamIpAddress, cmd, "row", timeout=5)
                LOGGER.debug(lab.id + ": command output is " + stateOutput)
                if re.search('row', stateOutput):
                    break
            else:
                raise MeasurementManagerError, "get table configuration fail"
            if re.search('0 rows', stateOutput):
                raise MeasurementManagerError, "The table do not exist"
            stateOutput = [line for line in stateOutput.rstrip().split(os.linesep) if re.search(r" \| ", line)]
            LOGGER.debug(lab.id + ": stateOutput output is " + str(stateOutput))
            keys = [key.strip() for key in stateOutput[0].split("|")]
            values = [value.strip() for value in stateOutput[1].split("|")]
            for index in range(len(keys)):
                measConfig[keys[index]] = values[index]
            timeInterval = re.search(r"(\d+)$", measConfig['ms_intvl_v'])
            if timeInterval:
                measConfig['ms_intvl_v'] = int(timeInterval.group(1))
            else:
                if re.search(r"HR$", measConfig['ms_intvl_v']):
                    measConfig['ms_intvl_v'] = 60
            measConfig['inhibited'] = True if measConfig['inhibited'] == 'Y' else False
            measConfig['ms_gen_file'] = True if measConfig['ms_gen_file'] == 'Y' else False
            LOGGER.debug("%s: %s: configuration is : %s", lab.id, table, str(measConfig))
            return measConfig
        except BaseException, msg:
            LOGGER.error(exceptionMessage +": " + str(msg))
            raise MeasurementManagerError, exceptionMessage

    def getMeasData(self, lab, table, startTime, endTime=None):
        '''
        this function is to dump measurement data
        On lab, use psql command to dump data
        @author: Xia zhao
        @param lab: the Lab object
        @param table: string, the table name
        @param startTime: int
        @param endTime: int, if None, the endTime will be now
        @return measData: list, the measurement data of the given table
        For example:
        [['schedtime', 'actualtime', 'duration', 'sh_pna_succ','sh_pna_error',],
        ['1438577100', '1438577101', '900', '0', '0',],
        ['1438578900', '1438578901', '900', '0', '0',]]
        @verbatim
        measurementManager = MeasurementManager()
        measData = measurementManager.getMeasData(lab, 'OAM_MEAS_DB_NRG', '1437376462')
        @endverbatim
        '''
        exceptionMessage = lab.id + ": " + table + ": " + msgs.GET_MEAS_DATA_FAILED
        if not endTime:
            endTime = int(time.time())

        try:
            tmpFile = "/tmp/measDataForAuto_" + str(startTime) + "_" + str(endTime)
            cmd = '/platdb/bin/psql -U meas -c "select * from '\
                  + table+' where schedtime>'+str(startTime)\
                  +' and schedtime<'+str(endTime)+'" | tee ' + tmpFile

            LOGGER.debug(lab.id + ": command is " + cmd)

            for index in range(10):
                _, _ = self.sshManager.sendStringAndExpect(lab.oamIpAddress, cmd, "row", timeout=10)
                try:
                    LOGGER.debug(lab.id + ": try to download " + tmpFile)
                    measDataOutputFile = self.sshManager.scpGet(lab.oamIpAddress, tmpFile)
                except BaseException:
                    LOGGER.debug("%s: the %s try to get measurement data", lab.id, str(index+1))
                else:
                    break
            else:
                raise MeasurementManagerError, "get measurement data fail"

            LOGGER.debug(lab.id + ": try to download " + tmpFile)
            measDataOutputFile = self.sshManager.scpGet(lab.oamIpAddress, tmpFile)

            LOGGER.debug(lab.id + ": delete tmp file on lab " + tmpFile)
            self.sshManager.run(lab.oamIpAddress, 'rm -rf '+tmpFile)

            LOGGER.debug(lab.id + ": local measurement data file is: " + measDataOutputFile)
            measDataOutput = open(measDataOutputFile, "r")
            measData = [line for line in measDataOutput.readlines() if re.search(r" \| ", line)]
            LOGGER.debug(lab.id + ": output is " + str(measData))
        except BaseException:
            LOGGER.error(exceptionMessage)
            raise MeasurementManagerError, exceptionMessage

        if not measData or re.search('0 rows', str(measData)):
            LOGGER.error(exceptionMessage + ": The table do not exist or not open")
            raise MeasurementManagerError, exceptionMessage + ": The table do not exist or not open"
        measData = [[key.strip() for key in line.split("|")] for line in measData]
        LOGGER.debug("%s: %s: start time %s: %s: measurement data is %s",
                     lab.id, table, str(startTime), str(endTime), str(measData))
        return measData

    def getMeasDataAsCsv(self, lab, table, csvDataFile, startTime, endTime=None):
        '''
        this function is to dump measurement data
        On lab, use psql command to dump data
        @author: Xia zhao
        @param lab: the Lab object
        @param table: string, the table name
        @param csvDataFile: the file name with full path on local PC.
                            Which will store all the measurement data of the given table.
        @param startTime: int
        @param endTime: int, if None, the endTime will be now
        @verbatim
        measurementManager = MeasurementManager()
        csvFile = measurementManager.getMeasData(lab, 'OAM_MEAS_DB_NRG', csvFileName, '1437376462')
        @endverbatim
        '''
        exceptionMessage = lab.id + ": " + table + ": " + msgs.GET_MEAS_DATA_FAILED
        if not endTime:
            endTime = int(time.time())
        try:
            tmpFile = "/tmp/measDataForAuto_" + str(time.time())
            cmd = '/platdb/bin/psql -U meas -c "select * from '\
                  + table+' where schedtime>'+str(startTime)\
                  +' and schedtime<'+str(endTime)+'" | tee ' + tmpFile

            LOGGER.debug(lab.id + ": command is " + cmd)

            for index in range(10):
                _, _ = self.sshManager.sendStringAndExpect(lab.oamIpAddress, cmd, "row", timeout=10)
                try:
                    LOGGER.debug(lab.id + ": try to download " + tmpFile)
                    measDataOutputFile = self.sshManager.scpGet(lab.oamIpAddress, tmpFile)
                except BaseException:
                    LOGGER.debug("%s: the %s try to get measurement data", lab.id, str(index+1))
                else:
                    break
            else:
                raise MeasurementManagerError, "get measurement data fail"

            self.sshManager.run(lab.oamIpAddress, 'rm -rf '+tmpFile)
            LOGGER.debug(lab.id + ": local measurement data file is: " + measDataOutputFile)
            measDataOutput = open(measDataOutputFile, "r")
            measData = [line for line in measDataOutput.readlines() if re.search(r" \| ", line)]
            LOGGER.debug(lab.id + ": output is " + str(measData))
        except BaseException:
            LOGGER.error(exceptionMessage)
            raise MeasurementManagerError, exceptionMessage

        if not measData or re.search('0 rows', str(measData)):
            LOGGER.error(exceptionMessage + ": The table do not exist or not open")
            raise MeasurementManagerError, exceptionMessage + ": The table do not exist or not open"
        measData = [[key.strip() for key in line.split("|")] for line in measData]
        LOGGER.debug("%s: %s: start time %s: %s: measurement data is %s",
                     lab.id, table, str(startTime), str(endTime), str(measData))

        with open(csvDataFile, 'a') as csvfile:
            wirter = csv.writer(csvfile)
            wirter.writerows(measData)
            csvfile.close()
        return csvDataFile

    def checkMeas(self, lab, table, field, threshold):
        '''
        this function is to check measurement
        Not implemented yet

        @param lab: the Lab object
        @param table: string, the table name
        @param param: string, the field will be checked
        @param threshold: float, if value > threshold, raise an exception
        @verbatim
        measurementManager = MeasurementManager()
        measurementManager.checkMeas()
        @endverbatim
        '''
        pass
