"""
This library contains ssh classes to access target platforms.
"""
