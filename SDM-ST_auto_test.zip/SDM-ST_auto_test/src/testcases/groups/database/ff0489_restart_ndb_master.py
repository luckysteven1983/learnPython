'''
Created on Oct 26, 2015

@author: Yohann Martineau
'''
import os
import random
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.alarm.alarm import Alarm
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0489_restart_ndb_master(SDMTestCase):
    '''Blade SW fault: restart ndb on one blade on BE MASTER'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.databaseManager = self.sdmManager.databaseManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsSpecific = []
        self.acceptedAlarmsSpecific = [Alarm(alarmCode=404, severity="Major"),
                                       Alarm(alarmCode=404, severity="Minor")]
        self.expectedAlarms4BE = []
        self.acceptedAlarms4BE = []
        self.expectedAlarms4FE = []
        self.acceptedAlarms4FE = []
        self.success = True
        self.exceptMsg = ""

    def test_restart_ndb_master(self):
        '''restart ndb on one blade on BE MASTER'''

        self.success = True
        self.exceptMsg = ""
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getLabsInNRG("1")
        masterBE = self.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        LOGGER.debug("%s: Choose one DB station", masterBE.id)
        dbStation = random.choice(masterBE.getStationListbyProductRole('DB').keys())
        LOGGER.debug("%s: DB station %s has been chosen", masterBE.id, dbStation)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)

        LOGGER.info("%s: %s: Start to restart ndb at %s", masterBE.id, dbStation, startTime)
        self.databaseManager.killNDB(masterBE, dbStation)


        LOGGER.debug("check the alarm")
        myAlarmsConfig4FE = AlarmsConfig(self.expectedAlarms4FE, self.acceptedAlarms4FE, startTime)
        for labIndex in self.testEnv.testBed.getFrontends().values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(lab=labIndex,
                                                                       myAlarmsConfig=myAlarmsConfig4FE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfig4BE = None
        for labIndex in self.testEnv.testBed.getBackends().values():
            if labIndex == masterBE:
                myAlarmsConfig4BE = AlarmsConfig(self.expectedAlarmsSpecific, self.acceptedAlarmsSpecific, startTime)
            else:
                myAlarmsConfig4BE = AlarmsConfig(self.expectedAlarms4BE, self.acceptedAlarms4BE, startTime)
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                self.exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg) + os.linesep

        if self.success:
            LOGGER.debug("ff0489_restart_ndb_master success!\n")
        else:
            LOGGER.error("ff0489_restart_ndb_master fail!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)
