"""
This package will contain all test cases related to first installation
"""
