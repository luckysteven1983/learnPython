how to use framework on windows:

> c:\Python27\Scripts\virtualenv.exe SDM-ST_auto_test-virtualenv
> SDM-ST_auto_test-virtualenv\Scripts\activate
> SET VS90COMNTOOLS=%VS120COMNTOOLS%
> pip install -r requirements.txt --proxy=http://global.proxy.alcatel-lucent.com:8000/

eclipse > new python interpreter, give path to SDM-ST_auto_test-virtualenv\Scripts\python.exe

generate key pair manually in SDM-ST_auto_test/conf directory, either using
cygwin:

$ ssh-keygen.exe -f /cygdrive/c/Users/yohannm/workspace/SDM-ST_auto_test/conf/id_rsa -t rsa -C "" -N ""

or any other tool generating openssh ssh key pairs. Keep default id_rsa name for
private key and id_rsa.pub for public key.

