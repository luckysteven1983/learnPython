#!/bin/sh

while [ 1 ]
do  
   echo `date`
   netstat -na|grep 192.17
   sleep $1
done
