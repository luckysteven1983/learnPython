'''
Created on March 30, 2015

@author: tlavanan
'''

import re
import urllib2
from lib.logging.logger import Logger

LOG = Logger.getLogger(__name__)

class VersionManager(object):
    '''
    this class will implement a check method with one parameter: a host name.
    Version and CP of this host name will be checked
    Output should look like :
        MCAS => 3.2.12
        DDM => 90.00.14.02-01
        SDM => SDM422 CP96
        or
        MCAS => 3.2.12
        DDM => 90.00.14.02-01
        SDM => SDM422 CP not found on web page with date :2015-02-05
    '''
    MCAS_CMD = "/usr/dhafw/tools/fw llsta"
    DDM_CMD = "/usr/dhafw/tools/fw lver"
    SDM_VERSIONS = "ls -d /sn/sps/OAM*/ /sn/sps/PROXY*/ 2>/dev/null"
    SDM_CMD = "bin/showversion"
    MCAS_REGEX = r"(MCAS)(.)([0-9]{1,2}\.[0-9]{1,2}\.?[0-9]{0,2})"
    DDM_REGEX = r"(current running version : )(r)([\S]+[-][0-9]+)"
    SDM_REGEX = "(20[0-9]+-[0-9]+-[0-9]+)"
    # we should use the lazy qualifier to match the first CP word. In SDM R430, the load information
    # will only occupy one line including all CP versions. If no lazy qualifier, it will always
    # match wrongly the last CP version.
    CP_REGEX = r"(.*?)(CP\.)([0-9]+)"

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def getversion(self, node):
        '''
            To have the node version for each type (SDM DDM MCAS)
            node is the node name or IP provided as a string
            the version is returned in a dictionary with MCAS, DDM and SDM version
            Ex: {'MCAS': '3.4.7', 'DDM': '91.00.11.03-01', 'SDM': '430CP2'}
        '''
        _versionDic = dict()
        _sshManager = self.sshManager
        _sshManager.getClient(node)
        _, out = _sshManager.run(node, self.MCAS_CMD)

        _verMCAS = re.search(self.MCAS_REGEX, out)
        _versionDic["MCAS"] = _verMCAS.group(3)
        LOG.debug(node + " : MCAS => " + _verMCAS.group(3))

        _, out = _sshManager.run(node, self.DDM_CMD)
        _verDDM = re.search(self.DDM_REGEX, out)
        LOG.debug(node + " : DDM => " + _verDDM.group(3))
        _versionDic["DDM"] = _verDDM.group(3)

        # For SDM SPA version, we maybe have two versions for SU case. (no such case for mCAS and
        # DDM version)
        tmpSdmVersion = ""
        _, sdmVersions = _sshManager.run(node, self.SDM_VERSIONS)
        LOG.debug("sdm versions: %s", sdmVersions)
        for sdmVersion in sdmVersions.split():
            sdmCmd = sdmVersion + self.SDM_CMD
            _, out = _sshManager.run(node, sdmCmd)
            date = re.search(self.SDM_REGEX, out)
            _verSDM = out.splitlines()[-1]
            # If SDM ver is 4.4 or higher we have directly the Tag version
            if int(_verSDM) >= 440:
                tmpSdmVersion += _verSDM + out.splitlines()[-2] + " "
            else:
                # The CP can be found on page http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdmVER.html
                # VER is the SDM version
                # CP for 422 are on page 421, so we have a special test for this case
                _sdmBuildsURL = "http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdm"
                if _verSDM == '422':
                    _sdmBuildsURL += "421"
                else:
                    _sdmBuildsURL += _verSDM
                _sdmBuildsURL += ".html"
                # trick to ignore system proxy for this request.
                proxyHandler = urllib2.ProxyHandler({})
                opener = urllib2.build_opener(proxyHandler)
                request = urllib2.Request(_sdmBuildsURL)
                response = opener.open(request)
                _cpREGEX = '(' + date.group(1) + ')' + self.CP_REGEX
                _CP = re.search(_cpREGEX, response.read())
                # Sometimes the CP is not present for selected date. In this case, we should checks the days after
                # This workaround will be implemented only if needed.
                if _CP != None:
                    LOG.debug(node + " : SDM => SDM" + _verSDM + " CP" + _CP.group(4))
                    tmpSdmVersion += _verSDM + "CP" + _CP.group(4) + " "
                else:
                    LOG.error(_verSDM + " CP not found on web page with date :" + date.group(1))
                    tmpSdmVersion += "SDM => SDM" + _verSDM + " CP not found on web page with date :" + date.group(1) + ""
            _versionDic["SDM"] = tmpSdmVersion.strip()
        return _versionDic

