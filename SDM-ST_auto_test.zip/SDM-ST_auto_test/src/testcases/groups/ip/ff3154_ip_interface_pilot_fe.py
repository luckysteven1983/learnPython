"""
Created on Nov 9, 2015

@author: Claude LE DU
# No test sheet found
"""

import os
import time

from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.network.network_manager import NetworkManagerError

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

TIMER_GDMP_ETH_DOWN = 5  # seconds
TIMER_RESTORE_INTERFACE = 30  # seconds
NB_RESTORE_TRIES = 120
GDMP_ENTRY = "gdm"
NB_LOOP_UP_DOWN = 10
UP_STATE = "UP"


class ff3154_ip_interface_pilot_fe(SDMTestCase):
    """ Loop Up/Down Interface GDMP on 1st FE """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.sshManager = self.sdmManager.sshManager
        self.networkManager = self.sdmManager.networkManager
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.gdmpEths = []
        if self.fe.hardware == 'VMMHI':
            msg = "This test is skipped on V8650. Waiting for SDMSQA-1366 to be solved"
            LOGGER.warning(msg)
            self.skipTest(msg)

    def tearDown(self):
        tries = 0
        while tries < NB_RESTORE_TRIES:
            try:
                self.networkManager.setInterfaceState(self.fe, self.gdmpEths, UP_STATE)
                tries = NB_RESTORE_TRIES + 1
            except NetworkManagerError:
                time.sleep(TIMER_RESTORE_INTERFACE)
                tries += 1
        if tries < NB_RESTORE_TRIES + 1:
            LOGGER.critical("GDMP interfaces could be down")


    def test_ff3154_ip_interface_pilot_fe(self):
        """ Loop Up/Down Interface GDMP on 1st FE """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)


    def _precheck(self):
        """Test case precheck - Returns current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        """ Execute test case """
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)

        LOGGER.info("GDMP interface will be disabled/enabled 10 times on " + self.fe.id + " pilot")

        # search for GDMP interface
        self.gdmpEths = self.networkManager.getInterface(self.fe, GDMP_ENTRY)
        # loop interface up and down
        self.networkManager.loopInterfaceUpDown(self.fe, GDMP_ENTRY, NB_LOOP_UP_DOWN, TIMER_GDMP_ETH_DOWN)

        return startTime


    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        exceptMsg = ""
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("Check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2],
                                           checkQoS=True, resetQoSStartingPoint=True)
