'''
Created on Feb 13, 2015

@author: yohannm
'''
from framework.testenv.product_role import ProductRole

class Frontend(ProductRole):
    '''
    classdocs
    '''

    def __init__(self):
        super(Frontend, self).__init__()
        self.id = None
        self.FE_Key = ""
