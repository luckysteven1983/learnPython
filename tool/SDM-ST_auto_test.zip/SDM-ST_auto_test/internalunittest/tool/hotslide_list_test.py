'''
Created on Aug 3, 2015

@author: jiaxij
'''
import unittest
import os

from lib.logging.logger import Logger
#from framework.sdm_test_case import SDMTestCase
LOGGER = Logger.getLogger(__name__)
from lib.autohotslide.hotslide_list import printLabListToFile

OUTPUTFILE = 'hotslide_list_test_once_dummy'

class dummy_lab(object):
    """
    @details This class is a dummy lab with only oamIpAddress available
    """

    def __init__(self, ip):
        """ TestEnv class constructor """

        self.oamIpAddress = ip

class hotslide_list_test(unittest.TestCase):
    """ test class """
    def setUp(self):
        LOGGER.info("Hotslide List Test")
        #self.logLinksPrint()#Used to get the log links in Junit XML results

    def tearDown(self):
        os.remove(os.path.dirname(os.path.abspath(OUTPUTFILE)) + '/' + OUTPUTFILE)

    def test_printLabListToFile(self):
        """ test printLabListToFile with dummy input """
        lab1 = dummy_lab('1.1.1.1')
        lab2 = dummy_lab('1.1.1.2')
        lab3 = dummy_lab('1.1.1.3')
        lab4 = dummy_lab('1.1.1.4')
        lab5 = dummy_lab('1.1.2.1')
        lab6 = dummy_lab('1.1.2.2')

        nonMasterBEList = [lab1, lab2]
        masterBEList = [lab3, lab4]
        _FEList = [lab5, lab6]

        printLabListToFile(nonMasterBEList, OUTPUTFILE, 'w')
        printLabListToFile(masterBEList, OUTPUTFILE, 'a')
        printLabListToFile(_FEList, OUTPUTFILE, 'a')

        expected = '1.1.1.1 m;1.1.1.2 m;\n1.1.1.3 m;1.1.1.4 m;\n1.1.2.1 m;1.1.2.2 m;\n'

        fileObject = open(OUTPUTFILE)
        try:
            output = fileObject.read()
        finally:
            fileObject.close()

        self.assertEqual(expected, output, 'test if _printLabListToFile functions properly')

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_1_restartProcess_pilot_success']
    unittest.main()
