"""
@file core_check_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-14
@brief core check
"""

import unittest
import lib.exceptions_messages as eMsgs
from lib.core_check.core_check_manager import CoreCheckManagerError
from framework.sdm_test_case import SDMTestCase
from framework.common import Utils
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class core_check_nightly_test_once(SDMTestCase):
    """Unit test for HealthCheck class.
    """
    def setUp(self):
        LOGGER.debug("TestHealthCheckManagerTest Once")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()

    def test_01_InvalideTimestamp(self):
        """Invalid time stamp"""
        LOGGER.debug('[Test Case 01] Invalid timestamp')

        lab = self.fe
        self.assertRaisesRegexp(CoreCheckManagerError, eMsgs.CORE_INVALID_TIME_FORMAT,
                                self.sdmManager.coreCheckManager.getCoreFilesByTime,
                                lab, '2013-00-00 11:11:134')

    def test_02_CoreDir(self):
        """Core file searching directories"""
        LOGGER.debug('[Test Case 02] Core file searching directories')

        self.sdmManager.coreCheckManager.addCoreDir('/root/andy')
        coreDirs = self.sdmManager.coreCheckManager.showCoreDir()
        self.assertTrue('/root/andy' in coreDirs)
        self.assertTrue(coreDirs['/root/andy'] == 0)

        self.sdmManager.coreCheckManager.removeCoreDir('/root/andy')
        coreDirs = self.sdmManager.coreCheckManager.showCoreDir()
        self.assertTrue('/root/andy' not in coreDirs)

    def test_03_ShowCores(self):
        """Show cores until now by time"""
        LOGGER.debug('---- [Test Case 03] Show cores until now by time ----')

        lab = self.fe
        LOGGER.debug('Core Dir:' + str(self.sdmManager.coreCheckManager.showCoreDir()))
        for core in self.sdmManager.coreCheckManager.getCoreFilesByTime(lab):
            LOGGER.debug(core)

    def test_04_ShowCores(self):
        """Show cores until now by delta"""
        LOGGER.debug('---- [Test Case 04] Show cores until now by delta ----')

        lab = self.fe
        for core in self.sdmManager.coreCheckManager.getCoreFilesByDelta(lab, days=3):
            LOGGER.debug(core)

    def test_05_CheckNoCore(self):
        """Check no core"""
        LOGGER.debug('\n---- [Test Case 05] ---- check no core----')

        lab = self.fe
        gdbDir = 'andy-gdbfiles'
        bTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, lab)
        self.sdmManager.coreCheckManager.checkCoreFilesByTime(lab, bTime, savedDir=gdbDir)
        self.sdmManager.coreCheckManager.checkCoreFilesByDelta(lab, mins=1)

    def test_06_GDBInfo(self):
        """Save GDB info"""
        LOGGER.debug('---- [Test Case 06] ---- GDB Info ----')

        lab = self.fe
        gdbDir = 'internalunittest/lib/core_check/gdbfiles06'
        #Create fake core (just a text file)
        self.sdmManager.sshManager.run(lab.oamIpAddress,
                                       "touch -d '2014-10-10 12:00:00' /sncore/andy-test-core-06")
        self.assertRaisesRegexp(CoreCheckManagerError, eMsgs.CORE_DUMP_FOUND,
                                self.sdmManager.coreCheckManager.checkCoreFilesByTime,
                                lab, '2014-10-10 11:22:33', gdbDir)
        self.sdmManager.sshManager.run(lab.oamIpAddress, "rm /sncore/andy-test-core-06")

    def test_07_GDBInfo(self):
        """Save GDB info"""
        LOGGER.debug('---- [Test Case 07] ---- GDB Info ----')

        lab = self.fe
        gdbDir = 'internalunittest/lib/core_check/gdbfiles07'
        #Create fake core (just a text file)
        self.sdmManager.sshManager.run(lab.oamIpAddress,
                                       "touch /sncore/andy-test-core-07")
        self.assertRaisesRegexp(CoreCheckManagerError, eMsgs.CORE_DUMP_FOUND,
                                self.sdmManager.coreCheckManager.checkCoreFilesByDelta,
                                lab, days=2, savedDir=gdbDir)
        self.sdmManager.sshManager.run(lab.oamIpAddress, "rm /sncore/andy-test-core-07")

if __name__ == "__main__":
    unittest.main()

