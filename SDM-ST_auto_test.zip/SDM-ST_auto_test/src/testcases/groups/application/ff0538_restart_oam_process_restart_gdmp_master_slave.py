'''
Created on Aug 25, 2015

@author: xzhao015
'''
import os
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)
OAMGSUITE_PROCESS_NAME = "OamGSUITE"

class ff0538_restart_oam_process_restart_gdmp_master_slave(SDMTestCase):
    '''test kill OAM processes on one FE of the testbed
    and restart gdmp process on MASTER & SLAVE '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.success = True
        self.exceptMsg = ""
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.multiTasksManager = self.sdmManager.multiTasksManager

    def test_restartOAM_restartGDMP(self):
        """ test kill OAM processes on one FE of the testbed
        and restart gdmp process on MASTER & SLAVE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("Test case post-check")
        expectedAlarmsBE = []
        acceptedAlarmsBE = []
        expectedAlarmsFE = []
        acceptedAlarmsFE = []
        exceptMsg = str()
        myAlarmsConfigFE = AlarmsConfig(expectedAlarmsFE, acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(expectedAlarmsBE, acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])

    def _restartOAM(self, lab):
        '''restart OAM on the lab'''
        LOGGER.debug("Start kill all oam processes on FE :" + lab.id)
        activePilot = self.sdmManager.mcasMachineManager.getActivePilot(lab)
        try:
            self.sdmManager.mcasApplicationManager.killOamAndWaitRecover(lab, activePilot, OAMGSUITE_PROCESS_NAME)
        except BaseException, msg:
            self.exceptMsg += str(msg)
            self.success = False
            LOGGER.error("kill all oam processes on FE :" + lab.id + " fail")
        else:
            LOGGER.debug("kill all oam processes on FE :" + lab.id + " successful")

    def _restartGdmp(self, be):
        '''restart gdmp on all blades of the be'''
        gdmpProcess = "GdmpServer"
        gdmpProcessRestart = "Gdmps"
        LOGGER.info("%s: restart gdmp process on all stations", be.id)
        stations = be.getAllBlade().keys()
        self.sdmManager.platformAsserts.assertProcessAliveOnStations(be, gdmpProcess, stations)
        LOGGER.debug("restart gdmps on all stations")
        self.sdmManager.databaseManager.runScriptOperation(be, gdmpProcessRestart, ddmOperation='restart', 
                                                           station=stations)
        LOGGER.debug("check the gdmps process on all stations can be recover")
        self.sdmManager.platformAsserts.assertProcessAliveOnStations(be, gdmpProcess, stations)

    def _runTestCase(self):
        ''' test restart OAM and restart GDMP process on all BE '''

        LOGGER.debug("Start to choose one FE to test this case")
        fes = self.testEnv.testBed.getFrontends()
        feID, fe = fes.popitem()  # will return one over all FEs (no order in a dictionary)

        LOGGER.info("Kill OAM process on FE or restart gdmp process on BEs in progress")
        threadName = self.multiTasksManager.register(self._restartOAM, fe)
        LOGGER.info("Kill OAM process on Lab '%s' in progress -> thread ID '%s'", feID, threadName)
        for be in self.allBEs:
            threadName = self.multiTasksManager.register(self._restartGdmp, be)
            LOGGER.info("Restart gdmp process on Lab '%s' in progress -> thread ID '%s'", be.id, threadName)
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.info("Wait kill OAM and restart gdmp process complete")
        if not self.multiTasksManager.runMultiTasks():
            raise Exception("Killing PDLSx process or restart gdmp on BE failure")

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", fe.id)
        return startTime
