'''
Created on Apr 8, 2015

@author: Xia
'''
import unittest

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_NONPILOT, \
    MIDDLEWARE_ROLE_PILOT


LOGGER = Logger.getLogger(__name__)

class load_station_info_test_once(SDMTestCase):
    '''
    This class is to test library used to load station info
    '''

    def setUp(self):
        LOGGER.info("Setup of Load Station Info Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.fe2 = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        self.maxDiff = None

    def tearDown(self):
        pass

    def assertListEqual(self, list1, list2):
        for index in list1:
            self.assertIn(index, list2)
        for index in list2:
            self.assertIn(index, list1)

    def test_1_fe(self):
        LOGGER.debug("test_1_fe")
        self.assertEqual(self.fe.stations['0-0-1'].rcsHostname, '0-0-1')
        self.assertEqual(self.fe.stations['0-0-1'].middlewareRole, MIDDLEWARE_ROLE_PILOT)
        self.assertEqual(self.fe.stations['0-0-2'].rcsHostname, '0-0-2')
        self.assertEqual(self.fe.stations['0-0-2'].middlewareRole, MIDDLEWARE_ROLE_NONPILOT)
        self.assertEqual(self.fe.stations['0-0-2'].ddmHostname, 'STATION_D')
        self.assertIn('RT', self.fe.stations['0-0-2'].productRole)
        self.assertNotIn('DB', self.fe.stations['0-0-2'].productRole)

    def test_2_fe_getpilot(self):
        LOGGER.debug("test_2_fe_getpilot")
        Pilot_get = self.fe.getBladeListbymiddlewareRole(MIDDLEWARE_ROLE_PILOT).keys()
        PilotList = ['0-0-1', '0-0-9']
        self.assertListEqual(PilotList, Pilot_get)

    def test_3_fe_getNonPilot(self):
        LOGGER.debug("test_3_fe_getNonPilot")
        nonPilot_get = self.fe.getBladeListbymiddlewareRole(MIDDLEWARE_ROLE_NONPILOT).keys()
        self.assertIn('0-0-2', nonPilot_get)

    def test_4_fe_getiLB(self):
        LOGGER.debug("test_4_fe_getiLB")
        iLB_get = self.fe.getStationListbyProductRole('iLB').keys()
        self.assertRegexpMatches(iLB_get[0], '0-0-')

    def test_5_fe_getSS7(self):
        LOGGER.debug("test_5_fe_getSS7")
        ss7_get = self.fe.getStationListbyProductRole('ss7').keys()
        self.assertRegexpMatches(ss7_get[0], '0-0-')

    def test_6_fe_getRT(self):
        LOGGER.debug("test_6_fe_getRT")
        rt_get = self.fe.getStationListbyProductRole('RT').keys()
        self.assertIn('0-0-2', rt_get)

    def test_7_be(self):
        LOGGER.info("test_7_be")
        self.assertEqual(self.be.stations['0-0-1'].rcsHostname, '0-0-1')
        self.assertEqual(self.be.stations['0-0-1'].middlewareRole, MIDDLEWARE_ROLE_PILOT)
        self.assertEqual(self.be.stations['0-0-2'].rcsHostname, '0-0-2')
        self.assertEqual(self.be.stations['0-0-2'].middlewareRole, MIDDLEWARE_ROLE_NONPILOT)
        self.assertEqual(self.be.stations['0-0-2'].mysqlNodeID, '4')
        self.assertEqual(self.be.stations['0-0-3'].mysqlNodeID, '6')
        self.assertListEqual(self.be.stations['0-0-2'].productRole, ['DB'])
        self.assertNotIn('RT', self.be.stations['0-0-3'].productRole)
        self.assertNotIn('ss7', self.be.stations['0-0-3'].productRole)
        self.assertNotIn('iLB', self.be.stations['0-0-3'].productRole)
        self.assertEqual(self.be.stations['0-0-2'].ddmHostname, 'STATION_D')

    def test_8_be_getDB(self):
        LOGGER.info("test_8_be_getDB")
        db_get = self.be.getStationListbyProductRole('DB').keys()
        self.assertIn('0-0-2', db_get)

    def test_9_be_getallStations(self):
        LOGGER.info("test_9_be_getallStations")
        stations_get = self.be.getAllBlade().keys()
        self.assertIn('0-0-2', stations_get)
        self.assertIn('0-0-1', stations_get)

    def test_10_fe_getiLB_ROUZIC(self):

        if self.fe2.hardware == "ROUZIC" :
            LOGGER.info("test_10_fe_getiLB_ROUZIC : " + str(self.fe2.hardware))
            iLBList = ['0-0-7', '0-0-8']
            iLB_get = self.fe2.getStationListbyProductRole('iLB').keys()
            self.assertListEqual(iLBList, iLB_get)

    def test_11_fe_getallStations_ROUZIC(self):
        if self.fe2.hardware == "ROUZIC" :
            stations_get = self.fe2.getAllBlade().keys()
            self.assertNotIn('0-0-7', stations_get)

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
