#!/bin/bash

#In case there are more than one top file for one station, we use the latest one.
vmstat_file=`ls -lrt vmstat_*|tail -1|awk '{print $9}'`
cat $vmstat_file | grep -v proc | grep -v r > tmp
awk 'BEGIN { print "AvgRunQue\tMaxRunQue"; max=0 } {avg+=$1; if ( $1 > max) max=$1; num++; next;} END { printf "%d\t%d\n", avg/num, max } ' tmp > runque.xls  
rm tmp
