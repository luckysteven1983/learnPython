"""
This library contains a log parser utility. 
"""
