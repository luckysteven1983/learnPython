"""
Created on August 26, 2015

@author: Qinqin FAN
# no test sheet found
"""

import os

from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import SPA_TIMEOUT_SMALL


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)
OAMGSUITE_PROCESS_NAME = "OamGSUITE"

class fc3955_restart_oam_process_fe_swo_mated_pair(SDMTestCase):
    "Test restart oam process on FE and swo mated pair"

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results

        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()

    def test_restart_oam_process_fe_swo_mated_pair(self):
        """
        ' Test restart oam process on FE and swo mated pair '
        What it does : kill the oam process on FE (and wait for it to recover) while swo mated pair
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case ...")
        # Get BE list
        beObjs = self.testEnv.testBed.getLabsInNRG("1")
        # Get a FE
        feObj = self.allFEs[0]
        LOGGER.debug("FE name: %s", feObj.id)
        # Get FE active pilote
        feObjActivePilot = self.mcasMachineManager.getActivePilot(feObj)

        # Run multiple tasks: kill OAM process and swo mated pair.
        LOGGER.info("Kill OAM SPA and BE switch-over in progress")
        multiTasksManager = self.sdmManager.multiTasksManager
        threadName = multiTasksManager.register(self.mcasApplicationManager.killOamAndWaitRecover,
                                                feObj, feObjActivePilot, OAMGSUITE_PROCESS_NAME, SPA_TIMEOUT_SMALL)
        LOGGER.info("Kill OAM process on Lab '%s' in progress -> thread ID '%s'", feObj.id, threadName)
        threadName = multiTasksManager.register(self.databaseManager.matedPairSwo, beObjs)
        LOGGER.info("BE switch-over on Lab '%s' in progress -> thread ID '%s'", [be.id for be in beObjs], threadName)

        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, beObjs[0])
        LOGGER.info("Kill OAM process on '%s' and BE switch-over on '%s'", feObj.id, [be.id for be in beObjs])

        if not multiTasksManager.runMultiTasks():
            raise Exception("Killing OAM process or BE switch-over failure")

        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case postcheck"""
        LOGGER.debug("test case post check")

        expectedAlarmsSpecific = []
        acceptedAlarmsSpecific = []
        expectedAlarms4BE = []
        acceptedAlarms4BE = []
        expectedAlarms4FE = []
        acceptedAlarms4FE = []
        exceptMsg = str()

        myAlarmsConfig4FE = AlarmsConfig(expectedAlarms4FE, acceptedAlarms4FE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4FE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep
        masterBE = self.databaseStateManager.getMasterBE(self.allBEs)
        for labIndex in self.allBEs:
            if labIndex in masterBE:
                myAlarmsConfig4BE = AlarmsConfig(expectedAlarmsSpecific, acceptedAlarmsSpecific, startTime)
            else:
                myAlarmsConfig4BE = AlarmsConfig(expectedAlarms4BE, acceptedAlarms4BE, startTime)
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
