"""
@file jenkins_worker_su_test_once
@ingroup SDMSQA
@author Andy SUN
@date 2015-06-12
@brief Test fucntions in jekins_worker_su.py
@detail

Test all functions provided in jekins_worker_su.py. After new fucntions are added in
jekins_worker_su.py, the file should be updated for UT.
"""

import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class jenkins_worker_su_test_once(SDMTestCase):
    """Unit test for jenkins_worker_su.py
    """

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results

    def test_01_Access_TestEnv(self):
        """Verify testEnv parameter for jenkins_worker_su.py can be accessed from here"""
        LOGGER.info("[Test Case 01] Test env parameter can be accessed from here")
        myLabs = [labName for labName in self.testEnv.testBed.labs]
        LOGGER.info("My test labs: %s", str(myLabs))

    def test_02_Access_SDM_SU_Manager(self):
        """Verify sdm su manager parameter for jenkins_worker_su.py can be accessed from here"""
        LOGGER.info("[Test Case 02] Test sdm su manager parameter can be accessed from here")
        LOGGER.info("My sdm su manager object: %s", self.sdmManager.sdmSuManager.__class__.__name__)

    def test_03_Access_SDM_SU_Manager(self):
        """Verify labs parameter for jenkins_worker_su.py can be accessed from here"""
        LOGGER.info("[Test Case 03] Test labs parameter can be accessed from here")
        if self.testLabs:
            LOGGER.info("My test labs: %s", self.testLabs)
        else:
            LOGGER.warning("No specific labs")

    def test_04_Ini_File_parser(self):
        """Parser ini parameter file"""
        LOGGER.info("[Test Case 04] Parse parameter file")
        LOGGER.info("DEFAULT parameter: %s", str(self.testParams))

if __name__ == "__main__":
    unittest.main()

