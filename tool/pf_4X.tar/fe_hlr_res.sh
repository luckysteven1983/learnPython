#!/bin/bash

function hlrFilter {
gawk '
$0 ~ /Measurement for table SDM_MEAS_LOAD_STATION_HLT/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}

file=`ls -lrt meas*|tail -1|awk '{print $9}'`
cat $file | hlrFilter > PDLSU
#This is the sample interval of measurements table. Unit: seconds
sampleInt=`cat PDLSU| grep "Expected Duration:"|awk '{ print $4 }'|tail -1`

function pdluNumFilter {
gawk '
BEGIN { max=0 }
($0 ~ /Duration/) { flag=1; count=0 }
($1=="'"$sampleInt"'") && (flag==1) { count=count+1; if ( count > max) max=count; }
($0 ~ /^$/)  { flag=0 }
END { print max }
'
}

data_no=`cat PDLSU|pdluNumFilter|tail -1`

k=1 
for key in STATION_ID  TC_QUEUE_LENGTH_MEAN CPA_NUM_MAX CTXDIAL_NUM_MEAN RTDMSE1_THREAD_NUM_MAX RTDMSE0_JOB_NUM_MEAN SSN6_QUEUE_LENGTH_MEAN SSN9_QUEUE_LENGTH_MAX TC_PROCESS_TIME_MAX CKW_PROCESS_TIME_MEAN RTDMSE_ACTIVITIES_MAX TC_CANCEL_MEAN RTDMSE_PROCESS_TIME_MAX 
do 
   grep -A $data_no -w $key PDLSU | head -1 |awk '{print $1 "\t" $2 "\t" $3}'> ${k}.txt
   grep -A $data_no -w $key PDLSU |grep -v "\-\-" |grep -v $key |awk '{print $1 "\t" $2 "\t" $3}' >> ${k}.txt
   let k++
done

grep -A $data_no -w OB_HLR_USSD_CPA_Num_MEAN PDLSU |head -1 |awk '{print $1}'> 14.txt
grep -A $data_no -w OB_HLR_USSD_CPA_Num_MEAN PDLSU |grep -v "\-\-" |grep -v OB_HLR_USSD_CPA_Num_MEAN |awk '{print $1 "\t" $2 }' >> 14.txt


paste 1.txt 2.txt 3.txt 4.txt 5.txt 6.txt 7.txt 8.txt 9.txt 10.txt 11.txt 12.txt 13.txt 14.txt> pdlsu_g2.txt
rm 1.txt 2.txt 3.txt 4.txt 5.txt 6.txt 7.txt 8.txt 9.txt 10.txt 11.txt 12.txt 13.txt 14.txt PDLSU

head -1 pdlsu_g2.txt|awk '{printf "TYPE\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",  $11, $12, $13, $14, $15, $16, $17, $18,$31, $32,$37,$38 }' >  fe_g2_meas.result

cat pdlsu_g2.txt |sed -n '2,$p' > pdlsu_g2.tmp
RTDMSE0_THREAD_NUM_MAX=`sort -k11 -n pdlsu_g2.tmp|tail -1|awk '{print $11}'`
RTDMSE0_THREAD_NUM_MEAN=`awk '{ avg+=$12; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
RTDMSE1_THREAD_NUM_MAX=`sort -k13 -n pdlsu_g2.tmp|tail -1|awk '{print $13}'`
RTDMSE1_THREAD_NUM_MEAN=`awk '{ avg+=$14; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
RTDMSE0_JOB_NUM_MAX=`sort -k15 -n pdlsu_g2.tmp|tail -1|awk '{print $15}'`
RTDMSE0_JOB_NUM_MEAN=`awk '{ avg+=$16; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
RTDMSE1_JOB_NUM_MAX=`sort -k17 -n pdlsu_g2.tmp|tail -1|awk '{print $17}'`
RTDMSE1_JOB_NUM_MEAN=`awk '{ avg+=$18; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
RTDMSE_ACTIVITIES_MAX=`sort -k31 -n pdlsu_g2.tmp|tail -1|awk '{print $31}'`
RTDMSE_ACTIVITIES_MEAN=`awk '{ avg+=$32; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
RTDMSE_PROCESS_TIME_MAX=`sort -k37 -n pdlsu_g2.tmp|tail -1|awk '{print $37}'`
RTDMSE_PROCESS_TIME_MEAN=`awk '{ avg+=$38; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`

rm pdlsu_g2.tmp
printf "%5s\t%-23d\t%-24d\t%-23d\t%-24d\t%-20d%-21d\t%-20d\t%-21d\t%-21d\t%-22d\t%-23d%-24d\n", "PDLSU"  $RTDMSE0_THREAD_NUM_MAX $RTDMSE0_THREAD_NUM_MEAN $RTDMSE1_THREAD_NUM_MAX $RTDMSE1_THREAD_NUM_MEAN $RTDMSE0_JOB_NUM_MAX $RTDMSE0_JOB_NUM_MEAN $RTDMSE1_JOB_NUM_MAX $RTDMSE1_JOB_NUM_MEAN $RTDMSE_ACTIVITIES_MAX $RTDMSE_ACTIVITIES_MEAN $RTDMSE_PROCESS_TIME_MAX $RTDMSE_PROCESS_TIME_MEAN  >>fe_g2_meas.result

head -1 pdlsu_g2.txt|awk '{printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n","RTDMSE0_THREAD_NUM_MAX", "RTDMSE0_THREAD_NUM_MEAN", "RTDMSE1_THREAD_NUM_MAX","RTDMSE1_THREAD_NUM_MEAN","RTDMSE0_JOB_NUM_MAX","RTDMSE0_JOB_NUM_MEAN","RTDMSE1_JOB_NUM_MAX","RTDMSE1_JOB_NUM_MEAN","RTDMSE_ACTIVITIES_MAX","RTDMSE_ACTIVITIES_MEAN","RTDMSE_PROCESS_TIME_MAX","RTDMSE_PROCESS_TIME_MEAN"}' > pdlsu_g2_meas.xls

echo -e "$RTDMSE0_THREAD_NUM_MAX\t$RTDMSE0_THREAD_NUM_MEAN\t$RTDMSE1_THREAD_NUM_MAX\t$RTDMSE1_THREAD_NUM_MEAN\t$RTDMSE0_JOB_NUM_MAX\t$RTDMSE0_JOB_NUM_MEAN\t$RTDMSE1_JOB_NUM_MAX\t$RTDMSE1_JOB_NUM_MEAN\t$RTDMSE_ACTIVITIES_MAX\t$RTDMSE_ACTIVITIES_MEAN\t$RTDMSE_PROCESS_TIME_MAX\t$RTDMSE_PROCESS_TIME_MEAN" >> pdlsu_g2_meas.xls 


cat fe_g2_meas.result



