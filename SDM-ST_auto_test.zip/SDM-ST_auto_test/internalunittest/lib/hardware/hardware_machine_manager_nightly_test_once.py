'''

Created on Jun 11, 2015

@author: S Beaufils

Modified Jul 22, 2015
Tangi Lavanant (VMMHI support)

Restart a random board of lab(s). Random board is chosen in non-pilot boards

'''
import random
import unittest
from framework.sdm_test_case import SDMTestCase
from lib.hardware.hardware_machine_manager import HardwareMachineManager, HardwareMachineManagerError, StateHW
from lib.platform.mcas.mcas_machine_manager import PILOT_RECOVER_TIMEOUT, MACHINE_STATUS_CHECK_INTERVAL
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class hardware_machine_manager_nightly_test_once(SDMTestCase):
    '''
    test_once for restart board function
    '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.hostFE = self.testEnv.testBed.getFrontends().popitem()
        self.hostBE = self.testEnv.testBed.getBackends()
        self.lab = self.hostFE
        self.hardwareManager = self.sdmManager.hardwareManagerFactory.createHardwareManager(self.hostFE)

    def test_GetBoardStatus(self):
        '''
        Get the status of a board
        We suppose the board is powered on
        '''
        LOGGER.info("Get the status of a board")
        npMach = self.sdmManager.mcasMachineManager.getMachinesList(self.hostFE)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        LOGGER.info(' Get status of board ' + boardN + ' on ' + self.hostFE.id)

        _output = self.hardwareManager.getHardwareState(self.hostFE, boardN)
        _msg = ("Board " + boardN + " on " + self.hostFE.id + " is  not powered on")
        CommonAssert.assertEqual(_output, StateHW.BOARD_POWERED_ON, _msg, 'error')
        LOGGER.info("Board " + boardN + " on " + self.hostFE.id + " is powered on")

    def test_GetBoardStatusRAW(self):
        '''
        Get the status of a board in RAW mode
        Result depends on Hardware
        '''
        LOGGER.info("Get the status of a board")
        npMach = self.sdmManager.mcasMachineManager.getMachinesList(self.hostFE)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        LOGGER.info(' Get status of board ' + boardN + ' on ' + self.hostFE.id)

        _output = self.hardwareManager.getHardwareStateRAW(self.hostFE, boardN)
        LOGGER.info("Board " + boardN + " on " + self.hostFE.id + " RAW status is : " + _output)

    def test_vmmhiList(self):
        '''
        list vmmhi boards
        '''
        if self.lab.hardware == 'VMMHI':
            LOGGER.info("Specific test for VMMHI")
            output = self.hardwareManager.vmmhiStatus(self.lab)
            LOGGER.debug(output)
        else:
            LOGGER.info("Specific test for VMMHI, not performed on " + self.lab.hardware)

    def test_implementationError(self):
        '''
        restart a random  non-pilot board of self.lab
        '''
        npMach = self.sdmManager.mcasMachineManager.getMachinesNonPilot(self.lab)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        LOGGER.info(' >>>> restarting board ' + boardN + ' on ' + self.lab.id + ' with ImplementationError')

        sshmngr = SshManager()

        # --- creates the instance of the super class
        hardwareManager = HardwareMachineManager(sshmngr, self.sdmManager.mcasMachineManager)

        # try to execute the restart board . Which will cause an exception :
        try:
            hardwareManager.restartBoard(self.lab, boardN)
        except NotImplementedError as exc:
            LOGGER.error("Expected Error : " + exc.message)


    def test_boardNumberError(self):
        '''
        restart a non existent board
        '''
        # npMach = self.sdmManager.mcasMachineManager.getMachinesNonPilot(self.lab)
        # --- choose the second one of the list : random
        boardN = '44'
        LOGGER.info(' >>>> restarting board ' + boardN + ' on ' + self.lab.id + ' with wrong board number ')

        # try to execute the restart board . Which will cause an exception :
        try:
            self.hardwareManager.restartBoard(self.lab, boardN)
        except HardwareMachineManagerError as exc:
            LOGGER.error(" Error : " + exc.message)

    def test_restart_active_pilot(self):
        """Restart active pilot on ATCA
        """
        LOGGER.info("Test restarting active pilot")
        activePilot = self.sdmManager.mcasMachineManager.getActivePilot(self.lab)
        LOGGER.debug("Active pilot %s", activePilot)
        if self.lab.hardware in ['ROUZIC', 'BONO24', 'BONO48', 'HPG6', 'HPG8']:
            self.hardwareManager.restartBoard(self.lab, activePilot.split('-')[-1])
            CommonAssert.timedAssert(PILOT_RECOVER_TIMEOUT, MACHINE_STATUS_CHECK_INTERVAL,
                                 self.sdmManager.mcasMachineManager.checkMachineStatus,
                                 self.lab, logLevel='debug')
        else:
            LOGGER.warning("Only Support to restart active pilot on ATCA and HP lab now")

    def tearDown(self):
        """Lab Recovery"""
        # recover lab in case of the lab is broken by test case.
        LOGGER.info('Recover lab if necessary')
        self.sdmManager.labRecover.machineRecover(self.lab)

if __name__ == "__main__":

    unittest.main()
