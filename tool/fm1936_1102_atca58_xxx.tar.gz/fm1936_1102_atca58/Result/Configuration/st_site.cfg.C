IsMainNrg = true
StationRank = 3
