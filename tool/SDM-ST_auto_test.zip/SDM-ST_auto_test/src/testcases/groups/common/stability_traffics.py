"""
Created on May 23, 2015

@author: Nicolas Aubourg
"""

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
import time
import lib.exceptions_messages as msgs
import os
from framework.common import Utils


logger = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

BUILD_ID = os.getenv("BUILD_ID", "0000-00-00 00:00:00")

class stability_traffics(SDMTestCase):


    def setUp(self):
        logger.debug("testStabilityTraffic:setUp")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.success = True
        self.exceptMsg = ""


    def testStabilityTraffic(self):
        """
        Check the traffic stability for a given number of minutes.
        A QoS check is done every 5 minutes. Nothing is displayed unless the number of errors has increased.
        At the end of the test, a final QoS check is done. If it doesn't meet the required QoS, the test will
        be set to failed.
        A check cores and check alarms is also done.
        """
        logger.debug("testStabilityTraffic:main")
        trafficManager = self.sdmManager.trafficManager

        if len(trafficManager.startedTraffics) != 0:
            _, fe = self.testEnv.testBed.getFrontends().popitem()
            startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
            self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0], checkQoS=False)
            timerTraffic = int(self.timerStabilityTraffic)  # pylint: disable=no-member
            if timerTraffic < 5:
                # do one loop at least
                timerTraffic = 5
            durationHours = timerTraffic / 60
            durationMinutes = timerTraffic % 60
            durationText = str(durationHours) + "h" + str(durationMinutes) + "min"
            logger.info("Stability launch for  " + durationText + "...")
            logger.info("Verifying QoS every 5 min. Will only display traffic QoS if #errors has increased...")
            nbLoop = timerTraffic / 5
            i = 1
            while i <= nbLoop:
                time.sleep(300)
                if i == nbLoop:
                    logger.info("\n\n*****************************************\nTraffic duration: " +
                                durationText + " - Final QoS:\n" +
                                "*****************************************\n")
                for myTraffic in trafficManager.startedTraffics:
                    badQoS = False
                    try:
                        myTraffic.checkGlobalQoS()
                    except BaseException as ex:
                        if msgs.TRAFFIC_BAD_QOS in ex.message:
                            badQoS = True
                        else:
                            raise ex

                    # check if nb errors increased since previous check or if last loop
                    if i == nbLoop or myTraffic.getErrorStatus():
                        if i <> nbLoop:
                            logger.info("loop #" + str(i) + " (" + str(i * 5) + " min):")
                        trafficCounters = myTraffic.getCountersString()
                        if badQoS:
                            text = "Bad QoS: " + trafficCounters + " for " + myTraffic.trafficInfo
                            logger.error(text)
                            if i == nbLoop:
                                # A bad QoS will set testcase to failed
                                self.success = False
                                self.exceptMsg += " " + text
                        else:
                            logger.info(trafficCounters + " for " + myTraffic.trafficInfo)
                i += 1
            # end while

            logger.info("\n*****************************************\n\n" +
                        "End of stability test")
            logger.debug("Checking the end status of the test case")
            try:
                # Capture final alarms & additional check
                self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkQoS=False)
            except BaseException, msg:
                self.success = False
                self.exceptMsg += str(msg)
                logger.error("%s: assertEndState failed:", str(msg))

            if self.success:
                logger.info("Stability traffics successful!\n")
            else:
                logger.error("Stability traffics failed!\n")
                logger.error(self.exceptMsg)
                raise Exception(self.exceptMsg)

        else:
            # no traffic started
            logger.error(msgs.TRAFFIC_MANAGER_TRAFFIC_NOT_STARTED)
            raise Exception(msgs.TRAFFIC_MANAGER_TRAFFIC_NOT_STARTED)
