"""Framework log format test case"""
