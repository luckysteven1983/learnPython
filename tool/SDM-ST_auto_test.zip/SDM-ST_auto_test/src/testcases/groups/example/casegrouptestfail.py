'''
Created on July 23, 2015

@author: Qinqin FAN
'''

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)

class casegrouptestfail(SDMTestCase):
    '''This class defines tests'''

    def setUp(self):
        LOGGER.debug("setUp")
        LOGGER.debug("testEnv id: %s", self.testEnv.id)

    def tearDown(self):
        LOGGER.debug("tearDown")

    def test_case(self):
        ''' This is a basic test'''
        LOGGER.info("case in group 1")
        raise Exception("test case fail")
