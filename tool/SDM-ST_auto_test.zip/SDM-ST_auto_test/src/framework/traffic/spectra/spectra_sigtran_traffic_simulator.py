"""
@file
Created on July 3, 2015
@ingroup SDMSQA Automation
@author Zhao Junming
@brief Defines SpectraSIGTRANTrafficSimulator class
"""

from framework.traffic.sigtran_traffic_simulator import SIGTRANTrafficSimulator

class SpectraSIGTRANTrafficSimulator(SIGTRANTrafficSimulator):
    """
    @details This class describes a Spectra traffic as defined in configuration.xml.
    """

    def __init__(self):
        """
        SpectraSIGTRANTrafficSimulator class constructor
        """
        super(SpectraSIGTRANTrafficSimulator,self).__init__()
        self.trafficProfileId = ""
        self.ftpAccount = None
        self.workspace = None
