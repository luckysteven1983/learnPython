"""
@file logparser_sunnyday_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-03-03
@brief Sunny day test cases for lib McasLogParser
"""

import unittest
import re
from lib.logparser.mcas_log_parser import McasLogParser
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase

logger = Logger.getLogger(__name__)

class logparser_sunnyday_nightly_test_once(SDMTestCase):
    """Unit test for McasLogParser class.

    All test cases are for lineFilter method.
    """

    def setUp(self):
        """Test file: Testlog0, Testlog1, Testlog2, Testlog3, Testlog4, Testlog5

        The sorted file: Testlog5, Testlog1, Testlog0, Testlog2, Testlog4,
        Testlog3. And the timestamp range is:

        Testlog5: '2012-12-24 21:34:34' ~ '2012-12-24 22:00:00'
        Testlog1: '2013-12-24 21:34:34' ~ '2013-12-24 22:00:00'
        Testlog0: '2014-12-24 21:34:34' ~ '2014-12-24 22:00:00'
        Testlog2: '2014-12-24 22:00:00' ~ '2014-12-24 22:00:00'
        Testlog4: '2014-12-24 22:00:00' ~ '2015-03-24 22:00:01'
        Testlog3: '2015-03-24 22:00:02' ~ '2015-03-24 23:10:00'
        """
        self._prefix = 'Testlog'
        self._logParser = McasLogParser('internalunittest/lib/logparser/test_files')

    def test_01_NoLogContent(self):
        """No log content between given timestamps.

        If No log content is found between given timestamps, Empty list will be
        returned by lineFilter.
        """
        logger.debug('\n[Test case 01] No log content between given timestamps.')

        # The empyt list will be returned for the following cases.
        # 1. the begining time is beyond the end time.
        # 2. the begining time is beyond the last time in log file
        # 3. the end time is earlier than the first time in log file
        case1 = self._logParser.lineFilter(self._prefix, '.*',
                                '2013-12-24 21:34:41', '2013-12-24 21:34:40')
        case2 = self._logParser.lineFilter(self._prefix, '.*',
                                bTime='2015-03-24 23:10:01')
        case3 = self._logParser.lineFilter(self._prefix, '.*',
                                eTime='2012-12-24 21:34:33')
        self.assertFalse(case1)
        self.assertFalse(case2)
        self.assertFalse(case3)

    def test_02_FirstLogFile(self):
        """The timestamp is located in the first log file (Testlog5)."""
        logger.debug('\n[Test case 02] The timestamp in first log file.')

        # No content match
        emptyList = self._logParser.lineFilter(self._prefix, 'nosuchline in Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertFalse(emptyList)
        emptyList = self._logParser.lineFilter(self._prefix, 'nosuchline in Testlog5',
                                eTime='2012-12-24 21:59:59')
        self.assertFalse(emptyList)

        # Match 'In File Testlog5' and the number of matched line is 27
        matchedList = self._logParser.lineFilter(self._prefix, 'In File Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertEqual(len(matchedList), 27)

        # Match 'in the first' in Testlog5 and the matched lines are 3
        matchedList = self._logParser.lineFilter(self._prefix, 'in the first',
                                eTime='2012-12-24 21:59:59')
        self.assertEqual(len(matchedList), 3)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog5'))

        # Match 'the first line log' in Testlog5 and the number of line is 6
        matchedList = self._logParser.lineFilter(self._prefix, 'the first line log',
                                '2012-12-24 21:34:40', '2012-12-24 21:34:52')
        self.assertEqual(len(matchedList), 6)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog5'))

        # Match '.*' in Testlog5 and the number of line is 30
        matchedList = self._logParser.lineFilter(self._prefix, '.*',
                                '2012-12-24 21:34:34', '2012-12-24 22:00:00')
        # skip empty line
        matchedList = [line for line in matchedList if line.strip()]
        self.assertEqual(len(matchedList), 30)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog5'))

        # Match 'line log' in Testlog5 and the number of line is 30
        matchedList = self._logParser.lineFilter(self._prefix, 'line log',
                                '2012-12-24 21:34:33', '2012-12-24 22:00:01')
        self.assertEqual(len(matchedList), 30)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog5'))

        # Match 'line log' in Testlog5 and the number of line is 30
        matchedList = self._logParser.lineFilter(self._prefix, 'line log',
                                eTime='2012-12-24 22:00:01')
        self.assertEqual(len(matchedList), 30)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog5'))

    def test_03_OneMiddleLogFile(self):
        """The timestamp is located in one middle log file (Testlog1)."""
        logger.debug('\n[Test case 03] The timestamp in one middle log file.')

        # No content match
        emptyList = self._logParser.lineFilter(self._prefix, 'nosuchline in Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertFalse(emptyList)

        # Match 'In File Testlog1' and the number of matched line is 27
        matchedList = self._logParser.lineFilter(self._prefix, 'In File Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertEqual(len(matchedList), 27)

        # Match 'the first line log' in Testlog1 and the number of line is 6
        matchedList = self._logParser.lineFilter(self._prefix, 'the first line log',
                                '2013-12-24 21:34:40', '2013-12-24 21:34:52')
        self.assertEqual(len(matchedList), 6)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog1'))

        # Match '.*' in Testlog1 and the number of line is 30
        matchedList = self._logParser.lineFilter(self._prefix, '.*',
                                '2013-12-24 21:34:34', '2013-12-24 22:00:00')
        # skip empty line
        matchedList = [line for line in matchedList if line.strip()]
        self.assertEqual(len(matchedList), 30)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog1'))

        # Match 'line log' in Testlog1 and the number of line is 30
        matchedList = self._logParser.lineFilter(self._prefix, 'line log',
                                '2013-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertEqual(len(matchedList), 30)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog1'))

    def test_04_LastLogFile(self):
        """The timestamp is located in last log file (Testlog3)."""
        logger.debug('\n[Test case 04] The timestamp in last log file.')

        # No content match
        emptyList = self._logParser.lineFilter(self._prefix, 'nosuchline in Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertFalse(emptyList)
        emptyList = self._logParser.lineFilter(self._prefix, 'nosuchline in Testlog3',
                                bTime='2015-03-24 22:00:02')
        self.assertFalse(emptyList)

        # Match 'In File Testlog3' and the number of matched line is 9
        matchedList = self._logParser.lineFilter(self._prefix, 'In File Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:01:00')
        self.assertEqual(len(matchedList), 9)

        # Match 'the first line log' in Testlog3 and the number of line is 2
        matchedList = self._logParser.lineFilter(self._prefix, 'the first line log',
                                '2015-03-24 23:00:00', '2015-03-24 23:01:00')
        self.assertEqual(len(matchedList), 2)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog3'))

        # Match '.*' in Testlog3 and the number of line is 12
        matchedList = self._logParser.lineFilter(self._prefix, '.*',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        # skip empty line
        matchedList = [line for line in matchedList if line.strip()]
        self.assertEqual(len(matchedList), 12)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog3'))

        # Match 'line log' in Testlog3 and the number of line is 12
        matchedList = self._logParser.lineFilter(self._prefix, 'line log',
                                bTime='2015-03-24 22:00:01')
        self.assertEqual(len(matchedList), 12)
        for line in matchedList:
            self.assertTrue(line.strip().startswith('In File Testlog3'))

    def test_05_MultiLogFiles(self):
        """The timestamp is located in multiple log files."""
        logger.debug('\n[Test case 05] The timestamp in multiple log files.')

        # Match 'In File Testlog' in Testlog5 and Testlog1. And the number of
        # line is 60
        matchedList1 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                eTime='2013-12-24 22:00:01')
        matchedList2 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                eTime='2013-12-24 22:00:00')
        matchedList3 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34', '2013-12-24 22:00:00')
        matchedList4 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertEqual(len(matchedList1), 60)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)
        self.assertListEqual(matchedList3, matchedList4)
        pattern = re.compile('Testlog[51]')
        for line in matchedList1:
            self.assertRegexpMatches(line, pattern)

        # Match 'In File Testlog' in Testlog1 and Testlog0. And the number of
        # line is 57
        matchedList1 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2013-12-24 21:34:33', '2014-12-24 21:36:01')
        matchedList2 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2013-12-24 21:34:34', '2014-12-24 21:36:00')
        self.assertEqual(len(matchedList1), 57)
        self.assertListEqual(matchedList1, matchedList2)
        pattern = re.compile('Testlog[10]')
        for line in matchedList1:
            self.assertRegexpMatches(line, pattern)

        # Match 'In File Testlog' in Testlog0, Testlog2 and Testlog4. And the
        # number of line in Testlog0 is 3, that in Testlog2 is 30 and that in
        # Test log4 is 3
        matchedList1 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2014-12-24 22:00:00')
        self.assertEqual(len(matchedList1), 36)
        pattern = re.compile('Testlog0.*in the tenth timeslot')
        for line in matchedList1[0:3]:
            self.assertRegexpMatches(line, pattern)
        pattern = re.compile('Testlog2')
        for line in matchedList1[3:33]:
            self.assertRegexpMatches(line, pattern)
        pattern = re.compile('Testlog4.*in the first timeslot')
        for line in matchedList1[33:]:
            self.assertRegexpMatches(line, pattern)

        # Match 'In File Testlog' in Testlog0, Testlog2, Testlog4 and Testlog3.
        # And the number of line is 75
        matchedList1 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00')
        matchedList2 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:00')
        matchedList3 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:01')
        self.assertEqual(len(matchedList1), 75)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)

        # Match 'in the first timeslot' in Testlog0, Testlog2, Testlog4 and
        # Testlog3. And the number of line is 9
        matchedList1 = self._logParser.lineFilter(self._prefix, 'the first timeslot',
                                '2014-12-24 22:00:00')
        matchedList2 = self._logParser.lineFilter(self._prefix, 'the first timeslot',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:00')
        matchedList3 = self._logParser.lineFilter(self._prefix, 'in the first timeslot',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:01')
        self.assertEqual(len(matchedList1), 9)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)

    def test_06_FullLogFiles(self):
        """The timestamp is located in full log files."""
        logger.debug('\n[Test case 06] The timestamp in full log files.')

        # Match 'In File Testlog' in full log files and the number of line is
        # 162
        matchedList1 = self._logParser.lineFilter(self._prefix, 'In File Testlog')
        matchedList2 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34')
        matchedList3 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33')
        matchedList4 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                eTime='2015-03-24 23:10:00')
        matchedList5 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                eTime='2015-03-24 23:10:01')
        matchedList6 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34', '2015-03-24 23:10:00')
        matchedList7 = self._logParser.lineFilter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33', '2015-03-24 23:10:01')
        self.assertEqual(len(matchedList1), 162)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)
        self.assertListEqual(matchedList3, matchedList4)
        self.assertListEqual(matchedList4, matchedList5)
        self.assertListEqual(matchedList5, matchedList6)
        self.assertListEqual(matchedList6, matchedList7)

    def test_07_NoLogContent(self):
        """No log content between given timestamps.

        If No log content is found between given timestamps, False will be
        returned by lineContains.
        """
        logger.debug('\n[Test case 07] No log content between given timestamps.')

        # The empyt list will be returned for the following cases.
        # 1. the begining time is beyond the end time.
        # 2. the begining time is beyond the last time in log file
        # 3. the end time is earlier than the first time in log file
        case1 = self._logParser.lineContains(self._prefix, '.*',
                                '2013-12-24 21:34:41', '2013-12-24 21:34:40')
        case2 = self._logParser.lineContains(self._prefix, '.*',
                                bTime='2015-03-24 23:10:01')
        case3 = self._logParser.lineContains(self._prefix, '.*',
                                eTime='2012-12-24 21:34:33')
        self.assertFalse(case1)
        self.assertFalse(case2)
        self.assertFalse(case3)

    def test_08_FirstLogFile(self):
        """The timestamp is located in the first log file (Testlog5)."""
        logger.debug('\n[Test case 08] The timestamp in first log file.')

        # No content match
        bFalse = self._logParser.lineContains(self._prefix, 'nosuchline in Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertFalse(bFalse)
        bFalse = self._logParser.lineContains(self._prefix, 'nosuchline in Testlog5',
                                eTime='2012-12-24 21:59:59')
        self.assertFalse(bFalse)

        # Match 'In File Testlog5' in Testlog5
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertTrue(bTrue)

        # Match 'in the first' in Testlog5.
        bTrue = self._logParser.lineContains(self._prefix, 'in the first',
                                eTime='2012-12-24 21:59:59')
        self.assertTrue(bTrue)

        # Match 'the first line log' in Testlog5.
        bTrue = self._logParser.lineContains(self._prefix, 'the first line log',
                                '2012-12-24 21:34:40', '2012-12-24 21:34:52')
        self.assertTrue(bTrue)

        # Match '.*' in Testlog5.
        bTrue = self._logParser.lineContains(self._prefix, '.*',
                                '2012-12-24 21:34:34', '2012-12-24 22:00:00')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog5.
        bTrue = self._logParser.lineContains(self._prefix, 'line log',
                                '2012-12-24 21:34:33', '2012-12-24 22:00:01')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog5.
        bTrue = self._logParser.lineContains(self._prefix, 'line log',
                                eTime='2012-12-24 22:00:01')
        self.assertTrue(bTrue)
        bFalse = self._logParser.lineContains(self._prefix, '(line log.*){3}',
                                eTime='2012-12-24 22:00:01')
        self.assertFalse(bFalse)

    def test_09_OneMiddleLogFile(self):
        """The timestamp is located in one middle log file (Testlog1)."""
        logger.debug('\n[Test case 09] The timestamp in one middle log file.')

        # No content match
        bFalse = self._logParser.lineContains(self._prefix, 'nosuchline in Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertFalse(bFalse)

        # Match 'In File Testlog1' in Testlog1.
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertTrue(bTrue)

        # Match 'the first line log' in Testlog1.
        bTrue = self._logParser.lineContains(self._prefix, 'the first line log',
                                '2013-12-24 21:34:40', '2013-12-24 21:34:52')
        self.assertTrue(bTrue)

        # Match '.*' in Testlog1.
        bTrue = self._logParser.lineContains(self._prefix, '.*',
                                '2013-12-24 21:34:34', '2013-12-24 22:00:00')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog1.
        bTrue = self._logParser.lineContains(self._prefix, 'line log',
                                '2013-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertTrue(bTrue)

    def test_10_LastLogFile(self):
        """The timestamp is located in last log file (Testlog3)."""
        logger.debug('\n[Test case 10] The timestamp in last log file.')

        # No content match
        bFalse = self._logParser.lineContains(self._prefix, 'nosuchline in Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertFalse(bFalse)
        bFalse = self._logParser.lineContains(self._prefix, 'nosuchline in Testlog3',
                                bTime='2015-03-24 22:00:02')
        self.assertFalse(bFalse)

        # Match 'In File Testlog3' in Testlog3.
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:01:00')
        self.assertTrue(bTrue)

        # Match 'the first line log' in Testlog3.
        bTrue = self._logParser.lineContains(self._prefix, 'the first line log',
                                '2015-03-24 23:00:00', '2015-03-24 23:01:00')
        self.assertTrue(bTrue)

        # Match '.*' in Testlog3 and the number of line is 12
        bTrue = self._logParser.lineContains(self._prefix, '.*',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog3.
        bTrue = self._logParser.lineContains(self._prefix, 'line log',
                                bTime='2015-03-24 22:00:01')
        self.assertTrue(bTrue)

    def test_11_MultiLogFiles(self):
        """The timestamp is located in multiple log files."""
        logger.debug('\n[Test case 11] The timestamp in multiple log files.')

        # Match 'In File Testlog' in Testlog5 and Testlog1
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                eTime='2013-12-24 22:00:01')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                eTime='2013-12-24 22:00:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34', '2013-12-24 22:00:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertTrue(bTrue)

        # Match 'In File Testlog' in Testlog1 and Testlog0.
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2013-12-24 21:34:33', '2014-12-24 21:36:01')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2013-12-24 21:34:34', '2014-12-24 21:36:00')
        self.assertTrue(bTrue)

        # Match 'In File Testlog' in Testlog0, Testlog2 and Testlog4.
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2014-12-24 22:00:00')
        self.assertTrue(bTrue)

        # Match 'In File Testlog' in Testlog0, Testlog2, Testlog4 and Testlog3.
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:01')
        self.assertTrue(bTrue)

    def test_12_FullLogFiles(self):
        """The timestamp is located in full log files."""
        logger.debug('\n[Test case 12] The timestamp in full log files.')

        # Match 'In File Testlog' in full log files.
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                eTime='2015-03-24 23:10:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                eTime='2015-03-24 23:10:01')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34', '2015-03-24 23:10:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.lineContains(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33', '2015-03-24 23:10:01')
        self.assertTrue(bTrue)

    def test_13_NoLogContent(self):
        """No log content between given timestamps.

        If No log content is found between given timestamps, Empty list will be
        returned by filter.
        """
        logger.debug('\n[Test case 13] No log content between given timestamps.')

        # The empyt list will be returned for the following cases.
        # 1. the begining time is beyond the end time.
        # 2. the begining time is beyond the last time in log file
        # 3. the end time is earlier than the first time in log file
        case1 = self._logParser.filter(self._prefix, '.*',
                                '2013-12-24 21:34:41', '2013-12-24 21:34:40')
        case2 = self._logParser.filter(self._prefix, '.*',
                                bTime='2015-03-24 23:10:01')
        case3 = self._logParser.filter(self._prefix, '.*',
                                eTime='2012-12-24 21:34:33')
        self.assertFalse(case1)
        self.assertFalse(case2)
        self.assertFalse(case3)

    def test_14_FirstLogFile(self):
        """The timestamp is located in the first log file (Testlog5)."""
        logger.debug('\n[Test case 14] The timestamp in first log file.')

        # No content match
        emptyList = self._logParser.filter(self._prefix, 'nosuchline in Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertFalse(emptyList)
        emptyList = self._logParser.filter(self._prefix, 'nosuchline in Testlog5',
                                eTime='2012-12-24 21:59:59')
        self.assertFalse(emptyList)

        # Match 'In File Testlog5' and the number of matched item is 9
        matchedList = self._logParser.filter(self._prefix, 'In File Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertEqual(len(matchedList), 9)

        # Match 'in the first' in Testlog5 and the matched item is 1
        matchedList = self._logParser.filter(self._prefix, 'in the first',
                                eTime='2012-12-24 21:59:59')
        self.assertEqual(len(matchedList), 1)
        self.assertEqual(matchedList[0].count('In File Testlog5'), 3)

        # Match 'the first line log' in Testlog5 and the number of item is 6
        matchedList = self._logParser.filter(self._prefix, 'the first line log',
                                '2012-12-24 21:34:40', '2012-12-24 21:34:52')
        self.assertEqual(len(matchedList), 6)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog5'), 3)

        # Match '.*' in Testlog5 and the number of item is 10
        matchedList = self._logParser.filter(self._prefix, '.*',
                                '2012-12-24 21:34:34', '2012-12-24 22:00:00')
        self.assertEqual(len(matchedList), 10)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog5'), 3)

        # Match 'line log' in Testlog5 and the number of item is 10
        matchedList = self._logParser.filter(self._prefix, 'line log',
                                '2012-12-24 21:34:33', '2012-12-24 22:00:01')
        self.assertEqual(len(matchedList), 10)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog5'), 3)

        # Match 'line log' in Testlog5 and the number of item is 10
        matchedList = self._logParser.filter(self._prefix, 'line log',
                                eTime='2012-12-24 22:00:01')
        self.assertEqual(len(matchedList), 10)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog5'), 3)

    def test_15_OneMiddleLogFile(self):
        """The timestamp is located in one middle log file (Testlog1)."""
        logger.debug('\n[Test case 15] The timestamp in one middle log file.')

        # No content match
        emptyList = self._logParser.filter(self._prefix, 'nosuchline in Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertFalse(emptyList)

        # Match 'In File Testlog1' and the number of matched item is 9
        matchedList = self._logParser.filter(self._prefix, 'In File Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertEqual(len(matchedList), 9)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog1'), 3)

        # Match 'the first line log' in Testlog1 and the number of item is 6
        matchedList = self._logParser.filter(self._prefix, 'the first line log',
                                '2013-12-24 21:34:40', '2013-12-24 21:34:52')
        self.assertEqual(len(matchedList), 6)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog1'), 3)

        # Match '.*' in Testlog1 and the number of item is 10
        matchedList = self._logParser.filter(self._prefix, '.*',
                                '2013-12-24 21:34:34', '2013-12-24 22:00:00')
        self.assertEqual(len(matchedList), 10)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog1'), 3)

        # Match 'line log' in Testlog1 and the number of item is 10
        matchedList = self._logParser.filter(self._prefix, 'line log',
                                '2013-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertEqual(len(matchedList), 10)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog1'), 3)

    def test_16_LastLogFile(self):
        """The timestamp is located in last log file (Testlog3)."""
        logger.debug('\n[Test case 16] The timestamp in last log file.')

        # No content match
        emptyList = self._logParser.filter(self._prefix, 'nosuchline in Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertFalse(emptyList)
        emptyList = self._logParser.filter(self._prefix, 'nosuchline in Testlog3',
                                bTime='2015-03-24 22:00:02')
        self.assertFalse(emptyList)

        # Match 'In File Testlog3' and the number of matched item is 3
        matchedList = self._logParser.filter(self._prefix, 'In File Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:01:00')
        self.assertEqual(len(matchedList), 3)

        # Match 'the first line log' in Testlog3 and the number of item is 2
        matchedList = self._logParser.filter(self._prefix, 'the first line log',
                                '2015-03-24 23:00:00', '2015-03-24 23:01:00')
        self.assertEqual(len(matchedList), 2)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog3'), 3)

        # Match '.*' in Testlog3 and the number of item is 4
        matchedList = self._logParser.filter(self._prefix, '.*',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertEqual(len(matchedList), 4)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog3'), 3)

        # Match 'line log' in Testlog3 and the number of item is 4
        matchedList = self._logParser.filter(self._prefix, 'line log',
                                bTime='2015-03-24 22:00:01')
        self.assertEqual(len(matchedList), 4)
        for line in matchedList:
            self.assertEqual(line.count('In File Testlog3'), 3)

    def test_17_MultiLogFiles(self):
        """The timestamp is located in multiple log files."""
        logger.debug('\n[Test case 17] The timestamp in multiple log files.')

        # Match 'In File Testlog' in Testlog5 and Testlog1. And the number of
        # item is 20
        matchedList1 = self._logParser.filter(self._prefix, 'In File Testlog',
                                eTime='2013-12-24 22:00:01')
        matchedList2 = self._logParser.filter(self._prefix, 'In File Testlog',
                                eTime='2013-12-24 22:00:00')
        matchedList3 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34', '2013-12-24 22:00:00')
        matchedList4 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertEqual(len(matchedList1), 20)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)
        self.assertListEqual(matchedList3, matchedList4)
        pattern = re.compile('Testlog[51]')
        for line in matchedList1:
            self.assertRegexpMatches(line, pattern)
            self.assertEqual(line.count('In File Testlog'), 3)

        # Match 'In File Testlog' in Testlog1 and Testlog0. And the number of
        # item is 19
        matchedList1 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2013-12-24 21:34:33', '2014-12-24 21:36:01')
        matchedList2 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2013-12-24 21:34:34', '2014-12-24 21:36:00')
        self.assertEqual(len(matchedList1), 19)
        self.assertListEqual(matchedList1, matchedList2)
        pattern = re.compile('Testlog[10]')
        for line in matchedList1:
            self.assertRegexpMatches(line, pattern)
            self.assertEqual(line.count('In File Testlog'), 3)

        # Match 'In File Testlog' in Testlog0, Testlog2 and Testlog4. And the
        # number of item in Testlog0 is 1, that in Testlog2 is 10 and that in
        # Test log4 is 1
        matchedList1 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2014-12-24 22:00:00')
        self.assertEqual(len(matchedList1), 12)
        pattern = re.compile('Testlog0.*in the tenth timeslot')
        self.assertRegexpMatches(matchedList1[0], pattern)
        self.assertEqual(matchedList1[0].count('Testlog0'), 3)
        pattern = re.compile('Testlog2')
        for line in matchedList1[1:11]:
            self.assertRegexpMatches(line, pattern)
            self.assertEqual(line.count('Testlog2'), 3)
        pattern = re.compile('Testlog4.*in the first timeslot')
        self.assertRegexpMatches(matchedList1[-1], pattern)
        self.assertEqual(matchedList1[-1].count('Testlog4'), 3)

        # Match 'In File Testlog' in Testlog0, Testlog2, Testlog4 and Testlog3.
        # And the number of item is 25
        matchedList1 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00')
        matchedList2 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:00')
        matchedList3 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:01')
        self.assertEqual(len(matchedList1), 25)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)

        # Match 'in the first timeslot' in Testlog0, Testlog2, Testlog4 and
        # Testlog3. And the number of item is 3
        matchedList1 = self._logParser.filter(self._prefix, 'the first timeslot',
                                '2014-12-24 22:00:00')
        matchedList2 = self._logParser.filter(self._prefix, 'the first timeslot',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:00')
        matchedList3 = self._logParser.filter(self._prefix, 'in the first timeslot',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:01')
        self.assertEqual(len(matchedList1), 3)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)

    def test_18_FullLogFiles(self):
        """The timestamp is located in full log files."""
        logger.debug('\n[Test case 18] The timestamp in full log files.')

        # Match 'In File Testlog' in full log files and the number of line is
        # 54
        matchedList1 = self._logParser.filter(self._prefix, 'In File Testlog')
        matchedList2 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34')
        matchedList3 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33')
        matchedList4 = self._logParser.filter(self._prefix, 'In File Testlog',
                                eTime='2015-03-24 23:10:00')
        matchedList5 = self._logParser.filter(self._prefix, 'In File Testlog',
                                eTime='2015-03-24 23:10:01')
        matchedList6 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:34', '2015-03-24 23:10:00')
        matchedList7 = self._logParser.filter(self._prefix, 'In File Testlog',
                                '2012-12-24 21:34:33', '2015-03-24 23:10:01')
        self.assertEqual(len(matchedList1), 54)
        self.assertListEqual(matchedList1, matchedList2)
        self.assertListEqual(matchedList2, matchedList3)
        self.assertListEqual(matchedList3, matchedList4)
        self.assertListEqual(matchedList4, matchedList5)
        self.assertListEqual(matchedList5, matchedList6)
        self.assertListEqual(matchedList6, matchedList7)

    def test_19_NoLogContent(self):
        """No log content between given timestamps.

        If No log content is found between given timestamps, False will be
        returned by contains.
        """
        logger.debug('\n[Test case 19] No log content between given timestamps.')

        # The empyt list will be returned for the following cases.
        # 1. the begining time is beyond the end time.
        # 2. the begining time is beyond the last time in log file
        # 3. the end time is earlier than the first time in log file
        case1 = self._logParser.contains(self._prefix, '.*',
                                '2013-12-24 21:34:41', '2013-12-24 21:34:40')
        case2 = self._logParser.contains(self._prefix, '.*',
                                bTime='2015-03-24 23:10:01')
        case3 = self._logParser.contains(self._prefix, '.*',
                                eTime='2012-12-24 21:34:33')
        self.assertFalse(case1)
        self.assertFalse(case2)
        self.assertFalse(case3)

    def test_20_FirstLogFile(self):
        """The timestamp is located in the first log file (Testlog5)."""
        logger.debug('\n[Test case 20] The timestamp in first log file.')

        # No content match
        bFalse = self._logParser.contains(self._prefix, 'nosuchline in Testlog5',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertFalse(bFalse)
        bFalse = self._logParser.contains(self._prefix, 'nosuchline in Testlog5',
                                eTime='2012-12-24 21:59:59')
        self.assertFalse(bFalse)

        # Match 'In File Testlog5' in Testlog5
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog5.*){3}',
                                '2012-12-24 21:34:34', '2012-12-24 21:59:59')
        self.assertTrue(bTrue)

        # Match 'in the first' in Testlog5.
        bTrue = self._logParser.contains(self._prefix, 'in the first',
                                eTime='2012-12-24 21:59:59')
        self.assertTrue(bTrue)

        # Match 'the first line log' in Testlog5.
        bTrue = self._logParser.contains(self._prefix, 'the first line log',
                                '2012-12-24 21:34:40', '2012-12-24 21:34:52')
        self.assertTrue(bTrue)

        # Match '.*' in Testlog5.
        bTrue = self._logParser.contains(self._prefix, '.*',
                                '2012-12-24 21:34:34', '2012-12-24 22:00:00')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog5.
        bTrue = self._logParser.contains(self._prefix, '(line log.*){3}',
                                '2012-12-24 21:34:33', '2012-12-24 22:00:01')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog5.
        bTrue = self._logParser.contains(self._prefix, '(line log.*){3}',
                                eTime='2012-12-24 22:00:01')
        self.assertTrue(bTrue)

    def test_21_OneMiddleLogFile(self):
        """The timestamp is located in one middle log file (Testlog1)."""
        logger.debug('\n[Test case 21] The timestamp in one middle log file.')

        # No content match
        bFalse = self._logParser.contains(self._prefix, 'nosuchline in Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertFalse(bFalse)

        # Match 'In File Testlog1' in Testlog1.
        bTrue = self._logParser.contains(self._prefix, 'In File Testlog1',
                                '2013-12-24 21:34:34', '2013-12-24 21:59:59')
        self.assertTrue(bTrue)

        # Match 'the first line log' in Testlog1.
        bTrue = self._logParser.contains(self._prefix, 'the first line log',
                                '2013-12-24 21:34:40', '2013-12-24 21:34:52')
        self.assertTrue(bTrue)

        # Match '.*' in Testlog1.
        bTrue = self._logParser.contains(self._prefix, '.*',
                                '2013-12-24 21:34:34', '2013-12-24 22:00:00')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog1.
        bTrue = self._logParser.contains(self._prefix, '(line log.*){3}',
                                '2013-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertTrue(bTrue)

    def test_22_LastLogFile(self):
        """The timestamp is located in last log file (Testlog3)."""
        logger.debug('\n[Test case 22] The timestamp in last log file.')

        # No content match
        bFalse = self._logParser.contains(self._prefix, 'nosuchline in Testlog3',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertFalse(bFalse)
        bFalse = self._logParser.contains(self._prefix, 'nosuchline in Testlog3',
                                bTime='2015-03-24 22:00:02')
        self.assertFalse(bFalse)

        # Match 'In File Testlog3' in Testlog3.
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog3.*){3}',
                                '2015-03-24 22:00:02', '2015-03-24 23:01:00')
        self.assertTrue(bTrue)

        # Match 'the first line log' in Testlog3.
        bTrue = self._logParser.contains(self._prefix, 'the first line log',
                                '2015-03-24 23:00:00', '2015-03-24 23:01:00')
        self.assertTrue(bTrue)

        # Match '.*' in Testlog3 and the number of line is 12
        bTrue = self._logParser.contains(self._prefix, '.*',
                                '2015-03-24 22:00:02', '2015-03-24 23:10:00')
        self.assertTrue(bTrue)

        # Match 'line log' in Testlog3.
        bTrue = self._logParser.contains(self._prefix, '(line log.*){3}',
                                bTime='2015-03-24 22:00:01')
        self.assertTrue(bTrue)

    def test_23_MultiLogFiles(self):
        """The timestamp is located in multiple log files."""
        logger.debug('\n[Test case 23] The timestamp in multiple log files.')

        # Match 'In File Testlog' in Testlog5 and Testlog1
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                eTime='2013-12-24 22:00:01')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                eTime='2013-12-24 22:00:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2012-12-24 21:34:34', '2013-12-24 22:00:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2012-12-24 21:34:33', '2013-12-24 22:00:01')
        self.assertTrue(bTrue)

        # Match 'In File Testlog' in Testlog1 and Testlog0.
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2013-12-24 21:34:33', '2014-12-24 21:36:01')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2013-12-24 21:34:34', '2014-12-24 21:36:00')
        self.assertTrue(bTrue)

        # Match 'In File Testlog' in Testlog0, Testlog2 and Testlog4.
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2014-12-24 22:00:00', '2014-12-24 22:00:00')
        self.assertTrue(bTrue)

        # Match 'In File Testlog' in Testlog0, Testlog2, Testlog4 and Testlog3.
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2014-12-24 22:00:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2014-12-24 22:00:00', '2015-03-24 23:10:01')
        self.assertTrue(bTrue)

    def test_24_FullLogFiles(self):
        """The timestamp is located in full log files."""
        logger.debug('\n[Test case 24] The timestamp in full log files.')

        # Match 'In File Testlog' in full log files.
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2012-12-24 21:34:34')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2012-12-24 21:34:33')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                eTime='2015-03-24 23:10:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                eTime='2015-03-24 23:10:01')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2012-12-24 21:34:34', '2015-03-24 23:10:00')
        self.assertTrue(bTrue)
        bTrue = self._logParser.contains(self._prefix, '(In File Testlog.*){3}',
                                '2012-12-24 21:34:33', '2015-03-24 23:10:01')
        self.assertTrue(bTrue)

if __name__ == "__main__":
    unittest.main()

