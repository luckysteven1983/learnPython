"""
Created on Sep. 16, 2015

@author: Jiaxi Jin

This library prepares the authentication for SSH connection established between mCAS and COM before SU takes place

   Typical usage :
     SdmSuPrepareSshAuth.sshSetup(mcasIP, comIP)
"""

import os
import argparse
from lib.ssh.ssh_manager import SshManager
from lib.logging.logger import Logger

class SdmSuPrepareSshAuthError(BaseException):
    """If error, raise it."""
    pass

LOGGER = Logger.getLogger(__name__)

# ---- init CONSTANTS
BUFF_SIZE = 8192

def sshCreateMcasUser(ip, user, password, cmd):
    """
    SSH to mCAS and create user with given arguments
    helper function, not supposed to be called independently
    """
    try:

        ssh = SshManager().getClient(ip)

        for _m in cmd:

            if '/usr/sbin/AcctMgt -passwd' in _m:

                chan = ssh.invoke_shell()

                SshManager.sendStringRoutine(chan, _m, 'New Password')
                SshManager.sendStringRoutine(chan, password, 'Re-enter new Password')
                SshManager.sendStringRoutine(chan, password, 'AcctMgt: Completed')

            else:

                ssh.exec_command(_m)

        SshManager().closeClient(ip)

        LOGGER.debug('create mCAS User %s on %s\tOK\n', user, ip)

        return True

    except SdmSuPrepareSshAuthError:

        LOGGER.debug('create mCAS User %s on %s\tError\n', user, ip)

        return False

def sshMcasKeyGen(ip, user, password, cmd, comUser, comPw, comIP):
    """
    SSH to mCAS and then generate rsa public key, copy to COM
    helper function, not supposed to be called independently
    """
    try:

        ssh = SshManager().getClient(ip, user, password)

        for _m in cmd:

            if _m == 'cd .ssh/; ssh-keygen -t rsa':

                chan = ssh.invoke_shell()
                SshManager.sendStringRoutine(chan, _m, 'Enter file in which to save the key')
                SshManager.sendStringRoutine(chan, '', 'Enter passphrase (empty for no passphrase)')
                SshManager.sendStringRoutine(chan, '', 'Enter same passphrase again')
                SshManager.sendStringRoutine(chan, '', 'The key fingerprint is')

            elif _m == cmd[5]:

                chan = ssh.invoke_shell()

                str2Wait = comUser + '@' + comIP + '\'s password'
                firstTimePrompt = 'Are you sure you want to continue connecting (yes/no)?'
                firstTimeAck = False

                output = ''
                chan.sendall(_m + os.linesep)
                while not str2Wait in output:
                    output = chan.recv(BUFF_SIZE)
                    if (not firstTimeAck) and (firstTimePrompt in output):
                        chan.sendall('yes' + os.linesep)
                        firstTimeAck = True

                chan.sendall(comPw + os.linesep)
                while not '100%' in output:
                    output = chan.recv(BUFF_SIZE)

            else:

                ssh.exec_command(_m)

        SshManager().closeClient(ip)

        LOGGER.debug('ssh-keygen on %s\tOK\n', ip)

        return True

    except SdmSuPrepareSshAuthError:

        LOGGER.debug('ssh-keygen on %s\tError\n', ip)

        return False

def sshCatAuthorizedKey(ip, user, password, cmd):
    """
    on COM, cat the authorized key to file
    helper function, not supposed to be called independently
    """
    try:

        ssh = SshManager().getClient(ip, user, password)

        for _m in cmd:

            ssh.exec_command(_m)

        SshManager().closeClient(ip)

        LOGGER.debug('cat rsa key to authorized_key on %s\tOK\n', ip)

        return True

    except SdmSuPrepareSshAuthError:

        LOGGER.debug('cat rsa key to authorized_key on %s\tError\n', ip)

        return False

def syncToOtherPilot(ip, cmd, mcasPw):
    """
    sync to pilot A and B
    helper function, not supposed to be called independently
    """
    try:

        ssh = SshManager().getClient(ip)

        for _m in cmd:

            if 'rsync' in _m:

                chan = ssh.invoke_shell()

                str2Wait = 'WARNING!'
                firstTimePrompt = 'Are you sure you want to continue connecting (yes/no)?'
                firstTimeAck = False

                output = ''
                chan.sendall(_m + os.linesep)
                while not str2Wait in output:
                    output = chan.recv(BUFF_SIZE)
                    if (not firstTimeAck) and (firstTimePrompt in output):
                        chan.sendall('yes' + os.linesep)
                        firstTimeAck = True
                    elif firstTimeAck:
                        chan.sendall(mcasPw)

            else:

                ssh.exec_command(_m)

        SshManager().closeClient(ip)

        LOGGER.debug('sync PilotA and PilotB on %s\tOK\n', ip)

        return True

    except SdmSuPrepareSshAuthError:

        LOGGER.debug('sync PilotA and PilotB on %s\tError\n', ip)

        return False

class SdmSuPrepareSshAuth(object):
    """ class to prepare object """

    def __init__(self):
        '''
        Constructor
        '''
        pass

    @staticmethod
    def sshSetup(comIP, mcasIP, comUser='guest', comPw='guest', mcasUser='rmtadm', mcasPw='COM_cc_n1'):
        """
        Establish ssh connection between mCAS and COM and save the setup env to further usage

        @param comIP : the address of COM server
        @param mcasIP : the IP address of mCAS server (PilotA)
        @param comUser : the user name on COM server
        @param comPw : password
        @param mcasUser : the user name to be created on mCAS server
        @param mcasPw : password to be created on mCAS

        SdmSuPrepareSshAuth.sshSetup(mcasIP, comIP)
        """
        comSSHDir = ':/home/' + comUser + '/.ssh'
        rsaCpName = 'id_rsa.pub_mcas_' + mcasUser + '_NE_' + comUser

        createMcasUserCmd = ['/usr/sbin/AcctMgt -add -d /home/' + mcasUser + ' -m -g adm -G wheel,ainet ' + mcasUser,
                             '/usr/sbin/AcctMgt -passwd ' + mcasUser,
                             'chage -M -1 ' + mcasUser]#

        mcasKeyGenCmd = ['mkdir -p .ssh',
                         'cd .ssh/; rm -f id_rsa*',
                         'cd .ssh/; ssh-keygen -t rsa',
                         'cd .ssh/; ls -ltr',
                         'cd .ssh/; cp id_rsa.pub ' + rsaCpName,
                         'cd .ssh/; scp ' + rsaCpName + ' ' + comUser + '@' + comIP + comSSHDir]

        catAuthorizedKeyCmd = ['cd .ssh/; cat ' + rsaCpName + ' >> authorized_keys']

        syncToOtherPilotCmd = ['rsync -aH /home/' + mcasUser + '/.ssh/ PilotB:/home/' + mcasUser + '/']

        LOGGER.debug("ssh setup between %s and %s started\n", mcasIP, comIP)

        if sshCreateMcasUser(mcasIP, mcasUser, mcasPw, createMcasUserCmd) and \
        sshMcasKeyGen(mcasIP, mcasUser, mcasPw, mcasKeyGenCmd, comUser, comPw, comIP) and \
        sshCatAuthorizedKey(comIP, comUser, comPw, catAuthorizedKeyCmd) and \
        syncToOtherPilot(mcasIP, syncToOtherPilotCmd, mcasPw):
            LOGGER.debug("ssh setup between %s and %s succeeded\n", mcasIP, comIP)
            return True
        else:
            LOGGER.debug("ssh setup between %s and %s failed\n", mcasIP, comIP)
            return False

if __name__ == '__main__':

    __mcasUser__ = 'rmtadm'

    __mcasPw__ = 'COM_cc_n1'

    __comUser__ = 'public'

    __comPw__ = 'public'

    __parser__ = argparse.ArgumentParser()

    __parser__.add_argument("mcasIP", help="the IP address of mCAS server (PilotA)")
    #parser.add_argument("--mcasIP", help="the address of mCAS server", default=mcasIP)
    __parser__.add_argument("-mu", "--mcasUser", help="user name to be created on mCAS server", default=__mcasUser__)
    __parser__.add_argument("-mp", "--mcasPw", help="user password to be created on mCAS server", default=__mcasPw__)
    __parser__.add_argument("comIP", help="the address of COM server")
    #parser.add_argument("--comIP", help="the address of COM server", default=comIP)
    __parser__.add_argument("-cu", "--comUser", help="the user name on COM server", default=__comUser__)
    __parser__.add_argument("-cp", "--comPw", help="the user's password on COM server", default=__comPw__)

    __args__ = __parser__.parse_args()

    print "SDM SU Prepare SSH Authentication Begin......"

    SdmSuPrepareSshAuth().sshSetup(__args__.comIP, __args__.mcasIP, __args__.comUser,
                                   __args__.comPw, __args__.mcasUser, __args__.mcasPw)
