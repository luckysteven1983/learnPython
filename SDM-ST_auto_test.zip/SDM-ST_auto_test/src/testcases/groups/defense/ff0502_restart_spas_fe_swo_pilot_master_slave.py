"""
Created on August 18, 2015

@author: Tangi Lavanant
"""

from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0502_restart_spas_fe_swo_pilot_master_slave(SDMTestCase):
    """
    ff0502 Blade SW fault: remove the spa on FE and swo control pilot on MASTER & SLAVE
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()

    def test_remove_spas_fe_swo_pilot_master_slave(self):
        """remove the spa on FE and swo pilot on MASTER and SLAVE.

        Procedure:
        1. restart OAM SPA on the FE and meanwhile do pilot switch-over on all BE of NRG.
        2. restart SDM SPA on the FE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check and return current active alarm list"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""

        LOGGER.debug("run test case remove_spas_fe_swo_pilot_master_slave")
        # Get BE list
        beObjs = self.testEnv.testBed.getLabsInNRG()
        # Get a FE
        feObj = self.allFEs[0]
        LOGGER.debug("FE name: %s", feObj.id)
        multiTasksManager = self.sdmManager.multiTasksManager

        LOGGER.info("Restart OAM SPA and pilot switch-over on BE in progress")
        threadName = multiTasksManager.register(self.mcasApplicationManager.restartSPA, feObj, "OAM")
        LOGGER.info("Restart OAM SPA on Lab '%s' in progress -> thread ID '%s'", feObj.id, threadName)
        for be in beObjs:
            threadName = multiTasksManager.register(self.mcasMachineManager.pilotSwitchover, be)
            LOGGER.info("Pilot switch-over on Lab '%s' in progress -> thread ID '%s'", be.id, threadName)

        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, beObjs[0])
        LOGGER.info("Restarting SDM SPA on %s and pilot switch-over on BEs %s", feObj.id, [be.id for be in beObjs])

        if not multiTasksManager.runMultiTasks():
            raise Exception("Restart OAM SPA or pilot switch-over failure")
        LOGGER.debug("Restart SDM SPA")
        self.mcasApplicationManager.restartSPA(feObj, "SDM")
        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post check")

        LOGGER.debug("check the end status of the test env")
        allLabs = self.testEnv.testBed.labs.values()
        beObjs = self.testEnv.testBed.getLabsInNRG()
        leftLabs = [lab for lab in allLabs if lab not in beObjs]
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=leftLabs)
