#!/bin/bash

# This script is used to report the pmap information to pmap for process
# Usage:
#       $TOOL_DIR/gmetric_pmap.sh [-d delay] process1 [process2 ...]        
#  For example:
#               $TOOL_DIR/gmetric_pmap.sh Oam
#       The Oam will match processes: OamEirServer/OamNghlrServer/OamMnpServer/OamSdmhssServer
#       So totally 4 processes for Oam would be monitored.
#  You can also use the wildchar like . * [ ] which is just the same definition in grep
#               $TOOL_DIR/gmetric_pmap.sh "Oam[EM]"
#        Above script only match OamEirServer/OamMnpServer
#
#
# history
# 2009-4-28 modify the script to support multi-process with the same name. 
#               The script will call `ps -A` other than "ps -ef"
#           if the process has 1+ instance like 2 ndbd process on BE, it will not send the pmap to ganglia.

# script basename
script=`echo "$0" | sed 's:.*/::'`

usage="Usage: $script [-d delay] process1 [process2 ...]"
delay=300

gmetric_command=/usr/bin/gmetric

while getopts :d: o
do	case "$o" in
	d) delay=$OPTARG;;
	h) echo $usage; exit 0;;
	[?]) echo >&2 $usage
		exit -1;;
	esac
done
shift $(($OPTIND - 1))

if [ -z "$1" ]; then
      echo $usage
      exit -1  
fi

if ! [ -x  $gmetric_command ]; then
        echo "Gmetric command is not executable. No ganglia pmap data generated..."
fi

while [ 1 ]
do
        for process in $* 
        do      
                psnames=`ps -A| awk '{ print $4 }' |grep "$process"|grep -v grep|grep -v "$script" |uniq` 
                for psname in $psnames
                do 
                        psids=`ps -A |grep "$psname"|grep -v grep|grep -v "$script" |awk '{ print $1 }'`
        
                        number=`echo "$psids" |wc -l`   
                        process_exp=`echo $psname|sed "s:/:@:g"`
                        
                        if [ "$number" -gt 1 ]; then
                                echo -e "Warning: $process_exp include $number instances. pmap for $process_exp would not send to ganglia"
                        fi                             
                        date=`date "+%F %X"`
                        for psid in $psids
                        do
                                value=`pmap -d "$psid" |grep write |sed "s/.*private: //" |sed "s/K.*//"|awk '{ print $1/1024 }' 2>/dev/null`
                                if [ "$number" -eq 1 ]; then
                                        echo -e "`date "+%F %X"`\t$process_exp\t${value}M"                                
                                        #$gmetric_command  --name="pmap_$process_exp" --value="$value" --type=float --units="M"
                                else       
                                        echo -e "${date}\t${process_exp}-pid${psid}\t${value}M"
                                fi         
                        done                        
                done
        done
        sleep $delay
done
