"""Unit test for health check lib"""
