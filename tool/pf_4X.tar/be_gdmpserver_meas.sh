#!/bin/bash

file=`ls -lrt meas*|tail -1|awk '{print $9}'`

grep -A 17 -w NbReplyThreads $file|grep -v "\-\-"|head -1 > be_gdmpserver_meas.txt
grep -A 17 -w NbReplyThreads $file|grep -v "\-\-"|grep -v NbReplyThreads >> be_gdmpserver_meas.txt

Max_NbReplyThreads=`sort -k2 -n be_gdmpserver_meas.txt|tail -1|awk '{print $2}'`
Max_NdbObjectsUsed=`sort -k3 -n be_gdmpserver_meas.txt|tail -1|awk '{print $3}'`

echo "Max(NbReplyThreads) Max(NdbObjectUsed)" > be_gdmpserver_meas.result
echo $Max_NbReplyThreads "               " $Max_NdbObjectsUsed >> be_gdmpserver_meas.result
rm be_gdmpserver_meas.txt

