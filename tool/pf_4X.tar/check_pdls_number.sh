#!/bin/bash
server_number=`cat /etc/hosts |grep -i station|grep -v grep|wc -l`;

i=1;
sta=2;

h=`expr $server_number / 2`;
while [ $i -le `expr $server_number - 2` ]
do
     if [[ "`uname -n`" =~ "HP" ]] ; then
        if [ $sta -le `expr $h + 1` ]; then
             if [ $sta -eq 3 ]; then
                let sta++;
                continue;
             else
        	ssh 0-0-$sta 'ps -ef | grep PDLS | grep -v grep | grep -v MDS' >> check_PDLS_number.result;
        	echo "=============  $sta  =========="  >> check_PDLS_number.result;
        	let sta++;
                let i++;
             fi
     	else
        	tmp=`expr $i % $h`;
                if [ $tmp -gt 0 ]; then
                   sta=`expr 11 + $tmp`;                  
                else
                   sta=`expr 10 + $tmp`;
                fi
        	ssh 0-0-$sta 'ps -ef | grep PDLS | grep -v grep | grep -v MDS' >> check_PDLS_number.result
       		echo "=============  $sta  =========="  >> check_PDLS_number.result
        	let i++
      	fi

#      elif [[ "`uname -n`" =~ "BONO" ]]; then
        else
           if [ $sta -gt $h ]; then
               tmp=`expr $i % $h`;
               sta=`expr 10 + $tmp`;
           fi
           ssh 0-0-$sta 'ps -ef | grep PDLS | grep -v grep | grep -v MDS' >> check_PDLS_number.result
           echo "=============  $sta  =========="  >> check_PDLS_number.result
           let sta++
           let i++
      fi
done
