#!/bin/sh
#
# 8-09-2011	licanhua
# 5-31-2011	draft by canhua
#
# This script is used to install the test tool to ATCA lab.
# First, please put the package in a directory like: /pt/bin
# Then excute the following command to install the test tool:
# 
#       sh install.sh [FE|fe|be|BE] packagename
#

# custom variables:
 #valid type: FE/BE/COMPACT
type=COMPACT

rcp="rcp"
rsh="rsh"

#default value for PILOT/NPILOT
PILOT_D="STATION_A STATION_B"
NPILOT_D="STATION_C STATION_D STATION_E STATION_F STATION_G STATION_H STATION_I STATION_J STATION_K STATION_L"

TOOL_DIR=`pwd`

COMMON_INI=$TOOL_DIR/common.ini
COMMON_INI_SYNC=$TOOL_DIR/common.ini.sync

case "x$1" in
	xFE|xfe)
	shift
	type="FE"
	;;
	xBE|xbe)
	shift
	type="BE"
	;;
	xCOMPACT|xcompact)
	shift
	;;
esac

package=$1

if [ -z "$package" ] || ! [ -f "$package" ]; then
   echo "package $package unknown."
   echo "sh install.sh [FE|BE|COMPACT] packagename"
   echo "Example: "
   echo "  sh install.sh `ls -1 *.gz|head -1`"
   echo "  sh install.sh FE `ls -1 *.gz|head -1`"
   echo "  sh install.sh BE `ls -1 *.gz|head -1`"
   echo "  sh install.sh COMPACT `ls -1 *.gz|head -1`"
   exit 1
fi

if [ X"$LOGNAME" != X"root" ]; then
        echo "Please login with root"
  exit -1
fi

rm -rf $COMMON_INI $COMMON_INI_SYNC; 

cat > $COMMON_INI <<END
#!/bin/sh

#This file is auto created by install.sh
#please don't edit manually
END


# use the default value for PILOT/NPILOT if can't find in /etc/hosts
PILOT=`cat /etc/hosts|grep STATION_[A-B]|awk '{ print $2 }' |xargs 2>/dev/null`
if [ $? -ne 0 ]; then
	PILOT=$PILOT_D
fi

NPILOT=`cat /etc/hosts|grep STATION_[C-Z]|awk '{ print $2 }' |xargs 2>/dev/null`
if [ $? -ne 0 ]; then
	NPILOT=$NPILOT_D
fi


hostname=`hostname`


echo "copy and tar zxvf $package to all station"
for station in $PILOT $NPILOT; do
	echo -n "On $station ..."

	if ! ping -c 1 $station > /dev/null 2>&1  ; then
		echo " Failed to ping on $station"
		echo  "$station=''" >> 	$COMMON_INI
		continue	
	fi	
	
#	skip self 
	xhostname=`$rsh $station hostname`
	if [ $? -ne 0 ]; then
		echo " Failed to rsh to $station"	
		echo  "$station=''" >> 	$COMMON_INI	
		continue
	fi

	echo "$station=`echo $xhostname|sed 's/^[^-]*-//'`" >> 	$COMMON_INI	
	if [ "x$hostname" = "x$xhostname" ]; then
 	   echo "OK"
	   continue
	fi
	
# mkdir and cp packages	
	if $rsh $station mkdir -p $TOOL_DIR > /dev/null; then 
	   $rcp $package $station:/$TOOL_DIR >/dev/null
	   $rsh $station "cd $TOOL_DIR;tar zxvf $package" > /dev/null 
	else
		echo " Failed to install on $station"
	fi
	echo "OK"	    
done

#create link
echo "create lg/pt/gpackcore/lftp/lcores link on $PILOT"
for file in lg pt gpackcore lftp lcores lping lnewinstall pt_upload bkdoor; do
	for station in $PILOT; do
		$rsh $station ln -sf $TOOL_DIR/$file /bin/$file	
	done
done


echo "create lg link on $NPILOT"
for file in lg pt gpackcore bkdoor; do
	for station in $NPILOT; do
		$rsh $station ln -sf $TOOL_DIR/$file /bin/$file	
	done
done

echo "create .local_profile in /root"
#for station in $PILOT $NPILOT; do
for station in $PILOT ; do
  $rsh $station	"if ! [ -f /root/.local_profile ]; then cp $TOOL_DIR/local_profile /root/.local_profile ; fi"
done

echo "Create $COMMON_INI_SYNC file"


echo "rcp=\"$rcp\"" >> $COMMON_INI
echo "rsh=\"$rsh\"" >> $COMMON_INI
echo "PILOT=\"$PILOT\"" >> $COMMON_INI
echo "NPILOT=\"$NPILOT\"" >> $COMMON_INI
echo "type=\"$type\"" >> $COMMON_INI
echo "TOOL_DIR=\"$TOOL_DIR\"" >> $COMMON_INI

cp $COMMON_INI $COMMON_INI_SYNC

#echo "sync $COMMON_INI_SYNC to $PILOT"
$TOOL_DIR/pt sync 
 
echo "+ Done"
