"""
@file
Created on April 1st, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines Disturbances class
"""

PROVISIONING = "provisioning"
TELECOM = "telecom"

class Disturbances(object):
    """ @details This class describes all disturbances as defined in configuration.xml. """

    def __init__(self):
        """ Disturbances class constructor """

        self.disturbancesHP = {PROVISIONING:{}, TELECOM:{}}
        self.disturbancesBono = {PROVISIONING:{}, TELECOM:{}}
        self.disturbancesRouzic = {PROVISIONING:{}, TELECOM:{}}


    def getDisturbance(self, trafficType, disturbName, hardware, SDMRelease="default"):
        """ Method to get a disturbance time for a given SDM release
        @param trafficType type of traffic (provisioning, telecom)
        @param disturbName name of disturbance as defined in configuration.xml
        @param hardware type of hardware (HP, Bono, Rouzic)
        @param SDMRelease name of SDM release as defined in configuration.xml
        @return disturbTime time of disturbance in milliseconds """

        key = (disturbName, SDMRelease)
        if hardware == "HP":
            return self.disturbancesHP[trafficType][key]
        elif hardware == "Bono":
            return self.disturbancesBono[trafficType][key]
        elif hardware == "Rouzic":
            return self.disturbancesRouzic[trafficType][key]


    def setDisturbance(self, trafficType, disturbName, hardware, disturbTime, SDMRelease="default"):
        """ Method to set a disturbance time for a given SDM release
        @param trafficType type of traffic (provisioning, telecom)
        @param disturbName name of disturbance as defined in configuration.xml
        @param hardware type of hardware (HP, Bono, Rouzic)
        @param disturbTime time of disturbance in milliseconds
        @param SDMRelease name of SDM release as defined in configuration.xml """

        key = (disturbName, SDMRelease)
        if hardware == "HP":
            self.disturbancesHP[trafficType][key] = disturbTime
        elif hardware == "Bono":
            self.disturbancesBono[trafficType][key] = disturbTime
        elif hardware == "Rouzic":
            self.disturbancesRouzic[trafficType][key] = disturbTime
