'''
Created on Jan 30, 2015

@author: yohannm
'''

class ResourceIntensive(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        self.minCPUs = 0
        self.minMemory = 0