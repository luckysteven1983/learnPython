#!/bin/bash
echo -e "Station\t" "HottestCpu\t" "HottestCore\t" "AvgCpu" > hot_sta_core
for sta in A B
do
    if [ -f top_$sta* ]; then
		top_file=`ls -lrt top_$sta*|tail -1|awk '{print $9}'`
		#Number of CPU cores
		core_num=`cat /proc/cpuinfo|grep processor|wc -l`
		cmd="paste"
		for core in `seq $core_num`
		do
   			core=`expr $core - 1`
  			grep "Cpu${core} " $top_file | awk -F, '{ print $4 $5}'|sed -n -e 's/%id//p'|sed -n -e 's/%wa//p' | awk '{ printf "%.1f\n", 100-$1-$2}' > Cpu${core}
   			cmd=`echo $cmd " " Cpu${core}`
            #Calculate average/min/max CPU usage of each core
            awk -v sta=$sta core=$core '{if(min==""){min=max=$1}; if($1>max) {max=$1}; if($1< min) {min=$1}; total+=$1; count+=1} END {printf "%s\t%s\t%.1f\t%.1f\t%.1f\n, sta, Cpu"core", total/count, min, max}' Cpu${core} >> Sta_$sta_cpu.rpt
            rm Cpu${core}
		done

		exec $cmd > cpu_$sta.txt &
		sleep 1
        #Calculate max CPU usage of each sample interval for station X
		max=`awk -v sta=$sta '{ max=0; for(i=1;i<=NF;i++) if(max<$i) max=$i; sum+=max; ++num; next } END {printf "%s\t%.1f", sta,sum/num}' cpu_$sta.txt`
        hottestCore=`sort -n -k3 Sta_$sta_cpu.rpt |tail -1|awk '{print $2}'`
        AvgCoreCpu=`sort -n -k3 Sta_$sta_cpu.rpt |tail -1|awk '{print $3}'`
        echo -e $sta "\t" $max "\t" $hottestCore "\t" $AvgCoreCpu "\n" >> hot_sta_core
        rm cpu_$sta.txt 
    fi
done

for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
do
        #In case there are more than one top file for one station, we use the latest one.
        #top_file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'|wc -l`
        #In case there is no top file for some station, we ignore it.
        if [ -f top_$sta* ]
            top_file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'`
            core_num=`cat /proc/cpuinfo|grep processor|wc -l`
            cmd="paste"
            for core in `seq $core_num`
              do
                 core=`expr $core - 1`
                 grep "Cpu${core} " $top_file | awk -F, '{ print $4 $5}'|sed -n -e 's/%id//p'|sed -n -e 's/%wa//p' | awk '{ printf "%.1f\n", 100-$1-$2}' > Cpu${core}
                 cmd=`echo $cmd " " Cpu_${core}`
				 #Calculate average/min/max CPU usage of each core
                 awk -v sta=$sta core=$core '{if(min==""){min=max=$1}; if($1>max) {max=$1}; if($1< min) {min=$1}; total+=$1; count+=1} END {printf "%s\t%s\t%.1f\t%.1f\t%.1f\n, sta, Cpu"core", total/count, min, max}' Cpu${core} >> Sta_$sta_cpu.rpt
                 rm Cpu${core}
              done

              exec $cmd > cpu_$sta.txt &
              sleep 1
              max=`awk -v sta=$sta  '{ max=0; for(i=1;i<=NF;i++) if(max<$i) max=$i; sum+=max; ++num; next } END {printf "%s\t%.1f", sta,sum/num}' cpu_$sta.txt`
	          hottestCore=`sort -n -k3 Sta_$sta_cpu.rpt |tail -1|awk '{print $2}'`
              AvgCoreCpu=`sort -n -k3 Sta_$sta_cpu.rpt |tail -1|awk '{print $3}'`
              echo -e $sta "\t" $max "\t" $hottestCore "\t" $AvgCoreCpu "\n" >> hot_sta_core
              rm cpu_$sta.txt
        fi
done

for file in `ls Sta_*_cpu.rpt`
do 
   cat $file >> cpu.rpt
   rm $file
done
