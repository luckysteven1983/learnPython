"""
@file
Created on May 21, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines TgenLDAPTraffic Class
@details For tgen setup, see <a href="https://atlassianwave.web.alcatel-lucent.com/confluence/display/SDM8650/Running+traffic+%28tgen%2C+ptool%2C+Mistral%29+from+Jenkins">documentation</a>
"""

import time
import os
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from framework.traffic.traffic import Traffic, BadQosException

LOGGER = Logger.getLogger(__name__)

# tgen location on PC lab
TGEN_DIR = "/local/jenkins/tgenV26bin_ForExternal/TestU"
BUILD_TAG = os.getenv("BUILD_TAG", "build tag default")
BUILD_ID = os.getenv("BUILD_ID", "12345")
JOB_NAME = os.getenv("JOB_NAME", "job_name")
NODE_NAME = os.getenv("NODE_NAME", "jenkins_slave")
DIR_LOG_LOCAL = "log"


class TgenLDAPTraffic(Traffic):
    """
    @details This class offers the commands to control a tgen simulator.
    """

    def __init__(self, tgenTrafficProfile, tgenLDAPTrafficSimulator, testBed):
        """ TgenLDAPTraffic class constructor """

        super(TgenLDAPTraffic, self).__init__()
        self.tgenTrafficProfile = tgenTrafficProfile
        self.testBed = testBed
        self.scenario = tgenTrafficProfile.scenario  # name of the traffic as defined in tgen_udc.ini
        self.tps = tgenTrafficProfile.tps  # transactions per second
        self.threads = tgenTrafficProfile.threads  # number of threads to be used (usually 100)
        self.server = tgenLDAPTrafficSimulator.server  # name of the FE lab as defined in tgen_servers.ini
        self.myTestBed = testBed
        self.trafficType = "LDAP"
        self.toolName = "Tgen"
        self.qos = 0
        self.previousQos = 0
        self.errors = 0
        self.successes = 0
        self.previousErrors = 0
        # nbRequestsStart/End and nbErrorsStart/End store values from last and last but one getRequestsAndErrors
        self.nbRequestsStart = 0
        self.nbRequestsEnd = 0
        self.requests = 0
        self.nbErrorsStart = 0
        self.nbErrorsEnd = 0
        self.account = tgenLDAPTrafficSimulator.account
        self.toolIpAddress = tgenLDAPTrafficSimulator.toolIpAddress
        self.dirlog = os.path.dirname(TGEN_DIR) + "/server_" + self.server + "-scenario_" + self.scenario
        self.sshManager = tgenLDAPTrafficSimulator.sshManager
        # getClient is called because for traffic PCs, the connection is not done in  jenkins_worker
        self.sshManager.getClient(self.toolIpAddress, user=self.account.login, pw=self.account.password)
        self.tps = tgenTrafficProfile.tps
        self.trafficInfo = "Tgen LDAP traffic on " + self.toolIpAddress + \
                           " - server: " + str(self.server) + " scenario: " + str(self.scenario) + \
                           " (" + tgenTrafficProfile.application + ")"


    def _getPid(self):
        """ Check if a given tgen traffic is running
        @return pid the pid of tgen process """

        cmd = "bash -c 'ps -ef | grep tgen_mas | grep -v grep | grep \"\-t " + self.scenario + "\"" # pylint: disable=anomalous-backslash-in-string
        cmd += " | grep \"\-g " + self.server + "\" | tr -s \" \" | cut -d\" \" -f2'" # pylint: disable=anomalous-backslash-in-string
        _, stdout = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        pid = stdout
        return pid


    def start(self, killIfExists=False):
        """ Start a tgen traffic
        @param killIfExists the traffics must be killed and restarted if already exist
        @exception Exception if this scenario is already running
        @exception Exception if &lt;FE_Prefix&gt;.xml is not present in tgen directory
        @exception Exception if traffic can not be started """

        cmd = "ls " + TGEN_DIR
        rc, _ = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        if rc != 0:
            LOGGER.error(msgs.TGEN_DIR_NOT_FOUND + "(" + TGEN_DIR + ") for " + self.trafficInfo)
            raise TgenTrafficException(msgs.TGEN_DIR_NOT_FOUND + "(" + TGEN_DIR + ") for " + self.trafficInfo)

        pid = self._getPid()
        if pid and not killIfExists:
            LOGGER.debug(msgs.TGEN_SCENARIO_ALREADY_IN_USE + ": " + self.trafficInfo)
        else:
            if pid and killIfExists:
                LOGGER.info(msgs.TGEN_SCENARIO_ALREADY_IN_USE + ": " + self.trafficInfo + \
                            " => this traffic will be restarted")
                cmd = "bash -c 'kill -9 " + pid + "'"
                LOGGER.debug("execute command on %s: %s", self.toolIpAddress, cmd)
                self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)

            LOGGER.info("Try to start " + self.trafficInfo)
            # Launch the traffic with tgen
            cmd = "bash -c 'cd " + TGEN_DIR + "; mkdir -p " + self.dirlog \
                  + "; cd " + self.dirlog + "; rm -f *; " \
                  + "nohup ../TestU/tgen_jenkins.csh " + TGEN_DIR + " " + self.scenario + " " \
                  + self.tps + " " + self.threads + " " + self.server + " &'"
            self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login, ignoreStdStreams=True)
            LOGGER.debug("Waiting 10s before checking " + self.trafficType + " traffic...")
            time.sleep(10)
            pid = self._getPid()
            if not pid:
                LOGGER.error(msgs.TGEN_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
                raise TgenTrafficException(msgs.TGEN_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
            LOGGER.info(self.trafficType + " traffic launched (pid=" + pid + ")...")


    def _searchNbRequestsAndErrorsInLog(self):
        """ Get the end of tgen log and search numbers of requests and errors
        @exception Exception if this scenario is not running """

        pid = self._getPid()
        if not pid:
            LOGGER.error(msgs.TGEN_TRAFFIC_PROCESS_ID_NOT_FOUND + " for " + self.trafficInfo)
            raise TgenTrafficException(msgs.TGEN_TRAFFIC_PROCESS_ID_NOT_FOUND + " for " + self.trafficInfo)

        jlog = self.dirlog + "/j.log"  # temp log file (tail of jenkins.log)
        # keep the end of tgen log file and delete control characters
        cmd = "bash -c 'cd " + self.dirlog + "; tail -200 jenkins.log | col -bx | sed \'s/^K//g\' > j.log'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        # keep last QoS block from log file
        cmd = "bash -c 'a=$(grep -n statistics " + jlog + " | tail -n2 | cut -d\":\" -f1 | head -n1); " + \
              " sed -i -e \"1,$a d\" " + jlog + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        LOGGER.debug("remote traffic log file on " + self.toolIpAddress + ": " + jlog)
        # get the file to work locally
        pathToJlog = self.sshManager.scpGet(self.toolIpAddress, self.dirlog + "/j.log", user=self.account.login)
        # rename it to avoid conflicts
        localJlog = pathToJlog + "_" + BUILD_ID + "_" + BUILD_TAG.replace(" ", "_")
        os.rename(pathToJlog, localJlog)
        # search values from array. Example:
        #                                  ********* statistics - request **********
        #   -------------------------------------------------------------------------------------------------------------------
        #   |         Request name         |   mean  |   min   |   max   |    cnt   |    ko    |  timout  |   over max delay  |
        #   -------------------------------------------------------------------------------------------------------------------
        #   | LDAP_Bind_Rq                 |    0.78 |    0.56 |    3.16 |      200 |        0 |        0 |   0.0% (       0) |
        #   | LDAP_Search_Rq               |   68.44 |    0.32 |  358.35 |   885780 |     3898 |        0 |  71.3% (  631386) |
        #   | LDAP_Modify_Rq               |   75.76 |    0.33 |  323.92 |  4436746 |    19280 |        0 |  73.7% ( 3268561) |
        #   | LDAP_Add_Rq                  |   79.89 |    2.48 |  318.59 |   442650 |    44637 |        0 |  78.2% (  346130) |
        #   | LDAP_Delete_Rq               |   76.27 |    0.86 |  319.23 |   442624 |    44632 |        0 |  74.0% (  327473) |
        #   -------------------------------------------------------------------------------------------------------------------
        kos = 0
        timeouts = 0
        requests = 0
        with open(localJlog, "r") as myFile:
            for line in myFile:
                if "LDAP_" in line and "Bind_Rq" not in line:  # ignore bind requests
                    cnt = int(line.split("|")[5].strip())
                    requests += cnt
                    ko = int(line.split("|")[6].strip())
                    kos += ko
                    timout = int(line.split("|")[7].strip())
                    timeouts += timout
        errors = kos + timeouts
        return requests, errors


    def getRequestsAndErrors(self):
        """ Checks the number of requests and errors, for instance
            to set a starting point from which to calculate the QoS """
        # nbRequestsStart and nbErrorsStart store values from last but one checkQoSInit
        self.nbRequestsStart = self.nbRequestsEnd
        # nbErrorsStart/1 = total ko + total timeout
        self.nbErrorsStart = self.nbErrorsEnd
        # nbRequestsEnd and nbErrorsEnd store values from last checkQoSInit
        self.nbRequestsEnd, self.nbErrorsEnd = self._searchNbRequestsAndErrorsInLog()


    def checkGlobalQoS(self):
        """ Check the traffic QoS from the beginning"""

        self.previousErrors = self.errors
        self.previousQos = self.qos
        self.requests, self.errors = self._searchNbRequestsAndErrorsInLog()
        if self.requests == 0:
            self.qos = 1
        else:
            self.qos = float(self.errors) / float(self.requests)
        if self.qos != 0:
            self.qos = "{:1.8f}".format(self.qos)
        LOGGER.debug(self.trafficInfo)
        LOGGER.debug("Requests: " + str(self.requests))
        LOGGER.debug("Previous errors: " + str(self.previousErrors) + " Current errors: " + str(self.errors))
        LOGGER.debug("Previous QoS:" + str(self.previousQos) + " Current QoS: " + str(self.qos))
        if float(self.qos) > 0.000001:
            msg = msgs.TRAFFIC_BAD_QOS + " (" + str(self.qos) + ") for " + self.trafficInfo
            LOGGER.error(msg)
            raise BadQosException(msg)


    def getErrorStatus(self):
        """ Return true if number of errors increased between two checkGlobalQoS """

        if self.errors > self.previousErrors:
            return True
        else:
            return False


    def getCountersString(self):
        """ Returns a string made of traffic counters """

        successes = self.requests - self.errors
        text = "QoS=" + str(self.qos) + "  Calls=" + str(self.requests) + "  Successes=" + str(successes) + \
               "  Errors =" + str(self.errors)
        return text


    def stop(self):
        """ Stop a tgen traffic
        @exception Exception if this scenario is not running """

        LOGGER.info("Try to stop " + self.trafficInfo)
        pid = self._getPid()
        if not pid:
            LOGGER.error(msgs.TGEN_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
            raise TgenTrafficException(msgs.TGEN_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
        # stop tgen
        cmd = "bash -c 'kill -15 " + pid + "'"
        LOGGER.debug("execute command on %s: %s", self.toolIpAddress, cmd)
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        # wait for tgen.out generation after kill
        cmd = "bash -c 'lsof " + self.dirlog + "/tgen.out | wc -l'"
        LOGGER.debug("Waiting for tgen.out generation...")
        i = 0
        while i < 60:
            _, stdout = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
            if stdout == "0":
                break
            time.sleep(1)
            i += 1
        LOGGER.info(self.trafficType + " traffic stopped...")

        tarLogs = "tgen" + "_server_" + self.server + "_scenario_" + self.scenario + "_pid_" + pid + ".tar.gz"
        cmd = "bash -c 'cd " + self.dirlog + "; tar zcvf " + tarLogs + " tgen.out tgen.log'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        pathToTarlogs = self.sshManager.scpGet(self.toolIpAddress, self.dirlog + "/" + tarLogs, user=self.account.login)
        ltarLogs = DIR_LOG_LOCAL + "/" + tarLogs
        os.rename(pathToTarlogs, ltarLogs)
        LOGGER.debug("local traffic log file on " + NODE_NAME + ": /home/jenkins/workspace/" + \
                     JOB_NAME.replace(" ", "_") + "/" + ltarLogs)
        LOGGER.debug("Use 'tar xvf <filename>' to uncompress archive")
        cmd = "bash -c 'rm -rf " + self.dirlog
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)


class TgenTrafficException(BaseException):
    """If error, raise it."""
    pass
