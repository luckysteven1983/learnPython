"""
Created on Oct 22, 2015

@author: Zheng Yuan

#weblink_id=3KJ-00117-0820-QPZZA
"""
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.common import Utils
import os
import random

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class es4793_check_CPU_usage(SDMTestCase):
    """
    Case Description:
       Use health check tool to check CPU usage per board
    Manual Test Steps:
       1. Run the health check command and check the log file
       2. The output should be:
          Completed cpu_usage check with status ok
          health completed
       3.check the log, there should be logs generated correctly.
    """

    def setUp(self):
        """Init the managers this case need"""
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.myHCM = self.sdmManager.healthCheckManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mySshManager = self.sdmManager.sshManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.fe = random.choice(self.allFEs)
        self.be = random.choice(self.allBEs)
        self.lab = random.choice([self.fe, self.be])
        self.success = True
        self.exceptMsg = str()
        LOGGER.debug("Test case es4793_check_CPU_usage started")


    def _precheck(self):
        """Test case pre-check and return current active alarm list """
        checkQoS = False

        LOGGER.info("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0], checkQoS)


    def test_check_CPU_usage(self):
        """Use health check tool to check CPU usage"""
        healthCommand = "cpu_usage"
        expectCheckOutput = ["Completed cpu_usage check with status ok", "health completed"]
        toolDir = "/cust_use/healthTools"
        checkLogDir = toolDir + "/log/healthcheck"
        checkLogCommand = "ls " + checkLogDir + ";ls " + checkLogDir + "/per_module"
        checkLogs = ["all.log", "progress.log", "summary.log", "per_module", "cpu_usage.log"]
        logContents = ["cpu_usage summary", "health completed", "Start cpu_usage check",
                      "Completed cpu_usage check with status ok"]  # What contents the log should contain
        logFiles = [checkLogDir + "/all.log", checkLogDir + "/progress.log",
                       checkLogDir + "/summary.log", checkLogDir + "/per_module/cpu_usage.log"]
        outputErrMsg = "The output of the health check tool can not meet the requirement"
        logsGenErrMsg = "The health check tool did not generate the logs needed"
        checkQoS = False

        # Lab Health check
        self._precheck()

        # get the start time of the TC
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.lab)

        # Run health check tool CPU check command
        LOGGER.debug("Run health check tool CPU check command ")
        checkOutput = self.myHCM.runToolCmd(self.lab, healthCommand)

        # Check the output of the result of the CPU check command
        LOGGER.debug("Check the output of the result of the CPU check command")
        for output in expectCheckOutput:
            if output not in checkOutput:
                LOGGER.debug("The output of the health check tool can not meet the requirement")
                self.success = False
                self.exceptMsg += str(outputErrMsg) + os.linesep

        # Check whether the logs have generated
        LOGGER.debug("Check whether log files have generated")
        checkLogOutput = self.mySshManager.run(self.lab.oamIpAddress, checkLogCommand)
        for logName in checkLogs:
            if logName not in checkLogOutput[1]:
                LOGGER.debug("The health check tool did not generate the logs needed")
                self.success = False
                self.exceptMsg += str(logsGenErrMsg) + os.linesep

        # Check logs contains the specified content
        LOGGER.debug("Check logs contains the specified content")
        try:
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[0], logContents[0], logContents[1])
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[1], logContents[3], logContents[1])
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[2], logContents[0])
            self.platformAsserts.assertFileContainsExpectedContents(self.lab.oamIpAddress,
                                                                    logFiles[3], logContents[0], logContents[3])
        except BaseException, msg:
            LOGGER.debug("Logs do not contain the specified content, log generated error.")
            self.success = False
            self.exceptMsg += str(msg) + os.linesep

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkQoS)
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        # Show the case running result
        LOGGER.debug("Show the result of the case")
        if self.success:
            LOGGER.debug("es4793_check_CPU_usage success!\n")
        else:
            LOGGER.error("es4793_check_CPU_usage failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)
