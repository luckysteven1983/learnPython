"""
@file ddm_log_utilities_nightly_test_once.py
@ingroup SDMSQA
@author Serge Beaufils
@date 2015-10-03
@brief find specific text in /var/local/nectar/log/ddmGateSupervisor.log
"""

import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from random import  randint
from lib.logparser.ddm_log_parser import (DDMLogParser, DDM_GATE_SUPERV_FILE)
from framework.common import Utils


LOGGER = Logger.getLogger(__name__)

START_TIM1 = '2015-01-01 01:00:00'
END_TIM1 = '2015-01-31 01:00:00'
TS_LEN = 24  # Timestamp length in ddmGateSupervisor.log


class ddm_log_utilities_nightly_test_once(SDMTestCase):
    """
    Unit test for DDMLogParser class.
    log file is : /var/local/nectar/log/ ddmGateSupervisor.log
    Mon May 11 11:44:30 2015 | ALR | Creation Alarm 505 | 0-0-12 | PDLSL3 | pid = 58441 |NRG 1 | no best RW gate available
    Mon May 11 11:44:30 2015 | ALR | Sending alarm RAISE to MCAS | 505 | MJ | 0-0-12
    ...
    """

    def setUp(self):
        LOGGER.info("ddm_log_utilities_nightly_test_once Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self._sshManager = self.sdmManager.sshManager
        self.maManager = self.sdmManager.mcasApplicationManager
        self._ddmLog = DDMLogParser(self._sshManager)

        # --- for the test we need to prepare some data
        #  1) fetch the log file from server
        self.ddmGateLogFile = self._sshManager.scpGet(self.fe.oamIpAddress, DDM_GATE_SUPERV_FILE)
        if self.ddmGateLogFile == '':
            LOGGER.error('unable to scp %s:%s', self.fe.id, DDM_GATE_SUPERV_FILE)
            raise BaseException('unable to scp ddmGateSupervisor.log')

        # 2) get some timestamps in the log file (1st line, in first half, in second half, and last line)
        with open(self.ddmGateLogFile, "r") as fgat:
            lines = fgat.readlines()
        self.nbrLines = len(lines)
        lastLine = self.nbrLines - 1

        # timestamp of first line
        self.tsStart = Utils.convertDdmGateTimeToDatetime(lines[0][0:TS_LEN])
        # timestamp of last line
        self.tsEnd = Utils.convertDdmGateTimeToDatetime(lines[lastLine][0:TS_LEN])
        indexMiddle = lastLine / 2
        # random timestamp in first half of file
        self.ts1 = Utils.convertDdmGateTimeToDatetime(lines[randint(1, indexMiddle - 1)][0:TS_LEN])
        # random timestamp in second half of file
        self.ts2 = Utils.convertDdmGateTimeToDatetime(lines[randint(indexMiddle + 1,
                                                                    lastLine - 1)][0:TS_LEN])

        # 3) now we fetch a random text in the file
        oneLine = lines[randint(1, lastLine - 1)]
        startPos = TS_LEN + randint(0, len(oneLine) - TS_LEN)
        endPos = startPos + 15 if (startPos + 15) < len(oneLine) else len(oneLine) - 1
        self.randomTxt = oneLine[startPos:endPos]  # choose a 15-char text



    def test_01_searchSuccess(self):
        """
        we fetch for a random text from the log file
        Then we search this text with the API
        """
        LOGGER.debug('\n[Test case 01] text  found in log file ')

        txtLog = 'random text found from <None> '
        linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe, startTime=None, occur=self.randomTxt)
        if len(linesFound) > 0:
            LOGGER.info(txtLog + ' : test OK')
        else:
            LOGGER.error(txtLog + ' : problem in API ? ')
            raise BaseException(txtLog + ' : problem in API ? ')

        # startDate is a long time ago , should be OK
        txtLog = 'random text found from ' + START_TIM1
        linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe, startTime=START_TIM1, occur=self.randomTxt)
        if len(linesFound) > 0:
            LOGGER.info(txtLog + ' : test OK')
        else:
            LOGGER.error(txtLog + ' : problem in API ? ')
            raise BaseException(txtLog + ' : problem in API ? ')

        # interval is short and it is a long time ago , should be KO
        txtLog = 'random text NOT found from ' + START_TIM1 + ' to ' + END_TIM1
        linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe,
                                                          startTime=START_TIM1,
                                                          endTime=END_TIM1,
                                                          occur=self.randomTxt)
        if len(linesFound) == 0:
            LOGGER.info(txtLog + ' : test OK')
        else:
            LOGGER.error(txtLog + ' : problem in API ? ')
            raise BaseException(txtLog + ' : problem in API ? ')


    def test_02_searchFailed(self):
        """
        search for a text which doesn't exist
        """
        LOGGER.debug('\n[Test case 01] text NOT found in log file ')
        txt = 'abcxyz'
        txtLog = 'text NOT found from <None>'
        linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe, startTime=None, occur=txt)
        if len(linesFound) == 0:
            LOGGER.info(txtLog + ' : test OK')
        else:
            LOGGER.error(txtLog + ' : problem in API ? ')
            raise BaseException(txtLog + ' : problem in API ? ')


    def test_03_searchWithDate(self):
        """
        search with endDate > startDate then swap the dates
        """
        LOGGER.debug('\n search empty text in DDM log with dates , must get full file')
        txtLog = 'startTime is first line, endTime is last time'
        linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe, startTime=self.tsStart, endTime=self.tsEnd, occur='')
        if len(linesFound) == self.nbrLines:
            LOGGER.info(txtLog + ' : test OK')
        else:
            LOGGER.error(txtLog + ' : problem in API ? ')
            raise BaseException(txtLog + ' : problem in API ? ')

        LOGGER.debug('\n search empty text in DDM log with invalid dates , must get no lines')
        txtLog = 'startTime is higher than endTime'
        linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe, startTime=self.tsEnd, endTime=self.tsStart, occur='')
        if len(linesFound) == 0:
            LOGGER.info(txtLog + ' : test OK')
        else:
            LOGGER.error(txtLog + ' : problem in API ? ')
            raise BaseException(txtLog + ' : problem in API ? ')


    def test_04_emptyOccur(self):
        """
        search for an empty text, will return the full log file
        """
        LOGGER.debug('\n[Test case 01] search empty text in log file ')
        ddmGateLogFile = self._sshManager.scpGet(self.fe.oamIpAddress, DDM_GATE_SUPERV_FILE)
        if ddmGateLogFile != '':
            with open(ddmGateLogFile, "r") as fgat:
                lengthOriFile = len(fgat.readlines())
                fgat.close()

            linesFound = self._ddmLog.searchDdmGateSupervisor(self.fe, startTime='0000-00-00 00:00:00', occur='')
            lengthResult = len(linesFound)
            if lengthResult == lengthOriFile:
                LOGGER.info('same number of lines : test is OK')
            else:
                LOGGER.error('unexpected behaviour : NOT same number of lines , problem in API ? ')
                raise BaseException('unexpected behaviour : NOT same number of lines , problem in API ? ')


if __name__ == "__main__":
    unittest.main()

