"""
Created on Aug 17, 2015

@author: Andy SUN
"""

import os
import time

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_NONPILOT


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ez4323_kill_cluster_master(SDMTestCase):
    """Blade SW fault: kill cluster on BE MASTER
    """

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_kill_cluster_master(self):
        """kill cluster on master BE

        Procedure:
        1. kill cluster on master BE
        2. check topology on FE.
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case")
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        # Half cluster reset on any master BE.
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(self.allBEs)[0]
        LOGGER.info("Kill cluster on master BE %s", masterBE.id)
        # Got the two nonpilots
        stations = self.allBEs[0].stations.values()
        stations = [sta.rcsHostname for sta in stations if sta.middlewareRole == MIDDLEWARE_ROLE_NONPILOT][0:2]
        for station in stations:
            LOGGER.info("Restart %s on master BE %s", station, masterBE.id)
            self.sdmManager.mcasMachineManager.stationfwRestartNonPilot(masterBE, station)
        # We need to wait all NDB become started.
        LOGGER.info("Waiting NDB up on master BE %s", masterBE.id)
        CommonAssert.timedAssert(3*60*60, 30, self.sdmManager.databaseStateManager.assertNdbState,
                                 masterBE, 'started', logLevel='debug')

        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        time.sleep(10)
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep
        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
