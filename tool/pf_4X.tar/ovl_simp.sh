#!/bin/bash

#############################################
#   Usage: $0 <simp log dir>
############################################
#cd $1
if [ -f *.tar ] ; then
   for f in `ls -l *.tar | awk '{print $9}'`
   do 
     tar xvf $f
   done
fi

function QosFilter { 
gawk '
BEGIN { FS = "[:,|]"; }
$0 ~ /Time:/ { Time=$0; sub(/^.*Time: /,"",Time);gsub(/=*/,"",Time);}
$0 ~ /Total/ { if ( $9 ~ /[0-9]\.[0-9]/)  { TPS=$9 }  }
$0 ~ /^Success:/ { Succ=$0;gsub(/,/,"",Succ);printf( "Time: %s TPS: %6.2f %s QoS: %.2e\n",Time,TPS,Succ,($6+$8+$10)/($2+$6+$8+$10));}
'; 
}

if [ -f total_simp.txt ] 
then
  rm total_simp.txt statistics.txt
fi

for file in `ls -l simp.log.*|awk '{print $9}'`
do
   echo "Process file $file...."
   type=`grep result $file|tail -1|awk '{print $1}'|cut -c9`
   if [ $type = "H" ]
   then
        type="HSS"
   else
        type="LTE"
   fi

   cat $file |QosFilter|awk '{print "'"$file"'", "'"$type"'", $0}' >> total_simp.txt
   tail -80 $file|QosFilter|tail -1|awk '{print "'"$file"'", "'"$type"'", $0}' >> statistics.txt
done
#cat statistics.txt | awk 'BEGIN { hTPS=lTPS=hSuccess=lSuccess=hFailed=lFailed=hFailed3004=lFailed3004=hFailed5012=lFailed5012=hLost=lLost=eHSS=eLTE=0; printf("TYPE\tSuccess\tFailed\tFailed3004\tFailed5012\tLost\tTPS\tQos\n"); } { if ($2 ~ /HSS/) { eHSS=1;hTPS+=$10; hSuccess+$12; hFailed+=$14; hFailed3004+=$16; hFailed5012+=$18; hLost+=$20;} else { eLTE=1; lTPS+=$10; lSuccess+$12; lFailed+=$14; lFailed3004+=$16; lFailed5012+=$18; lLost+=$20;} } END { if (eHSS=1) { printf(


