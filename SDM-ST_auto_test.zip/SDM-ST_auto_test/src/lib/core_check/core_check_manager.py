"""
@file core_check_manager.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-03-12
@brief Check core files on lab

Check core files on lab and save gdb info if needed.
"""

import re
import os
import lib.exceptions_messages as eMsgs
from datetime import timedelta
from framework.common import Utils
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

def validateTimeFormat(timestamp):
    """Validate timestamp provided by user.

    If error, raise CoreCheckManagerError execption.

    Keyword arguments:
    timestamp -- time format like 'YYYY-MM-DD HH:MM:SS'
    """
    regex = re.compile(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
    if not regex.match(timestamp):
        errorMsg = "%s: '%s'" %(eMsgs.CORE_INVALID_TIME_FORMAT, timestamp)
        LOGGER.error(errorMsg)
        raise CoreCheckManagerError(errorMsg)

def saveGdbInfo(savedFile, gdbInfo):
    """Write gdb information into a savedFile.

    Keyword arguments:
    savedFile -- a file for saving gdb information
    gdbInfo -- a gdb output to be writen into a file
    """
    with open(savedFile, 'a+') as fileHandler:
        fileHandler.write('+'*80 + '\n')
        fileHandler.write(gdbInfo)
        fileHandler.write('\n' + '-'*80 + '\n')

class CoreCheckManagerError(Exception):
    """If error, raise it."""
    pass

class CoreCheckManager(object):
    """Check core files under given directories on lab.

    Check core files under given directories on remote lab. By default, the
    directories to be checked on remote lab include below
    1) /var/local/nectar/crash and its subdirectoires
    2) /sncore and its subdirectoires
    3) /sdmcore and its subdirectories
    4) /etc/httpd and its subdirectories
    5) /opt/proxy

    The directories can be dynamically modifed with the method 'addCoreDir' and
    'removeCodeDir'. The directories will be checked on each blade (e.g. 0-0-2,
    0-0-3, 0-0-5, ...) and the blades are got dynamically through checking
    directory '/opt/config/servers' on active pilot.

    Usage:
        Let's take lab 135.251.83.201 as an example on how to get a CoreCheckManager
        instance.

        import SshManager, CoreCheckManager
        sshManager = SshManager()
        core = CoreCheckManager(sshManager)

        So then we can use instance 'core' to call the methods provided by this
        class. On how to call the method, please check doc string in each
        method.
    """

    def __init__(self, sshManager, multiTasksManager):
        """Init CoreCheckManager instance with sshManager.

        Keyword arguments:
        sshManager -- an SSH or other protocol instance used for remote command
                    execution.
        """
        # Run multi-tasks
        self.multiTasksManager = multiTasksManager
        # Execute remote command
        self._sshManager = sshManager
        # Keep core file directories and their searching max-depth
        self._coreDir = {'/var/local/nectar/crash': 0, '/sncore': 0, '/sdmcore': 0, '/etc/httpd': 0, '/opt/proxy': 1}

    def getCoreFilesByTime(self, lab, bTime='0000-00-00 00:00:00', savedDir=None, name='core', bladesToClean=None):
        """Get core file list according to given time and name.

        It recevies string type time (lab time) and name as arguments. The time
        string should be like 'YYYY-MM-DD HH:MM:SS' and the name string is the
        name you want to match and by default, it will search *core*. It returns
        a list constituted by core files.

        If string type argument savedDir is set and it is a directory and the
        ower has write permission in this directory, the gdb info for each core
        file will be saved to this directory,

        Keyword arguments:
        lab -- one lab object
        bTime -- begining time for searching (default '0000-00-00 00:00:00')
        savedDir -- a directory where to write gdb information (default None)
        name  -- name for searching with wildcard (default 'core')

        Example:
            coreList = core.getCoreFilesByTime(lab)
            It will return all core file lists. The coreList is like below
            ['[2014-10-11 10:12:13] 0-0-1:/sncore/core1',
             '[2014-10-11 10:12:15] 0-0-2:/sncore/core2',
             ...]

            coreList = core.getCoreFilesByTime(lab, '2014-10-11 10:12:14')
            It will return core files since '2014-10-11 10:12:14', the coreList
            is like below
            ['[2014-10-11 10:12:15] 0-0-2:/sncore/core2', ...]

            coreList = core.getCoreFilesByTime(lab, name='crash')
            It will return core files named with *crash*, the coreList is like
            below
            ['[2014-10-11 11:12:13] 0-0-9:/sncore/sdmcrash1',
             '[2014-10-11 11:12:15] 0-0-10:/sncore/sdmcrash2',
            ...]

            coreList = core.getCoreFilesByTime(lab, '2014-10-11 10:12:14',
                        '/home/user/coredir')
            It will core files since '2014-10-11 10:12:14', the coreList
            is like below
            ['[2014-10-11 10:12:15] 0-0-2:/sncore/core2',
             '[2014-10-11 10:22:15] 0-0-3:/sncore/core3',
            ...]
            And if the directory '/home/user/coredir' exists and the ower has
            writing permission. The detail gdb info will be saved to this
            directory. Two new files '0-0-2' and '0-0-3' will be created. And
            gdb info for /sncore/core2 can be found in file 0-0-2, and gdb info
            for /sncore/core3 can be found in file 0-0-3. If the directory
            doesn't exist or the owner has no wirting permission under the
            directory, it will be looked as savedDir=None.
            If the user calls this method continually or the file '0-0-2' has
            already exists in this directory, the gdb info will be appened into
            the end of the file.
        """
        validateTimeFormat(bTime)
        coreFiles = self._getCoreFiles(lab, name, bladesToClean)
        coreFiles = ['[%s] %s' %(t, f) for t, f in coreFiles if bTime <= t]
        if isinstance(savedDir, str) and\
                os.path.isdir(savedDir) and\
                os.access(savedDir, os.W_OK | os.X_OK):
            self._getGdbInfo(lab, coreFiles, savedDir)
        return coreFiles

    def getCoreFilesByDelta(self, lab, days=0, hours=0, mins=0, savedDir=None, name='core'):
        """Get core file lists according to delta and name.

        It recevies int type time delta based on current lab time (days, hours
        and minutes) and string type name as arguments. The delta is a positive
        integer based on current lab time. the name argument is the same with
        method 'getCoreFilesByTime'. It returns a list constituted by core
        files just like 'getCoreFilesByTime'.

        If savedDir is given, it will save the gdb information just like method
        'getCoreFilesByTime'.

        Keyword arguments:
        lab -- one lab object
        days -- delta of days based on current lab time (default 0)
        hours -- delta of hours based on current lab time (default 0)
        mins -- delta of minutes based on current lab time (default 0)
        savedDir -- a directory where to write gdb information (default None)
        name -- name for searching with wildcard (default 'core')

        Example:
            coreList = core.getCoreFilesByDelta(lab)
            Its result is equal to core.getCoreFilesByTime(lab)

            coreList = core.getCoreFilesByDelta(lab, hours=3)
            It will return a core file list happened before 3 hours.

            coreList = core.getCoreFilesByDelta(lab, hours=3, mins=3)
            It will return a core file list happened before 3 hours and 3
            mininutes.
        """
        timeDelta = timedelta(days=days, minutes=mins, hours=hours)
        bTime = str(Utils.getCurrentLabTime(self._sshManager, lab, False) - timeDelta)
        return self.getCoreFilesByTime(lab, bTime, savedDir, name)

    def addCoreDir(self, coreDir, maxDepth=0):
        """Add core directory where to search core files.

        Add core file searching directory with string type coreDir and int type
        maxDepth. If the core file directory exits, it will be covered.

        Keyword arguments:
        coreDir  -- the core directory to be added to check core
        maxDepth -- the max searching depth in core diectory (default 0)

        Example:
            core.addCoreDir('/tmp/coredir')
            it will add directory or file '/tmp/coredir' and its subdirectories
            to its core file searching path.

            core.addCoreDir('/tmp/coredir', 1)
            it will only add directory or file '/tmp/coredir' to its core file
            searching path.

            core.addCoreDir('/tmp/coredir', 2)
            it will add directory or file '/tmp/coredir' and its first level
            subdirectories to its core file searching path.
       """
        if not isinstance(maxDepth, int) or maxDepth < 1:
            maxDepth = 0
        self._coreDir[coreDir] = maxDepth

    def removeCoreDir(self, coreDir):
        """Remove core directory where to search core files.

        Keyword arguments:
        coreDir  -- the core directory to be added to check core

        Example:
            core.removeCoreDir('/tmp/coredir')
            it will remove directory or file '/tmp/coredir' and its
            subdirectories from its current core file searching path.
        """
        if coreDir in self._coreDir:
            del self._coreDir[coreDir]

    def showCoreDir(self):
        """Show all current core directory's dictionary.

        Example:
            dirDict = core.showCoreDir()
            The dirDict will get a dictionary including all searching path like
            below
            {'/var/local/nectar/crash': 1, '/sncore': 0, '/sdmcore': 0}
        """
        return self._coreDir

    def checkCoreFilesByTime(self, lab, bTime='0000-00-00 00:00:00', savedDir=None, name='core'):
        """Check core file according to given begining time and name and raise exception if core
        files are found.

        If savedDir is given and there are core files, the gdb information will
        be saved to this directory.

        Keyword arguments:
        lab -- one lab object
        bTime -- begining time for searching (default '0000-00-00 00:00:00')
        savedDir -- a directory where to write gdb information (default None)
        name  -- name for searching with wildcard (default 'core')

        Example:
            core.checkCoreFilesByTime(lab)
            raise exception if core files are found

            core.checkCoreFilesByTime(lab, '2014-10-10 11:12:13', '/coredir')
            raise exception if core files are found since '2014-10-10 11:12:13' are found and save
            the gdb information to '/coredir'.
        """
        coreFiles = self.getCoreFilesByTime(lab, bTime, savedDir, name)
        if coreFiles:
            errorMsg = eMsgs.CORE_DUMP_FOUND + "\n" + "\n".join(coreFiles)
            LOGGER.error('%s: %s', lab.id, errorMsg)
            raise CoreCheckManagerError(errorMsg)

    def checkCoreFilesByDelta(self, lab, days=0, hours=0, mins=0, savedDir=None, name='core'):
        """Check core file according to given time delta and name and raise exception if core files
        are found.

        If savedDir is given and there are core files, the gdb information will
        be saved to this directory.

        Keyword arguments:
        lab -- one lab object
        days -- delta of days based on current lab time (default 0)
        hours -- delta of hours based on current lab time (default 0)
        mins -- delta of minutes based on current lab time (default 0)
        savedDir -- a directory where to write gdb information (default None)
        name -- name for searching with wildcard (default 'core')

        Example:
            core.checkCoreFilesByDelta(lab)
            raise exception if core files are found.

            core.checkCoreFilesByDelta(lab, 1, '/coredir')
            raise exception if core files are found since 1 day are found and save the gdb
            information to '/coredir'.
        """
        coreFiles = self.getCoreFilesByDelta(lab, days, hours, mins, savedDir, name)
        if coreFiles:
            errorMsg = eMsgs.CORE_DUMP_FOUND + "\n" + "\n".join(coreFiles)
            LOGGER.error('%s: %s', lab.id, errorMsg)
            raise CoreCheckManagerError(errorMsg)

    def _getCoreFiles(self, lab, name, bladesToClean=None):
        """Get all core files in core directories.

        Keyword arguments:
        lab -- one lab object
        name -- name for searching with wildcard
        """
        coreList = []
        cmdString = self._getCommand(name)
        bladesList = bladesToClean
        if bladesToClean == None:
            bladesList = self._getBlades(lab)
        for blade in bladesList:
            if self._checkBladeAlive(lab, blade):
                coreList.extend(self._getCoreOnBlade(lab, blade, cmdString))
        return coreList

    def _checkBladeAlive(self, lab, blade):
        """Check this blade is active or not.

        Keyword arguments:
        lab -- one lab object
        blade -- blade to be checked
        """
        pingCmd = "ping -c 2 -W 2 %s >/dev/null 2>&1; echo $?" %blade
        return int(self._runShellCmd(lab, pingCmd, True)) == 0

    def _getCoreOnBlade(self, lab, blade, cmdString):
        """Get core files on one blade.

        Keyword arguments:
        lab -- one lab object
        blade -- blade where searching the core file
        cmdString -- One shell command executed on this blade.
        """
        coreList = []
        pattern = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) (.*)')
        command = 'ssh %s "%s" 2>/dev/null' %(blade, cmdString)
        for line in self._runShellCmd(lab, command).split(os.linesep):
            #line: -rw-r--r-- 1 root root 72 2015-03-05 08:54:22 /dir/file
            found = pattern.search(line)
            if found:
                coreList.append((found.group(1), blade + ':' + found.group(2)))
        return coreList

    def _getBlades(self, lab):
        """Get current blade list on the remote lab.

        Keyword arguments:
        lab -- one lab object
        """
        return self._runShellCmd(lab, 'ls /opt/config/servers').split()

    def _getCommand(self, name):
        """Build searching command used for execution on the remote server.

        Keyword arguments:
        name -- name for searching with wildcard
        """
        command = ''
        for coreDir, searchDepth in self._coreDir.items():
            option = '-maxdepth %s' %searchDepth if searchDepth else ''
            command += "find -L %s %s -iname '*%s*' -type f " %(coreDir, option, name)
            command += "-exec ls -l --time-style='+%F %T' {} ';';"
        return command

    def _runShellCmd(self, lab, command, rc=False):
        """Execute remote command with instance given in contructor.

        It directly invokes the method provided by SSH instance.

        Keyword arguments:
        lab -- one lab object
        command -- command to be executed on remote server.
        rc -- return return code if True or stdout
        """
        response = self._sshManager.run(lab.oamIpAddress, command)
        return response[0] if rc else response[1]

    def _getGdbInfo(self, lab, coreFilesList, savedDir):
        """Save gdb information for each core file to directory 'savedDir'

        Keyword arguments:
        lab -- one lab object
        coreFilesList -- core files list
        savedDir -- a directory used to save gdb information
        """
        for core in coreFilesList:
            # core is like '[2014-10-10 11:22:33] 0-0-1:/sncore/core'
            rList = core.split()[-1].split(':')
            bladeNo = rList[0]
            coreFile = rList[1]
            binFile = self._getBinFile(lab, bladeNo, coreFile)
            if not binFile:
                gdbInfo = 'No bin file found for %s' %core
            else:
                gdbInfo = 'gdb Information: gdb %s %s\n' %(binFile, coreFile)
                gdbInfo += self._runGdbCmd(lab, bladeNo, binFile, coreFile)
            saveGdbInfo(savedDir + os.sep + bladeNo, gdbInfo)

    def _runGdbCmd(self, lab, bladeNo, binFile, coreFile):
        """Run gdb command on remote server.

        Keyword arguments:
        lab -- one lab object
        bladeNo -- blade number where to run the gdb command
        binFile -- binary file for gdb command
        coreFile -- core file for gdb command
        """
        # Here we don't need interactive shell for gdb, because gdb provides a
        # method to run gdb commands just like a shell command.
        # gdb binFile corefile -x gdbCommandFile
        # Here we have no more knowledge no how to debug this core, so only run
        # gdb and print its stack backtrace and then quit from it.
        gdbCmd = r"echo -e 'bt\nquit' > tmpgdbfile"
        gdbCmd += " && gdb %s %s -x tmpgdbfile" %(binFile, coreFile)
        gdbCmd += " && rm tmpgdbfile"
        cmd = 'ssh %s "%s"' %(bladeNo, gdbCmd)
        return self._runShellCmd(lab, cmd)

    def _searchBinFile(self, lab, bladeNo, binStr):
        """Search binary file on one blade with given binaray string.

        Keyword arguments:
        lab -- one lab object
        bladeNo -- blade number where to search bin file
        binStr -- a part name of binaray file
        """
        cmd = "ssh %s \"find / -iname '%s' -type f 2>/dev/null -executable\
               2>/dev/null\" 2>/dev/null" %(bladeNo, binStr)
        response = self._runShellCmd(lab, cmd).strip()
        return response.split(os.linesep) if response else None

    def _getBinFile(self, lab, bladeNo, coreFile):
        """Get bin file generating the core file.

        Keyword arguments:
        lab -- one lab object
        bladeNo -- blade number where to search bin file
        coreFile -- to be searched core file
        """
        cmd = "ssh %s 'file %s 2>/dev/null' 2>/dev/null" %(bladeNo, coreFile)
        # 'PDLSM3' or '/usr/bin/perl /usr/dhafw/tools/launcher/launchLdapServer'
        response = self._runShellCmd(lab, cmd).strip()
        found = re.search(r"core file.*'(.*)'$", response)
        if not found:
            return None
        binStr = found.group(1).split()[0]
        if binStr.find('/') != -1:
            return binStr
        binFiles = self._searchBinFile(lab, bladeNo, binStr)
        if binFiles:
            # If match more, only need to return the 1st one because maybe they
            # are linked to the same one.
            return binFiles[0].strip()
        # Maybe we need to search its parent process.
        # For example, we should search 'S7TCH0' and then 'S7TCH'.
        binStr = binStr.rstrip('0123456789')
        binFiles = self._searchBinFile(lab, bladeNo, binStr)
        if binFiles:
            return binFiles[0].strip()
        return None

    def runCheckCoreOnAllTestBed(self, testBed, startTime):
        """Check core file on all labs in parallel

        @param testBed    testBed on which check core files
        @param startTime  start time since when check core files
        """
        # Check core on all labs in parallel
        LOGGER.debug("Check core files on all Labs in progress")
        for labID in testBed.labs:
            threadName = self.multiTasksManager.register(self.checkCoreFilesByTime, testBed.labs[labID], str(startTime))
            LOGGER.debug("Check core files on Lab '%s' in progress -> thread ID '%s'", labID, threadName)
        LOGGER.debug("Wait check core files complete on all Labs")
        return self.multiTasksManager.runMultiTasks()
