"""
This package contains all platform / middleware test cases.
i.e. mcas, tomix test cases, but also netbackup related test cases.
"""
