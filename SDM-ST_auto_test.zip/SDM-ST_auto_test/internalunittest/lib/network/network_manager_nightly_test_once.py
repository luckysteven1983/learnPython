'''
Created on Nov 10, 2015

@author: xzhao015
'''

from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
LOGGER = Logger.getLogger(__name__)


class network_manager_nightly_test_once(SDMTestCase):

    def setUp(self):
        LOGGER.info("network_manager_nightly_test_once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        self.networkManager = self.sdmManager.networkManager
    def tearDown(self):
        pass

    def test_01_loopInterfaceUpDown_success(self):
        LOGGER.info("test_01_loopInterfaceUpDown_success")
        self.networkManager.loopInterfaceUpDown(self.be, 'gdm14', 2, 5)

    def test_02_loopInterfaceUpDown_fail(self):
        LOGGER.info("test_02_loopInterfaceUpDown_fail")
        self.assertRaises(BaseException, self.networkManager.loopInterfaceUpDown, self.be, 'gdm15', 2, 5)

    def test_03_getInterface_success(self):
        LOGGER.info("test_03_getInterface_success")
        _ = self.networkManager.getInterface(self.be, 'gdm14')

    def test_04_getInterface_fail(self):
        LOGGER.info("test_04_getInterface_fail")
        self.assertRaises(BaseException, self.networkManager.getInterface, self.be, 'gdm15')

    def test_05_assertInterfaceState_success(self):
        LOGGER.info("test_05_assertInterfaceState_success")
        interfaceList = self.networkManager.getInterface(self.be, 'gdm14')
        for interface in interfaceList:
            self.networkManager.assertInterfaceState(self.be, interface, 'up')

    def test_06_assertInterfaceState_fail(self):
        LOGGER.info("test_06_assertInterfaceState_fail")
        interfaceList = self.networkManager.getInterface(self.be, 'gdm14')
        for interface in interfaceList:
            self.assertRaises(BaseException, self.networkManager.assertInterfaceState, self.be, interface, 'down')

    def test_07_setInterfaceState_success(self):
        LOGGER.info("test_07_setInterfaceState_success")
        interfaceList = self.networkManager.getInterface(self.be, 'gdm14')
        self.networkManager.setInterfaceState(self.be, interfaceList, 'down')
        self.networkManager.assertInterfaceListState(self.be, interfaceList, 'down')
        self.networkManager.setInterfaceState(self.be, interfaceList, 'up')
        self.networkManager.assertInterfaceListState(self.be, interfaceList, 'up')

    def test_08_setInterfaceState_fail(self):
        LOGGER.info("test_08_setInterfaceState_fail")
        interface = self.networkManager.getInterface(self.be, 'gdm14')
        self.assertRaises(BaseException, self.networkManager.setInterfaceState, self.be, interface, 'up_fail')

