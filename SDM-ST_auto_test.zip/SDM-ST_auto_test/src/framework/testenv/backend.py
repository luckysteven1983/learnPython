'''
Created on Feb 13, 2015

@author: yohannm
'''
from framework.testenv.product_role import ProductRole

class Backend(ProductRole):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        super(Backend, self).__init__()
        self.networkReplicatedGroup = 0
        self.replicatedAddress = list()
        self.ndbAddress = list()
        self.isAutomaticSwoEnabled = None
