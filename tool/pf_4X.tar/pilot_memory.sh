#!/bin/bash

#In case there are more than one top file for one station, we use the latest one.
top_file=`ls -lrt top_*|tail -1|awk '{print $9}'`
#In case there is no top file for some station, we ignore it.
grep Mem: $top_file|tail -1|awk '{print $4}'|sed -n -e 's/k//p' >> used_mem 
grep Mem: $top_file|tail -1|awk '{print $8}'|sed -n -e 's/k//p' >> buffer
grep Swap: $top_file|tail -1|awk '{print $8}'|sed -n -e 's/k//p' >> cache        
 
paste used_mem buffer cache > tmp     
awk 'BEGIN {print "Mem(G)"} { mem=($1-$2-$3); printf "%.2f\n", mem/1024/1024; } ' tmp > memory.result
rm  used_mem buffer cache tmp 
cat memory.result
