'''
Created on Nov 2, 2015

@author: Tangi Lavanant

'''
import random
import unittest

from framework.asserts.common_asserts import CommonAssert
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_platform_manager import MCAS_ASTART_TIMEOUT


LOGGER = Logger.getLogger(__name__)
MCAS_INTERVAL_CHECK = 30

class mcas_platform_manager_nightly_test_once(SDMTestCase):
    '''
    Test for McasPlatformManager
    '''

    def setUp(self):
        LOGGER.info("McasAstopAstart Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.mcasPlatformManager = self.sdmManager.mcasPlatformManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts

    def tearDown(self):
        pass


    def test_01_runAstopAll_success(self):
        '''
        This is a test once for Astop/Astart on all boards
        '''
        LOGGER.info("test_01_runAstopAll_success")
        self.mcasPlatformManager.runAstop(self.fe)
        self.mcasPlatformManager.runAstart(self.fe)
        for blade in self.fe.stations:
            CommonAssert.timedAssert(MCAS_ASTART_TIMEOUT, MCAS_INTERVAL_CHECK, self.testEnvAsserts.assertStationOK, self.fe, blade,
                                 'COMPL', 'debug')

    def test_02_runAstart_AstopBlade_success(self):
        '''
        This is a test once for Astop/Astart on a board
        '''
        LOGGER.info("test_02_runAstart_AstopBlade_success")
        npMach = self.fe.getStationListbyProductRole('RT').keys()[:2]
        blade = npMach[random.randint(0, len(npMach) - 1)]
        LOGGER.info("runAstop and then Astart on blade: " + blade)
        self.mcasPlatformManager.runAstop(self.fe, blade)
        self.mcasPlatformManager.runAstart(self.fe, blade)
        CommonAssert.timedAssert(MCAS_ASTART_TIMEOUT, MCAS_INTERVAL_CHECK, self.testEnvAsserts.assertStationOK, self.fe, blade,
                                 'COMPL', 'debug')

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
