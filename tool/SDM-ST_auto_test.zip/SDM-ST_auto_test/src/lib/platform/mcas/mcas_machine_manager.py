"""
@file mcas_machine_manager.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-03-12
@brief Manager all machine operations in subshl

Manager all machine operations in subshl.
"""

import os
import time
import re
import lib.exceptions_messages as eMsgs
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

ROUZIC_WORKAROUND = 30
MIDDLEWARE_ROLE_NONPILOT = 'non-pilot'
MIDDLEWARE_ROLE_PILOT = 'pilot'

def unique(iteration, status):
    """Return True if each item in iteration matches status with regexp or False

    @param iteration    an iterable object
    @param status    to be checked regexp pattern
    """
    pattern = re.compile(status)
    if not iteration:
        return False
    for item in iteration:
        if not pattern.search(item):
            return False
    return True

def getMatedPairBlade(blade):
    """Return mated pair blade name.

    @param blade string like '0-0-2'

    @verbatim
        matedPair = subshl.getMatedPairBlade('0-0-2')
        it returns '0-0-10'
    @endverbatim
    """
    tmpList = blade.split('-')
    blade = int(tmpList[-1])
    tmpList[-1] = str(8 + blade) if blade < 9 else str(blade - 8)
    return '-'.join(tmpList)

class MCASMachineManagerError(BaseException):
    """If error, raise it."""
    pass

class MCASMachineManager(object):
    """All machine operations in subshl.

    @verbatim
        Let's take lab 135.251.83.201 as an example on how to get a
        MCASMachineManager instance.

        import SshManager, MCASMachineManager
        sshManager = SshManager()
        subshl = MCASMachineManager(sshManager)

        So then we can use instance subshl to call the methods provided by this
        class. On how to call the method, please check doc string in each
        method.
    @endverbatim
    """

    def __init__(self, sshManager, subshlManager, prefix='0-0-'):
        """Init MCASMachineManager instance with sshManager.

        @param sshManager    an SSH or other protocol instance used for remote command execution.
        @param subshlManager subshl proxy
        @param prefix    machine host name prefix (default '0-0-')
        """
        self._subshl = subshlManager
        self._sshManager = sshManager
        self._prefix = prefix
        self._CA = CommonAssert

    def getMachineInfo(self, lab, machine=None):
        """Get machine information.

        It will return a list in which, each item includes one machine
        information string

        The output of 'op:status,machine' for FE, BE and PFE will be like below

        MACHINE    STATE     REASON   STATUS   CHK  ID  TYPE    STATE      MATE
        --------  --------  --------  -------  ----  ----  -----  --------  ----
        0-0-1     LEAD      AUTO      COMPL    ALW   1   PILOT  STANDBY   0-0-9
        0-0-2     LEAD      MAN       COMPL    ALW   3   VHOST  STANDBY   0-0-10
        0-0-3     LEAD      AUTO      COMPL    ALW   5   VHOST  STANDBY   0-0-11
        0-0-9     LEAD      AUTO      COMPL    ALW   2   PILOT  ACTIVE    0-0-1
        0-0-10    LEAD      AUTO      COMPL    ALW   4   VHOST  ACTIVE    0-0-2
        0-0-11    LEAD      AUTO      COMPL    ALW   6   VHOST  ACTIVE    0-0-3

        So the return list should be below
        ['0-0-1     LEAD      AUTO      COMPL    ALW   1   PILOT  STANDBY
        0-0-9', '0-0-2     LEAD      MAN       COMPL    ALW   3   VHOST  STANDBY
        0-0-10', ...]

        The output of'op:status,machine' for PMGW will be like below

                                         NODE  ------------- VHOST -------------
        MACHINE        STATE     REASON    ID   TYPE    STATE         MATE
        ----------------  --------  --------  ----  -----  --------  -----------
        MACHINE=0-0-1     LEAD      AUTO      1   PILOT  STANDBY   MACHINE=0-0-9
        MACHINE=0-0-2     LEAD      AUTO      3
        MACHINE=0-0-3     LEAD      AUTO      5
        MACHINE=0-0-9     LEAD      AUTO      2   PILOT  ACTIVE    MACHINE=0-0-1
        MACHINE=0-0-10    LEAD      AUTO      4
        MACHINE=0-0-11    LEAD      AUTO      6

        So the return list should be below
        ['MACHINE=0-0-1     LEAD      AUTO      1   PILOT  STANDBY
        MACHINE=0-0-9', 'MACHINE=0-0-2     LEAD      AUTO      3', ...]

        By default, it will return all machine information. Specify an
        integer 1, 2 ... or string like '0-0-1', '0-0-2' to return one machine information.

        @param lab    one lab object
        @param machine    an integer indicating machine number or string like '0-0-1' (default None)
        """
        machine = 'all' if machine is None else self._getMachineName(lab, machine)
        response = self._subshl.run(lab, 'op:status,machine=' + machine)
        mInfo = [line.strip() for line in response.split(os.linesep)]
        pattern = re.compile('(MACHINE=)?' + self._prefix)
        return [line for line in mInfo if pattern.match(line)]

    def getVhostsInfo(self, lab):
        """Get Vhost information.

        It will return a list in which, each item includes one vhost
        information string like getMachineInfo method.

        @param lab    one lab object

        @verbatim
           vHosts = subshl.getVhostsInfo(lab)

           the return value vHosts should be a list including all vhost
           information like below

           ['0-0-2     LEAD      MAN       COMPL    ALW   3   VHOST  STANDBY
           0-0-10', '0-0-3     LEAD      AUTO      COMPL    ALW   5   VHOST
           STANDBY   0-0-11', '0-0-10    LEAD      AUTO      COMPL    ALW   4
           VHOST  ACTIVE    0-0-2', '0-0-11    LEAD      AUTO      COMPL    ALW
           6   VHOST  ACTIVE    0-0-3']
        @endverbatim
        """
        return [m for m in self.getMachineInfo(lab) if m.find('VHOST') != -1]

    def getMachinesNotVHost(self, lab):
        """Get all non-pilot which is not vhost.

        @param lab    one lab object

        @verbatim
           MachineList = MCASMachineManager.getMachinesNotVHost(lab)

           the return value all non-pilot which is not vhost.

           ['0-0-4','0-0-5','0-0-12','0-0-13']
        @endverbatim
        """
        return [m.split()[0] for m in self.getMachineInfo(lab) if not re.search('VHOST|PILOT', m)]


    def getMachinesNonPilot(self, lab):
        """Get all non-pilot .
        @param lab    one lab object

        @verbatim
           MachineList = MCASMachineManager.getMachinesNonPilot(lab)
           the return value all non-pilot .
           ['0-0-4','0-0-5','0-0-12','0-0-13']
        @endverbatim
        """
        return [m.split()[0] for m in self.getMachineInfo(lab) if not re.search('PILOT', m)]


    def checkMachineStatus(self, lab, machine=None, status='COMPL', logLevel='error'):
        """raise an exception if machine status is not equal to given status.

        If the machine is None, it will check all machines. The status can be
        a regexp pattern.

        @param lab    one lab object
        @param machine    an integer indicating machine number or string like '0-0-1' (default None)
        @param status    expected machine status (default 'COMPL')

        @verbatim
            subshl.checkMachineStatus(lab)
            It will raise an exception if all machines status are  NOT 'COMPL'

            subshl.checkMachineStatus(lab, status='INTERVL')
            It will raise an exception if all machines status are  NOT 'INTERVL'

            subshl.checkMachineStatus(lab, machine=1) or
            subshl.checkMachineStatus(lab, machine='0-0-1')
            It will raise an exception if machine 1 (normally, 0-0-1) status is NOT 'COMPL'

            subshl.checkMachineStatus(lab, 1, 'INTERVEL') or
            subshl.checkMachineStatus(lab, '0-0-1', 'INTERVEL')
            It will raise an exception if machine 1 (normally, 0-0-1) status is NOT
            'INTERVEL'
        @endverbatim
        """
        exceptionMessage = lab.id + ": is not in state of " + ": " + status
        LOGGER.debug(lab.id + ": Try to assert " + " is in state of " + status)
        if not unique(self.getMachineInfo(lab, machine), status):
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMessage)
            else:
                LOGGER.debug(exceptionMessage)
            raise AssertionError(exceptionMessage)

    def getVhostsStatus(self, lab, machine=None):
        """
        Return the VHOST STATE of a machine as a string.
        If the machine is None, it will check all VHOST machines => returns a dict of string
        If no VHost on the specified machine , returns None
        @param lab    one lab object
        @param machine    an integer indicating machine number or string like '0-0-1' (default None)
        @usage
                                      INIT    SOFT  NODE  --------- VHOST ---------
       MACHINE    STATE     REASON   STATUS   CHK    ID   TYPE    STATE      MATE
       --------  --------  --------  -------  ----  ----  -----  --------  --------
       0-0-1     LEAD      AUTO      COMPL    ALW   1     PILOT  STANDBY   0-0-9
       0-0-2     LEAD      AUTO      COMPL    ALW   3     VHOST  ACTIVE    0-0-10
        ...
       0-0-10    LEAD      AUTO      COMPL    ALW   4     VHOST  STANDBY   0-0-2

            bValue = subshl.getVhostsStatus(lab, machine=2)
                # return 'ACTIVE' or 'STANDBY' or any available status
            bValue = subshl.getVhostsStatus(lab)
                # return a dict : ['0-0-2':'ACTIVE', '0-0-3':'ACTIVE', '0-0-10':'STANDBY', '0-0-11':'STANDBY']
        """
        lvh = [m for m in self.getVhostsInfo(lab) if m.find('VHOST') != -1]  # list of VHost machine
        res = {vhw[0]:vhw[-2] for vhw in (vh.split() for vh in lvh)}  # extract MACHINE:STATE fields and make a dict
        if machine is None:
            return res
        else:
            blad = (self._prefix + str(machine)) if type(machine) == int else machine
            if blad in res.keys():
                return res[blad]
            else:
                LOGGER.error("%s: %s", eMsgs.MCAS_INVALID_VHOST, blad)
                raise MCASMachineManagerError, "%s: %s" % (eMsgs.MCAS_INVALID_VHOST, blad)


    def checkVhostsStatus(self, lab, status='COMPL'):
        """Return True if all vhosts status are equal to given status or False.
        And the stauts should be a regexp pattern.

        @param lab    one object lab
        @param status    expected vhost status (default 'COMPL')

        @verbatim
            bValue = subshl.checkVhostsStatus(lab)
            It will return True if all vhosts status are 'COMPL' or False

            bValue = subshl.checkVhostsStatus(lab, status='INTERVEL')
            It will return True if all vhosts status are 'INTERVEL' or False
        @endverbatim
        """
        return unique(self.getVhostsInfo(lab), status)

    def getMachinesList(self, lab):
        """Return the equiped machine list.

        @param lab    one object lab

        @verbatim
            rList = subshl.getMachinesList(lab)
            It will return a list including all machines, so the rList should be
            like this, ['0-0-1', '0-0-2', ...]
        @endverbatim
        """
        return self._sshManager.run(lab.oamIpAddress, 'ls /opt/config/servers')[1].split()

    def getVhostsList(self, lab):
        """Return a list containing all vhosts.

        @param lab    one object lab

        @verbatim
            rList = subshl.getVhostsList()
            It will return a list including all vhosts, so the rList should be
            like this, ['0-0-2', '0-0-3', ...]
        @endverbatim
        """
        return [m.split()[0] for m in self.getVhostsInfo(lab)]

    def getMatedPairState(self, lab, mIndex):
        """Return the machine mated pair state by given machine mIndex.

        @param lab    one object lab
        @param mIndex    an intger index indicating the machine location or string like '0-0-1'

        @verbatim
            mState = subshl.getMatedPairState(lab, 1) or
            mState = subshl.getMatedPairState(lab, '0-0-1')
            It will return the machine 0-0-1 state ('ACTIVE', 'STANDBY' or '')
        @endverbatim
        """
        mState = ''
        mInfo = self.getMachineInfo(lab, mIndex)[0]
        found = re.search(r'(ACTIVE|STANDBY)', mInfo)
        if found:
            mState = found.group(1)
        return mState

    def removeMachine(self, lab, mIndex, switchOver=False):
        """Remove the machine indicated by mIndex and return True or Flase.

        @param lab    one object lab
        @param mIndex    an intger index indicating the machine location or string like '0-0-1'
        @param switchOver    an flag to indicate whether switchover if the target host is active

        @verbatim
            bValue = subshl.removeMachine(lab, 2) or
            bValue = subshl.removeMachine(lab, '0-0-2')
            If machine 0-0-2 is removed successfully, it will return True or
            False.
        @endverbatim
        """
        if switchOver and self.getMatedPairState(lab, mIndex) == "ACTIVE":
            LOGGER.debug("%s: The target vhost %s is active and switchover", lab.id, mIndex)
            return self.vHostSwitchover(lab, mIndex)
        cmd = 'rmv:machine=%s;y' % (self._getMachineName(lab, mIndex))
        result = self._checkCommandSuccess(lab, cmd)
        # ugly workaround for rouzic labs where power on is ignored if sent right
        # after power off. Here, we should use hardware manager to get the current
        # hardware status for the blade and return only when the blade is actually
        # powered off. Unfortunately, for the moment, hardware manager does not
        # provide the current hardware state.
        time.sleep(ROUZIC_WORKAROUND)
        return result

    def restoreMachine(self, lab, mIndex):
        """Restore the machine indicated by mIndex and return True or Flase.

        @param lab    one object lab
        @param mIndex    an intger index indicating the machine location or string like '0-0-1'

        @verbatim
            bValue = subshl.restoreMachine(lab, 2) or
            bValue = subshl.restoreMachine(lab, '0-0-2')
            If machine 0-0-2 is restored successfully, it will return True or
            False.
        @endverbatim
        """
        cmd = 'rst:machine=%s;y' % (self._getMachineName(lab, mIndex))
        return self._checkCommandSuccess(lab, cmd)

    def powerOffMachine(self, lab, mIndex):
        """Power off the machine indicated by mIndex and return True or Flase.

        @param lab    one object lab
        @param mIndex    an intger index indicating the machine location or string like '0-0-1'

        @verbatim
            bValue = subshl.powerOffMachine(lab, 2) or
            bValue = subshl.powerOffMachine(lab, '0-0-2')
            If machine 0-0-2 is powered off successfully, it will return True or
            False.
        @endverbatim
        """
        cmd = 'set:board,machine=%s,power=off' % (self._getMachineName(lab, mIndex))
        result = self._checkCommandSuccess(lab, cmd)
        # ugly workaround for rouzic labs where power on is ignored if sent right
        # after power off. Here, we should use hardware manager to get the current
        # hardware status for the blade and return only when the blade is actually
        # powered off. Unfortunately, for the moment, hardware manager does not
        # provide the current hardware state.
        time.sleep(ROUZIC_WORKAROUND)
        return result

    def powerOnMachine(self, lab, mIndex):
        """Power on the machine indicated by mIndex and return True or Flase.

        @param lab    one object lab
        @param mIndex    an intger index indicating the machine location or string like '0-0-1'

        @verbatim
            bValue = subshl.powerOnMachine(lab, 2) or
            bValue = subshl.powerOnMachine(lab, '0-0-2')
            If machine 0-0-2 is powered on successfully, it will return True or
            False.
        @endverbatim
        """
        cmd = 'set:board,machine=%s,power=on' % (self._getMachineName(lab, mIndex))
        return self._checkCommandSuccess(lab, cmd)

    def vHostSwitchover(self, lab, mIndex):
        """Switchover vhost indicated by an integer mIndex.

        if the vhost indicated by mIndex is not vhost, an exception
        'MCASMachineManagerError' will be raised.

        @param lab    one object lab
        @param mIndex    an intger index indicating the vhost location or string like '0-0-1'

        @verbatim
            bValue = subshl.vHostSwitchover(lab, 2) or
            bValue = subshl.vHostSwitchover(lab, '0-0-2')
            If vHost 0-0-2 is switched over successfully, it will return True or
            False.
        @endverbatim
        """
        hostName = self._getMachineName(lab, mIndex)
        if hostName not in self.getVhostsList(lab):
            LOGGER.error("%s: %s", eMsgs.MCAS_INVALID_VHOST, hostName)
            raise MCASMachineManagerError, "%s: %s" % (
                eMsgs.MCAS_INVALID_VHOST, hostName)
        cmd = 'sw:vhost=%s;y' % hostName
        return self._checkCommandSuccess(lab, cmd, 'SUCCESSFULLY')

    def pilotSwitchover(self, lab, duration=1200):
        """Do pilot switchover.

        @param lab    one object lab
        @param duration    wait until duration timeout (defualt 1200)

        If duration is given with seconds (such as 3200, 1600), the method will check whether the
        all blades become COMPL status until durtion is reached. If all blades can become COMPL,
        it will return Ture or False after duration timeout.
        If duration is given None, it will immediately return true after do 'sw:pilot'.

        @verbatim
            bTrue = subshl.pilotSwitchover(lab, None)
            it will return True after do 'sw:pilot'.

            bValue = subshl.pilotSwitchover(lab)
            If pilot is switched over successfully and all blades become COMPL during 1200 seconds,
            it will return True or False.
        @endverbatim
        """
        self.checkMachineStatus(lab, 1)
        self.checkMachineStatus(lab, 9)
        oldMachineState = self.getMatedPairState(lab, 1)
        if not oldMachineState:
            LOGGER.error("%s: %s", lab.id, eMsgs.MCAS_MACHINE_STATE_NOK)
            raise MCASMachineManagerError, eMsgs.MCAS_MACHINE_STATE_NOK
        self._subshl.run(lab, 'sw:pilot;y')
        # Make sure the connection has been broken
        if not self._sshManager.isDead(lab.oamIpAddress, heartbeat=5):
            errorMsg = lab.id + ": ssh transport is still alive whereas it should not after a pilot switchover"
            LOGGER.error(errorMsg)
            raise MCASMachineManagerError, errorMsg
        if duration is None:
            return True
        # Wait all blades become COMPL
        LOGGER.debug("Lab %s - wait %s seconds for blades COMPL", lab.id, duration)
        while duration > 0:
            time.sleep(30)
            try:
                self.checkMachineStatus(lab, logLevel="debug")
                break
            except BaseException:
                pass
            duration -= 30
            LOGGER.debug("Lab %s - remaining %s seconds for blades COMPL", lab.id, duration)
        else:
            errorMsg = lab.id + ": pilot switchover failure (timeout to wait baldes COMPL)"
            LOGGER.error(errorMsg)
            raise MCASMachineManagerError, errorMsg
        # we have break so machine already COMPL
        newMachineState = self.getMatedPairState(lab, 1)
        if not newMachineState:
            LOGGER.error(lab.id + ":" + eMsgs.MCAS_MACHINE_STATE_NOK)
            raise MCASMachineManagerError, eMsgs.MCAS_MACHINE_STATE_NOK
        return oldMachineState != newMachineState

    def getActivePilot(self, lab):
        """Return active pilot name like '0-0-1' or '0-0-9'.

        @param lab    one lab object

        @verbatim
            bladeName = subshl.getActivePilot(lab)
            Return '0-0-1' or '0-0-9'
        @endverbatim
        """
        bladeName = re.search(r"(\d{1,2}-\d{1,2}-\d{1,2}$)",
                              self._sshManager.run(lab.oamIpAddress, 'hostname')[1]).group(1)
        # 0 for active, 1 for standby
        curActive = self._sshManager.run(lab.oamIpAddress,
                                         '/opt/config/lib/pilot_is_active; echo $?')[1]
        if curActive != '0':
            bladeName = getMatedPairBlade(bladeName)
        return bladeName


    def getActivePilotAsStation(self, lab):
        """Return active pilot as a Station object

        @param lab    one lab object
        @usage stationPilot = subshl.getActivePilot(lab)
        """
        bladeName = re.search(r"(\d{1,2}-\d{1,2}-\d{1,2}$)",
                              self._sshManager.run(lab.oamIpAddress, 'hostname')[1]).group(1)
        # list of pilot blades
        curActive = self._sshManager.run(lab.oamIpAddress,
                                         '/usr/psp/customize/list_servers_having_mod pilot')[1]
        listPilot = curActive.rstrip().split()
        # 0 for active, 1 for standby
        curActive = self._sshManager.run(lab.oamIpAddress,
                                         '/opt/config/lib/pilot_is_active; echo $?')[1]
        if curActive != '0':
            bladeName = list(set(listPilot) - set([bladeName]))[0]  # "substract" bladeName from list of pilot
        _station = lab.getStationsFromString([bladeName])
        return _station[0]


    def getActiveVhost(self, lab, mIndex):
        """Return active vhost name given by mIndex like '0-0-2' or '0-0-10'.

        Only if you have both vhost pair, you can call it. If you have only one blade such as
        '0-0-2', you will get the exception when call the function on blade '0-0-10' or on blade
        '0-0-2' but it is not active now.

        @param lab    one lab object
        @param mIndex    an intger index indicating the machine location or string like '0-0-2'

        @verbatim
            activeVhost = subshl.getActiveVhost(lab, 2) or
            activeVhost = subshl.getActiveVhost(lab, '0-0-2')
            Return '0-0-2' if it is acitve and '0-0-10' if it is active. If it is not vhost pair or
            no active vhost for the moment, return empty string.
        @endverbatim
        """
        bladeName = self._getMachineName(lab, mIndex)
        if self.getMatedPairState(lab, bladeName) == 'ACTIVE':
            return bladeName
        bladeName = getMatedPairBlade(bladeName)
        if self.getMatedPairState(lab, bladeName) == 'ACTIVE':
            return bladeName
        return ''

    def _getMachineName(self, lab, mIndex):
        """Return machine name indicated by mIndex if it is valid machine, Or
        raise MCASMachineManagerError exception.

        @param lab    one object lab
        @param mIndex    an intger index indicating the machine location or string like '0-0-1'
        """
        mIndex = str(mIndex)
        mName = self._prefix + mIndex if mIndex.find('-') == -1 else mIndex
        if mName not in self._sshManager.run(lab.oamIpAddress, 'ls /opt/config/servers')[1].split():
            LOGGER.error("%s %s: %s", lab.id, mName, eMsgs.MCAS_UNEQUIP_MACHINE)
            raise MCASMachineManagerError, "%s: %s" % (
                eMsgs.MCAS_UNEQUIP_MACHINE, mName)
        return mName

    def _checkCommandSuccess(self, lab, cmd, target='COMPLETED'):
        """Return True if target is matched in subshl command output or False.

        @param lab    one lab object
        @param cmd    subshl command
        @param target    to be matched string in response
        """
        pattern = re.compile(target)
        return pattern.search(self._subshl.run(lab, cmd)) is not None

    def stationfwRestartNonPilot(self, lab, station):
        '''
        this function is to restart a non pilot station on FE or BE
        command '/usr/dhafw/tools/fw restartnp D (station letter);'
        @param lab: the Lab object
        @param station: the rcs-hostname of the station
        '''
        _stationLetter = lab.stations[station].ddmHostname[-1:]
        LOGGER.debug(str(lab.id) + ": restart Station :  " + _stationLetter)
        cmd = "/usr/dhafw/tools/fw restartnp " + _stationLetter
        [cmdStatus, stateOutput] = self._sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            LOGGER.debug(str(lab.id) + ": Restart NonPilot Station " + _stationLetter + " State : " + stateOutput)
            if lab.hardware == 'VMMHI':
                LOGGER.warning("Specific workaround for v8650")
                LOGGER.warning("See: http://acos.alcatel-lucent.com/forum/forum.php?thread_id=47735&forum_id=7039")
                time.sleep(10)
            CommonAssert.timedAssert(300, 10, self.checkMachineStatus, \
                                        lab, station, status='OOS', logLevel='debug')
            LOGGER.debug(str(lab.id) + ": Station " + _stationLetter + " is restarting")
        else:
            LOGGER.error("Restart NonPilot State : " + stateOutput)
            LOGGER.error("Restart NonPilot State not success on " + lab.id + " Station " \
                          + _stationLetter + " : " + eMsgs.RESTART_NONPILOT_FAIL)
            raise MCASMachineManagerError, "Restart NonPilot State not success on " + lab.id + " Station " \
                          + _stationLetter + " : " + eMsgs.RESTART_NONPILOT_FAIL
