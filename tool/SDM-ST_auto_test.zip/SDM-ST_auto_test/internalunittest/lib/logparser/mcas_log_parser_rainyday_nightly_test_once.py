"""
@file logparser_rainyday_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-03-03
@brief Rainy day test cases for lib McasLogParser
"""

import unittest
import lib.exceptions_messages as eMsgs
from lib.logparser.mcas_log_parser import (McasLogParser, McasLogParserError)
from lib.logparser.mcas_log import MCASLogError
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase

logger = Logger.getLogger(__name__)

class logparser_rainyday_nightly_test_once(SDMTestCase):
    """Unit test for McasLogParser class."""

    def setUp(self):
        self._logDir = 'internalunittest/lib/logparser/test_files'

    def test_01_InvalidLogDirectory(self):
        """Invalid log directory is provided.

        If an invalid log directory is provided by user, an exception will be
        raised.
        """
        logger.debug('\n[Test case 01] One invalid log directory is provided.')
        self.assertRaisesRegexp(McasLogParserError, eMsgs.LOG_DIR_NOT_FOUND,
                    McasLogParser, 'nosuchdir')

    def test_02_NoLogFiles(self):
        """No log files in log directory.

        If no logs start with the provided prefix in log directory, an exception
        will be raised. We don't need cover all APIs testing in McasLogParser,
        because the exception is raised in MCASLog
        """
        logger.debug('\n[Test case 02] No log files in log directory.')
        myLog = McasLogParser(self._logDir)
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_FILE_NOT_FOUND,
                    myLog.lineFilter, 'nosuchprefix', '.*')

    def test_03_InvalidLogFormat(self):
        """No timestamp is found in log file.

        If no timestamp is found in log file, an exception will be raised. We
        don't need cover all APIs testing in McasLogParser, because the exception is
        raised in MCASLog.
        """
        logger.debug('\n[Test case 03] No timestamp is found in log file.')
        myLog = McasLogParser(self._logDir)
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_FILE_FROMAT,
                    myLog.lineFilter, 'Emptylog', '.*')
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_FILE_FROMAT,
                    myLog.lineFilter, 'Invalidlog', '.*')

    def test_04_InvalidTimeformat(self):
        """Invalid timestamps are provided by user.

        If the timestamp format given by user is invalid, an exception will be
        raised. The correct timestamp format should be 'YYYY-MM-DD HH:MM:SS'. We
        don't need cover all APIs testing in McasLogParser, because the exception is
        raised in MCASLog.
        """
        logger.debug('\n[Test case 04] Invalid timestamps are provided by user')
        myLog = McasLogParser(self._logDir)
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_TIME_FROMAT,
                    myLog.lineFilter, 'Testlog', '.*', '2013-00-00 11:11:134')
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_TIME_FROMAT,
                    myLog.lineFilter, 'Testlog', '.*', '2013/00/00 11:11:34')
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_TIME_FROMAT,
                    myLog.lineFilter, 'Testlog', '.*', '')
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_TIME_FROMAT,
                    myLog.lineFilter, 'Testlog', '.*',
                    '2013-00-00 11:11:13', '')
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_INVALID_TIME_FROMAT,
                    myLog.lineFilter, 'Testlog', '.*',
                    '2013-00-00 11:11:13', 'asdfsdf')

    def test_05_LogFileMissing(self):
        """Some log files are missing.

        If the some files starting with the same prefix are not files such as
        directories, an exception will be raised.
        """
        logger.debug('\n[Test case 05] Some log files are missing')
        myLog = McasLogParser(self._logDir)
        self.assertRaisesRegexp(MCASLogError, eMsgs.LOG_FILE_MISSING,
                    myLog.lineFilter, 'Shouldbefile', '.*')

if __name__ == "__main__":
    unittest.main()

