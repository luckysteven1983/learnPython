#!/bin/bash
function hssFilter {
gawk '
$0 ~ /Measurement for table SDM_MEAS_LOAD_STATION_HSS/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}


function lteFilter {
gawk '
$0 ~ /Measurement for table SDM_MEAS_LOAD_STATION_LTE/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}

function hlrFilter {
gawk '
$0 ~ /Measurement for table SDM_MEAS_LOAD_STATION_HLT/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}

function mnpFilter {
gawk '
$0 ~ /Measurement for table SDM_MEAS_LOAD_STATION_MNP/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}

function pdlsNumFilter {
gawk '
BEGIN { max=0 }
($0 ~ /Duration/) { flag=1; count=1 }
($1=="'"$sampleInt"'") && (flag==1) { count=count+1; if ( count > max) max=count; }
($0 ~ /^$/)  { flag=0 }
END { print max }
'
}

function parse_meas {
export app=$1
if [ -f ${app}_g2.txt ]; then
pdls_meas_num=`head -1 ${app}_g2.txt | awk '{print NF}'`
records_num=`cat ${app}_g2.txt|wc -l`
if [ $records_num -gt 1 ]; then
   sed -n "2,$records_num p" ${app}_g2.txt > ${app}.data
   stations=`sed -n "2,$records_num p" ${app}_g2.txt|awk '{print $1}'|sort |uniq`
   procs=`sed -n "2,$records_num p" ${app}_g2.txt|awk '{print $2}'|grep PDLS|sort |uniq`

   for proc in $procs
   do
    index=3
    cat ${app}.data |grep $proc > ${proc}.data
    while [  $index -le $pdls_meas_num ] 
    do
     meas=`head -1 ${app}_g2.txt | awk '{print $"'"$index"'" }'`
     cmd="paste"
     for sta in $stations
     do
       echo $sta > ${proc}_${meas}_$sta.txt
       grep $sta ${proc}.data | awk ' { print $"'"$index"'" } ' >> ${proc}_${meas}_${sta}.txt
       cmd=`echo $cmd " " ${proc}_${meas}_${sta}.txt`
     done
     exec $cmd > ${proc}_${meas}.txt &
     sleep 1
     let index++
     rm ${proc}_*0-0-*.txt
   done
   rm ${proc}.data
   done
   rm ${app}.data
  fi
fi
}


file=`ls -lrt meas_*|tail -1|awk '{print $9}'`
echo "Measurement file is $file....."
#============================== DATE===================================================================================================
grep -A 3 "SDM_MEAS_LOAD" $file  | grep Expected | uniq | awk -F ";" '{ print $1 }' | tr -d ' ' > PDLS_MEAS_DATES.txt

#==============================PDLSI PARTS===================================================================================================
cat $file | hssFilter > PDLSI
#This is the sample interval of measurements table. Unit: seconds
sampleInt=`cat PDLSI| grep "Expected Duration:"|awk '{ print $4 }'|tail -1`
data_no=`cat PDLSI|pdlsNumFilter|tail -1`

k=1 
for key in STATION_ID ACTIVE_IN_AO_NUM_MEAN ACTIVE_OUT_AO_NUM_MEAN PDLSI_Q_LEN_MEAN DBCOME_Q_LEN_MEAN DBCOMEHIQUE_Q_LEN_MEAN DATAPROFILE_THRNUM_MEAN  COMMITROLLBCK_THRNUM_MEAN ACT_GDMI_TRAN_NUM_MEAN HSS_DIAM_Q_LEN_MEAN 
do 
   grep -A $data_no -w $key PDLSI  > /dev/null
   if [ $? -eq 0 ]; then
      grep -A $data_no -w $key PDLSI | head -1 |awk '{print $1 "\t" $2 "\t" $3}'> PDLSI_${k}.txt
      grep -A $data_no -w $key PDLSI |grep -v "\-\-" |grep -v $key |awk '{print $1 "\t" $2 "\t" $3}' >> PDLSI_${k}.txt
      let k++
   fi
done

   grep -A $data_no -w DATAPROFILE_ACTIVE_JOBNUM  PDLSI > /dev/null
   if [ $? -eq 0 ]; then
       grep -A $data_no -w DATAPROFILE_ACTIVE_JOBNUM PDLSI |head -1 |awk '{print $1 "\t" $2}'> PDLSI_11.txt
       grep -A $data_no -w DATAPROFILE_ACTIVE_JOBNUM PDLSI |grep -v "\-\-" |grep -v DATAPROFILE_ACTIVE_JOBNUM |awk '{print $1 "\t" $2 }' >> PDLSI_11.txt
       paste PDLSI_1.txt PDLSI_2.txt PDLSI_3.txt PDLSI_4.txt PDLSI_5.txt PDLSI_6.txt PDLSI_7.txt PDLSI_8.txt PDLSI_9.txt PDLSI_10.txt PDLSI_11.txt > pdlsi_g2.txt
       rm PDLSI_1.txt PDLSI_2.txt PDLSI_3.txt PDLSI_4.txt PDLSI_5.txt PDLSI_6.txt PDLSI_7.txt PDLSI_8.txt PDLSI_9.txt PDLSI_10.txt PDLSI_11.txt  PDLSI
fi

#===============================PDLSL PARTS===================================================================================================
cat $file | lteFilter > PDLSL
#This is the sample interval of measurements table. Unit: seconds
sampleInt=`cat PDLSL| grep "Expected Duration:"|awk '{ print $4 }'|tail -1`
data_no=`cat PDLSL|pdlsNumFilter|tail -1`

k=1
for key in STATION_ID ACTIVE_IN_AO_NUM_MAX PDLSL_Q_LEN_MEAN DBCOME_Q_LEN_MAX DATAPROFILE_THRNUM_MEAN COMMITROLLBCK_THRNUM_MAX
do
   grep -A $data_no -w $key PDLSL > /dev/null
   if [ $? -eq 0 ]; then
      grep -A $data_no -w $key PDLSL | head -1|awk '{print $1 "\t" $2 "\t" $3}' > PDLSL_${k}.txt
      grep -A $data_no -w $key PDLSL |grep -v "\-\-" |grep -v $key |awk '{print $1 "\t" $2 "\t" $3}'>> PDLSL_${k}.txt
      let k++
   fi
done
grep -A $data_no -w LTE_DIAM_Q_LEN_MEAN PDLSL > /dev/null
if [ $? -eq 0 ]; then
    grep -A $data_no -w LTE_DIAM_Q_LEN_MEAN PDLSL | head -1 |awk '{print $1 "\t" $2}' > PDLSL_7.txt
    grep -A $data_no -w LTE_DIAM_Q_LEN_MEAN PDLSL |grep -v "\-\-" |grep -v LTE_DIAM_Q_LEN_MEAN |awk '{print $1 "\t" $2}' >> PDLSL_7.txt
    paste PDLSL_1.txt PDLSL_2.txt PDLSL_3.txt PDLSL_4.txt PDLSL_5.txt PDLSL_6.txt PDLSL_7.txt > pdlsl_g2.txt
    rm PDLSL_1.txt PDLSL_2.txt PDLSL_3.txt PDLSL_4.txt PDLSL_5.txt PDLSL_6.txt PDLSL_7.txt PDLSL
fi

#===============================PDLSU PARTS===================================================================================================
cat $file | hlrFilter > PDLSU
#This is the sample interval of measurements table. Unit: seconds
sampleInt=`cat PDLSU| grep "Expected Duration:"|awk '{ print $4 }'|tail -1`
data_no=`cat PDLSU|pdlsNumFilter|tail -1`

k=1 
for key in STATION_ID  TC_QUEUE_LENGTH_MEAN CPA_NUM_MAX CTXDIAL_NUM_MEAN RTDMSE1_THREAD_NUM_MAX RTDMSE0_JOB_NUM_MEAN SSN6_QUEUE_LENGTH_MEAN SSN9_QUEUE_LENGTH_MAX TC_PROCESS_TIME_MAX CKW_PROCESS_TIME_MEAN RTDMSE_ACTIVITIES_MAX TC_CANCEL_MEAN RTDMSE_PROCESS_TIME_MAX 
do 
   grep -A $data_no -w $key PDLSU > /dev/null
   if [ $? -eq 0 ]; then
      grep -A $data_no -w $key PDLSU | head -1 |awk '{print $1 "\t" $2 "\t" $3}'> PDLSU_${k}.txt
      grep -A $data_no -w $key PDLSU |grep -v "\-\-" |grep -v $key |awk '{print $1 "\t" $2 "\t" $3}' >> PDLSU_${k}.txt
      let k++
   fi
done
 grep -A $data_no -w OB_HLR_USSD_CPA_Num_MEAN PDLSU > /dev/null
 if [ $? -eq 0 ]; then
    grep -A $data_no -w OB_HLR_USSD_CPA_Num_MEAN PDLSU |head -1 |awk '{print $1}'> PDLSU_14.txt
    grep -A $data_no -w OB_HLR_USSD_CPA_Num_MEAN PDLSU |grep -v "\-\-" |grep -v OB_HLR_USSD_CPA_Num_MEAN |awk '{print $1 "\t" $2 }' >> PDLSU_14.txt

   paste PDLSU_1.txt PDLSU_2.txt PDLSU_3.txt PDLSU_4.txt PDLSU_5.txt PDLSU_6.txt PDLSU_7.txt PDLSU_8.txt PDLSU_9.txt PDLSU_10.txt PDLSU_11.txt PDLSU_12.txt PDLSU_13.txt PDLSU_14.txt> pdlsu_g2.txt
   rm PDLSU_1.txt PDLSU_2.txt PDLSU_3.txt PDLSU_4.txt PDLSU_5.txt PDLSU_6.txt PDLSU_7.txt PDLSU_8.txt PDLSU_9.txt PDLSU_10.txt PDLSU_11.txt PDLSU_12.txt PDLSU_13.txt PDLSU_14.txt PDLSU
fi

#===============================PDLSM PARTS===================================================================================================
cat $file | mnpFilter > PDLSM
#This is the sample interval of measurements table. Unit: seconds
sampleInt=`cat PDLSM| grep "Expected Duration:"|awk '{ print $4 }'|tail -1`
data_no=`cat PDLSM|pdlsNumFilter|tail -1`

k=1 
for key in STATION_ID_MNP TC_QUEUE_LENGTH_MEAN_MNP CPA_NUM_MAX_MNP CTXDIAL_NUM_MEAN_MNP RTDMSE1_THREAD_NUM_MAX_MNP RTDMSE0_JOB_NUM_MEAN_MNP SSN_QUEUE_LENGTH_MEAN_MNP TA_PROCESS_TIME_MEAN_MNP CKW_PROCESS_TIME_MAX_MNP MEMORY_MEAN_MNP TC_CANCEL_MAX_MNP TC_NOTICE_MEAN_MNP 
do 
   grep -A $data_no -w $key PDLSM > /dev/null
   if [ $? -eq 0 ]; then
      grep -A $data_no -w $key PDLSM | head -1 |awk '{print $1 "\t" $2 "\t" $3}'> PDLSM_${k}.txt
      grep -A $data_no -w $key PDLSM |grep -v "\-\-" |grep -v $key |awk '{print $1 "\t" $2 "\t" $3}' >> PDLSM_${k}.txt
      let k++
   fi
done
 grep -A $data_no -w OB_HLR_USSD_CPA_Num_MAX_MNP PDLSM > /dev/null
 if [ $? -eq 0 ]; then
    grep -A $data_no -w OB_HLR_USSD_CPA_Num_MAX_MNP PDLSM |head -1 |awk '{print $1}'> PDLSM_13.txt
    grep -A $data_no -w OB_HLR_USSD_CPA_Num_MAX_MNP PDLSM |grep -v "\-\-" |grep -v OB_HLR_USSD_CPA_Num_MAX_MNP |awk '{print $1 "\t" $2 }' >> PDLSM_13.txt

   paste PDLSM_1.txt PDLSM_2.txt PDLSM_3.txt PDLSM_4.txt PDLSM_5.txt PDLSM_6.txt PDLSM_7.txt PDLSM_8.txt PDLSM_9.txt PDLSM_10.txt PDLSM_11.txt PDLSM_12.txt PDLSM_13.txt > pdlsm_g2.txt
   rm PDLSM_1.txt PDLSM_2.txt PDLSM_3.txt PDLSM_4.txt PDLSM_5.txt PDLSM_6.txt PDLSM_7.txt PDLSM_8.txt PDLSM_9.txt PDLSM_10.txt PDLSM_11.txt PDLSM_12.txt PDLSM_13.txt PDLSM
fi



#==================================PDLSI internal resource====================================================================================================
if [ -f pdlsi_g2.txt ]; then
  if [ `cat pdlsi_g2.txt |wc -l` -gt 1 ]; then
  head -1 pdlsi_g2.txt|awk '{print "TYPE  " $5 " " $11 " " $14 " " $20 " " $26 " " $29}' > fe_g2_meas.result
  cat pdlsi_g2.txt |sed -n '2,$p' > pdlsi_g2.tmp
  pdlsi_ao_max=`sort -k5 -n pdlsi_g2.tmp|tail -1|awk '{print $5}'`
  pdlsi_q_length_max=`sort -k11 -n pdlsi_g2.tmp|tail -1|awk '{print $11}'`
  pdlsi_dbcome_max=`sort -k14 -n pdlsi_g2.tmp|tail -1|awk '{print $14}'`
  pdlsi_dataprofile_thrnum_max=`sort -k20 -n pdlsi_g2.tmp|tail -1|awk '{print $20}'`
  pdlsi_tran_max=`sort -k26 -n pdlsi_g2.tmp|tail -1|awk '{print $26}'`
  pdlsi_diam_q_length_max=`sort -k29 -n pdlsi_g2.tmp|tail -1|awk '{print $29}'`
  rm pdlsi_g2.tmp
  printf "%s %-20d %-15d %-16d %-22d %-21d %-d\n" "PDLSI"  $pdlsi_ao_max   $pdlsi_q_length_max $pdlsi_dbcome_max  $pdlsi_dataprofile_thrnum_max $pdlsi_tran_max $pdlsi_diam_q_length_max>> fe_g2_meas.result

  head -1 pdlsi_g2.txt|awk '{printf "%s\t%s\t%s\t%s\t%s\t%s\n", "PDLSI_"$5, $11, "PDLSI_"$14, "PDLSI_"$20, "PDLSI_"$26, $29 }' > pdlsi_g2_meas.xls
  echo -e "${pdlsi_ao_max}\t${pdlsi_q_length_max}\t${pdlsi_dbcome_max}\t${pdlsi_dataprofile_thrnum_max}\t${pdlsi_tran_max}\t${pdlsi_diam_q_length_max}" >>pdlsi_g2_meas.xls
else 
   echo  "PDLSI resource data doesn't exist!"
  fi
fi

#==================================PDLSL internal resource===================================================================================================
if [ -f pdlsl_g2.txt ]; then
 if [ `cat pdlsl_g2.txt |wc -l` -gt 1 ]; then
   cat pdlsl_g2.txt | sed -n '2,$p' > pdlsl_g2.tmp
   pdlsl_ao_max=`sort -k4 -n pdlsl_g2.tmp|tail -1|awk '{print $4}'`
   pdlsl_q_length_max=`sort -k8 -n pdlsl_g2.tmp|tail -1|awk '{print $8}'`
   pdlsl_dbcome_max=`sort -k10 -n pdlsl_g2.tmp|tail -1|awk '{print $10}'`
   pdlsl_dataprofile_thrnum_max=`sort -k14 -n pdlsl_g2.tmp|tail -1|awk '{print $14}'`
   pdlsl_tran_max=`sort -k18 -n pdlsl_g2.tmp|tail -1|awk '{print $18}'`
   pdlsl_diam_q_length_max=`sort -k20 -n pdlsl_g2.tmp|tail -1|awk '{print $20}'`

   printf "%s %-20d %-15d %-16d %-22d %-21d %-d\n" "PDLSL" $pdlsl_ao_max $pdlsl_q_length_max $pdlsl_dbcome_max $pdlsl_dataprofile_thrnum_max $pdlsl_tran_max $pdlsl_diam_q_length_max >> fe_g2_meas.result


   head -1 pdlsl_g2.txt|awk '{printf "%s\t%s\t%s\t%s\t%s\t%s\n", "PDLSL_"$4, $8, "PDLSL_"$10, "PDLSL_"$14, "PDLSL_"$18, $20}' > pdlsl_g2_meas.xls
echo -e "${pdlsl_ao_max}\t${pdlsl_q_length_max}\t${pdlsl_dbcome_max}\t${pdlsl_dataprofile_thrnum_max}\t${pdlsl_tran_max}\t${pdlsl_diam_q_length_max}" >>pdlsl_g2_meas.xls

   rm pdlsl_g2.tmp
   else
      echo "PDLSL resource data doesn't exist!"
   fi
fi
#=====================================PDLSU internal resource==============================================================================================
if [ -f pdlsu_g2.txt ]; then
   if [ `cat pdlsu_g2.txt |wc -l` -gt 1 ]; then
   head -1 pdlsu_g2.txt|awk '{printf "TYPE\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",  $11, $12, $13, $14, $15, $16, $17, $18,$31, $32,$37,$38 }' >>  fe_g2_meas.result
   cat pdlsu_g2.txt |sed -n '2,$p' > pdlsu_g2.tmp
   RTDMSE0_THREAD_NUM_MAX=`sort -k11 -n pdlsu_g2.tmp|tail -1|awk '{print $11}'`
   RTDMSE0_THREAD_NUM_MEAN=`awk '{ avg+=$12; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
   RTDMSE1_THREAD_NUM_MAX=`sort -k13 -n pdlsu_g2.tmp|tail -1|awk '{print $13}'`
   RTDMSE1_THREAD_NUM_MEAN=`awk '{ avg+=$14; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
   RTDMSE0_JOB_NUM_MAX=`sort -k15 -n pdlsu_g2.tmp|tail -1|awk '{print $15}'`
   RTDMSE0_JOB_NUM_MEAN=`awk '{ avg+=$16; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
   RTDMSE1_JOB_NUM_MAX=`sort -k17 -n pdlsu_g2.tmp|tail -1|awk '{print $17}'`
   RTDMSE1_JOB_NUM_MEAN=`awk '{ avg+=$18; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
   RTDMSE_ACTIVITIES_MAX=`sort -k31 -n pdlsu_g2.tmp|tail -1|awk '{print $31}'`
   RTDMSE_ACTIVITIES_MEAN=`awk '{ avg+=$32; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`
   RTDMSE_PROCESS_TIME_MAX=`sort -k37 -n pdlsu_g2.tmp|tail -1|awk '{print $37}'`
   RTDMSE_PROCESS_TIME_MEAN=`awk '{ avg+=$38; ++num; next} END {printf "%d", avg/num}' pdlsu_g2.tmp`

   rm pdlsu_g2.tmp
   printf "%5s\t%-23d\t%-24d\t%-23d\t%-24d\t%-20d%-21d\t%-20d\t%-21d\t%-21d\t%-22d\t%-23d%-24d\n", "PDLSU"  $RTDMSE0_THREAD_NUM_MAX $RTDMSE0_THREAD_NUM_MEAN $RTDMSE1_THREAD_NUM_MAX $RTDMSE1_THREAD_NUM_MEAN $RTDMSE0_JOB_NUM_MAX $RTDMSE0_JOB_NUM_MEAN $RTDMSE1_JOB_NUM_MAX $RTDMSE1_JOB_NUM_MEAN $RTDMSE_ACTIVITIES_MAX $RTDMSE_ACTIVITIES_MEAN $RTDMSE_PROCESS_TIME_MAX $RTDMSE_PROCESS_TIME_MEAN  >> fe_g2_meas.result
   head -1 pdlsu_g2.txt|awk '{printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n","RTDMSE0_THREAD_NUM_MAX", "RTDMSE0_THREAD_NUM_MEAN", "RTDMSE1_THREAD_NUM_MAX","RTDMSE1_THREAD_NUM_MEAN","RTDMSE0_JOB_NUM_MAX","RTDMSE0_JOB_NUM_MEAN","RTDMSE1_JOB_NUM_MAX","RTDMSE1_JOB_NUM_MEAN","RTDMSE_ACTIVITIES_MAX","RTDMSE_ACTIVITIES_MEAN","RTDMSE_PROCESS_TIME_MAX","RTDMSE_PROCESS_TIME_MEAN"}' > pdlsu_g2_meas.xls

   echo -e "$RTDMSE0_THREAD_NUM_MAX\t$RTDMSE0_THREAD_NUM_MEAN\t$RTDMSE1_THREAD_NUM_MAX\t$RTDMSE1_THREAD_NUM_MEAN\t$RTDMSE0_JOB_NUM_MAX\t$RTDMSE0_JOB_NUM_MEAN\t$RTDMSE1_JOB_NUM_MAX\t$RTDMSE1_JOB_NUM_MEAN\t$RTDMSE_ACTIVITIES_MAX\t$RTDMSE_ACTIVITIES_MEAN\t$RTDMSE_PROCESS_TIME_MAX\t$RTDMSE_PROCESS_TIME_MEAN" >> pdlsu_g2_meas.xls 
  else
   echo "PDLSU resource data doesn't exist!"
  fi
fi

for app in pdlsi pdlsl pdlsu pdlsm
do
   parse_meas $app
done

cat fe_g2_meas.result
