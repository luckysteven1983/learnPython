'''
Created on Mar 17, 2015

@author: Xia Zhao
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.alarm.alarm import Alarm
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0493_restart_spas_fe(SDMTestCase):
    '''test restart spas on FE'''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self._mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        # waiting for feedback from system engineering team to define expected alarms
        self.expectedAlarms = [#Alarm(10109, "Major")
                              ]
        self.acceptedAlarms = [Alarm(0, "Major"),
                               Alarm(917201, "Major"),
                               Alarm(906065, "Major"),
                               Alarm(906065, "Minor"),
                               Alarm(50906, "Major"),
                               Alarm(50910, "Major"),
                               Alarm(70910, "Major"),
                               Alarm(50906, "Minor"), Alarm(50910, "Minor"),
                               Alarm(70910, "Minor"), Alarm(917201, "Major")]
        self.success = True
        self.exceptMsg = ""

    def test_restart_spas_fe(self):
        '''test restart spas on fe'''

        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("start to choose one FE to test this case")
        fes = self.testEnv.testBed.getFrontends()
        feID = fes.keys()[0]
        fe = fes[feID]
        LOGGER.info("Restart spas on FE: " + str(feID))

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.debug("Restart spas on FE at: " + startTime)

        spaList = ["SDM", "OAM"]
        for spaName in spaList:
            LOGGER.debug("Restart SPA " + spaName + " on FE: " + str(feID))
            try:
                self._mcasApplicationManager.restartSPA(fe, spaName)
            except BaseException, msg:
                self.exceptMsg += str(msg)
                self.success = False
                LOGGER.error("Restart SPA " + spaName + " on FE: " + str(feID) + " fail")
            else:
                LOGGER.debug("Restart SPA " + spaName + " on FE: " + str(feID) + " successful")

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", feID)

        LOGGER.debug("check the alarm")
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(fe, myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: alarm check fail", feID)

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: end state of test env check fail", feID)

        if self.success:
            LOGGER.debug("ff0493 restart spas on FE success!\n")
        else:
            LOGGER.error("ff0493 restart spas on FE fail!\n")
            LOGGER.error(self.exceptMsg)
            # spa recover done in jenkins worker
            raise Exception(self.exceptMsg)
