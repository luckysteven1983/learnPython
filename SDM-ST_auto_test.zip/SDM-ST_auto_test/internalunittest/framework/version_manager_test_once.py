'''
Created on Mar 30, 2015

@author: tlavanant
'''
import unittest
from framework.version_manager import VersionManager
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class version_manager_test_once(SDMTestCase):

    """
        Test the CheckVersion. Retrieves the MCAS, DDM and SDM version including CP
        Output should look like, for example :
        {'node': '172.25.201.153', 'MCAS': '3.2.13', 'DDM': '90.00.17.03-01', 'SDM': '422CP117'}
        or
        MCAS => 3.2.12
        DDM => 90.00.14.02-01
        SDM => SDM422 CP not found on web page with date :2015-02-05
    """

    def testCheckVersion(self):
        '''
            test to get version
        '''
        LOGGER.info("testCheckVersion")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, frontend = self.testEnv.testBed.getFrontends().popitem()
        host1 = frontend.oamIpAddress
        LOGGER.debug("Connecting to host : " + host1)
        sshManager = self.sdmManager.sshManager
        check = VersionManager(sshManager)
        LOGGER.info(VersionManager.getversion(check, host1))

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
