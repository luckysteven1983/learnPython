'''
Created on Mar 30, 2015
@file
@ingroup database
@author Xia Zhao
@brief some functions about database state manager

'''

import os
import re
import lib.exceptions_messages as Emsgs
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class DatabaseStateManagerError(BaseException):
    """If error, raise it."""
    pass

class DatabaseStateManager(object):
    '''
    classdocs
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def getState(self, lab, key='Operator Status'):
        '''
        this function is to get database state
        command '/usr/dhafw/bin/mpread'
        @param lab: the Lab object
        @param key: string

        @verbatim
        DSM = DatabaseStateManager(...)
        DSM.getState(lab)
            if get status success, return a string, eg: 'MASTER'; otherwise, raise an exception
        DSM.getState(lab,None)
            if get status sucess, return a Dictionary; otherwise, raise an exception
            For the Dictionary, eg:
            {'Low replication latency': '2',
            'Geo Red status': 'STANDBY',
            'Max replication latency': '5',
            'Read on standby': 'enable',
            'Global Status': 'The slave is secured',
            'Size of data': '3',
            'Stale Status': 'no',
            'DB access': 'OK_RO',
            'Global checkpoint': '335153',
            'Mode': 'BACKEND',
            'DB zone': '2',
            'Operator Status': 'SLAVE',
            'Manage stale status': 'yes',
            'Automatic Swo': 'disable'}
        @endverbatim
        '''
        LOGGER.debug(str(lab.oamIpAddress) + ": start to get database state ")
        cmd = "/usr/dhafw/bin/mpread"
        [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            LOGGER.debug("Get Database State success")
            state = [line.strip() for line in stateOutput.split(os.linesep)]
            if key:
                pattern = re.compile(key)
                for line in state:
                    if pattern.match(line):
                        stateOut = line.replace(key, '').strip()
                        LOGGER.debug("Get Database State " + key + ": " + stateOut + "\n")
                        return stateOut
                LOGGER.error("%s: %s", lab.id, Emsgs.GET_DATABASE_STATE_FAIL)
                raise DatabaseStateManagerError, Emsgs.GET_DATABASE_STATE_FAIL

            else:
                stateDict = {}
                stateDict['Geo Red status'] = state[1].replace('Geo Red status', '').strip()
                stateDict['DB zone'] = state[2].replace('DB zone', '').strip()
                stateDict['DB access'] = state[3].replace('DB access', '').strip()
                stateDict['Operator Status'] = state[4].replace('Operator Status', '').strip()
                stateDict['Global Status'] = state[5].replace('Global Status', '').strip()
                stateDict['Mode'] = state[6].replace('Mode', '').strip()
                stateDict['Global checkpoint'] = state[7].replace('Global checkpoint', '').strip()
                stateDict['Size of data'] = state[8].replace('Size of data', '').strip()
                stateDict['Automatic Swo'] = state[9].replace('Automatic Swo', '').strip()
                stateDict['Manage stale status'] = state[10].replace('Manage stale status', '').strip()
                stateDict['Read on standby'] = state[11].replace('Read on standby', '').strip()
                stateDict['Stale Status'] = state[12].replace('Stale Status', '').strip()
                stateDict['Max replication latency'] = state[13].replace('Max replication latency', '').strip()
                stateDict['Low replication latency'] = state[14].replace('Low replication latency', '').strip()
                LOGGER.debug(str(stateDict) + "\n")
                return stateDict
        else:
            LOGGER.error("%s: %s", lab.id, Emsgs.GET_DATABASE_STATE_FAIL)
            raise DatabaseStateManagerError, Emsgs.GET_DATABASE_STATE_FAIL

    def getMasterBE(self, labList):
        '''
        this function is to get master be
        if there is only one lab in the labList, will return the be which is NO_MATED_PAIR
        When there is only one BE in the NRG, we should put the Be in NO_MATED_PAIR status

        @param labList: a list of the Lab object

        @verbatim
        DSM = DatabaseStateManager(...)
        DSM.getMasterBE(labList)
        @endverbatim
            if success, return the Lab list of the master be; otherwise, raise an exception
        output example:
        [hp01, hp02] hp01 and hp02 are lab object.
        '''

        LOGGER.debug("start to get master BE from labList: " + str(labList))
        labMaster = []
        labMasterips = ""
        pattern = None
        nbBEs = len(labList)
        if nbBEs == 1:
            LOGGER.debug("1 BE in labList: will look for NO_MATED_PAIR operator status")
            pattern = re.compile('NO_MATED_PAIR')
        else:
            LOGGER.debug(str(nbBEs) + " BEs in labList: will look for MASTER operator status")
            pattern = re.compile('MASTER')
        result = False
        for labIndex in labList:
            state = self.getState(labIndex, 'Operator Status')
            LOGGER.debug("Operator Status for " + str(labIndex) + " is " + state)
            if state and pattern.match(state):
                labMaster.append(labIndex)
                result = True
                labMasterips += str(labIndex.oamIpAddress) + " "

        if result:
            LOGGER.debug("Get master success\n")
            LOGGER.debug("master is " + labMasterips + "\n")
            return labMaster
        else:
            msg = Emsgs.GET_MASTER_BE_FAIL
            if len(labList) == 1:
                msg += ": " + labList[0].id + " status is " + state + " instead of NO_MATED_PAIR"
            else:
                msg += ": none of the labs is MASTER"
            LOGGER.error(msg)
            raise DatabaseStateManagerError, msg

    def getSlaveBE(self, labList):
        '''
        this function is to get slave be

        @param labList: a list of the Lab object

        @verbatim
        DSM = DatabaseStateManager(...)
        DSM.getSlaveBE(labList)
        @endverbatim
            if success, return the Lab list of the slave be; otherwise, raise an exception
        output example:
        [hp01, hp02] hp01 and hp02 are lab object.
        '''

        LOGGER.debug("start to Get slave BE")
        labSalve = [lab for lab in labList if self.getState(lab, 'Operator Status') == 'SLAVE']
        if labSalve:
            LOGGER.debug("Get Slave success\n")
            labIds = [lab.id for lab in labSalve]
            LOGGER.debug("Slave is " + ','.join(labIds) + '\n')
            return labSalve
        else:
            LOGGER.error(Emsgs.GET_SLAVE_BE_FAIL)
            raise DatabaseStateManagerError, Emsgs.GET_SLAVE_BE_FAIL

    def getNDBState(self, lab, station=None):
        '''
        this function is to get ndb state
        command '/usr/dhafw/tools/fw lsndb'
        @param lab: the Lab object
        @param station: the rcs-hostname of the station

        @verbatim
        DSM = DatabaseStateManager(...)
        DSM.getNDBState(lab)
        return example:{'0-0-6': 'started', '0-0-15': 'started',
        '0-0-8': 'started', '0-0-13': 'started',
        '0-0-16': 'started', '0-0-14': 'started',
        '0-0-5': 'started', '0-0-4': 'started',
        '0-0-7': 'started', '0-0-2': 'started',
        '0-0-11': 'started', '0-0-10': 'started',
        '0-0-3': 'started', '0-0-12': 'started'}
        DSM.getNDBState(lab,'0-0-2')
        return example:started
        @endverbatim
        '''
        LOGGER.debug(str(lab.id) + ": start to get ndb state ")
        cmd = "/usr/dhafw/tools/fw lsndb"
        [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            LOGGER.debug(str(lab.id) + ": Get ndb State success")
            patternState = " (.*) \(.*"
            state = [line.strip() for line in stateOutput.split(os.linesep)]
            if station:
                if not re.search('0-0-', station):
                    station = '0-0-' + station
                nodeid = lab.stations[station].mysqlNodeID
                pattern = re.compile("Node " + str(nodeid) + ":")
                stateOut = ""
                for line in state:
                    if pattern.match(line):
                        stateTmp = line.split(":")[1]
                        match = re.search(patternState, stateTmp)
                        if match:
                            stateOut = match.group(1)
                        elif re.search("not connected", stateTmp):
                            stateOut = "not connected"
                        else:
                            stateOut = ""
                        LOGGER.debug(str(lab.id) + " " + station + ": Get ndb State: " + stateOut + "\n")
                        return stateOut
                LOGGER.error("%s: %s", lab.id, Emsgs.GET_NDB_STATE_FAIL)
                raise Exception(Emsgs.GET_NDB_STATE_FAIL)
            else:
                stateDict = {}
                pattern = re.compile("Node ")
                for line in state:
                    stateOut = ""
                    if pattern.match(line):
                        nodeid = line.split()[1].rstrip(":")
                        for hostname in lab.stations.keys():
                            if lab.stations[hostname].mysqlNodeID == nodeid:
                                station = hostname
                                break
                        stateTmp = line.split(":")[1]
                        match = re.search(patternState, stateTmp)
                        if match:
                            stateDict[station] = match.group(1)
                        elif re.search("not connected", stateTmp):
                            stateDict[station] = "not connected"
                        else:
                            stateDict[station] = ""
                return stateDict
        else:
            LOGGER.error("%s: %s", lab.id, Emsgs.GET_NDB_STATE_FAIL)
            raise DatabaseStateManagerError, Emsgs.GET_NDB_STATE_FAIL

    def assertNdbState(self, lab, ndbState, station=None, logLevel='error'):
        '''
        assert ndb status is the given
        @param lab: Lab type
        @param ndbState: string, eg: 'started'
        @param station: string, the rcs-hostname of the station, eg: 0-0-2

        @verbatim
        assertNdbState(lab, 'started')
        assertNdbState(lab, 'started', '0-0-2')
        @endverbatim
        '''
        LOGGER.debug("Try to assert NDB is in state of " + ndbState)
        if station:
            exceptionMessage = lab.id + ": " + station + ":" + ndbState + ": " + Emsgs.ASSERT_NDB_STATE_FAIL
            if not re.search('0-0-', station):
                station = '0-0-' + station
            CommonAssert.assertEqual(ndbState, self.getNDBState(lab, station), exceptionMessage, logLevel)
        else:
            exceptionMessage = lab.id + ": " + ndbState + ": " + Emsgs.ASSERT_NDB_STATE_FAIL
            try:
                state = self.getNDBState(lab)
            except:
                LOGGER.error(exceptionMessage)
                raise AssertionError(exceptionMessage)
            dbStation = lab.getStationListbyProductRole('DB').keys()
            for station in dbStation:
                CommonAssert.assertEqual(ndbState, state[station], exceptionMessage, logLevel)

    def assertNdbNotState(self, lab, ndbState, station=None, logLevel='error'):
        '''
        assert ndb status is NOT the given state
        @param lab: Lab type
        @param ndbState: string, eg: 'started'
        @param station: string, the rcs-hostname of the station, eg: 0-0-2
        If station is not provided, state will be asserted on all stations

        @verbatim
        assertNdbState(lab, 'started')
        assertNdbState(lab, 'started', '0-0-2')
        @endverbatim
        '''
        LOGGER.debug("Try to assert NDB is in NOT state of " + ndbState)
        if station:
            exceptionMessage = lab.id + ": " + station + ":" + ndbState + ": " + Emsgs.ASSERT_NDB_STATE_FAIL
            if not re.search('0-0-', station):
                station = '0-0-' + station
            CommonAssert.assertNotEqual(ndbState, self.getNDBState(lab, station), exceptionMessage, logLevel)
        else:
            exceptionMessage = lab.id + ": " + ndbState + ": " + Emsgs.ASSERT_NDB_STATE_FAIL
            try:
                state = self.getNDBState(lab)
            except:
                LOGGER.error(exceptionMessage)
                raise AssertionError(exceptionMessage)
            dbStation = lab.getStationListbyProductRole('DB').key()
            for station in dbStation:
                CommonAssert.assertNotEqual(ndbState, state[station], exceptionMessage, logLevel)

    def isAutomaticSwoEnabled(self,lab):
        '''
        assert the "Automatic swo" paramenter is in state enabled
        call the getState(lab,key) method
        @param lab: Lab type
        @return: boolean

        @verbatim
        IsAutomaticSwoEnabled(lab)
        @endverbatim
        '''

        state_automatic_swo = self.getState(lab,"Automatic Swo")
        if state_automatic_swo == "enable":
            return True
        else:
            return False

    def enableAutomaticSwo(self,lab):
        '''
        change the "Automatic swo" parameter to "enable"
        command : 'usr/dhafw/bin/mpswo -s enable'
        @param lab: Lab type
        @retrun void. if error during the process, raise an exception

        @verbatim
        enableAutomaticSwo(lab)
        @endverbatim
        '''

        cmd = "/usr/dhafw/bin/mpswo -s enable"
        [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            LOGGER.info(str(lab.id) + ": Change 'Automatic swo' to enable success")
            LOGGER.debug("command result : "+ stateOutput)
        else:
            LOGGER.error("%s: %s", lab.id, Emsgs.ENABLE_AUTOMATIC_SWO_FAIL)
            raise Exception("%s: %s", lab.id, Emsgs.ENABLE_AUTOMATIC_SWO_FAIL)

    def disableAutomaticSwo(self,lab):
        '''
        change the "Automatic swo" parameter to "disable"
        command : 'usr/dhafw/bin/mpswo -s disable'
        @param lab: Lab type
        @retrun void. if error during the process, raise an exception

        @verbatim
        disableAutomaticSwo(lab)
        @endverbatim
        '''

        cmd = "/usr/dhafw/bin/mpswo -s disable"
        [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            LOGGER.info(str(lab.id) + ": Change 'Automatic swo' to disable success")
            LOGGER.debug("command result : "+ stateOutput)
        else:
            LOGGER.error("%s: %s", lab.id, Emsgs.DISABLE_AUTOMATIC_SWO_FAIL)
            raise Exception("%s: %s", lab.id, Emsgs.DISABLE_AUTOMATIC_SWO_FAIL)