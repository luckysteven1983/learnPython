'''
Created on May 7, 2015

@author: Xia Zhao

CommAssert provides a number of assert* methods to check for and report failures.

'''

import time
from unittest.case import TestCase
from lib.logging.logger import Logger
import traceback

LOGGER = Logger.getLogger(__name__)

class CommonAssertError(AssertionError):
    """If error, raise it."""
    pass

class CommonAssert(object):
    '''
    CommAssert provides a number of assert* methods to check for and report failures.
    If assert failed, will raise an AssertionError with a message.
    functions are as below:
    assertTrue: Test that expr is true
    assertFalse: Test that expr is false
    assertEqual: Test that first and second are equal.
    assertNotEqual: Test that first and second are not equal.
    assertAlmostEqual: Test that first and second are approximately equal by computing the
                       difference
    assertIn: Test that first is in second.
    assertNotIn: Test that first is not in second.
    assertIsInstance: Test that obj is an instance of class
    assertNotIsInstance: Test that obj is an instance of class
    assertRaises: Test that an exception is raised when callable is called
    timedAssert
    assertSequenceEqual: Tests that two sequences are equal.
    assertListEqual: Tests that two lists are equal.
    assertListAlmostEqual: Tests that two lists are almost equal (do not care the order).
    assertTupleEqual: Tests that two tuples are equal.
    assertDictEqual: Test that two dictionaries are equal.
    assertDictContainsSubset: Tests whether the key/value pairs in dictionary actual are a superset
                              of those in expected.
    assertLess: Test that first is respectively < than second
    assertLessEqual: Test that first is respectively <= than second
    assertGreater: Test that first is respectively > than second
    assertGreaterEqual: Test that first is respectively  >= than second
    assertIsNone: Test that expr is None
    assertIsNotNone: Test that expr is not None
    '''
    def __init__(self):
        '''
        Constructor
        '''
        pass

    @staticmethod
    def assertTrue(expr, msg=None, logLevel='error'):
        """Check that the expression is true."""
        try:
            TestCase('assertTrue').assertTrue(expr, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertFalse(expr, msg=None, logLevel='error'):
        """Check that the expression is false."""
        try:
            TestCase('assertFalse').assertFalse(expr, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertEqual(first, second, msg=None, logLevel='error'):
        """Fail if the two objects are unequal as determined by the '=='
           operator.
        """
        try:
            TestCase('assertEqual').assertEqual(first, second, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg


    @staticmethod
    def assertNotEqual(first, second, msg=None, logLevel='error'):
        """Fail if the two objects are equal as determined by the '!='
           operator.
        """
        try:
            TestCase('assertNotEqual').assertNotEqual(first, second, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertRegexpMatches(text, expectedRegexp, msg=None, logLevel='error'):
        """Assert regexp match"""
        try:
            TestCase('assertRegexpMatches').assertRegexpMatches(text, expectedRegexp, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertAlmostEqual(first, second, places=None, msg=None, delta=None, logLevel='error'):
        """Fail if the two objects are unequal as determined by their
           difference rounded to the given number of decimal places
           (default 7) and comparing to zero, or by comparing that the
           between the two objects is more than the given delta.

           Note that decimal places (from zero) are usually not the same
           as significant digits (measured from the most signficant digit).

           If the two objects compare equal then they will automatically
           compare almost equal.

        self.assertAlmostEqual(1.1,1.2,0)  -> success
        self.assertAlmostEqual(1.0001,1.0002,3)  -> success
        self.assertAlmostEqual(1.00000001,1.00000002)  -> success
        self.assertAlmostEqual(0.0000001,0)  -> fail
        self.assertAlmostEqual(1.1,1.2,1)  -> fail
        """
        try:
            TestCase('assertAlmostEqual').assertAlmostEqual(first, second, places, msg, delta)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertIn(member, container, msg=None, logLevel='error'):
        """Just like self.assertTrue(a in b), but with a nicer default message."""
        try:
            TestCase('assertIn').assertIn(member, container, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertNotIn(member, container, msg=None, logLevel='error'):
        """Just like self.assertTrue(a not in b), but with a nicer default message."""
        try:
            TestCase('assertNotIn').assertNotIn(member, container, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertIsInstance(obj, cls, msg=None, logLevel='error'):
        """Same as self.assertTrue(isinstance(obj, cls)), with a nicer
        default message."""
        try:
            TestCase('assertIsInstance').assertIsInstance(obj, cls, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertNotIsInstance(obj, cls, msg=None, logLevel='error'):
        """Included for symmetry with assertIsInstance."""
        try:
            TestCase('assertNotIsInstance').assertNotIsInstance(obj, cls, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertRaises(excClass, logLevel='error', callableObj=None, *args, **kwargs):
        """Fail unless an exception of class excClass is raised
           by callableObj when invoked with arguments args and keyword
           arguments kwargs. If a different type of exception is
           raised, it will not be caught, and the test case will be
           deemed to have suffered an error, exactly as for an
           unexpected exception.

           If called with callableObj omitted or None, will return a
           context object used like this::

                with self.assertRaises(SomeException):
                    do_something()

           The context manager keeps a reference to the exception as
           the 'exception' attribute. This allows you to inspect the
           exception after the assertion::

               with self.assertRaises(SomeException) as cm:
                   do_something()
               the_exception = cm.exception
               self.assertEqual(the_exception.error_code, 3)
        """
        try:
            TestCase('assertRaises').assertRaises(excClass, callableObj, *args, **kwargs)
        except:
            if logLevel.lower() == 'error':
                LOGGER.error("exception not raised ")
            else:
                LOGGER.debug("exception not raised ")
            raise CommonAssertError, "exception not raised "

    @staticmethod
    def timedAssert(timeout, interval, methodToAssert, *args,  **kwargs):
        '''
        @param timeout: int, unit is second, default is 300
        @param interval: int, unit is second, value range >0, default is 5
        @param methodToAssert: method, the method name
        @param *args: the args for the positionnal parameters 
        @param **kwargs: the args for the named parameters (ex: logLevel='debug')

        There is one method need to be Assert: assertSPAState(lab, spaName, spaState)
        timedAssert(300, 5, assertSPAState, lab, spaName, spaState)

        every 5s, method assertSPAState(lab, spaName, spaState) will be run,
        until no exception raised or timeout reached.
        if time reach to 300s, raise a exception with error message
        '''
        startTime = time.time()
        endTime = startTime + timeout
        executeTime = startTime
        txtDebug = "Execute function %s with parameter %s %s" % (methodToAssert.__name__ , str(args), str(kwargs))
        while executeTime <= endTime:
            try:
                LOGGER.debug(txtDebug)
                methodToAssert(*args, **kwargs)
            except BaseException:
                LOGGER.debug(traceback.format_exc())
                sleepTime = interval - (time.time() - executeTime)
                if int(sleepTime > 0):
                    time.sleep(interval)
                else:
                    LOGGER.warn("interval is not big enough, execute time > interval")
                executeTime = time.time()
            else:
                break
        else:
            msg = '%s NOT SUCCESS' % txtDebug
            LOGGER.error(msg)
            raise AssertionError(msg)


    @staticmethod
    def assertSequenceEqual(seq1, seq2, msg=None, seqType=None, logLevel='error'):
        """An equality assertion for ordered sequences (like lists and tuples).

        For the purposes of this function, a valid ordered sequence type is one
        which can be indexed, has a length, and has an equality operator.

        @param seq1: The first sequence to compare.
        @param seq2: The second sequence to compare.
        @param seqType: The expected datatype of the sequences, or None if no
                    datatype should be enforced.
        @param msg: Optional message to use on failure instead of a list of
                    differences.

        assertSequenceEqual(seq1, seq2)
        eg:
        assertSequenceEqual([1,2],[1,2]) -> success
        assertSequenceEqual([3,2],[1,2]) -> fail
        """
        try:
            TestCase('assertSequenceEqual').assertSequenceEqual(seq1, seq2, msg, seqType)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertListEqual(list1, list2, msg=None, logLevel='error'):
        """A list-specific equality assertion.

        Args:
            list1: The first list to compare.
            list2: The second list to compare.
            msg: Optional message to use on failure instead of a list of
                    differences.
        """
        try:
            TestCase('assertListEqual').assertListEqual(list1, list2, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertListAlmostEqual(list1, list2, msg=None, logLevel='error'):
        """A list-specific equality assertion, do not care about the order

        Args:
            list1: The first list to compare.
            list2: The second list to compare.
            msg: Optional message to use on failure instead of a list of
                    differences.
        Usage:
            assertListAlmostEqual([1,2],[2,1])  ->success
            assertListAlmostEqual([3,2],[2,1])  ->fail
        """
        try:
            for index in list1:
                TestCase('assertIn').assertIn(index, list2, msg)
            for index in list2:
                TestCase('assertIn').assertIn(index, list1, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertTupleEqual(tuple1, tuple2, msg=None, logLevel='error'):
        """A tuple-specific equality assertion.

        Args:
            tuple1: The first tuple to compare.
            tuple2: The second tuple to compare.
            msg: Optional message to use on failure instead of a list of
                    differences.
        """
        try:
            TestCase('assertTupleEqual').assertTupleEqual(tuple1, tuple2, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertDictEqual(d1, d2, msg=None, logLevel='error'):
        """A Dictionary equality assertion.

        Args:
            d1: The first Dictionary to compare.
            d2: The second Dictionary to compare.
            msg: Optional message to use on failure instead of a list of
                    differences.
        """
        try:
            TestCase('assertDictEqual').assertDictEqual(d1, d2, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertDictContainsSubset(expected, actual, msg=None, logLevel='error'):
        """Checks whether actual is a superset of expected."""
        try:
            TestCase('assertDictContainsSubset').assertDictContainsSubset(expected, actual, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertLess(first, second, msg=None, logLevel='error'):
        """Just like self.assertTrue(a < b), but with a nicer default message."""
        try:
            TestCase('assertLess').assertLess(first, second, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertLessEqual(first, second, msg=None, logLevel='error'):
        """Just like self.assertTrue(a <= b), but with a nicer default message."""
        try:
            TestCase('assertLessEqual').assertLessEqual(first, second, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertGreater(first, second, msg=None, logLevel='error'):
        """Just like self.assertTrue(a > b), but with a nicer default message."""
        try:
            TestCase('assertGreater').assertGreater(first, second, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertGreaterEqual(first, second, msg=None, logLevel='error'):
        """Just like self.assertTrue(a >= b), but with a nicer default message."""
        try:
            TestCase('assertGreaterEqual').assertGreaterEqual(first, second, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertIsNone(obj, msg=None, logLevel='error'):
        """Same as self.assertTrue(obj is None), with a nicer default message."""
        try:
            TestCase('assertIsNone').assertIsNone(obj, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg

    @staticmethod
    def assertIsNotNone(obj, msg=None, logLevel='error'):
        """Included for symmetry with assertIsNone."""
        try:
            TestCase('assertIsNotNone').assertIsNotNone(obj, msg)
        except BaseException, exceptionMsg:
            if logLevel.lower() == 'error':
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise CommonAssertError, exceptionMsg
