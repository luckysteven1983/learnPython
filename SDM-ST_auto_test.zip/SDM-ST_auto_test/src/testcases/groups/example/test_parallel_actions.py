"""
Created on Sep 16, 2015
@author: Andy SUN
"""

from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class test_parallel_actions(SDMTestCase):
    """Test parallel actions
        
    Just check the time saving after some tasks in parallel.
    """

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.sshManager = self.sdmManager.sshManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.oneLab = self.testEnv.testBed.labs.values()[0]

    def test_parallel(self):
        """test parallel"""
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.info("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        # Get BE list
        LOGGER.info("run test case ...")
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sshManager, self.oneLab)
        self.sshManager.run(self.oneLab.oamIpAddress, "echo hello world")
        return startTime

    def _postcheck(self, startTime):
        """Test case postcheck"""
        LOGGER.info("test case post check")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
