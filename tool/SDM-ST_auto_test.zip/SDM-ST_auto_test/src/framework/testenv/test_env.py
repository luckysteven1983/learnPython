"""
Created on Jan 30, 2015
@author: yohannm
@brief Defines the TestEnv class
"""

class TestEnv(object):
    """
    @details This class handles a test environment (testEnv) from configuration file.
    """

    def __init__(self):
        """ TestEnv class constructor """

        self.id = None
        self.testBed = None
        self.trafficSimulators = []
