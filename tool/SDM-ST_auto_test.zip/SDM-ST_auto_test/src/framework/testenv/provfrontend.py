'''
Created on June 23, 2015

@author: FrankZh
'''
from framework.testenv.product_role import ProductRole

class ProvFrontend(ProductRole):
    '''
    classdocs
    '''

    def __init__(self):
        super(ProvFrontend, self).__init__()
        self.id = None
        self.FE_Key = ""
