"""
@file
Created on Mar 10, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines JmeterSOAPTrafficSimulator class
"""

from framework.traffic.soap_traffic_simulator import SOAPTrafficSimulator

class JmeterSOAPTrafficSimulator(SOAPTrafficSimulator):
    """
    @details This class describes a Jmeter traffic as defined in configuration.xml.
    """

    def __init__(self, sshManager):
        """
        JmeterSOAPTrafficSimulator class constructor
        """
        self.trafficProfileId = ""       
        super(JmeterSOAPTrafficSimulator, self).__init__(sshManager)
        self.sshManager = sshManager
