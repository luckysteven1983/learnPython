"""
package including classes describing configuration, versions, etc, all classes
related to TestEnv class described above.
"""