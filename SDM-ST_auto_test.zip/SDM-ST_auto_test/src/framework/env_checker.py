"""
Created on Jan 28, 2015

@author: yohannm
"""

import os
import re

from lxml import etree
import paramiko

from framework.testenv.backend import Backend
from framework.testenv.frontend import Frontend
from framework.testenv.provfrontend import ProvFrontend
from framework.testenv.station import Station
import lib.exceptions_messages as Emsgs
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_PILOT, \
    MIDDLEWARE_ROLE_NONPILOT


LOGGER = Logger.getLogger(__name__)

def getIpFromNetworkNrgZone(tree, nrg, zone, optionName):
    """Return IP list of optionName"""
    # From R4.4, the function tag might have BE.NETWORK.NRG.1.ZONE.1,
    # BE.NETWORK.NRG.1.ZONE.1_IPV4, or BE.NETWORK.NRG.1.ZONE.1_IPV6, so we will match
    # all and get a replicated or ndb ip address list (maybe both IPV4 and V6 exist)
    addressPattern = '/applicationConfiguration/module[@name="IP_conf"]' + \
                   '/function[starts-with(@name, "BE.NETWORK.NRG.' + nrg + '.ZONE.' + \
                    zone + '")]' + '/option[@name="' + optionName + '"]/@value'
    tmpList = tree.xpath(addressPattern)
    LOGGER.debug("nrg: %s\nzone: %s\noptionName: %s\naddress: %s",
                 nrg, zone, optionName, str(tmpList))
    return [ip.split("/")[0].strip() for ip in tmpList if ip.split()]

class EnvCheckerException(BaseException):
    """If error, raise it."""
    pass

class EnvChecker(object):
    """
    this class will implement a check method with two parameters: an iterable
    of hostnames and a TestEnv. The iterable of hostnames will represent the
    actual list of hostnames of a TestBed considered as available and TestEnv
    will contain the TestCase required environement (minimal hardware and
    software versions)
    """

    def __init__(self, sshManager, versionManager, multiTasksManager,databaseStateManager=None):
        """
        Constructor
        """
        self.sshManager = sshManager
        self.versionManager = versionManager
        self.multiTasksManager = multiTasksManager
        self.databaseStateManager = databaseStateManager

    def _labInfo(self, lab):
        """Load lab information
        """
        sdmGeneralData = "/cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml"
        xmlOption = '/applicationConfiguration/module[@name="%s"]/function[@name="%s"]/option[@name="%s"]/@value'
        sdmGeneralDataPath = self.sshManager.scpGet(lab.oamIpAddress, sdmGeneralData)
        LOGGER.debug("sdmGeneralDataPath " + sdmGeneralDataPath)
        tree = etree.parse(sdmGeneralDataPath)  # pylint: disable=no-member
        lab.zoneId = tree.xpath(xmlOption % ("IP_conf", "Common", "Zone_id"))[0]
        role = tree.xpath(xmlOption % ("General", "Common", "CONFIGURATION"))[0]
        if role == "BE":
            productRole = Backend()
            nrg = tree.xpath(xmlOption % ("IP_conf", "Common", "NRG_key"))[0]
            productRole.networkReplicatedGroup = nrg
            productRole.replicatedAddress = getIpFromNetworkNrgZone(tree, nrg, lab.zoneId, "GMPS.ADDRESS")
            productRole.ndbAddress = getIpFromNetworkNrgZone(tree, nrg, lab.zoneId, "NDB.ADDRESS")
            if self.databaseStateManager:
                productRole.isAutomaticSwoEnabled = self.databaseStateManager.isAutomaticSwoEnabled(lab)

        elif role == "FE":
            productRole = Frontend()
            productRole.FE_Key = tree.xpath(xmlOption % ("IP_conf", "Common", "FE_KEY"))[0]
            productRole.ss7StacksMode = tree.xpath(xmlOption % ("IP_conf", "Common", "SS7_PARAM_SCP_DIST_SS7"))[0]
        elif role == "Prov-FE":
            productRole = ProvFrontend()
            productRole.FE_Key = tree.xpath(xmlOption % ("IP_conf", "Common", "FE_KEY"))[0]
        else:
            LOGGER.warn("unknown role %s in SDM_General_Data.xml of %s", role, lab.toolIpAddress)
        lab.productRole = productRole
        hardware = tree.xpath(xmlOption % ("General", "Common", "HARDWARE"))[0]
        lab.hardware = hardware
        self.loadStationInfo(lab)

    def _loadLabInfo(self, testEnv):
        """ Load some information
        (networkReplicatedGroup, FE key, node type (BE or FE))
        from SDM_General_Data.xml into testEnv """
        labs = testEnv.testBed.labs.values()
        # Fetch each lab version
        LOGGER.debug("Load lab version on all Labs in progress")
        for lab in labs:
            threadName = self.multiTasksManager.register(self.versionManager.getversion, lab.oamIpAddress)
            LOGGER.debug("Load lab version on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        LOGGER.debug("Wait load lab version complete on all Labs")
        versions = self.multiTasksManager.runMultiTasks(self.multiTasksManager.TASK_RETURN_VALUES)
        for lab, version in zip(labs, versions):
            if version is None:
                LOGGER.warning("cannot load lab version on %s ", lab.id)
                version = 'unknown'
            testEnv.testBed.version[lab.id] = version
        LOGGER.debug("Load lab info on all Labs in progress")
        for lab in labs:
            threadName = self.multiTasksManager.register(self._labInfo, lab)
            LOGGER.debug("Load lab info on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        LOGGER.debug("Wait load lab info complete on all Labs")
        if not self.multiTasksManager.runMultiTasks():
            LOGGER.error(Emsgs.LOAD_LAB_INFO_FAIL)
            raise EnvCheckerException, Emsgs.LOAD_LAB_INFO_FAIL

    def loadStationInfo(self, lab):
        """Load some information about stations (name middlewareRole toolIpAddress serialIp productRole )

        rcs_hostname and middlewareRole can be get from "/usr/psp/customize/list_servers"
        FE result:
        0-0-1 -> pilot ------------------ rcs_hostname is 0-0-1, middlewareRole is pilot
        0-0-10 -> MAS  ------------------ rcs_hostname is 0-0-10, middlewareRole is non-pilot
        BE result:
        0-0-1 -> pilot ------------------ rcs_hostname is 0-0-1, middlewareRole is pilot
        0-0-10 -> DDM  ------------------ rcs_hostname is 0-0-10, middlewareRole is non-pilot

        ddmHostname can be get from "/usr/dhafw/tools/5350adaptation/getDDMHostname rcs_hostname"
        result:
        STATION_A

        productRole can be get from "/usr/psp/customize/list_server_mods rcs_hostname"
        server mods:
        ASR         --------------- productRole is iLB
        ddm_cluster --------------- productRole is DB
        DDM         --------------- productRole is RT
        SS7         --------------- productRole is ss7

        """
        LOGGER.debug("Log on : " + lab.oamIpAddress)
        sshClient = self.sshManager.getClient(lab.oamIpAddress)
        if not sshClient.get_transport().is_alive():
            LOGGER.error('Connection to ' + lab.oamIpAddress + ' no longer exists.')
            raise paramiko.SSHException

        nodeIDdict = dict()
        if isinstance(lab.productRole, Backend):
            mysqlConf = self.sshManager.scpGet(lab.oamIpAddress, "/usr/dhafw/data/mysql/config.ini")
            with open(mysqlConf, "r") as myFile:
                for line in myFile:
                    if re.search('NodeId=', line):
                        nodeid = line.split("=")[1].rstrip(os.linesep)
                    if re.search('hostname=', line):
                        ddmHostname = line.split("=")[1].rstrip(os.linesep)
                        nodeIDdict[ddmHostname] = nodeid

        cmd = "/usr/psp/customize/list_servers"
        _, stdout, _ = sshClient.exec_command(cmd)
        if stdout.channel.recv_exit_status():
            LOGGER.error("%s: %s", lab.id, Emsgs.LOAD_STATION_INFO_FAIL)
            raise EnvCheckerException(Emsgs.LOAD_STATION_INFO_FAIL)

        serverLine = [line.strip() for line in stdout.read().rstrip().split(os.linesep)]
        for line in serverLine:
            rcsHostname = line.split()[0]
            serverRule = line.split()[-1]
            lab.stations[rcsHostname] = Station()
            lab.stations[rcsHostname].rcsHostname = rcsHostname
            if serverRule == "pilot":
                lab.stations[rcsHostname].middlewareRole = MIDDLEWARE_ROLE_PILOT
            else:
                lab.stations[rcsHostname].middlewareRole = MIDDLEWARE_ROLE_NONPILOT

            cmd = "/usr/dhafw/tools/5350adaptation/getDDMHostname " + rcsHostname
            _, stdout, _ = sshClient.exec_command(cmd)
            if not stdout.channel.recv_exit_status():
                ddmHostname = stdout.read().rstrip()
                lab.stations[rcsHostname].ddmHostname = ddmHostname

            cmd = "/usr/psp/customize/list_server_mods " + rcsHostname
            _, stdout, _ = sshClient.exec_command(cmd)
            if not stdout.channel.recv_exit_status():
                result = [line.strip() for line in stdout.read().rstrip().split(os.linesep)]
                if 'SS7' in result:
                    lab.stations[rcsHostname].productRole.append('ss7')
                if 'ASR' in result:
                    lab.stations[rcsHostname].productRole.append('iLB')
                if 'DDM' in result:
                    lab.stations[rcsHostname].productRole.append('RT')
                if 'ddm_cluster' in result:
                    lab.stations[rcsHostname].productRole.append('DB')
                    lab.stations[rcsHostname].mysqlNodeID = nodeIDdict[ddmHostname]

        if lab.hardware.lower() == "rouzic" and isinstance(lab.productRole, Frontend):
            lab.stations['0-0-7'] = Station()
            lab.stations['0-0-8'] = Station()
            lab.stations['0-0-7'].rcsHostname = '0-0-7'
            lab.stations['0-0-7'].productRole.append('iLB')
            lab.stations['0-0-8'].rcsHostname = '0-0-8'
            lab.stations['0-0-8'].productRole.append('iLB')

    def checkInitialState(self, testEnv):
        """
        Constructor
        """
        LOGGER.info("Loading labs information")
        self._loadLabInfo(testEnv)
