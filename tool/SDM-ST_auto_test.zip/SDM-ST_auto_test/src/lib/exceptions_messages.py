"""
@file
@ingroup SDMSQA Automation
@author Claude Le du
@date 2015-02-26
@brief Describes all the the exceptions used in the framework
"""

# Alarm code format 1001XX, 1002XX....1009XX, 1010XX; 1011XX 2 first digit reserved for future use in
# case of needs

# Alarm exception message Error code 1001XX
ALARM_UNEXPECTED_ALARM = "Alarm_err_100100: Unexpected alarms occurred"
ALARM_EXPECTED_ALARM_NOT_FOUND = "Alarm_err_100101: Expected alarms not found"
ALARM_FILE_NOT_FOUND = "Alarm_err_100102: File not found"
ALARM_STARTING_DATE_AFTER_ENDING_DATE = "Alarm_err_100103: startingDate > endingDate"
ALARM_UNSUPPORTED_FAILURE_MODE = "Alarm_err_100104: unsupported failureMode"
ALARM_MUST_NOT_HAVE_FOUND = "Alarm_err_100105: must not have alarms found"

# Log Parser error code 1002XX
LOG_DIR_NOT_FOUND = "Log_err_100200: Directory not found"
LOG_FILE_NOT_FOUND = "Log_err_100201: File not found"
LOG_FILE_MISSING = "Log_err_100202: Missing some files"
LOG_INVALID_FILE_FROMAT = "Log_err_100203: Invalid file format"
LOG_INVALID_TIME_FROMAT = "Log_err_100204: Invalid time format"

# HardWare Manager error
VMMHI_GET_STATUS_ERROR = 'Hardware Status not retrieved'

# Machine Manager error code 3xx
MCAS_UNEQUIP_MACHINE = 'Mcas_err_100300: Unequiped machine'
MCAS_INVALID_VHOST = 'Mcas_err_100301: Invalid vhost'
MCAS_MACHINE_STATE_NOK = 'Mcas_err_100302: Can not get the machine state'
MCAS_ASTOP_FAILS = 'Mcas_err_100303: Astop command failed'
MCAS_ASTART_FAILS = 'Mcas_err_100304: Astart command failed'

# Core Check Manager error code 1004XX
CORE_INVALID_TIME_FORMAT = "Core_err_100400: Invalid time format"
CORE_DUMP_FOUND = "Core_err_100401: Core file found"

# database error code 1005XX
GET_DATABASE_STATE_FAIL = "DB_err_100500: get database state failed"
GET_MASTER_BE_FAIL = "DB_err_100501: get master be failed"
GET_SLAVE_BE_FAIL = "DB_err_100502: get slave be failed"
GET_NDB_STATE_FAIL = "DB_err_100503: get ndb state failed"
GET_TOPOLOGY_FAIL = "DB_err_100504: get topology failed"
LOAD_NODES_FAIL = "DB_err_100505: load nodes fail"
ENABLE_AUTOMATIC_SWO_FAIL = "DB_err_100506: enable automatic swo failed"
DISABLE_AUTOMATIC_SWO_FAIL = "DB_err_100507: disable automatic swo failed"

# database_manager error code 1006XX
PROCESS_RESTART_FAILED_ON_ACTIVE_PILOT = "DDM_err_100600: process restart failed on active pilot"
PROCESS_RESTART_FAILED_ON_STATIONS = "DDM_err_100601: process restart failed on stations"
UNSUPPORTED_BE_STATE = "DDM_err_100602: Unsupported BE state"
DDM_CMD_NOK = "DDM_err_100603: Can not execute DDM command"
DDM_OPERATOR_STATUS_NOK = 'DDM_err_100604: Operator status NOK'
DDM_GLOBAL_STATUS_NOK = 'DDM_err_100605: Global status NOK'
TOPOLOGY_STATE_NOK = "DDM_err_100606: topology state NOK"
RESTART_NONPILOT_FAIL = "DDM_err_100607: Non Pilot Board Restart Fails"
SINGLE_NODE_NRG_NOT_SUPPORTED = "DDM_err_100608: Single node NRGs are not supported"
SCRIPT_FAILED_ON_STATION = "DDM_err_100609: Script failed on station "
PROCESS_START_FAILED_ON_ACTIVE_PILOT = "DDM_err_100610: process start failed on active pilot"
PROCESS_START_FAILED_ON_STATIONS = "DDM_err_100611: process start failed on stations"
PROCESS_STOP_FAILED_ON_ACTIVE_PILOT = "DDM_err_100612: process stop failed on active pilot"
PROCESS_STOP_FAILED_ON_STATIONS = "DDM_err_100613: process stop failed on stations"
PROCESS_FORCE_STATUS_FAILED_ON_ACTIVE_PILOT = "DDM_err_100614: process forceStatusOk failed on active pilot"
PROCESS_FORCE_STATUS_FAILED_ON_STATIONS = "DDM_err_100615: process forceStatusOk failed on stations"
OPERATION_NOT_SUPPORTED = "DDM_err_100617: Operation not supported with Script: "
UNKNOWN_SCRIPT = "DDM_err_100618: Unknown script on stations : "

# linux process manager error code 1007XX
PROCESS_NOT_ALIVE = "Process_err_100700: process is not alive"
GET_PID_FAIL = "Process_err_100701: get pid failed"
KILL_PROCESS_FAIL = "Process_err_100702: kill process fail"
NO_PROCESS_FOUND = "Process_err_100703: No process found"

# Asserts error code 1008XX
ASSERT_PROCESS_ALIVE_PILOT_FAIL = "Assert_err_100800: assert proccess is alive on active pilot fail"
ASSERT_PROCESS_ALIVE_ALL_STATION_FAIL = "Assert_err_100801: assert proccess is alive on all stations fail"
ASSERT_NO_SPA_FAIL = "Assert_err_100802: assert no spa fail"
ASSERT_SPA_STATE_FAIL = "Assert_err_100803: assert spa state fail"
ASSERT_NDB_STATE_FAIL = "Assert_err_100804: assert ndb state fail"
TIME_ASSERT_FAIL = "Assert_err_100805: timed assert fail"
ASSERT_LOCAL_PROCESS_STATE_FAIL = "Assert_err_100806: assert local spa state fail"
ASSERT_LOG_CONTAIN_CONTENT_FAIL = "Assert_err_100807: assert the log contains the specified content failed"

# Ptool traffic error code 1009XX
PTOOL_CONFIG_FILE_NOT_FOUND = "Ptool_err_100900: configuration file not found on PC lab"
PTOOL_FAILED_TO_RUN_RESET_SCRIPT = "Ptool_err_100901: Failed to run reset pur script on PC lab"
PTOOL_SCENARIO_ALREADY_IN_USE = "Ptool_err_100902: This scenario is already running for the same frontend"
PTOOL_SCENARIO_NOT_FOUND = "Ptool_err_100903: scenario file not found on PC lab"
PTOOL_SCENARIO_NO_NRG_IN_NAME = "Ptool_err_100904: scenario name must include \"NRGn\" where n is the NRG key"
PTOOL_START_TRAFFIC_FAILED = "Ptool_err_100905: -failed to start"
PTOOL_TRAFFIC_NOT_FOUND = "Ptool_err_100906: Traffic not found"
PTOOL_TRAFFIC_PROCESS_ID_NOT_FOUND = "Ptool_err_100907: Traffic process ID not found"
TRAFFIC_BAD_QOS = "Traffic_err_100908: Traffic QoS is bad"
PTOOL_TRAFFIC_TYPE_NOT_IN_PTOOL_DIR = "Ptool_err_100910: Traffic type (LTE or HSS) must be contained in ptool dir name"
PTOOL_TRAFFIC_SIMULATOR_NOT_FIT = "Ptool_err_100911: Ptool traffic simulator not fit for this profile"

# Tgen traffic error code 1010XX
TGEN_DIR_NOT_FOUND = "Tgen_err_101000: directory not found on PC lab"
TGEN_SCENARIO_ALREADY_IN_USE = "Tgen_err_101001: This scenario is already running for the same frontend"
TGEN_START_TRAFFIC_FAILED = "Tgen_err_101002: failed to start"
TGEN_TRAFFIC_NOT_FOUND = "Tgen_err_101003: is not running on this server with this traffic"
TGEN_TRAFFIC_PROCESS_ID_NOT_FOUND = "Tgen_err_101004: Traffic process ID not found"
TGEN_TRAFFIC_SIMULATOR_NOT_FIT = "Tgen_err_101005: Tgen traffic simulator not fit for this profile"

# Ssh Manager error code 1011XX
GATEWAY_MISSING_USERPW = 'Ssh_err_101100: you provided gateway, so please provide associated user and password'
LOST_CONNECTION = 'Ssh_err_101101: ssh reconnection failed after attempts: {host, attempts}: '
CONNECTION_DOWN = 'Ssh_warn_101102: ssh connection down, trying to reconnect: {host, timeout (seconds)}: '
PUBLIC_KEY_COPY_ERROR = "Ssh_err_101103: error while copying public key, return code: "
CONNECTION_NOT_FOUND = 'Ssh_warn_101104: ssh connection down: '

# Env Checker error code 1012XX
LOAD_STATION_INFO_FAIL = "Env_err_101200: load station info fail"
LOAD_LAB_INFO_FAIL = "Env_err_101201: load lab info fail"

# Traffic Manager error code 1013XX
TRAFFIC_MANAGER_TRAFFIC_NOT_STARTED = "TrafficMg_err_101300: traffic(s) not started"
TRAFFIC_MANAGER_TRAFFIC_STOPPED_BAD_FIRST_QOS = "TrafficMg_err_101301: traffic(s) stopped due to a bad first QoS"

# Health Check error code 1014XX
HEALTH_CHECK_ALARM_TABLE = 'HealthCheck_err_101400: Can not get alarm table through subshl command'
HEALTH_CHECK_ALARM_PARSER = 'HealthCheck_err_101401: Can not parse alarm file'
HEALTH_CHECK_ACTIVE_ALARM = 'HealthCheck_err_101402: Active Alarms not cleared'
HEALTH_CHECK_ALARM_SEVERITY = 'HealthCheck_err_101403: Unsupported alarm severity'
HEALTH_CHECK_TOOL_NOK = 'HealthCheck_err_101404: health check tool not installed'
HEALTH_CHECK_SPA_NOK = 'HealthCheck_err_101405: spa state NOK'
HEALTH_CHECK_MACHINE_NOK = 'HealthCheck_err_101406: machine state NOK'
HEALTH_CHECK_STATION_NOK = 'HealthCheck_err_101407: station state NOK'
HEALTH_CHECK_SIGTRAN_NOK = 'HealthCheck_err_101408: sigtran link state NOK'
HEALTH_CHECK_SSNLINK_NOK = 'HealthCheck_err_101409: ssn link state NOK'
HEALTH_CHECK_NDB_NOK = 'HealthCheck_err_101410: ndb state NOK'
HEALTH_CHECK_PROC_NOK = 'HealthCheck_err_101411: process state NOK'
HEALTH_CHECK_CONN_NOK = 'HealthCheck_err_101412: connection state NOK'
HEALTH_CHECK_DIAMLINK_NOK = 'HealthCheck_err_101413: diameter link state NOK'
HEALTH_CHECK_POINT_NOK = 'HealthCheck_err_101414: unsupported check points'
HEALTH_CHECK_HELPME_NOK = 'HealthCheck_err_101415: helpme result is NOK'

# CheckQoSAllTraffics test case error code 1015XX
CHECK_QOS_NO_TRAFFIC = "CheckQoS_err_101500: No traffic running" + \
                        " (notraffic parameter or no traffic in configuration file)"
CHECK_QOS_BAD_QOS = "CheckQoS_err_101501: Stability traffic, bas QoS"

# spa error code 1016XX
GET_SPA_VERSION_FAILED = "Spa_err_101600: Get SPA version failed"
GET_SPA_STATUS_FAILED = "Spa_err_101601: Get SPA status failed"
DO_NOT_SUPPORT_LAB_TYPE = "Spa_err_101602: Do not support this lab type"
RMV_SPA_FAIL = "Spa_err_101603: remove spa failed"
RST_SPA_FAIL = "Spa_err_101604: restore spa failed"
DEL_PROC_SPA_FAIL = "Spa_err_101605: delete process of spa failed"
ABT_SPA_FAIL = "Spa_err_101606: abort process of spa failed"
INSTALL_PROC_SPA_FAIL = "Spa_err_101607: install process of spa failed"
DEL_CONF_SPA_FAIL = "Spa_err_101608: delete configuration of spa failed"
INSTALL_CONF_SPA_FAIL = "Spa_err_101609: install configuration of spa failed"
RESTART_SPA_FAIL = "Spa_err_101610: restart spa failed"

# Measurement Manager error code 1019xx
OPEN_MEAS_TABLE_FAILED = "Meas_error_101900: open meas table failed"
UPDATE_MEAS_TABLE_FAILED = "Meas_error_101901: update meas table failed"
CLOSE_MEAS_TABLE_FAILED = "Meas_error_101902: close meas table failed"
GET_MEAS_TABLE_FAILED = "Meas_error_101903: get meas table failed"
GET_MEAS_TABLE_CONFIG_FAILED = "Meas_error_101904: get meas table config failed"
GET_MEAS_DATA_FAILED = "Meas_error_101903: get data table failed"

# Framework error code 1017XX
TEST_ITEM_NOK = "Fw_err_101700: Test item not found"
ENV_HEALTH_NOK = "Fw_err_101701: Env health check failure"
LABS_NOT_FOUND = "Fw_err_101702: Can not found all labs"
STOP_ON_FAILED_TC = "Fw_err_101703: Stopping testsuite at failed testcase"
TEST_PATTERN_NOK = "Fw_err_101704: Test Once Pattern not matching with any file"
LAB_CONNECTION_FAILURE = "Fw_err_101705: Failed to connect to lab"
ROUTER_CONNECTION_FAILURE = "Fw_err_101706: Failed to connect to router"

# Current Alarm Manager error code 1018XX
CURRENT_ALARM_TABLE_NOK = 'CurrentAlarm_err_101800: Can not get alarm table through subshl command'
CURRENT_ALARM_PARSER_NOK = 'CurrentAlarm_err_101801: Can not parse alarm file'

# src.framework.MangeIpDisturbances code 1020XX
HARDWARE_NOT_SUPPORTED = 'IpDIsturb_err_102000: IP Disturbance hardware not available (only HP / ATCA / CLOUD) : '
CONF_FILE_MISSING = 'IpDIsturb_err_102001: Configuration file is missing : '
UNKNOWN_OPERATION = 'IpDIsturb_err_102002: IP Disturbance operation unknown : '
COMMAND_FAILED = 'IpDIsturb_err_102003: IP Disturbances command failed : '

# Jmeter traffic error code 1021XX
JMETER_SCENARIO_ALREADY_IN_USE = "Jmeter_err_102100: This scenario is already running for the same frontend"
JMETER_SCENARIO_NOT_FOUND = "Jmeter_err_102101: Jmeter scenario file not found on PC lab"
JMETER_START_TRAFFIC_FAILED = "Jmeter_err_102102: Jmeter failed to start"
JMETER_TRAFFIC_NOT_FOUND = "Jmeter_err_102103: Traffic not found"

# Spectra2 Traffic error code 1022xx
SPECTRA_CONNECT_FAILED = "Spectra_err_102200: Opening spectra2 connection failed"
SPECTRA_RUN_FAILED = "Spectra_err_102201: Running spectra2 failed"
SPECTRA_RUN_TRAFFIC_MODEL_FAILED = "Spectra_err_102202: Run spectra traffic model failed"
SPECTRA_NOT_RUNNING = "Spectra_err_102203: Generator status is NOT running"
SPECTRA_REPORT_FAILED = "Spectra_err_102204: Generate report failed"
SPECTRA_EVENTLOG_NOK = "Spectra_err_102205: Unable to get Spectra event log file"
SPECTRA_ALL_LINKS_NOK = "Spectra_err_102206: Not all the links are up"
SPECTRA_STOP_FAILED = "Spectra_err_102207: Stopping spectra2 failed"

# load balancer error code 1023xx
GET_CURL_OUTPUT_FAIL = "loadbalancer_error_102301: Get Curl output fail"
GET_ACTIVE_LOADBALANCER_FAIL = "loadbalancer_error_102302: Get active board running LoadBalancer fails"
RESTART_LB_PROCESS_FAIL = "loadbalancer_error_102303: Restart LB process fail"
ASSERT_LB_PROCESS_START_FAIL = "loadbalancer_error_102304: Assert LB process start fail"
LB_UNSUPPORTED_HARDWARE = "loadbalancer_error_102305: Unsupported hardware"

# Database Log Manager 1024xx
DDM_CMD_FAILURE = "DDM_LOG_API_ERROR_102401: DDM log api failure"

# MultiTask class 1025xx
TASK_TYPE_FAILURE = "UNSUPPORTED_TASK_TYPE_102501: Unsupported task type"
if __name__ == '__main__':
    pass
