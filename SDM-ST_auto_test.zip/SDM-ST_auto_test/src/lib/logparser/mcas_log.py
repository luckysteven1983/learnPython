"""
@file MCASlog.py
@ingroup SDMSQA
@author Andy SUN
@brief Parse log files generated through MCAS API

Parse log files generated through MCAS API according to the given timestamps.
And return next log structure between the timestamps for each iteration.
"""

import re
import os
import bisect
import fileinput
from lib.logging.logger import Logger
import lib.exceptions_messages as eMsgs

LOGGER = Logger.getLogger(__name__)

class MCASLogError(BaseException):
    """If error, raise it."""
    pass

class MCASLog(object):
    """Parse log files generated through MCAS API according to the given
    timestamps. And return next log structure between the timestamps for each
    iteration. Each log file based on MCAS API has the following the log
    structure. 

        +++ HP26 2014-12-24 21:34:34 DEBUG        #999999 0-0-1 >
        REPT ERROR LOG MSGH, FILE /n/plflR3001/SOURCE/SU4kR30.src/cc/msgh/proc/
        MHproc .C, LINE 634
        MSGH: ALL HOSTS NOT REGISTERED
        END OF REPORT #999999++-

        where, line starting with '+++' is the timestamp of the log. And the
        line ending with '++-' means the end of log. The log content is between
        both.

    Normally, you can use it like below:

    logs = ['OMlog0', 'OMlog1']
    myLog = MCASLog(logs)
    for oneLog in iter(mylog):
        logger.debug(oneLog)

    logs = ['OMlog0', 'OMlog1']
    beginTime = '2014-12-24 21:11:11' 
    endTime = '2014-12-24 22:11:11' 
    myLog = MCASLog(logs, beginTime, endTime)
    for oneLog in iter(mylog):
        logger.debug(oneLog)

    For each iteration, it will return a touple like this (preFormat, content,
    postFormat) and each item in the touple is a string including the control
    characters at the beging and end. For the example above, the preFormat
    should be '+++ HP26 2014-12-24 21:34:34 DEBUG        #999999 0-0-1 >', the
    postFormat should be 'END OF REPORT #999999++-', and the content should be
    real log contents between preFormat and postFormat.  
    """

    def __init__(self, logFiles, bTime = '0000-00-00 00:00:00',
                 eTime = '9999-99-99 99:99:99'):
        """Init MCASLog instance with log files and timestamps.

        Return an iterable object and for each iteration, get next log struct.
        If the begining time is not given, it will parse the log file from the
        begining, and if the end time is not given, it will parse the log file
        to the end. If both timestamps are not given, it will parse the whole
        log file. Here two invalid timestamps are used in order for convenient
        time comparison. The timestamp should be like 'YYYY-MM-DD HH:MM:SS'

        Keyword arguments:
        logFiles -- the local log files
        bTime    -- the begining time to be filtered in log file (default
                    '0000-00-00 00:00:00')
        eTime    -- the end time to be filtered in log file (default
                    '9999-99-99 99:99:99')
        """
        if not logFiles:
            LOGGER.error(eMsgs.LOG_FILE_NOT_FOUND)
            raise MCASLogError, eMsgs.LOG_FILE_NOT_FOUND
        self._validateTimeFormat(bTime, eTime)
        self._logFiles = list()
        self._bTime = bTime
        self._eTime = eTime
        # MCAS time: +++ HP26 2014-12-24 21:34:34 DEBUG        #999999 0-0-1 >
        self._headPattern = re.compile(
                             r'\+{3} .+ (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) '
                            )
        self._sort(logFiles)
        self._fileHandler = fileinput.input(self._getFilteredFiles())

    def _getFilteredFiles(self):
        """Get file list between the begining and end timestamp.
           
        Went through the sorted log file list and return the filtered file list
        between the begining and end timestamp.
        """
        # Reduce some file operations if timestamps given by user does not go
        # accross the all log files
        timestamps = [t[0] for t in self._logFiles]
        # We should parse the previous file
        firstFile = bisect.bisect_left(timestamps, self._bTime) - 1
        # In case this is first file
        if firstFile < 0: 
            firstFile = 0
        # No need to include this file
        lastFile = bisect.bisect_right(timestamps, self._eTime)
        self._logFiles = [f[1] for f in self._logFiles[firstFile:lastFile]]
        return self._logFiles

    def _sort(self, logFiles):
        """Sort the log files according to its 1st timestamp.

        Keyword arguments:
        logFiles -- log file names
        """
        self._logFiles = [(self._getFirstTimestamp(f), f) for f in logFiles 
                            if os.path.isfile(f)]
        if len(self._logFiles) != len(logFiles):
            LOGGER.error(eMsgs.LOG_FILE_MISSING)
            raise MCASLogError, eMsgs.LOG_FILE_MISSING
        self._logFiles.sort()

    def __iter__(self):
        """Return an iterable object."""
        return self

    def __del__(self):
        """Deconstructor."""
        try:
            self._fileHandler.close()
        except AttributeError:
            pass

    def _parser(self):
        """Parse log files and return one log struture each time."""
        # Line starting with '+++'
        head = ''
        # Log content
        msg = ''
        # Line ending with '++-'
        tail = '' 
        for line in self._fileHandler:
            found = self._headPattern.match(line.strip())
            # Log head
            if found:
                # Later than the end time from user
                if found.group(1) > self._eTime:
                    break
                # Earlier than the begining time from user
                if found.group(1) < self._bTime:
                    continue
                # When begining time <= timestamp < end time
                # Log head found
                head = line
                msg = ''
                tail = ''
                continue
            # Log tail
            if line.strip().endswith('++-'):
                # Not find begining time
                if not head:
                    continue
                # We get a whole log structure.
                else:
                    tail = line
                    break
            # Log content
            msg += line
        return (head, msg, tail)

    def next(self):
        """Return next log structure between timestamps."""
        # In python 2.x, no __next__ special method.
        # When file list to be filtered is empty, the fileinput will read from
        # stdin by default, so the program will be hung. In this case, raise
        # StopIteration. Alternatively, we can find the case earlier in
        # __init__ method and raise it then, but in order for consistence
        # between begining time is eariler than last one and end time is later
        # than first one (we don't know the last timestamp in log file), check
        # it here.
        if not self._logFiles:
            raise StopIteration
        ret = self._parser()
        if ret[0]:
            # LOGGER.debug("Find a log: %s", ret[0])
            return ret
        else:
            # LOGGER.debug("At the end of the log file")
            raise StopIteration

    def _getFirstTimestamp(self, logFile):
        """Find the 1st timestamp in log file.

        Keyword arguments:
        logFile -- log file name
        """
        with open(logFile, 'r') as f:
            for line in f:
                found = self._headPattern.match(line.strip())
                if found: 
                    return found.group(1)
        LOGGER.error("%s: '%s'", eMsgs.LOG_INVALID_FILE_FROMAT, logFile)
        raise MCASLogError, "%s: '%s'" %(eMsgs.LOG_INVALID_FILE_FROMAT, logFile)

    def _validateTimeFormat(self, *timestamp):
        """Validate timestamp provided by user.

        Keyword arguments:
        timestamp -- time format like 'YYYY-MM-DD HH:MM:SS'
        """
        regex = re.compile(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$')
        for t in timestamp:
            if not regex.match(t):
                LOGGER.error("%s: %s", eMsgs.LOG_INVALID_TIME_FROMAT, t)
                raise MCASLogError, "%s: '%s'" %(
                            eMsgs.LOG_INVALID_TIME_FROMAT, t)

