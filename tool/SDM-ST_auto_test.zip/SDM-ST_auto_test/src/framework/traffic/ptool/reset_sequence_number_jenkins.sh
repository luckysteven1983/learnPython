#!/bin/bash

## Created on oct 31, 2014
## @file
## @ingroup SDMSQA Automation
## @author Claude Le Du
## @brief Private expect called by reset_sequence_number_jenkins.sh. send PLG script on frontend.
## @usage ./reset_sequence_number_jenkins.sh <scenario> <master backend>
##    ex: ./reset_sequence_number_jenkins.sh scenario.xml.vzw430.NRG1.1111TPS.1 spa03oam admin
## @cond

if [ $# -ne 2 ]
then
   echo -e "\nError: usage: $0 <scenario> <master_be>\n"
   exit 1
fi
scenario=$1
master_be=$2

if [ ! -f $scenario ]; then
   echo "Error: file $scenario not found."
   exit 2
fi

# to avoid error : "Offending RSA key"
ssh-keygen -R $master_be

DATE=$(date +%d%m%Y-%Hh%M)
workfile=reset_sequence_number_jenkins_$DATE.res
pur_reset_filename=PUR_RESET_$DATE.plg

# nbPur=$(grep -c -i pur $scenario)
nbPur=$(grep -B1 -i pur $scenario | grep -i "MaxNumOfMsg" | wc -l)
if [ $nbPur  -eq 0 ]; then
	echo -e "\nWarning: PUR msg not found in $scenario\n"
	echo -e "\nCheck if your scenario contains PUR message\n"
	exit
fi

i=0
while [ $i -lt $nbPur ]; do  # loop on each PUR found in scenario

   echo "--- PUR MSG #$i ---"
   MaxNumOfMsg=($(grep -B1 -i pur $scenario | grep -iEo "MaxNumOfMsg=.[0-9]+" | grep -Eo "[0-9]+"))
   if [ "${MaxNumOfMsg[$i]}" = "" ]; then
      echo -e "\nError: MaxNumOfMsg from PUR msg #$i not found\n"
      exit 1
   fi

   echo "Building first and last PuidUsername" 
   l=($(grep -B1 -i pur $scenario | grep -iEo "low8='[0-9]+'" | sed "s/low8='\([0-9]\)'/\1/"))
   if [[ ! ${l[$i]} =~ ^[0-9]$ ]]; then
      # at least one digit must be present
      echo "Error: low8 is not a digit"
      exit 1
   fi
   low8=${l[$i]}
   low7=0; low6=0; low5=0; low4=0; low3=0; low2=0; low1=0
   l=($(grep -B1 -i pur $scenario | grep -iEo "low7='[0-9]+'" | sed "s/low7='\([0-9]\)'/\1/"))
   if [[ ${l[$i]} =~ ^[0-9]$ ]]; then
      low7=${l[$i]}
      l=($(grep -B1 -i pur $scenario | grep -iEo "low6='[0-9]+'" | sed "s/low6='\([0-9]\)'/\1/"))
      if [[ $l =~ ^[0-9]$ ]]; then
         low6=${l[$i]}
         l=($(grep -B1 -i pur $scenario | grep -iEo "low5='[0-9]+'" | sed "s/low5='\([0-9]\)'/\1/"))
	    if [[ ${l[$i]} =~ ^[0-9]$ ]]; then
            low5=${l[$i]}
            l=($(grep -B1 -i pur $scenario | grep -iEo "low4='[0-9]+'" | sed "s/low4='\([0-9]\)'/\1/"))
            if [[ ${l[$i]} =~ ^[0-9]$ ]]; then
               low4=${l[$i]}
               l=($(grep -B1 -i pur $scenario | grep -iEo "low3='[0-9]+'" | sed "s/low3='\([0-9]\)'/\1/"))
	       if [[ ${l[$i]} =~ ^[0-9]$ ]]; then
                  low3=${l[$i]}
                  l=($(grep -B1 -i pur $scenario | grep -iEo "low2='[0-9]+'" | sed "s/low2='\([0-9]\)'/\1/"))
                  if [[ ${l[$i]} =~ ^[0-9]$ ]]; then
                     low2=${l[$i]}
                     l=($(grep -B1 -i pur $scenario | grep -iEo "low1='[0-9]+'" | sed "s/low1='\([0-9]\)'/\1/"))
                     if [[ ${l[$i]} =~ ^[0-9]$ ]]; then
                        low1=${l[$i]}
                     fi
                  fi
               fi
            fi
         fi
      fi
   fi
   firstSubscriber="$low8$low7$low6$low5$low4$low3$low2$low1"
   let lastSubscriber=$firstSubscriber+${MaxNumOfMsg[$i]}
   echo "firstSubscriber=$firstSubscriber"
   echo "lastSubscriber=$lastSubscriber"

   msgFile=($(grep -i pur $scenario | grep -iEo "msgFile=.*.msg" | cut -d"=" -f2 | tr -d "'"))
   #echo "msgFile=$msgFile"

   sip=$(grep sip ${msgFile[$i]} | grep -Eo "sip:[0-9]+" | cut -d":" -f2)
   firstPuidUsername=${sip:0:7}$firstSubscriber
   lastPuidUsername=${sip:0:7}$lastSubscriber
   echo "firstPuidUsername=$firstPuidUsername"
   echo "lastPuidUsername=$lastPuidUsername"

   echo "Getting first and last suMSubscriberProfileId from database"
   ./reset_sequence_number_jenkins_suMSubscriberProfileId.exp $master_be $firstPuidUsername $lastPuidUsername > $workfile
   if [ "$?" -ne 0 ]; then
      echo -e "\nERROR: cannot get suMSubscriberProfileId from database\n"
      exit 1
   fi

   # changed 2 following lines for bash 3.2 compatibility
   #firstSuMsubscriberProfileId=$(cat $workfile | sed "1,/------------------------/d" | grep -A2 suMsubscriberProfileId | grep -Eo [0-9]*)
   #lastSuMsubscriberProfileId=$(cat $workfile | sed "1,/------------------------/d" | grep -A3 suMsubscriberProfileId | tail -1 | grep -Eo [0-9]*)
   firstSuMsubscriberProfileId=$(cat $workfile | sed "1,/------------------------/d" | grep -A2 suMsubscriberProfileId | tail -n1 | cut -d" " -f2)
   lastSuMsubscriberProfileId=$(cat $workfile | sed "1,/------------------------/d" | grep -A3 suMsubscriberProfileId | tail -n1 | cut -d" " -f2)
   if [ "$firstSuMsubscriberProfileId" == "" ] || [ "$lastSuMsubscriberProfileId" == "" ]; then
      echo -e "\nERROR: suMSubscriberProfileId(s) not found\n"
      exit 1
   fi
   rm -f $workfile
   echo $firstSuMsubscriberProfileId
   echo $lastSuMsubscriberProfileId

   echo "generation of PUR_RESET_<DATE>.plg"
   suMSubscriberProfileId=$firstSuMsubscriberProfileId
   while [ $suMSubscriberProfileId -lt $lastSuMsubscriberProfileId ]; do
      echo "setattr  puidRepositoryDataId=1,puidId=1,imsServiceProfileId=1,suMSubscriptionProfileId=1,suMSubscriberProfileId=$suMSubscriberProfileId,subscriptionFunctionId=1,managedElementId=HSS1 sequenceNumber1 0" >> $pur_reset_filename
      let suMSubscriberProfileId=suMSubscriberProfileId+1
   done
   echo "Done"

   let i=i+1
done

echo "Sending PUR_RESET_<DATE>.sh on master back-end"
./reset_sequence_number_send_PUR_RESET_sh_on_master.exp $master_be $pur_reset_filename
if [ "$?" -ne 0 ]; then
   echo -e "\nERROR: cannot send $pur_reset_filename on master back-end\n"
   exit 1
fi
rm -f $pur_reset_filename

echo "Moving PUR_RESET.plg to /MDS/ModData"
./reset_sequence_number_move_PUR_RESET_plg.exp $master_be
if [ "$?" -ne 0 ]; then
   echo -e "\nERROR: cannot move PUR_RESET.plg\n"
   exit 1
fi

echo "dbclist on Gdmp backdoor to get hlr position"
./reset_sequence_number_dbclist.exp $master_be > $workfile
if [ "$?" -ne 0 ]; then
   echo -e "\nERROR: running dbclist\n"
   exit 1
fi

echo "dbcset hlr and run PUR_RESET.plg (may be quite long)..."
hlrnb=`grep hlr $workfile | cut -d" " -f1`
./reset_sequence_number_run_plg.exp $master_be $hlrnb
if [ "$?" -ne 0 ]; then
   echo -e "\nERROR: running PUR_RESET.plg\n"
   exit 1
fi

rm -f $workfile

## @endcond

