'''
entry point to all managers.

@author: yohannm
'''

class SdmManager(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self.sshManager = None
        self.healthCheckManager = None
        self.healthCheckAlarmManager = None
        self.coreCheckManager = None
        self.mcasMachineManager = None
        self.mcasPlatformManager = None
        self.trafficManager = None
        self.alarmsCheckerManager = None
        self.databaseStateManager = None
        self.databaseManager = None
        self.platformAsserts = None
        self.testEnvAsserts = None
        self.mcasApplicationManager = None
        self.labRecover = None
        self.linuxProcessManager = None
        self.sdmSuManager = None
        self.measurementManager = None
        self.seloadbalancerManager = None
        self.databaseTopologyManager = None
        self.asrloadbalancerManager = None
        self.malbanManager = None
        self.malbanProcessManager = None
        self.multiTasksManager = None
