"""
@file
@ingroup database
@author Andy SUN
@brief Database Log Management
"""

import lib.exceptions_messages as msgs
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class DatabaseLogManagerError(BaseException):
    """If error, raise it."""
    pass

class DatabaseLogManager(object):
    """Collect Database log
    """

    def __init__(self, sshManager):
        """Constructor
        """
        self.sshManager = sshManager

    def collectDDMLog(self, lab, days=1):
        """Collect DDM log with DDM API dlog.py and return the log name under framework cache
            directory

        @author      Andy SUN
        @param lab   the Lab object
        @param days  days in the past passed to DDM API

        @verbatim
        @usage
            Collect the DDM log in 2 days
            logName = CollectDDMLog(lab, 2)
        @endverbatim
        """
        ddmCmd = "/usr/dhafw/tools/dlog.py -q -d %d" %days
        (rc, logName) = self.sshManager.run(lab.oamIpAddress, ddmCmd)
        # DDM API returns failure
        if rc:
            errorMsg = "%s: %s - %s" %(lab.id, msgs.DDM_CMD_FAILURE, ddmCmd)
            LOGGER.error(errorMsg)
            raise DatabaseLogManagerError, errorMsg
        return self.sshManager.scpGet(lab.oamIpAddress, logName)
