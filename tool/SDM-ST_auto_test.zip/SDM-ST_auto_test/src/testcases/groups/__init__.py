"""
This package contains groups of test cases. One group is a kind of test
domain.
"""
