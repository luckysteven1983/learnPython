'''
@file
@ingroup database
@author Xia Zhao
@brief some functions about database manager
'''
import os
import pprint
import re
import time

from framework.asserts.common_asserts import CommonAssert
from lib.database.ddm.database_state_manager import DDM_DB_SYNCHRO_TIMEOUT, \
 DDM_DB_INTERVAL_CHECK
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MCASMachineManager
from lib.platform.mcas.subshl.subshl_manager import SubshlManager
from lib.ssh.ssh_manager import SshManager
from lib.common.multi_tasks_manager import MultiTasksManager


LOGGER = Logger.getLogger(__name__)

# Process constants
PROCESS_DBSUPERVISOR = "DbSupervisor"
PROCESS_GDMP_SERVER = "GdmpServer"
PROCESS_GDMP_SERVER_OVERLOAD = "GDMPServerOverload"
PROCESS_LDAP_SERVER = "ldapServer"
PROCESS_MYSQLD = "mysqld"
PROCESS_PLATFORM_PROXY = "PlatformProxy"
PROCESS_TOPOLOGY_MANAGER = "TopologyManager"

# Scripts constants
SCRIPT_DBSUPERVISOR = "DbSupervisor"
SCRIPT_GDMP_SERVER = "Gdmps"
SCRIPT_GDMP_SERVER_OVERLOAD = "GdmpsOverload"
SCRIPT_LDAP_SERVER = "Ldaps"
SCRIPT_PLATFORM_PROXY = "DDM_PlatProxy"
SCRIPT_TOPOLOGY_MANAGER = "TopologyManager"

SUPPORTED_SCRIPTS = (SCRIPT_DBSUPERVISOR, SCRIPT_GDMP_SERVER, SCRIPT_GDMP_SERVER_OVERLOAD,
                     SCRIPT_LDAP_SERVER, SCRIPT_PLATFORM_PROXY, SCRIPT_TOPOLOGY_MANAGER)


DB_STATUS_STOP = 'STOP'
DB_STATUS_KOM = 'STOP_KOM'
DB_STATUS_MASTER = 'MASTER'
DB_STATUS_SLAVE = 'SLAVE'
DB_STATUS_SLAVE_KOM = 'SLAVE_KOM'
DB_STATUS_SWO = 'SWITCHOVER'
DB_STATUS_NO_MP = 'NO_MATED_PAIR'
DB_STATUS_DBL_ACTIV = 'DOUBLE_ACTIVE'
DB_STATUS_STOP_DBL_ACTIV = 'STOP_DOUBLE_ACTIVE'
DB_STATUS_SLAVE_NO_REPL = 'SLAVE_NO_REPLICATION'
DB_STATUS_SLAVE_STOP_INJECT = 'SLAVE_STOP_INJECTION'

DB_CMD_STOP = 'stop'
DB_CMD_START = 'start'
DB_CMD_RESTART = 'restart'
DB_CMD_STATUS = 'status'
DB_CMD_CHECK = 'check'
DB_CMD_FORCE_STATUS_OK = 'forceStatusOk'
DB_CMD_STOP_FORCE_STATUS_OK = 'stopForceStatusOk'
DB_CMD_REMOVE_ST_CONF = 'removeStConfFile'

SUPPORTED_CMD = (DB_CMD_STOP, DB_CMD_START, DB_CMD_RESTART, DB_CMD_STATUS, DB_CMD_CHECK,
                 DB_CMD_FORCE_STATUS_OK, DB_CMD_STOP_FORCE_STATUS_OK, DB_CMD_REMOVE_ST_CONF)


class DatabaseManagerError(BaseException):
    """If error, raise it."""
    pass

class DatabaseManager(object):
    '''
    module for global database management features (restart node, etc.)
    '''

    supported_be_state = (DB_STATUS_STOP, DB_STATUS_KOM, DB_STATUS_MASTER, DB_STATUS_SLAVE,
                          DB_STATUS_SLAVE_KOM, DB_STATUS_SWO, DB_STATUS_NO_MP, DB_STATUS_DBL_ACTIV,
                          DB_STATUS_STOP_DBL_ACTIV, DB_STATUS_SLAVE_NO_REPL, DB_STATUS_SLAVE_STOP_INJECT)



    def __init__(self, sshManager, databaseStateManager, linuxProcessManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager
        self._dbState = databaseStateManager
        self._linuxProcessManager = linuxProcessManager


    def runScriptOperation(self, lab, script, ddmOperation='status', station=None):
        '''
        this function is to run an operation like stop, start, restart, etc  on ddm
        daemons as Gdmps , Ldaps , GdmpOverload , etc
        command : '/opt/dhafw/bin/daemon operation'
        @author: Serge Beaufils
        @param lab: the Lab object
        @param script: string, which will be either DbSupervisor, GdmpsOverload, Gdmps, Ldaps,
              PlatformProxy, or TopologyManager
        @param ddmOperation: start stop status check restart removeStConfFile
                             forceStatusOk stopForceStatusOk
        @param station:  string, using format [0-0-1 0-0-2 0-0-3],default value is none.
                if None, will start script on active pilot
                otherwise, will start script on the stations

        @verbatim
        DM = DatabaseManager()
        DM.runScriptOperation(lab,"GdmpsOverload", ddmOperation='restart')
            if script start success on active pilot, No exception raised;
            otherwise, raise an exception with an error message and the station list of failed
        DM.runScriptOperation(lab,"GdmpsOverload", ddmOperation='restart',station="0-0-1,0-0-2")
            if script start on all stations success, No exception raised;
            otherwise, raise an exception with an error message
        @endverbatim
        '''
        if ddmOperation not in SUPPORTED_CMD:
            errMsg = ddmOperation + msgs.OPERATION_NOT_SUPPORTED + script + " on stations:" + str(station)
            LOGGER.error(errMsg)
            raise DatabaseManagerError, errMsg
        if script not in SUPPORTED_SCRIPTS:
            errMsg = msgs.UNKNOWN_SCRIPT + script + ' on ' + str(station)
            LOGGER.error(errMsg)
            raise DatabaseManagerError, errMsg

        processName = "/opt/dhafw/bin/" + script
        if station:
            stationFailed = []
            LOGGER.debug(ddmOperation + " Process: " + script + " on stations:" + str(station))
            result = True
            for stationIndex in station:
                cmd = "ssh " + stationIndex + " " + processName + " " + ddmOperation
                [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
                if not cmdStatus:
                    LOGGER.debug(ddmOperation + " Process: " + script + " on station:" + stationIndex + " success")
                    LOGGER.debug("\n" + stateOutput + "\n")
                else:
                    LOGGER.error(msgs.SCRIPT_FAILED_ON_STATION + stationIndex + ' : ' + script + ' ' + ddmOperation)
                    stationFailed.append(stationIndex)
                    result = False
            if not result:
                LOGGER.error("%s: %s : %s", lab.id, msgs.PROCESS_START_FAILED_ON_STATIONS, str(station))
                raise DatabaseManagerError, msgs.PROCESS_START_FAILED_ON_STATIONS + str(station)
        else:
            LOGGER.debug(ddmOperation + " Process: " + processName + " on active pilot")
            cmd = processName + " " + ddmOperation
            [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
            if not cmdStatus:
                LOGGER.debug("\n" + stateOutput + "\n")
                LOGGER.debug(ddmOperation + " Process: " + script + " on active pilot success")
            else:
                LOGGER.error("%s: %s", lab.id, msgs.PROCESS_START_FAILED_ON_ACTIVE_PILOT)
                raise DatabaseManagerError, msgs.PROCESS_START_FAILED_ON_ACTIVE_PILOT



    def setState(self, lab, state, duration=30, finalState=None, gsSecured=False, interval=1):
        """@verbatim set BE to the given state.

        No return value for the method and raise exception if error.

        The method will set the lab (BE) to given state. If the duration is None, do not check the
        status. If duration is given by default or seconds, it will check whether the status change
        success or not until duration timeout. If fail, raise an exception.

        The supported state contains: 'STOP', 'STOP_KOM', 'MASTER', 'SLAVE', 'SLAVE_KOM',
        'SWITCHOVER', 'NO_MATED_PAIR', 'DOUBLE_ACTIVE', 'STOP_DOUBLE_ACTIVE',
        'SLAVE_NO_REPLICATION', and 'SLAVE_STOP_INJECTION'.

        For some BE state, e.g. STOP, when mpchg to STOP, the BE status will become MATED_PAIR_STOP
        or NO_PAIR_STOP. So for this case, if user wants to check whether the modification is
        successful, should set finalState to 'MATED_PAIR_STOP' or 'NO_PAIR_STOP'.

        @endverbatim
        @param lab: the Lab object
        @param state: the BE state to be changed to
        @param duration: seconds to wait state change end and verification (default 30 seconds)
        @param finalState: the BE finial state (default None)
        @param gsSecured: if true, to wait global status is secured. for the db change from stop/stop_kom to slave,
        operate status can become slave soon, but global status is not secured until db replication is done
        @param interval: the interval in second of checking the status. It is valid when duration is not None
        @usage:
        @verbatim
        import SshManager, DatabaseManager

        dm = DatabaseManager(SshManager())
        1) dm.setState(lab, 'STOP')
        2) dm.setState(lab, 'STOP', None)
        @endverbatim
        """
        state = state.upper()
        if state not in self.__class__.supported_be_state:
            LOGGER.error("Lab %s: %s", lab.id, msgs.UNSUPPORTED_BE_STATE)
            raise DatabaseManagerError, "Lab %s: %s" % (lab.id, msgs.UNSUPPORTED_BE_STATE)

        ddmCmd = '/usr/dhafw/bin/mpchg -s %s' % state
        if self._runShellCmd(lab, ddmCmd, True):
            LOGGER.error("Lab %s: %s", lab.id, msgs.DDM_CMD_NOK)
            raise DatabaseManagerError, "Lab %s: %s" % (lab.id, msgs.DDM_CMD_NOK)
        if duration is not None:
            if finalState is None:
                finalState = state
            CommonAssert.timedAssert(duration, 1, self._assertEqual, lab, finalState)
            if gsSecured:
                CommonAssert.timedAssert(duration, interval, self._assertTrue, lab,
                                         'Global Status', 'secured', msgs.DDM_GLOBAL_STATUS_NOK)

    def matedPairSwo(self, beList, onSlave=True, duration=30):
        """
        @verbatim Manual BE switchover on given labs.
        No return value for the method and raise exception if error.
        This method will do manual BE switchover on given labs according to the following cases.
        1) If only one BE in beList, the method will raise an exception.
        2) If more than one BE in beList (that means mated-pair BEs are given), the method will check the
        flag onSlave. If the flag is true, do switchover on slave BE and otherwise on master BE. And
        then wait until duration end, if both BE status change correctly, return nothing or else
        raise an exception.
        3) If duration is None, only do swo but not check whether the state change successfully
        or not
        @endverbatim
        @param beList: the Lab object List (contains 1 master and 1 or 2 slaves).
                       If 1 master and 2 slaves, the 1st slave is chosen for the switchover.
                       In 3-way case, you can also provide the master BE and only the slave on 
                       which you want to execute the switchover.
        @param onSlave: the swo command is executed on slave BE or not (default True)
        @param duration: seconds to wait swo end and verification (default 30 seconds)
        @verbatim
        import SshManager, DatabaseManager
        dm = DatabaseManager(SshManager())
        1) dm.matedPairSwo([lab1, lab2])
        Do BE switchover on slave BE. If lab1 and lab2 status change success in 30 seconds, no
        exception will be raised. Otherwise raise exception.
        2) dm.matedPairSwo([lab1, lab2], onSlave=False)
        Do BE switchover on master BE. If lab1 and lab2 status change success in 30 seconds, no
        exception will be raised. Otherwise raise exception. (not supported since SDM4.3)
        @endverbatim
        """
        targetLab = None
        stateMap = {'MASTER':'SLAVE', 'SLAVE':'MASTER', 'OK_RW':'OK_RO', 'OK_RO':'OK_RW'}
        if len(beList) == 1:
            LOGGER.error(msgs.SINGLE_NODE_NRG_NOT_SUPPORTED)
            raise BaseException(msgs.SINGLE_NODE_NRG_NOT_SUPPORTED)
        else:
            masterList = self._dbState.getMasterBE(beList)
            slaveList = self._dbState.getSlaveBE(beList)
            masterBE = masterList[0]
            slaveBE = slaveList[0]
            if onSlave:
                targetLab = slaveBE
            else:
                targetLab = masterBE
            masterBEStatus = self._dbState.getState(masterBE)
            masterDBAccess = self._dbState.getState(masterBE, 'DB access')
            slaveBEStatus = self._dbState.getState(slaveBE)
            slaveDBAccess = self._dbState.getState(slaveBE, 'DB access')
            try :
                stateMap[masterDBAccess]
            except KeyError as exc :
                errmsg = 'Exception raised ' + str(exc) + \
                  'Lab id ' + targetLab.id + ' Master has wrong DB Access state ' + masterDBAccess
                LOGGER.error(errmsg)
                raise BaseException(errmsg)
            try :
                stateMap[masterBEStatus]
            except KeyError as exc :
                errmsg = 'Exception raised ' + str(exc) + \
                  'Lab id ' + targetLab.id + ' Master has wrong DB Operator status ' + masterBEStatus
                LOGGER.error(errmsg)
                raise BaseException(errmsg)
            try :
                stateMap[slaveDBAccess]
            except KeyError as exc :
                errmsg = 'Exception raised ' + str(exc) + \
                 'Lab id ' + targetLab.id + ' Slave has wrong DB Access state ' + slaveDBAccess
                LOGGER.error(errmsg)
                raise BaseException(errmsg)
            try :
                stateMap[slaveBEStatus]
            except KeyError as exc :
                errmsg = 'Exception raised ' + str(exc) + 'Lab id ' + \
                 targetLab.id + ' Slave has wrong DB Operator status ' + slaveBEStatus
                LOGGER.error(errmsg)
                raise BaseException(errmsg)

            LOGGER.debug('now %s lab status is: %s, %s', masterBE.id, masterBEStatus, masterDBAccess)
            LOGGER.debug('now %s lab status is: %s, %s', slaveBE.id, slaveBEStatus, slaveDBAccess)
            LOGGER.debug('Do switchover on Lab %s', targetLab.id)
            self.setState(targetLab, 'SWITCHOVER', None)
            if duration is not None:
                LOGGER.debug('Check DB status on Lab %s and %s', masterBE.id, slaveBE.id)
                LOGGER.debug('%s: %s: assert Operator Status has been changed', masterBE.id, slaveBE.id)
                CommonAssert.timedAssert(duration, 5, self._assertEqual, masterBE, stateMap[masterBEStatus],
                                         msgs.DDM_OPERATOR_STATUS_NOK)
                CommonAssert.timedAssert(duration, 5, self._assertEqual, slaveBE, stateMap[slaveBEStatus],
                                         msgs.DDM_OPERATOR_STATUS_NOK)

                LOGGER.debug('%s: %s: assert Global Status is in right status', masterBE.id, slaveBE.id)
                CommonAssert.timedAssert(duration, 5, self._assertTrue, masterBE,
                                         'Global Status', 'secured', msgs.DDM_GLOBAL_STATUS_NOK)
                CommonAssert.timedAssert(duration, 5, self._assertTrue, slaveBE,
                                         'Global Status', 'secured', msgs.DDM_GLOBAL_STATUS_NOK)

                LOGGER.debug('%s: %s: assert DB access has been changed', masterBE.id, slaveBE.id)
                CommonAssert.timedAssert(duration, 5, self._assertTrue, masterBE,
                                         'DB access', stateMap[masterDBAccess], msgs.DDM_GLOBAL_STATUS_NOK)
                CommonAssert.timedAssert(duration, 5, self._assertTrue, slaveBE,
                                         'DB access', stateMap[slaveDBAccess], msgs.DDM_GLOBAL_STATUS_NOK)

    def killNDB(self, lab, station, timeOut=DDM_DB_SYNCHRO_TIMEOUT, interval=DDM_DB_INTERVAL_CHECK):
        """@verbatim kill ndb state on a specified station.

        No return value for the method and raise exception if error.

        The method will kill ndb process on a specified station. If the duration and interval are None,
        do not check the the ndb state.
        If duration are given by default or any seconds, it will check whether the ndb can be recover
        success or not until duration timeout. If fail, raise an exception.

        the ndb process name on hp bono and rouzic are difference.
        HP and BONO: /usr/mysql/bin/ndbmtd
        ROUZIC: /usr/mysql/bin/ndbd

        for timeOut, In requirement, different hardware has different value.
        HP and BONO: 110mn   Rouzic: 61mn
        Here default value is 110mn

        @endverbatim

        @param lab: the Lab object
        @param station: the rcs-hostname of the station, eg: 0-0-2
        @param timeOut: seconds to wait state change end and verification (default 6600 seconds)
        @param interval: seconds, the interval to check ndb state

        @verbatim
        import SshManager, DatabaseManager

        dm = DatabaseManager(SshManager())
        1) dm.killNDB(lab, '0-0-2')
        2) dm.killNDB(lab, '0-0-2', 300, 5)
        3) dm.killNDB(lab, '0-0-2', None, None)
        @endverbatim
        """
        processName = "/usr/mysql/bin/ndb"
        pidList = self._linuxProcessManager.getPidbyPS(lab, processName, station)
        LOGGER.debug('%s: %s: the old pid of ndb process is %s', lab.id, station, str(pidList))

        LOGGER.debug('%s: %s: kill process: %s', lab.id, station, str(pidList))
        self._linuxProcessManager.killProcessbyPid(lab, pidList, station)

        LOGGER.debug('sleep some time to make sure the ndb state changed')
        time.sleep(60)
        if timeOut:
            try:
                LOGGER.debug('%s: %s: wait ndb started, timeout is %s', lab.id, station, str(timeOut))
                CommonAssert.timedAssert(timeOut, interval, self._dbState.assertNdbState, \
                                        lab, 'started', station, 'debug')
            except:
                msg = lab.id + ": " + station + " : ndb cannot be started"
                LOGGER.error(msg)
                raise DatabaseManagerError, msg
            pidListAfter = self._linuxProcessManager.getPidbyPS(lab, processName, station)
            LOGGER.debug('Lab %s: the new pid of ndb process is %s', lab.id, str(pidListAfter))
            LOGGER.debug('Lab %s: compare the new pid %s with the old pid  %s', lab.id, str(pidListAfter), str(pidList))
            for pid in pidListAfter:
                try:
                    errorMsg = lab.id + ": " + processName + ": new pid same with the old pid"
                    CommonAssert.assertNotIn(pid, pidList, errorMsg)
                except:
                    msg = "the new pid " + str(pid) + " is the same with the old pid"
                    LOGGER.error(msg)
                    raise DatabaseManagerError, msg

    def loadNodes(self, lab, station=None):
        '''
        this function is to load node state
        command '/usr/dhafw/tools/fw llsta'
        @param lab: the Lab object
        @param station: the rcs-hostname of the station

        @verbatim
        DSM = DatabaseManager(...)
        DSM.loadNodes(lab, '0-0-13')
        example output:
        0-0-13:{'nodes_ids': '',
        'mCAS_state': 'Online',
        'patches': '',
        'rcs_hostname': '0-0-13',
        'boot_group': '2',
        'DDM_hostname': 'STATION_G',
        'server_module': 'AGRHPR,DDM',
        'server_role': 'MAS',
        'mCAS_version': 'MCAS 3.2.13',
        'DDM_state': 'active',
        'DDM_version': 'r90.00.15.01-07.el6'}
        @endverbatim
        '''
        allNodeInfoDict = dict()
        LOGGER.debug("%s: start to load nodes ", lab.id)
        cmd = "/usr/dhafw/tools/fw llsta"
        LOGGER.debug("%s: /usr/dhafw/tools/fw llsta ", lab.id)
        [cmdStatus, nodeInfoOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not cmdStatus:
            LOGGER.debug("%s: load nodes success", lab.id)
            nodeInfoOut = [line.strip() for line in nodeInfoOutput.split(os.linesep) if re.search('0-0-', line)]
            for line in nodeInfoOut:
                nodeInfoDict = dict()
                values = re.sub(", ", ",", line).split() + ["", "", ""]
                nodeInfoDict['rcs_hostname'] = values[0]
                nodeInfoDict['DDM_hostname'] = values[1]
                nodeInfoDict['boot_group'] = values[2]
                nodeInfoDict['mCAS_state'] = values[3]
                nodeInfoDict['DDM_state'] = values[4]
                if values[5] == "MCAS":
                    nodeInfoDict['mCAS_version'] = values[5] + " " + values[6]
                    nodeInfoDict['DDM_version'] = values[7]
                    nodeInfoDict['server_role'] = values[8]
                    nodeInfoDict['server_module'] = values[9]
                    nodeInfoDict['nodes_ids'] = values[10]
                    nodeInfoDict['patches'] = values[11]
                else:
                    nodeInfoDict['mCAS_version'] = values[5]
                    nodeInfoDict['DDM_version'] = values[6]
                    nodeInfoDict['server_role'] = values[7]
                    nodeInfoDict['server_module'] = values[8]
                    nodeInfoDict['nodes_ids'] = values[9]
                    nodeInfoDict['patches'] = values[10]
                allNodeInfoDict[values[0]] = nodeInfoDict
            LOGGER.debug("%s: all node information is %s", lab.id, pprint.pformat(\
                allNodeInfoDict, width=1))
        else:
            errorMsg = lab.id + ": " + msgs.LOAD_NODES_FAIL
            LOGGER.error(errorMsg)
            raise DatabaseManagerError, errorMsg
        if station:
            LOGGER.debug("%s: %s:  %s", lab.id, station, str(allNodeInfoDict[station]))
            return allNodeInfoDict[station]
        else:
            LOGGER.debug("%s:  %s", lab.id, str(allNodeInfoDict))
            return allNodeInfoDict

    def _assertEqual(self, lab, status, msg=None):
        """Private assert
        """
        if not msg:
            msg = lab.id + ": lab status is not " + status
        CommonAssert.assertEqual(self._dbState.getState(lab), status, msg, 'debug')

    def _assertTrue(self, lab, key, matchedString, msg=None):
        """Private assert
        """
        if not msg:
            msg = lab.id + ": " + key + " is not " + matchedString
        targetStr = self._dbState.getState(lab, key)
        CommonAssert.assertTrue(targetStr.endswith(matchedString), msg, 'debug')  # pylint: disable=no-member

    def _runShellCmd(self, lab, cmd, rc=False, debugLog=True):
        """Run remote shell command and return stdout or return code

        @param lab  one Lab object
        @param cmd  the command to be executed on remote lab.
        @param rc  return return code if it is True, or return stdout
        @param debugLog  indicate whether print debug log
        """
        if debugLog:
            LOGGER.debug('Lab %s - Remote command: %s', lab.id, cmd)
        response = self.sshManager.run(lab.oamIpAddress, cmd)
        if debugLog:
            LOGGER.debug('Lab %s - Remote response (rc): %s', lab.id, response[0])
            LOGGER.debug('Lab %s - Remote response (stdout): %s', lab.id, response[1])
        return response[0] if rc else response[1]

    def setHalfClusterBE(self, lab, parity=0):
        '''
        this function is to set half cluster

        @param lab: a Lab object
        @param parity: Can be used to choose which half-cluster will be restarted
        by default even MySQLNodeId are rebooted

        @verbatim
        SHC = SetHalfCluster(...)
        DSM.setHalfClusterBE(labList)
            if success, return ok; otherwise, raise an exception
        @endverbatim
        '''
        LOGGER.debug(str(lab.id) + " will be half restarted")
        table = lab.stations.keys()
        sshMngr = SshManager()
        subshlManager = SubshlManager(sshMngr)
        multiTasksManager = MultiTasksManager()#Added for embedded multitasking

        mCASMachineManager = MCASMachineManager(sshMngr, subshlManager, multiTasksManager)
        for element in table:
            if lab.stations[element].mysqlNodeID :
                if (int(lab.stations[element].mysqlNodeID) + parity) % 2 == 0 :
                    LOGGER.debug(str(lab.stations[element].ddmHostname) + " is being restarted")
                    mCASMachineManager.stationfwRestartNonPilot(lab, lab.stations[element].rcsHostname)
                else :
                    LOGGER.debug(str(lab.stations[element].ddmHostname) + " will not be restarted")
            else :
                LOGGER.debug(str(lab.stations[element].ddmHostname) + " will not be restarted")

    def getHalfClusterList(self, lab, parity=0):
        '''
        this function is to get half cluster station List

        @param lab: a Lab object
        @param parity: Can be used to choose which half-cluster will be return
        by default the station with even MySQLNodeId will be return
        @return: List, eg: ['0-0-2', '0-0-3', '0-0-4']

        @verbatim
        SHC = getHalfClusterList(...)
        DSM.getHalfClusterList(lab)
        if success, return the station list; otherwise, raise an exception
        @endverbatim
        '''
        table = lab.stations.keys()
        stationList = []
        for element in table:
            mySQLNodeID = lab.stations[element].mysqlNodeID
            if mySQLNodeID :
                if (int(mySQLNodeID) + parity) % 2 == 0 :
                    stationList.append(lab.stations[element].rcsHostname)
        if not stationList:
            msg = msgs.GET_HALF_CLUSTER_STATION_LIST_FAILED
            LOGGER.error(msg)
            raise DatabaseManagerError, msg
        return stationList
