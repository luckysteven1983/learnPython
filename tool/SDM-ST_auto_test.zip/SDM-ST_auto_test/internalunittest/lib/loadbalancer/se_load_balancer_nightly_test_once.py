'''
Created on Aug 3, 2015

@author: xzhao015
'''
import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
logger = Logger.getLogger(__name__)

class se_load_balancer_manager_nightly_test_once(SDMTestCase):

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        logger.info("Load Balancer Manager Nightly Test")
        _, self.lab = self.testEnv.testBed.getFrontends().popitem()
        self.seloadbalancerManager=self.sdmManager.seloadbalancerManager

    def tearDown(self):
        pass

    def test_1_getCurlOutput_success(self):
        logger.info('test_1_getCurlOutput_success')
        if self.lab.hardware == 'ROUZIC':
            command="curl 0-0-7-SWITCH:5000/se/lb/list"
            output = self.seloadbalancerManager.getCurlOutput(self.lab, command)
            self.assertNotEqual(output, None)
        else:
            logger.debug("lab hardware is " + self.lab.hardware + " skip this UT")

    def test_2_getActiveLB_success(self):
        logger.info('test_2_getActiveLB_success')
        if self.lab.hardware == 'ROUZIC':
            activeMalban = self.seloadbalancerManager.getActiveLB(self.lab)
            self.assertIn(activeMalban, ['0-0-7', '0-0-8'])
        else:
            logger.debug("lab hardware is " + self.lab.hardware + " skip this UT")

    def test_3_restartLBProcess_success(self):
        logger.info('test_3_restartLBProcess_success')
        if self.lab.hardware == 'ROUZIC':
            self.seloadbalancerManager.restartLBProcess(self.lab)
        else:
            logger.debug("lab hardware is " + self.lab.hardware + " skip this UT")

    def test_4_restartLBProcess_fail(self):
        logger.info('test_4_restartLBProcess_fail')
        if self.lab.hardware == 'ROUZIC':
            self.assertRaises(BaseException, self.seloadbalancerManager.restartLBProcess, self.lab, processName='ABCD')
            self.assertRaises(BaseException, self.seloadbalancerManager.restartLBProcess, self.lab, '0-0-2')
        else:
            logger.debug("lab hardware is " + self.lab.hardware + " skip this UT")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_1_restartProcess_pilot_success']
    unittest.main()
