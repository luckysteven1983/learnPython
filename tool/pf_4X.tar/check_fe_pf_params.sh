#!/bin/bash
SDM_VERSION=`ls -lrt /sn/sps/*|grep ":$"|grep SDM|sed -n 's/://p'`
OAM_VERSION=`ls -lrt /sn/sps/*|grep ":$"|grep OAM|sed -n 's/://p'`

echo "$SDM_VERSION/bin/data/pdlsipf_generic.cfg" > fe_performance_param.xls
for param in IXS_N_ELEMENT IXS_N_PAGE IXS_N_PAGE_SIZE IXS_MAX_KEY_SIZE
do 
   grep $param  $SDM_VERSION/bin/data/pdlsipf_generic.cfg |grep -v "#" >>fe_performance_param.xls
done


echo "$SDM_VERSION/bin/data/pdlslpf_generic.cfg" >> fe_performance_param.xls
for param in IXS_N_ELEMENT IXS_N_PAGE IXS_N_PAGE_SIZE IXS_MAX_KEY_SIZE
do 
   grep $param  $SDM_VERSION/bin/data/pdlslpf_generic.cfg |grep -v "#">>fe_performance_param.xls
done

echo "$SDM_VERSION/bin/data/pdlsupf_generic.cfg" >> fe_performance_param.xls
for param in IXS_N_ELEMENT IXS_N_PAGE IXS_N_PAGE_SIZE IXS_MAX_KEY_SIZE
do 
   grep $param  $SDM_VERSION/bin/data/pdlsupf_generic.cfg |grep -v "#" >>fe_performance_param.xls
done

echo "$OAM_VERSION/bin/HSS/data/oam_sdmhss_pf_generic.cfg" >> fe_performance_param.xls
for param in IXS_N_ELEMENT IXS_N_PAGE IXS_N_PAGE_SIZE IXS_MAX_KEY_SIZE
do 
    grep $param $OAM_VERSION/bin/HSS/data/oam_sdmhss_pf_generic.cfg |grep -v "#">>fe_performance_param.xls
done

echo "$OAM_VERSION/bin/COMM/data/oam_common_pf_generic.cfg" >> fe_performance_param.xls
for param in IXS_N_ELEMENT IXS_N_PAGE IXS_N_PAGE_SIZE IXS_MAX_KEY_SIZE
do 
    grep $param $OAM_VERSION/bin/COMM/data/oam_common_pf_generic.cfg |grep -v "#" >> fe_performance_param.xls
done

echo "$SDM_VERSION/bin/data/pdlsupf_generic.cfg" >> fe_performance_param.xls  
echo G2_USABLE_RTDMSE_THREAD_NUMBER_QUEUE_0 >> HLR_G2
echo G2_USABLE_RTDMSE_THREAD_NUMBER_QUEUE_1 >> HLR_G2
echo HIGH_LEVEL_TA_QUEUE >> HLR_G2
echo LOW_LEVEL_TA_QUEUE >> HLR_G2
echo G2_MAX_USABLE_CPA >> HLR_G2
echo MAX_CPA_PER_TA >> HLR_G2
echo G2_MAX_USABLE_CTXDIAL >> HLR_G2
echo G2_MAX_WAITING_RTDMSE0_JOB >> HLR_G2
echo G2_MAX_WAITING_RTDMSE1_JOB >> HLR_G2
echo MAX_RTDMSE_ACTIVITIES >> HLR_G2
echo HIGH_LEVEL_CPA >> HLR_G2
echo LOW_LEVEL_CPA >> HLR_G2
echo SS7_END_CONGESTION_THRESHOLD >> HLR_G2
echo SS7_BEGIN_CONGESTION_THRESHOLD >> HLR_G2
echo HIGH_LOAD_CPA >> HLR_G2
echo LOW_USSD_CPA >> HLR_G2
echo HIGH_USSD_CPA >> HLR_G2 
echo LOW_LOAD_CPA >> HLR_G2
echo G3_LENGTH_OF_USABLE_SSN6_QUE >> HLR_G2

for param in `cat HLR_G2|awk '{print $1}'` 
do   
  grep $param $SDM_VERSION/bin/data/pdlsupf_generic.cfg  > /dev/null
  if [ $? -eq 0 ]; then
     grep -w $param $SDM_VERSION/bin/data/pdlsupf_generic.cfg|grep -v "#" |awk -F"=" '{ print "'"$param"'" "\t" $2}' >> fe_performance_param.xls 
  else
     echo -e "$param\t Not Exists" >> fe_performance_param.xls 
  fi
done
rm HLR_G2

echo "$SDM_VERSION/bin/data/pdlsipf_generic.cfg" >> HSS_G2 
echo HIGH_LOAD_AO >> HSS_G2                          
echo G2_USABLE_GDMI_TRANSACTION_NUMBER >> HSS_G2      
echo G2_USABLE_DBCOME_THREAD_NUMBER >> HSS_G2         
echo G2_USABLE_DBCOMEHI_THREAD_NUMBER >> HSS_G2       
echo G2_LENGTH_OF_USABLE_DBCOME_QUE       >> HSS_G2 
echo G2_LENGTH_OF_USABLE_DBCOMEHI_QUE     >> HSS_G2 
echo G2_LENGTH_OF_USABLE_PDLSI_QUE         >> HSS_G2 
echo G2_USABLE_OUTGOING_AO_NUMBER          >> HSS_G2 
echo G3_LENGTH_OF_USABLE_DIAM_QUE >> HSS_G2 

for param in `cat HSS_G2|awk '{print $1}'`
do
  grep $param $SDM_VERSION/bin/data/pdlsipf_generic.cfg > /dev/null
  if [ $? -eq 0 ]; then
     grep -w $param $SDM_VERSION/bin/data/pdlsipf_generic.cfg|awk -F"=" '{ print "'"$param"'" "\t" $2}' |grep -v "#" >> fe_performance_param.xls
  else
     echo -e "$param\t Not Exists" >> fe_performance_param.xls
  fi
done
rm HSS_G2

echo "$SDM_VERSION/bin/data/pdlslpf_generic.cfg" >> LTE_G2
echo HIGH_LOAD_AO >> LTE_G2                       
echo G2_USABLE_GDMI_TRANSACTION_NUMBER  >> LTE_G2 
echo G2_USABLE_DBCOME_THREAD_NUMBER     >> LTE_G2 
echo G2_USABLE_DBCOMEHI_THREAD_NUMBER   >> LTE_G2 
echo G2_LENGTH_OF_USABLE_DBCOME_QUE     >> LTE_G2 
echo G2_LENGTH_OF_USABLE_DBCOMEHI_QUE   >> LTE_G2
echo G2_LENGTH_OF_USABLE_PDLSL_QUE      >> LTE_G2 
echo G2_USABLE_OUTGOING_AO_NUMBER       >> LTE_G2 
echo G3_LENGTH_OF_USABLE_DIAM_QUE       >> LTE_G2

for  param in `cat LTE_G2|awk '{print $1}'`
do
  grep $param $SDM_VERSION/bin/data/pdlslpf_generic.cfg > /dev/null
  if [ $? -eq 0 ]; then
     grep -w $param $SDM_VERSION/bin/data/pdlslpf_generic.cfg|awk -F"=" '{ print "'"$param"'" "\t" $2}' | grep -v "#" >> fe_performance_param.xls
  else
     echo -e "$param\t Not Exists" >> fe_performance_param.xls
  fi
done

rm LTE_G2

echo "TCP parameters" >> fe_performance_param.xls
for sta in 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16
do
   ping -c 1 0-0-$sta > /dev/null
   if [ $? -eq 0 ]; then
     rsh 0-0-$sta 'sysctl -a | grep net | grep mem | grep core | grep -v opt'
   fi
   echo "=====0-0-$sta====="
done >> fe_performance_param.xls

