"""
Created on May 28, 2015

@author: Xia Zhao
"""

from itertools import chain
import os
import pprint
import re

from framework.asserts.common_asserts import CommonAssert
from framework.testenv.frontend import Frontend
import lib.exceptions_messages as Emsgs
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)

class DatabaseTopologyManagerError(BaseException):
    """If error, raise it."""
    pass

class DatabaseTopologyManager(object):
    """
    classdocs
    """

    def __init__(self, sshManager):
        """
        Constructor
        """
        self.sshManager = sshManager

    def getTopology(self, lab):
        """
        this function is to get topology
        command '/usr/dhafw/bin/mppread'
        @param lab: the Lab object

        @verbatim
        result = getTopology(lab)
        return: dictionary, key value is NRGkey, type of key value is int

        get NRG1 'NRG Access': result[1]['NRG Access']
        get NRG1 BE1 'Access': result[1][1]['Access']

        example:
        {1:
        {'FrontEnd Isolated': 'NO',
        'FrontEnd Identification': '135.252.194.129',
        'NRGkey': '1',
        'NRG Access': 'OK_RW'
        'FrontEnd Software Version Number': '2', },
        1:
        {'BackEnd Audit': 'OK',
        'Software Version Number': '2',
        'Access': 'OK_RW',
        'Consolidate Access': 'OK_RW',
        'Database Audit': 'OK',
        'StaleStatus': 'No',
        'BackEnd Id': '1',
        'Host Name or Ip Address': '192.168.226.20',
        'Connection Port': '15777'},
        'FrontEnd Software Version Number': '2',
        2:
        {'BackEnd Audit': 'OK',
        'Software Version Number': '2',
        'Access': 'OK_RO',
        'Consolidate Access': 'OK_RO',
        'Database Audit': 'OK',
        'StaleStatus': 'No',
        'BackEnd Id': '2',
        'Host Name or Ip Address': '192.168.228.20',
        'Connection Port': '15777'}},
        2:
        {'FrontEnd Isolated': 'NO',
        'FrontEnd Identification': '135.252.194.129',
        'NRGkey': '2',
        'NRG Access': 'KO_MAINTENANCE'
        'FrontEnd Software Version Number': '2',
        1: {'BackEnd Audit': 'OK',
        'Software Version Number': '2',
        'Access': 'KO_MAINTENANCE',
        'Consolidate Access': 'KO_MAINTENANCE',
        'Database Audit': 'Not Running',
        'StaleStatus': 'No',
        'BackEnd Id': '1',
        'Host Name or Ip Address': '192.168.201.20',
        'Connection Port': '15777'},
        2: {'BackEnd Audit': 'OK',
        'Software Version Number': '2',
        'Access': 'KO_MAINTENANCE',
        'Consolidate Access': 'KO_MAINTENANCE',
        'Database Audit': 'Not Running',
        'StaleStatus': 'No',
        'BackEnd Id': '2',
        'Host Name or Ip Address': '192.168.213.20',
        'Connection Port': '15777'}}}
        @endverbatim
        """
        CommonAssert.assertIsInstance(lab.productRole, Frontend, Emsgs.DO_NOT_SUPPORT_LAB_TYPE)
        LOGGER.debug(str(lab.id) + ": start to get topology")
        cmd = "/usr/dhafw/bin/mppread"
        LOGGER.debug("command is: %s", cmd)
        [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, cmd)
        if cmdStatus:
            errorMsg = lab.id + ": " + Emsgs.GET_TOPOLOGY_FAIL
            LOGGER.error(errorMsg)
            raise DatabaseTopologyManagerError, errorMsg
        topology = dict()
        nrginfo = dict()
        beinfo = dict()
        LOGGER.debug(str(lab.id) + ": " + cmd + ": " + stateOutput)
        LOGGER.debug(str(lab.id) + ": Get topology success")
        nrgInfoPattern = re.compile('(NRGkey|NRG Access|FrontEnd Identification' + \
        '|FrontEnd Software Version Number|FrontEnd Isolated)')
        beInfoPattern = re.compile('(Host Name or Ip Address|Connection Port' + \
        '|Consolidate Access|Access|BackEnd Audit|Database Audit|Software Version Number|StaleStatus)')
        for line in stateOutput.split(os.linesep):
            found = re.search(nrgInfoPattern, line)
            if found:
                valueInfo = line.split("=")[1].strip()
                keyInfo = line.split("=")[0].strip()
                if keyInfo == 'NRGkey':
                    nrginfo = dict()
                    topology[int(valueInfo)] = nrginfo
                nrginfo[keyInfo] = valueInfo
                continue
            found = re.search('BackEnd Id', line)
            if found:
                beinfo = dict()
                beid = line.split(" ")[2].strip()
                beinfo['BackEnd Id'] = beid
                nrginfo[int(beid)] = beinfo
                continue
            found = re.search(beInfoPattern, line)
            if found:
                beinfo[line.split("=")[0].strip()] = line.split("=")[1].strip()
                continue
        LOGGER.debug("%s: Topology is: %s", lab.id, pprint.pformat(topology, width=1))
        return topology

    def getNRGListFromFE(self, lab, mppreadInfo=None):
        """
        this function is to get nrg number
        @param lab: the Lab object (front-end)
        @param mppreadInfo: the information got from getTopology

        @verbatim
        nrgNumber, nrgList = getNRGListFromFE(lab)
        return: NRG number, List of NRGs
        @endverbatim
        """
        CommonAssert.assertIsInstance(lab.productRole, Frontend, Emsgs.DO_NOT_SUPPORT_LAB_TYPE)
        LOGGER.debug(str(lab.id) + ": try to get the nrg number")
        if not mppreadInfo:
            mppreadInfo = self.getTopology(lab)
        nrgList = mppreadInfo.keys()
        LOGGER.debug("%s: nrg list is: %s", lab.id, str(nrgList))
        nrgNumber = len(nrgList)
        LOGGER.debug("%s: nrg number is: %s", lab.id, str(nrgNumber))
        return nrgNumber, nrgList

    def getNRGBEListFromFE(self, lab, nrgKey, mppreadInfo=None):
        """
        this function is to get be number of one nrg
        @param lab: the Lab object (front-end)
        @param nrgKey: int or string
        @param mppreadInfo: the information got from getTopology

        @verbatim
        beNumber = getNRGBEListFromFENumber(lab, 1)
        return: BE number, List of BEs
        @endverbatim
        """
        CommonAssert.assertIsInstance(lab.productRole, Frontend, Emsgs.DO_NOT_SUPPORT_LAB_TYPE)
        LOGGER.debug(str(lab.id) + ": try to get the be number in nrgKey")
        nrgKey = int(nrgKey)
        if not mppreadInfo:
            mppreadInfo = self.getTopology(lab)
        beList = [keyIndex for keyIndex in mppreadInfo[nrgKey].keys() if isinstance(keyIndex, int)]
        LOGGER.debug("%s: nrg%s: BE List is %s", lab.id, nrgKey, str(beList))
        beNumber = len(beList)
        LOGGER.debug("%s: nrg%s: BE number is %s", lab.id, nrgKey, str(beNumber))
        return beNumber, beList

    def checkTopology(self, testBed, logLevel='error'):
        """
        this function is to check the topology status
        If there is KO_MAINTENANCE and the NDB ip address is a real lab IP, exception raised
        or we should These BEs are "Fakes one" used to complete NRG when missing real Hardware.
        So they must be ignored for checking

        @param testBed    the TestBed object
        @param logLevel    log level

        @verbatim
        checkTopology(testBed)
        @endverbatim
        """
        errordetailMsg = ""
        # Need to check the topo from each FE
        for lab in testBed.getFrontends().values():
            LOGGER.debug("%s: try check the topology status", lab.id)
            mppreadInfo = self.getTopology(lab)
            # Check each nrg seen from this FE
            for nrgIndex in self.getNRGListFromFE(lab, mppreadInfo)[1]:
                LOGGER.debug("%s: try to check NRG%s status", lab.id, nrgIndex)
                tmpNDB = (be.productRole.ndbAddress for be in testBed.getLabsInNRG(str(nrgIndex)))
                NdbAddresses = list(chain.from_iterable(tmpNDB))
                LOGGER.debug("ndb address: %s", str(NdbAddresses))
                # Check each BE from this nrg
                for beIndex in self.getNRGBEListFromFE(lab, nrgIndex, mppreadInfo)[1]:
                    ndbAddress = mppreadInfo[nrgIndex][beIndex]['Host Name or Ip Address']
                    if ndbAddress not in NdbAddresses:
                        LOGGER.debug("Ignore BE: %s, IP: %s", str(beIndex), ndbAddress)
                        continue
                    errorMsg = lab.id + ": nrg" + str(nrgIndex) + ": BE" + str(beIndex)\
                     + ": Consolidate Access is KO_MAINTENANCE"
                    try:
                        CommonAssert.assertNotEqual('KO_MAINTENANCE', \
                                                mppreadInfo[nrgIndex][beIndex]['Consolidate Access'], errorMsg, logLevel)
                    except BaseException:
                        errordetailMsg = errordetailMsg + lab.id + ": <nrg:" + str(nrgIndex) + " BE:" + str(beIndex)\
                         + ' - ' + ndbAddress + "> Consolidate Access is in KO_MAINTENANCE state - "
                        LOGGER.error("%s: nrg%s: BE%s: Consolidate Access is KO_MAINTENANCE", \
                                     lab.id, nrgIndex, beIndex)
                    errorMsg = lab.id + ": nrg" + str(nrgIndex) + ": BE" + str(beIndex) + ": Access is KO_MAINTENANCE"
                    try:
                        CommonAssert.assertNotEqual('KO_MAINTENANCE', \
                                                    mppreadInfo[nrgIndex][beIndex]['Access'], errorMsg, logLevel)
                    except BaseException:
                        errordetailMsg = errordetailMsg + lab.id + ": <nrg:" + str(nrgIndex) + " BE:" + str(beIndex)\
                         + ' - ' + ndbAddress + ":Access is in KO_MAINTENANCE state - "
                        LOGGER.error("%s: nrg%s: BE%s: Access is KO_MAINTENANCE", \
                                     lab.id, nrgIndex, beIndex)
            if not errordetailMsg:
                LOGGER.debug("%s: topology status OK", lab.id)
            else:
                errorMsg = lab.id + ": " + Emsgs.TOPOLOGY_STATE_NOK + " - " + errordetailMsg
                LOGGER.error(errorMsg)
                raise DatabaseTopologyManagerError, errorMsg
