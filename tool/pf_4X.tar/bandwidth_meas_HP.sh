#!/bin/bash

function bwFilter { 
gawk '
$0 ~ /Incoming    Outgoing      Ierr/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}

# including switches configuration file
currentpath=$(cd "$(dirname "$0")"; pwd)
echo $currentpath
. $currentpath/bandwidth_meas.conf

file=`ls -lrt meas*|tail -1|awk '{print $9}'`
cmd="paste"
cat $file | bwFilter > bandwidth.txt
if [ "$1" = "FE" ]; then
    column=0
    # script must be modified (#columns) if TSWITCHFEHP size is over 6 elements)
    for elem in ${TSWITCHFEHP[*]}
    do
      type=$elem;
      if [ `cat bandwidth.txt | grep $type | wc -l` -gt 0 ]; then
         cat bandwidth.txt | grep $type | grep 0-0-1- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > ${type}.1
         cat bandwidth.txt | grep $type | grep 0-0-2- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > ${type}.2
         paste ${type}.1 ${type}.2 > ${type}.tmp
         cat ${type}.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "'"${type}"'" , $2+$7,$3+$8,$4+$9,$5+$10}' > ${type}.txt
         rm ${type}.1 ${type}.2 ${type}.tmp
         cmd=`echo $cmd " " ${type}.txt`
         let column++
      fi
     done
     exec $cmd > total.tmp &
     sleep 1
     if [ $column -eq 1 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2,$3,$4,$5}' > total.txt
     elif [ $column -eq 2 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7,$3+$8,$4+$9,$5+$10}' > total.txt
     elif [ $column -eq 3 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7+$12,$3+$8+$13,$4+$9+$14,$5+$10+$15}' > total.txt
     elif [ $column -eq 4 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7+$12+$17,$3+$8+$13+$18,$4+$9+$14+$19,$5+$10+$15+$20}' > total.txt
     elif [ $column -eq 5 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7+$12+$17+$22,$3+$8+$13+$18+$23,$4+$9+$14+$19+$24,$5+$10+$15+$20+$25}' > total.txt
     elif [ $column -eq 6 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7+$12+$17+$22+$27,$3+$8+$13+$18+$23+$28,$4+$9+$14+$19+$24+$29,$5+$10+$15+$20+$25+$30}' > total.txt
     fi
     rm  total.tmp

     echo -e "Type\tAvg(In)\tMax(In)\tAvg(Out)\tMAX(Out)" > bandwidth.result

     for elem in ${!TSWITCHFEHP[*]} total
     do
         key=${elem};
         if [ "$key" = "total" ]
         then
            file="total";
         else
            file=${TSWITCHFEHP[${elem}]};
         fi 
         awk 'BEGIN { maxIn=0; maxOut=0;} { if ($2 > maxIn) maxIn=$2; if  ($3 > maxOut) maxOut=$3; sumIn+=$2; sumOut+=$3; num++; next; } END { printf "%s\t%.2f\t%.2f\t%.2f\t%.2f\n", "'"$key"'", sumIn/num/1024, maxIn/1024,sumOut/num/1024,maxOut/1024}' ${file}.txt >> bandwidth.result
         rm ${file}.txt
    done
else
   column=0
   for type in ${TSWITCHBEHP[*]}
    do
      if [ `cat bandwidth.txt | grep $type | wc -l` -gt 0 ]; then
         cat bandwidth.txt | grep $type | grep 0-0-1- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > ${type}.1
         cat bandwidth.txt | grep $type | grep 0-0-2- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > ${type}.2
         paste ${type}.1 ${type}.2 > ${type}.tmp
         cat ${type}.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "'"${type}"'" , $2+$7,$3+$8,$4+$9,$5+$10}' > ${type}.txt
         rm ${type}.1 ${type}.2 ${type}.tmp
#         paste total.tmp  ${type}.txt > total
#         mv total total.tmp
         cmd=`echo $cmd " " ${type}.txt`
         let column++
      fi
     done
      exec $cmd > total.tmp &
      sleep 1
     if [ $column -eq 1 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2,$3,$4,$5}' > total.txt
     elif [ $column -eq 2 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7,$3+$8,$4+$9,$5+$10}' > total.txt
     elif [ $column -eq 3 ]; then
        cat  total.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "Total", $2+$7+$12,$3+$8+$13,$4+$9+$14,$5+$10+$15}' > total.txt
     fi
     rm  total.tmp

     echo -e "Type\tAvg(In)\tMax(In)\tAvg(Out)\tMAX(Out)" > bandwidth.result
     for elem in ${!TSWITCHBEHP[*]} total
     do
         key=${elem};
         if [ "$key" = "total" ]
         then
            file="total";
         else
            file=${TSWITCHBEHP[${elem}]};
         fi 
         awk 'BEGIN { maxIn=0; maxOut=0;} { if ($2 > maxIn) maxIn=$2; if  ($3 > maxOut) maxOut=$3; sumIn+=$2; sumOut+=$3; num++; next; } END { printf "%s\t%.2f\t%.2f\t%.2f\t%.2f\n", "'"$key"'", sumIn/num/1024, maxIn/1024,sumOut/num/1024,maxOut/1024}' ${file}.txt >> bandwidth.result
         rm ${file}.txt
    done
fi
rm bandwidth.txt
