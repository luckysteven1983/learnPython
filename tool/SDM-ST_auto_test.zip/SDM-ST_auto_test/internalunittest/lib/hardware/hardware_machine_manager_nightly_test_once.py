'''

Created on Jun 11, 2015

@author: S Beaufils

Modified Jul 22, 2015
Tangi Lavanant (VMMHI support)

Restart a random board of lab(s). Random board is chosen in non-pilot boards

'''
import random
import unittest
import sys
from framework.sdm_test_case import SDMTestCase
from lib.hardware.atcav2_hardware_machine_manager import AtcaV2HardwareMachineManager
from lib.hardware.hardware_machine_manager import HardwareMachineManager, HardwareMachineManagerError, StateHW
from lib.hardware.hp_hardware_machine_manager import HpHardwareMachineManager
from lib.hardware.vmmhi_hardware_machine_manager import VmmhiHardwareMachineManager
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class hardware_machine_manager_nightly_test_once(SDMTestCase):
    '''
    test_once for restart board function
    '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.hostFE = self.testEnv.testBed.getFrontends().popitem()
        self.hostBE = self.testEnv.testBed.getBackends()
        self.lab = self.hostFE

    def test_GetBoardStatus(self):
        '''
        Get the status of a board
        We suppose the board is powered on
        '''
        LOGGER.info("Get the status of a board")
        npMach = self.sdmManager.mcasMachineManager.getMachinesList(self.hostFE)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        LOGGER.info(' Get status of board ' + boardN + ' on ' + self.hostFE.id)

        sshmngr = SshManager()

        # --- creates the instance according to the hardware
        if self.lab.hardware in ['ROUZIC', 'BONO24', 'BONO48']:
            hardwareManager = AtcaV2HardwareMachineManager(sshmngr)
            _output = hardwareManager.getHardwareState(self.hostFE, boardN)
        elif self.lab.hardware in ['HPG6', 'HPG8']:
            hardwareManager = HpHardwareMachineManager(sshmngr)
            _output = hardwareManager.getHardwareState(self.hostFE, boardN)
        elif self.lab.hardware in ['VMMHI']:
            hardwareManager = VmmhiHardwareMachineManager(sshmngr)
            _output = hardwareManager.getHardwareState(self.hostFE, boardN)
        else:
            sys.exit('unknown hardware type : ' + self.hostFE.hardware)

        _msg = ("Board " + boardN + " on " + self.hostFE.id + " is  not powered on")
        CommonAssert.assertEqual(_output, StateHW.BOARD_POWERED_ON, _msg, 'error')
        LOGGER.info("Board " + boardN + " on " + self.hostFE.id + " is powered on")

    def test_GetBoardStatusRAW(self):
        '''
        Get the status of a board in RAW mode
        Result depends on Hardware
        '''
        LOGGER.info("Get the status of a board")
        npMach = self.sdmManager.mcasMachineManager.getMachinesList(self.hostFE)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        LOGGER.info(' Get status of board ' + boardN + ' on ' + self.hostFE.id)

        sshmngr = SshManager()

        # --- creates the instance according to the hardware
        if self.lab.hardware in ['ROUZIC', 'BONO24', 'BONO48']:
            hardwareManager = AtcaV2HardwareMachineManager(sshmngr)
            _output = hardwareManager.getHardwareStateRAW(self.hostFE, boardN)
        elif self.lab.hardware in ['HPG6', 'HPG8']:
            hardwareManager = HpHardwareMachineManager(sshmngr)
            _output = hardwareManager.getHardwareStateRAW(self.hostFE, boardN)
        elif self.lab.hardware in ['VMMHI']:
            hardwareManager = VmmhiHardwareMachineManager(sshmngr)
            _output = hardwareManager.getHardwareStateRAW(self.hostFE, boardN)
        else:
            sys.exit('unknown hardware type : ' + self.hostFE.hardware)
        LOGGER.info("Board " + boardN + " on " + self.hostFE.id + " RAW status is : " + _output)

    def test_vmmhiList(self):
        '''
        list vmmhi boards
        '''
        if self.lab.hardware == 'VMMHI':
            LOGGER.info("Specific test for VMMHI")
            sshmngr = SshManager()
            hardwareManager = VmmhiHardwareMachineManager(sshmngr)
            output = hardwareManager.vmmhiStatus(self.lab)
            LOGGER.debug(output)
        else:
            LOGGER.info("Specific test for VMMHI, not performed on " + self.lab.hardware)

    def test_implementationError(self):
        '''
        restart a random  non-pilot board of self.lab
        '''
        npMach = self.sdmManager.mcasMachineManager.getMachinesNonPilot(self.lab)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        LOGGER.info(' >>>> restarting board ' + boardN + ' on ' + self.lab.id + ' with ImplementationError')

        sshmngr = SshManager()

        # --- creates the instance of the super class
        hardwareManager = HardwareMachineManager(sshmngr)

        # try to execute the restart board . Which will cause an exception :
        try:
            hardwareManager.restartBoard(self.lab, boardN)
        except NotImplementedError as exc:
            LOGGER.error("Expected Error : " + exc.message)


    def test_boardNumberError(self):
        '''
        restart a non existent board
        '''
        # npMach = self.sdmManager.mcasMachineManager.getMachinesNonPilot(self.lab)
        # --- choose the second one of the list : random
        boardN = '44'
        LOGGER.info(' >>>> restarting board ' + boardN + ' on ' + self.lab.id + ' with wrong board number ')

        sshmngr = SshManager()

        # --- creates the instance of the super class
        if self.lab.hardware in ['ROUZIC', 'BONO24', 'BONO48']:
            hardwareManager = AtcaV2HardwareMachineManager(sshmngr)
        elif self.lab.hardware in ['HPG6', 'HPG8']:
            hardwareManager = HpHardwareMachineManager(sshmngr)
        elif self.lab.hardware in ['VMMHI']:
            hardwareManager = VmmhiHardwareMachineManager(sshmngr)
        else:
            sys.exit('unknown hardware type : ' + self.lab.hardware)

        # try to execute the restart board . Which will cause an exception :
        try:
            hardwareManager.restartBoard(self.lab, boardN)
        except HardwareMachineManagerError as exc:
            LOGGER.error(" Error : " + exc.message)

    def test_restart_active_pilot(self):
        """Restart active pilot on ATCA
        """
        LOGGER.info("Test restarting active pilot")
        activePilot = self.sdmManager.mcasMachineManager.getActivePilot(self.lab)
        LOGGER.debug("Active pilot %s", activePilot)
        if self.lab.hardware in ['ROUZIC', 'BONO24', 'BONO48']:
            hardwareManager = AtcaV2HardwareMachineManager(self.sdmManager.sshManager)
            hardwareManager.restartBoard(self.lab, activePilot.split('-')[-1])
        else:
            LOGGER.warning("Only Support to restart active pilot on ATCA lab now")

    def tearDown(self):
        """Lab Recovery"""
        # recover lab in case of the lab is broken by test case.
        LOGGER.info('Recover lab if necessary')
        self.sdmManager.labRecover.machineRecover(self.lab)

if __name__ == "__main__":

    unittest.main()
