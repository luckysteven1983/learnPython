"""
@file
@ingroup SDMSQA Automation
@author Claude Le du
@date 2015-02-25
@brief Unit test for AlarmsChecker class
"""

import unittest

from lib.alarm.alarm import Alarm
from lib.alarm.alarms_config import AlarmsConfig
from lib.alarm.alarms_checker import AlarmsChecker
from lib.alarm.alarms_checker import AlarmsCheckerError
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from framework.sdm_test_case import SDMTestCase
from framework.common import Utils
import time

LOGGER = Logger.getLogger(__name__)
LOGFILE = ("log/begining_active_alarms_for_UT.csv", "log/during_case_alarms_for_UT.csv",
           "log/end_active_alarms_for_UT.csv")

class alarms_checker_nightly_test_once(SDMTestCase):
    """ Unit test for AlarmsChecker class  """

    def setUp(self):
        self.mySnmpLogFiles = ["internalunittest/lib/alarm/resources/snmplog0",
                               "internalunittest/lib/alarm/resources/snmplog1",
                               "internalunittest/lib/alarm/resources/snmplog2",
                               "internalunittest/lib/alarm/resources/snmplog3",
                               "internalunittest/lib/alarm/resources/snmplog4",
                               "internalunittest/lib/alarm/resources/snmplog5",
                               "internalunittest/lib/alarm/resources/snmplog6",
                               "internalunittest/lib/alarm/resources/snmplog7",
                               "internalunittest/lib/alarm/resources/snmplog8",
                               "internalunittest/lib/alarm/resources/snmplog9"]
        self.myAlarmsChecker = AlarmsChecker(SshManager(), [])

        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_1_allAlarmsExpected(self):
        """ All alarms in snmplog files are expected """

        LOGGER.info("\n1. All alarms in snmplog files are expected\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")
        alarm0c = Alarm(alarmCode=0, severity="Cleared")
        alarm00 = Alarm(alarmCode=0, severity="Critical")
        alarm416 = Alarm(alarmCode=416, severity="Minor")
        alarm416c = Alarm(alarmCode=416, severity="Cleared")
        alarm417 = Alarm(alarmCode=417, severity="Critical")
        alarm417c = Alarm(alarmCode=417, severity="Cleared")
        alarm418c = Alarm(alarmCode=418, severity="Cleared")
        alarm430 = Alarm(alarmCode=430, severity="Major")
        alarm430c = Alarm(alarmCode=430, severity="Cleared")
        alarm431 = Alarm(alarmCode=431, severity="Critical")
        alarm431c = Alarm(alarmCode=431, severity="Cleared")
        alarm10109 = Alarm(alarmCode=10109, severity="Major")
        alarm10109c = Alarm(alarmCode=10109, severity="Cleared")
        alarm10726 = Alarm(alarmCode=10726, severity="Major")
        alarm10726c = Alarm(alarmCode=10726, severity="Cleared")
        alarm906065 = Alarm(alarmCode=906065, severity="Minor")
        alarm906065c = Alarm(alarmCode=906065, severity="Cleared")
        alarm916103 = Alarm(alarmCode=916103, severity="Major")
        alarm916103c = Alarm(alarmCode=916103, severity="Cleared")
        alarm917206 = Alarm(alarmCode=917206, severity="Critical")
        alarm917206c = Alarm(alarmCode=917206, severity="Cleared")
        alarm951201 = Alarm(alarmCode=951201, severity="Major")
        alarm951201c = Alarm(alarmCode=951201, severity="Cleared")
        alarm954001 = Alarm(alarmCode=954001, severity="Major")
        alarm954001c = Alarm(alarmCode=954001, severity="Cleared")
        alarm954003 = Alarm(alarmCode=954003, severity="Critical")
        alarm954003c = Alarm(alarmCode=954003, severity="Cleared")
        alarm999999 = Alarm(alarmCode=999999, severity="Major")
        alarm999999c = Alarm(alarmCode=999999, severity="Cleared")

        expectedAlarms = [alarm0, alarm0c, alarm00, alarm416, alarm416c, alarm417, alarm417c,
                          alarm418c, alarm430, alarm430c, alarm431, alarm431c, alarm10109,
                          alarm10109c, alarm10726, alarm10726c, alarm906065, alarm906065c,
                          alarm916103, alarm916103c, alarm917206, alarm917206c, alarm951201,
                          alarm951201c, alarm954001, alarm954001c, alarm954003, alarm954003c,
                          alarm999999, alarm999999c]
        acceptedAlarms = []
        startingDate = "2015-02-05 12:05:32"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.myAlarmsChecker.parseSnmpLogFiles(myAlarmsConfig=myAlarmsConfig,
                                               mySnmpLogFiles=self.mySnmpLogFiles,
                                               failureMode=AlarmsChecker.NORMAL)

    def test_2_allAlarmsExpectedOrAccepted(self):
        """ All alarms in snmplog files are either expected or accepted """

        LOGGER.info("\n2. All alarms in snmplog files are either expected or accepted\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")
        alarm0c = Alarm(alarmCode=0, severity="Cleared")
        alarm00 = Alarm(alarmCode=0, severity="Critical")
        alarm416 = Alarm(alarmCode=416, severity="Minor")
        alarm416c = Alarm(alarmCode=416, severity="Cleared")
        alarm417 = Alarm(alarmCode=417, severity="Critical")
        alarm417c = Alarm(alarmCode=417, severity="Cleared")
        alarm418c = Alarm(alarmCode=418, severity="Cleared")
        alarm430 = Alarm(alarmCode=430, severity="Major")
        alarm430c = Alarm(alarmCode=430, severity="Cleared")
        alarm431 = Alarm(alarmCode=431, severity="Critical")
        alarm431c = Alarm(alarmCode=431, severity="Cleared")
        alarm10109 = Alarm(alarmCode=10109, severity="Major")
        alarm10109c = Alarm(alarmCode=10109, severity="Cleared")
        alarm10726 = Alarm(alarmCode=10726, severity="Major")
        alarm10726c = Alarm(alarmCode=10726, severity="Cleared")
        alarm906065 = Alarm(alarmCode=906065, severity="Minor")
        alarm906065c = Alarm(alarmCode=906065, severity="Cleared")
        alarm916103 = Alarm(alarmCode=916103, severity="Major")
        alarm916103c = Alarm(alarmCode=916103, severity="Cleared")
        alarm917206 = Alarm(alarmCode=917206, severity="Critical")
        alarm917206c = Alarm(alarmCode=917206, severity="Cleared")
        alarm951201 = Alarm(alarmCode=951201, severity="Major")
        alarm951201c = Alarm(alarmCode=951201, severity="Cleared")
        alarm954001 = Alarm(alarmCode=954001, severity="Major")
        alarm954001c = Alarm(alarmCode=954001, severity="Cleared")
        alarm954003 = Alarm(alarmCode=954003, severity="Critical")
        alarm954003c = Alarm(alarmCode=954003, severity="Cleared")
        alarm999999 = Alarm(alarmCode=999999, severity="Major")
        alarm999999c = Alarm(alarmCode=999999, severity="Cleared")

        expectedAlarms = [alarm0, alarm0c, alarm00, alarm416, alarm416c, alarm417, alarm417c,
                          alarm418c, alarm430, alarm430c, alarm431, alarm431c, alarm10109,
                          alarm10109c, alarm10726, alarm10726c, alarm906065, alarm906065c,
                          alarm916103, alarm916103c, alarm917206, alarm917206c]
        acceptedAlarms = [alarm951201, alarm951201c, alarm954001, alarm954001c, alarm954003,
                          alarm954003c, alarm999999, alarm999999c]

        startingDate = "2015-02-05 12:05:32"
        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.myAlarmsChecker.parseSnmpLogFiles(myAlarmsConfig=myAlarmsConfig,
                                               mySnmpLogFiles=self.mySnmpLogFiles,
                                               failureMode=AlarmsChecker.NORMAL)
    def test_3_allAlarmsExpectedAnd2AcceptedNotPresent(self):
        """ All alarms in snmplog files are expected + 2 accepted alarms not present """

        LOGGER.info("\n3. All alarms in log files are expected + 2 accepted alarms not present\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")
        alarm0c = Alarm(alarmCode=0, severity="Cleared")
        alarm00 = Alarm(alarmCode=0, severity="Critical")
        alarm416 = Alarm(alarmCode=416, severity="Minor")
        alarm416c = Alarm(alarmCode=416, severity="Cleared")
        alarm417 = Alarm(alarmCode=417, severity="Critical")
        alarm417c = Alarm(alarmCode=417, severity="Cleared")
        alarm418c = Alarm(alarmCode=418, severity="Cleared")
        alarm430 = Alarm(alarmCode=430, severity="Major")
        alarm430c = Alarm(alarmCode=430, severity="Cleared")
        alarm431 = Alarm(alarmCode=431, severity="Critical")
        alarm431c = Alarm(alarmCode=431, severity="Cleared")
        alarm10109 = Alarm(alarmCode=10109, severity="Major")
        alarm10109c = Alarm(alarmCode=10109, severity="Cleared")
        alarm10726 = Alarm(alarmCode=10726, severity="Major")
        alarm10726c = Alarm(alarmCode=10726, severity="Cleared")
        alarm906065 = Alarm(alarmCode=906065, severity="Minor")
        alarm906065c = Alarm(alarmCode=906065, severity="Cleared")
        alarm916103 = Alarm(alarmCode=916103, severity="Major")
        alarm916103c = Alarm(alarmCode=916103, severity="Cleared")
        alarm917206 = Alarm(alarmCode=917206, severity="Critical")
        alarm917206c = Alarm(alarmCode=917206, severity="Cleared")
        alarm951201 = Alarm(alarmCode=951201, severity="Major")
        alarm951201c = Alarm(alarmCode=951201, severity="Cleared")
        alarm954001 = Alarm(alarmCode=954001, severity="Major")
        alarm954001c = Alarm(alarmCode=954001, severity="Cleared")
        alarm954003 = Alarm(alarmCode=954003, severity="Critical")
        alarm954003c = Alarm(alarmCode=954003, severity="Cleared")
        alarm999999 = Alarm(alarmCode=999999, severity="Major")
        alarm999999c = Alarm(alarmCode=999999, severity="Cleared")
        alarm999 = Alarm(alarmCode=999, severity="Minor")
        alarm9999 = Alarm(alarmCode=9999, severity="Minor")

        expectedAlarms = [alarm0, alarm0c, alarm00, alarm416, alarm416c, alarm417, alarm417c,
                          alarm418c, alarm430, alarm430c, alarm431, alarm431c, alarm10109,
                          alarm10109c, alarm10726, alarm10726c, alarm906065, alarm906065c,
                          alarm916103, alarm916103c, alarm917206, alarm917206c, alarm951201,
                          alarm951201c, alarm954001, alarm954001c, alarm954003, alarm954003c,
                          alarm999999, alarm999999c]
        acceptedAlarms = [alarm999, alarm9999]
        startingDate = "2015-02-05 12:05:32"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.myAlarmsChecker.parseSnmpLogFiles(myAlarmsConfig=myAlarmsConfig,
                                               mySnmpLogFiles=self.mySnmpLogFiles,
                                               failureMode=AlarmsChecker.NORMAL)

    def test_4_2UnexpectedAlarmsAnd2AcceptedNotFound(self):
        """ 2 unexpected alarms + 2 accepted not found"""

        LOGGER.info("\n4. Two unexpected alarms + 2 accepted not found\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")
        alarm0c = Alarm(alarmCode=0, severity="Cleared")
        alarm00 = Alarm(alarmCode=0, severity="Critical")
        alarm416 = Alarm(alarmCode=416, severity="Minor")
        alarm416c = Alarm(alarmCode=416, severity="Cleared")
        alarm417 = Alarm(alarmCode=417, severity="Critical")
        alarm417c = Alarm(alarmCode=417, severity="Cleared")
        alarm418c = Alarm(alarmCode=418, severity="Cleared")
        alarm430 = Alarm(alarmCode=430, severity="Major")
        alarm430c = Alarm(alarmCode=430, severity="Cleared")
        alarm431 = Alarm(alarmCode=431, severity="Critical")
        alarm431c = Alarm(alarmCode=431, severity="Cleared")
        alarm10109 = Alarm(alarmCode=10109, severity="Major")
        alarm10109c = Alarm(alarmCode=10109, severity="Cleared")
        alarm10726 = Alarm(alarmCode=10726, severity="Major")
        alarm10726c = Alarm(alarmCode=10726, severity="Cleared")
        alarm906065 = Alarm(alarmCode=906065, severity="Minor")
        alarm906065c = Alarm(alarmCode=906065, severity="Cleared")
        alarm916103 = Alarm(alarmCode=916103, severity="Major")
        alarm916103c = Alarm(alarmCode=916103, severity="Cleared")
        alarm917206 = Alarm(alarmCode=917206, severity="Critical")
        alarm917206c = Alarm(alarmCode=917206, severity="Cleared")
        alarm951201 = Alarm(alarmCode=951201, severity="Major")
        alarm951201c = Alarm(alarmCode=951201, severity="Cleared")
        alarm954001 = Alarm(alarmCode=954001, severity="Major")
        alarm954001c = Alarm(alarmCode=954001, severity="Cleared")
        alarm954003 = Alarm(alarmCode=954003, severity="Critical")
        alarm954003c = Alarm(alarmCode=954003, severity="Cleared")
        alarm999 = Alarm(alarmCode=999, severity="Minor")
        alarm9999 = Alarm(alarmCode=9999, severity="Minor")

        expectedAlarms = [alarm0, alarm0c, alarm00, alarm416, alarm416c, alarm417, alarm417c,
                          alarm418c, alarm430, alarm430c, alarm431, alarm431c, alarm10109,
                          alarm10109c, alarm10726, alarm10726c, alarm906065, alarm906065c,
                          alarm916103, alarm916103c, alarm917206, alarm917206c, alarm951201,
                          alarm951201c, alarm954001, alarm954001c, alarm954003, alarm954003c]
        acceptedAlarms = [alarm999, alarm9999]
        startingDate = "2015-02-05 12:05:32"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.assertRaisesRegexp(AlarmsCheckerError, msgs.ALARM_UNEXPECTED_ALARM,
                                self.myAlarmsChecker.parseSnmpLogFiles,
                                myAlarmsConfig=myAlarmsConfig, mySnmpLogFiles=self.mySnmpLogFiles,
                                failureMode=AlarmsChecker.NORMAL)

    def test_5_1ExpectedAlarmNotFound(self):
        """ 1 expected alarm not found """

        LOGGER.info("\n5. One expected alarm not found\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")
        alarm0c = Alarm(alarmCode=0, severity="Cleared")
        alarm00 = Alarm(alarmCode=0, severity="Critical")
        alarm416 = Alarm(alarmCode=416, severity="Minor")
        alarm416c = Alarm(alarmCode=416, severity="Cleared")
        alarm417 = Alarm(alarmCode=417, severity="Critical")
        alarm417c = Alarm(alarmCode=417, severity="Cleared")
        alarm418c = Alarm(alarmCode=418, severity="Cleared")
        alarm430 = Alarm(alarmCode=430, severity="Major")
        alarm430c = Alarm(alarmCode=430, severity="Cleared")
        alarm431 = Alarm(alarmCode=431, severity="Critical")
        alarm431c = Alarm(alarmCode=431, severity="Cleared")
        alarm10109 = Alarm(alarmCode=10109, severity="Major")
        alarm10109c = Alarm(alarmCode=10109, severity="Cleared")
        alarm10726 = Alarm(alarmCode=10726, severity="Major")
        alarm10726c = Alarm(alarmCode=10726, severity="Cleared")
        alarm906065 = Alarm(alarmCode=906065, severity="Minor")
        alarm906065c = Alarm(alarmCode=906065, severity="Cleared")
        alarm916103 = Alarm(alarmCode=916103, severity="Major")
        alarm916103c = Alarm(alarmCode=916103, severity="Cleared")
        alarm917206 = Alarm(alarmCode=917206, severity="Critical")
        alarm917206c = Alarm(alarmCode=917206, severity="Cleared")
        alarm951201 = Alarm(alarmCode=951201, severity="Major")
        alarm951201c = Alarm(alarmCode=951201, severity="Cleared")
        alarm954001 = Alarm(alarmCode=954001, severity="Major")
        alarm954001c = Alarm(alarmCode=954001, severity="Cleared")
        alarm954003 = Alarm(alarmCode=954003, severity="Critical")
        alarm954003c = Alarm(alarmCode=954003, severity="Cleared")
        alarm999999 = Alarm(alarmCode=999999, severity="Major")
        alarm999999c = Alarm(alarmCode=999999, severity="Cleared")
        alarm999 = Alarm(alarmCode=999, severity="Minor")

        expectedAlarms = [alarm0, alarm0c, alarm00, alarm416, alarm416c, alarm417, alarm417c,
                          alarm418c, alarm430, alarm430c, alarm431, alarm431c, alarm10109,
                          alarm10109c, alarm10726, alarm10726c, alarm906065, alarm906065c,
                          alarm916103, alarm916103c, alarm917206, alarm917206c, alarm951201,
                          alarm951201c, alarm954001, alarm954001c, alarm954003, alarm954003c,
                          alarm999]
        acceptedAlarms = [alarm999999, alarm999999c]
        startingDate = "2015-02-05 12:05:32"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.assertRaisesRegexp(AlarmsCheckerError, msgs.ALARM_EXPECTED_ALARM_NOT_FOUND,
                                self.myAlarmsChecker.parseSnmpLogFiles,
                                myAlarmsConfig=myAlarmsConfig,
                                mySnmpLogFiles=self.mySnmpLogFiles,
                                failureMode=AlarmsChecker.NORMAL)

    def test_6_StartingDateAfterLastSnmplogfileDate(self):
        """ Starting date after last snmplog file date """

        LOGGER.info("\n6. Starting date after last snmplog file date\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")

        expectedAlarms = [alarm0]
        acceptedAlarms = []
        startingDate = "2016-02-05 12:05:32"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.assertRaisesRegexp(AlarmsCheckerError, msgs.ALARM_EXPECTED_ALARM_NOT_FOUND,
                                self.myAlarmsChecker.parseSnmpLogFiles,
                                myAlarmsConfig=myAlarmsConfig,
                                mySnmpLogFiles=self.mySnmpLogFiles,
                                failureMode=AlarmsChecker.NORMAL)

    def test_7_EndingDateBeforeStartingDate(self):
        """ Ending date before starting date """

        LOGGER.info("\n7. Ending date before starting date\n")

        alarm0 = Alarm(alarmCode=0, severity="Major")

        expectedAlarms = [alarm0]
        acceptedAlarms = []
        startingDate = "2015-02-05 12:05:32"
        endingDate = "2015-02-04 12:07:51"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate, endingDate=endingDate)
        self.assertRaisesRegexp(AlarmsCheckerError, msgs.ALARM_STARTING_DATE_AFTER_ENDING_DATE,
                                self.myAlarmsChecker.parseSnmpLogFiles,
                                myAlarmsConfig=myAlarmsConfig,
                                mySnmpLogFiles=self.mySnmpLogFiles,
                                failureMode=AlarmsChecker.NORMAL)

    def test_8_SnmplogFileDoesNotExist(self):
        """ snmplog file does not exist """

        LOGGER.info("\n8. snmplog file does not exist\n")

        self.mySnmpLogFiles = ["resources/snmplogxx"]

        alarm0 = Alarm(alarmCode=0, severity="Major")

        expectedAlarms = [alarm0]
        acceptedAlarms = []
        startingDate = "2015-02-05 12:05:32"

        myAlarmsConfig = AlarmsConfig(expectedAlarms=expectedAlarms, acceptedAlarms=acceptedAlarms,
                                      startingDate=startingDate)
        self.assertRaisesRegexp(AlarmsCheckerError, msgs.ALARM_FILE_NOT_FOUND,
                                self.myAlarmsChecker.parseSnmpLogFiles,
                                myAlarmsConfig=myAlarmsConfig,
                                mySnmpLogFiles=self.mySnmpLogFiles,
                                failureMode=AlarmsChecker.NORMAL)

    def test_alarm_management_update(self):
        """This test case will do

        1. save active alarm into log/begining_active_alarms_for_UT.csv before test case
        2. save alarms in snmplog files during test case into log/during_case_alarms_for_UT.csv
        3. save active alarm into log/end_active_alarms_for_UT.csv after test case
        """
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self._preCheck()
        LOGGER.info("This is only for alarm update verifycation")
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        self._runCase(startTime)
        self._postCheck(startTime)

    def _preCheck(self):
        """Test case precheck and save current active alarms to csv file"""
        LOGGER.info("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runCase(self, startTime):
        """Run test case (only check snmp log)"""
        LOGGER.info("Expected alarms found so no exception\n")

        # Clear the given alarm in case the alarm can't be raised due to existence
        alarmPar = {"alarmAPI": "/cs/sn/utest/alarm/genalarm",
                    "alarmText": "Generate a specify alarm for alarm lib UT test",
                    "nodeId": "0-0-1",
                    "alarmLevel": "CL",
                    "alarmMsg": "Alarm for UT test",
                    "objName": "Snmp Alarm Manager",
                    "alarmCode": "99999",
                    "probableCause": "7",
                    "alarmSource": "BATCH",
                    "specificProblem": "Raise alarm for UT test",
                    "alarmType": "3"}
        alarmCmd = "%(alarmAPI)s \
                    -a '%(alarmText)s' \
                    -i '%(nodeId)s' \
                    -l '%(alarmLevel)s' \
                    -m '%(alarmMsg)s' \
                    -n '%(objName)s' \
                    -o '%(alarmCode)s' \
                    -p '%(probableCause)s' \
                    -r '%(alarmSource)s' \
                    -s '%(specificProblem)s' \
                    -t '%(alarmType)s'" %alarmPar

        LOGGER.debug("Clear Command:\n%s", alarmCmd)
        rc, stdout = self.sdmManager.sshManager.run(self.allBEs[0].oamIpAddress, alarmCmd)
        # return code is non-0
        if rc:
            raise Exception("Clear Alarm Error:\n%s" %stdout)

        # Generate Alarm
        alarmPar["alarmLevel"] = "CR"
        alarmCmd = "%(alarmAPI)s \
                    -a '%(alarmText)s' \
                    -i '%(nodeId)s' \
                    -l '%(alarmLevel)s' \
                    -m '%(alarmMsg)s' \
                    -n '%(objName)s' \
                    -o '%(alarmCode)s' \
                    -p '%(probableCause)s' \
                    -r '%(alarmSource)s' \
                    -s '%(specificProblem)s' \
                    -t '%(alarmType)s'" %alarmPar

        # Expected alarm not found
        alarms = [Alarm(alarmCode=int(alarmPar["alarmCode"]), severity='Critical')]
        mode = self.sdmManager.alarmsCheckerManager.__class__.EXPECTED_NOT_FOUND
        myAlarmsConfig = AlarmsConfig(expectedAlarms=alarms, startingDate=startTime)
        self.assertRaisesRegexp(AlarmsCheckerError, msgs.ALARM_EXPECTED_ALARM_NOT_FOUND,
                                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles,
                                myAlarmsConfig=myAlarmsConfig,
                                lab=self.allBEs[0],
                                logFile=LOGFILE[1],
                                failureMode=mode)
        # Raise alarm
        LOGGER.debug("Raise Alarm :\n%s", alarmCmd)
        rc, stdout = self.sdmManager.sshManager.run(self.allBEs[0].oamIpAddress, alarmCmd)
        # return code is non-0
        if rc:
            raise Exception("Generate Alarm Error:\n%s" %stdout)
        time.sleep(5)
        # Check alarm again and no expected alarms so from the console will only see a warning
        # message
        LOGGER.info("should have a warning here")
        myAlarmsConfig = AlarmsConfig(expectedAlarms=[], startingDate=startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(myAlarmsConfig=myAlarmsConfig,
                                                               lab=self.allBEs[0],
                                                               logFile=LOGFILE[1],
                                                               failureMode=mode)
        # Check alarm again and expected alarm is found
        myAlarmsConfig = AlarmsConfig(expectedAlarms=alarms, startingDate=startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(myAlarmsConfig=myAlarmsConfig,
                                                               lab=self.allBEs[0],
                                                               logFile=LOGFILE[1],
                                                               failureMode=mode)
        # Clear the raised alarm
        alarmPar["alarmLevel"] = "CL"
        alarmCmd = "%(alarmAPI)s \
                    -a '%(alarmText)s' \
                    -i '%(nodeId)s' \
                    -l '%(alarmLevel)s' \
                    -m '%(alarmMsg)s' \
                    -n '%(objName)s' \
                    -o '%(alarmCode)s' \
                    -p '%(probableCause)s' \
                    -r '%(alarmSource)s' \
                    -s '%(specificProblem)s' \
                    -t '%(alarmType)s'" %alarmPar
        LOGGER.debug("Clear Command:\n%s", alarmCmd)
        rc, stdout = self.sdmManager.sshManager.run(self.allBEs[0].oamIpAddress, alarmCmd)
        # return code is non-0
        if rc:
            raise Exception("Clear Alarm Error:\n%s" %stdout)

    def _postCheck(self, startTime):
        """Test case postcheck"""
        LOGGER.info("test case post check")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
