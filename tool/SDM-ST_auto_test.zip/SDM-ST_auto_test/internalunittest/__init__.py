'''
Created on Feb 10, 2015

@author: yohann
'''
"""
This folder contains internal unit tests
"""
