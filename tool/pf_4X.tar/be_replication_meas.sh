#!/bin/bash

file=`ls -lrt meas*|tail -1|awk '{print $9}'`
echo Time > time.txt
grep -A 1 -w  DDM_REPLICATION_MEAS $file|grep -v DDM_REPLICATION_MEAS|grep -v "\-\-"|awk -F ";" '{ print $1 }' | awk -F "," '{ print $2 "/" $3}'|awk -F "/" '{ print $3 "-" $1 "-" $2 "-" $4}' >> time.txt
grep -A 2 -w  LATENCY_SLAVE_REP_0  $file|grep -v "\-\-"|head -1 |awk '{print $1 "\t" $2 "\t" $3}' >latency0.txt
grep -A 2 -w  LATENCY_SLAVE_REP_0  $file|grep -v "\-\-"|grep -v   LATENCY_SLAVE_REP_0|awk '{print $1 "\t" $2 "\t" $3}'   >> latency0.txt

grep -A 2 -w  LATENCY_SLAVE_REP_3  $file|grep -v "\-\-"|head -1 >latency3.txt
grep -A 2 -w  LATENCY_SLAVE_REP_3  $file|grep -v "\-\-"|grep -v   LATENCY_SLAVE_REP_3   >> latency3.txt

grep -A 2 -w  LATENCY_SLAVE_REP_4  $file|grep -v "\-\-"|head -1|awk '{print $1 "\t" $2 "\t" $3}'  >latency4.txt
grep -A 2 -w  LATENCY_SLAVE_REP_4  $file|grep -v "\-\-"|grep -v   LATENCY_SLAVE_REP_4| awk '{print $1 "\t" $2 "\t" $3}'   >> latency4.txt

grep -A 2 -w  LATENCY_SLAVE_REP_7  $file|grep -v "\-\-"|head -1 >latency7.txt
grep -A 2 -w  LATENCY_SLAVE_REP_7  $file|grep -v "\-\-"|grep -v   LATENCY_SLAVE_REP_7   >> latency7.txt

grep -A 2 -w  LATENCY_SLAVE_REP_8  $file|grep -v "\-\-"|head -1|awk '{print $1 "\t" $2 "\t" $3}'  >latency8.txt
grep -A 2 -w  LATENCY_SLAVE_REP_8  $file|grep -v "\-\-"|grep -v   LATENCY_SLAVE_REP_8|awk '{print $1 "\t" $2 "\t" $3}'   >> latency8.txt

grep -A 2 -w  LATENCY_SLAVE_REP_11 $file|grep -v "\-\-"|head -1 >latency11.txt
grep -A 2 -w  LATENCY_SLAVE_REP_11 $file|grep -v "\-\-"|grep -v   LATENCY_SLAVE_REP_1  >> latency11.txt

paste  time.txt latency0.txt latency3.txt latency4.txt latency7.txt latency8.txt latency11.txt > be_rep_meas.result 

rm time.txt  latency0.txt latency3.txt latency4.txt latency7.txt latency8.txt latency11.txt

grep -A 2 -w  BINLOG_SPEED  $file|grep -v "\-\-"|head -1 > rep1.txt
grep -A 2 -w  BINLOG_SPEED  $file|grep -v "\-\-"|grep -v  BINLOG_SPEED  >> rep1.txt

grep -A 2 -w  BINLOG_TIME_TO_FILL_SPACE $file|grep -v "\-\-"|head -1 >rep2.txt
grep -A 2 -w  BINLOG_TIME_TO_FILL_SPACE  $file|grep -v "\-\-"|grep -v  BINLOG_TIME_TO_FILL_SPACE  >> rep2.txt

grep -A 2 -w  BINLOG_SIZE_TO_REPLICATE $file|grep -v "\-\-"|head -1 >rep3.txt
grep -A 2 -w  BINLOG_SIZE_TO_REPLICATE $file|grep -v "\-\-"|grep -v BINLOG_SIZE_TO_REPLICATE >>rep3.txt

grep -A 2 -w  BINLOG_INJECTION_SIZE $file|grep -v "\-\-"|head -1 >rep4.txt
grep -A 2 -w  BINLOG_INJECTION_SIZE $file|grep -v "\-\-"| grep -v BINLOG_INJECTION_SIZE >>rep4.txt

grep -A 2 -w  logSpacePartMax  $file|grep -v "\-\-"|head -1 >rep5.txt
grep -A 2 -w  logSpacePartMax  $file|grep -v "\-\-"|grep -v logSpacePartMax  >> rep5.txt

paste rep1.txt rep2.txt rep3.txt rep4.txt rep5.txt > be_rep_meas.txt 

rm  rep1.txt rep2.txt rep3.txt rep4.txt rep5.txt

#awk 'BEGIN { print "Avg(REP_0) Avg(REP_1)  Avg(REP_2) Avg(REP_3) Avg(REP_4) Avg(REP_5) Avg(REP_6) Avg(REP_7)  Avg(REP_8) Avg(REP_9) Avg(REP_10) Avg(REP_11)" } NR==1 {next } { rep1 += $1;    rep2 += $2 ;   rep3 += $3 ;  rep4 += $4 ;  rep5 += $5  ;   rep6 += $6 ;   rep7 += $7;  rep8 += $8 ;  rep9 += $9 ;  rep10 += $10 ;  rep11 += $11 ;  rep12 += $12 ; ++num;  next } END { printf "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", rep1/num, rep2/num, rep3/num, rep4/num, rep5/num,  rep6/num,  rep7/num, rep8/num, rep9/num, rep10/num, rep11/num, rep12/num }'   latency.txt   > be_rep_meas.result

#For be_rep_meas.txt, which has 12 columes. They are:
# DATABASE_DATA  DATABASE_INDEX  BINLOG_SPEED  BINLOG_NB_INSERTS  BINLOG_NB_UPDATES  BINLOG_NB_DELETES  BINLOG_TIME_TO_FILL_SPACE
# BINLOG_SIZE_TO_REPLICATE BINLOG_INJECTION_SPEED  BINLOG_INJECTION_TIME  BINLOG_INJECTION_SIZE logSpacePartMax

#awk 'BEGIN { print "Avg(BINLOG_SPEED) Avg(BINLOG_TIME_TO_FILL_SPACE)  Avg(BINLOG_SIZE_TO_REPLICATE) Avg(BINLOG_INJECTION_SPEED) Avg(BINLOG_INJECTION_SIZE) Avg(logSpacePartMax)" } NR==1 {next } { speed += $3;  time += $7; size += $8; in_speed += $9; in_size += $11; max += $12;  ++num;  next } END { printf "%16.2f\t%22.2f\t%30.2f\t%25.2f\t%15.2f\t%15.2f\n", speed/num,time/num,size/num,in_speed/num,in_size/num, max/num}'  be_rep_meas.txt  > be_rep_binlog_meas.result

awk 'BEGIN { print "Avg(BINLOG_SPEED) Avg(BINLOG_TIME_TO_FILL_SPACE)  Avg(BINLOG_SIZE_TO_REPLICATE) Avg(BINLOG_INJECTION_SPEED) Avg(BINLOG_INJECTION_SIZE) Avg(logSpacePartMax) Avg(BINLOG_NB_INSERTS) Avg(BINLOG_NB_UPDATES) Avg(BINLOG_NB_DELETES)" } NR==1 {next } { speed += $3;  time += $7; size += $8; in_speed += $9; in_size += $11; max += $12; insert +=$4; upd += $5; del += $6;  ++num;  next } END { printf "%16.2f\t%22.2f\t%30.2f\t%25.2f\t%15.2f\t%15.2f\t%15.2f\t%15.2f\t%15.2f\n", speed/num,time/num,size/num,in_speed/num,in_size/num, max/num, insert/num, upd/num, del/num}'  be_rep_meas.txt  > be_rep_binlog_meas.result

rm be_rep_meas.txt
