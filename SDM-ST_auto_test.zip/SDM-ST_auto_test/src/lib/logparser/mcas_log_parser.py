"""
@file mcas_log_parser.py
@ingroup SDMSQA
@author Andy SUN
@brief Parse all files starting with the same prefix.

Filter all log files starting with the same prefix (example: OMlog0, OMlog1,
etc), and run the regular express on filtered result.
"""

import os
import re
import lib.exceptions_messages as eMsgs
from lib.logparser.mcas_log import MCASLog
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class McasLogParserError(BaseException):
    """If error, raise it."""
    pass

class McasLogParser(object):
    """Parse log files with the same prefix (example: OMlog0, OMlog1, etc).

    Only support normal ANSCII text files based on the following log format.

        +++ HP26 2014-12-24 21:34:34 DEBUG        #999999 0-0-1 >
        REPT ERROR LOG MSGH, FILE /n/plflR3001/SOURCE/SU4kR30.src/cc/msgh/proc/
        MHproc.C, LINE 634
        MSGH: ALL HOSTS NOT REGISTERED
        END OF REPORT #999999++-

    Simple usage:
    log = McasLogParser('/log-local-dir')
    rlist = log.lineFilter('OMlog', '*.error', 
                            '2014-10-10 21:12:11', 2014-10-10 21:15:11')
    rbool = log.lineContains('OMlog', '*.error', 
                            '2014-10-10 21:12:11', 2014-10-10 21:15:11')
    rlist = log.filter('OMlog', '*.error', 
                            '2014-10-10 21:12:11', 2014-10-10 21:15:11')
    rbool = log.contains('OMlog', '*.error', 
                            '2014-10-10 21:12:11', 2014-10-10 21:15:11')
    """

    def __init__(self, logDir):
        """Init McasLogParser instance with log file directory

        Keyword arguments:
        logDir -- the local directory which the log files are located in
        """
        if not os.path.isdir(logDir):
            LOGGER.error("%s: %s", eMsgs.LOG_DIR_NOT_FOUND, logDir)
            raise McasLogParserError, "%s: '%s'" %(eMsgs.LOG_DIR_NOT_FOUND, logDir)
        self._logDir = logDir

    def _getLogFiles(self, prefix):
        """Get log files starting with prefix.

        Keyword arguments:
        prefix -- log file name prefix
        """
        prefix = prefix.strip()
        names = [f for f in os.listdir(self._logDir) if f.startswith(prefix)]
        return [self._logDir + os.sep + name for name in names]

    def lineFilter(self, prefix, regex, bTime = '0000-00-00 00:00:00', 
                   eTime = '9999-99-99 99:99:99'):
        """Filter lines between begining and end timestamp with regular express.

        Parse all lines between begining and end timestamp in files starting
        with prefix and return a list including all lines matching regular
        express. The timestamp format is like this 'YYYY-MM-DD HH:MM:SS'. If the
        begining time is not given, it will parse from the begining of first log
        file, and if the end time is not given, it will pasre to the end of last
        log file. If both timestamps are not given, it will parse all the whole
        files.

        This method will only support regular express per line not a full log
        within a timestamp. That means if the regular express goes across
        multi-lines, maybe it will not be your expectation, for this case,
        please use filter method instead.

        Keyword arguments:
        prefix -- log file name prefix
        regex -- regular express used for filter lines between timestamps
        bTime -- begining timestamp (default '0000-00-00 00:00:00')
        eTime -- end timestamp (default '9999-99-99 99:99:99')
        """
        bTime = bTime.strip()
        eTime = eTime.strip()
        ret = []
        logFiles = self._getLogFiles(prefix)
        pattern = re.compile(regex)
        for oneLog in iter(MCASLog(logFiles, bTime, eTime)):
            # oneLog: (loghead, logcontent, logtail)
            for line in oneLog[1].split('\n'):
                line = line.strip()
                if pattern.search(line):
                    ret.append(line)
        return ret

    def filter(self, prefix, regex, bTime = '0000-00-00 00:00:00', 
                   eTime = '9999-99-99 99:99:99'):
        """Filter between begining and end timestamp with regular express.

        Basically it is the same with lineFilter method except it supports
        multi-line search in regular express. Below is the different between
        both.

        For example, the log is like below.

            +++ HP26 2014-12-24 21:34:34 DEBUG        #999999 0-0-1 >
            Here is the mult-line log
            the first log is here
            the second log is here
            END OF REPORT #999999++-

        For the lineFilter method, the regular express will take action on each
        log line such as 'Here is the mult-line log', 'the first log is here',
        and 'the second log is here'. But for filter method, the regular express
        will only take action on the whole log content, so it can support
        multi-line search. That will be useful for log including multi-lines
        within a timestamp.

        Keyword arguments:
        prefix -- log file name prefix
        regex -- regular express used for filter between timestamps
        bTime -- begining timestamp (default '0000-00-00 00:00:00')
        eTime -- end timestamp (default '9999-99-99 99:99:99')
        """
        bTime = bTime.strip()
        eTime = eTime.strip()
        ret = []
        logFiles = self._getLogFiles(prefix)
        pattern = re.compile(regex, re.DOTALL)
        for oneLog in iter(MCASLog(logFiles, bTime, eTime)):
            # oneLog: (loghead, logcontent, logtail)
            content = oneLog[1]
            if pattern.search(content):
                ret.append(content)
        return ret

    def lineContains(self, prefix, regex, bTime = '0000-00-00 00:00:00', 
                     eTime = '9999-99-99 99:99:99'):
        """Filter lines between starttime and endtime with regular express.

        Parse all lines between begining and end timestamp in files starting
        with prefix and return true if any line matchs regular express, or
        return false.  The timestamp format is like this 'YYYY-MM-DD HH:MM:SS'.
        If the begining time is not given, it will parse from the begining of
        first log file, and if the end time is not given, it will pasre to the
        end of log file. If both timestamps are not given, it will parse all the
        whole log files.

        This method will only support regular express per line not a full log
        within a timestamp. That means if the regular express goes across
        multi-lines, maybe it will not be your expecation, for this case, please
        use contains method instead.

        Keyword arguments:
        prefix -- log file name prefix
        regex -- regular express used for filter lines between timestamps
        bTime -- begining timestamp (default '0000-00-00 00:00:00')
        eTime -- end timestamp (default '9999-99-99 99:99:99')
        """
        bTime = bTime.strip()
        eTime = eTime.strip()
        logFiles = self._getLogFiles(prefix)
        pattern = re.compile(regex)
        for oneLog in iter(MCASLog(logFiles, bTime, eTime)):
            # oneLog: (loghead, logcontent, logtail)
            for line in oneLog[1].split('\n'):
                if pattern.search(line.strip()):
                    return True
        return False

    def contains(self, prefix, regex, bTime = '0000-00-00 00:00:00', 
                   eTime = '9999-99-99 99:99:99'):
        """Filter between begining and end timestamp with regular express.

        Basically it is the same with lineContains method except it supports
        multi-line search in regular express. Below is the different between
        both.

        For example, the log is like below.

            +++ HP26 2014-12-24 21:34:34 DEBUG        #999999 0-0-1 >
            Here is the mult-line log
            the first log is here
            the second log is here
            END OF REPORT #999999++-

        For the lineContains method, the regular express will take action on
        each log line such as 'Here is the mult-line log', 'the first log is
        here', and 'the second log is here'. But for contains method, the
        regular express will only take action on the whole log content, so it
        can support multi-line search. That will be useful for log including
        multi-lines within a timestamp.

        Keyword arguments:
        prefix -- log file name prefix
        regex -- regular express used for filter between timestamps
        bTime -- begining timestamp (default '0000-00-00 00:00:00')
        eTime -- end timestamp (default '9999-99-99 99:99:99')
        """
        bTime = bTime.strip()
        eTime = eTime.strip()
        logFiles = self._getLogFiles(prefix)
        pattern = re.compile(regex, re.DOTALL)
        for oneLog in iter(MCASLog(logFiles, bTime, eTime)):
            # oneLog: (loghead, logcontent, logtail)
            if pattern.search(oneLog[1]):
                return True
        return False
