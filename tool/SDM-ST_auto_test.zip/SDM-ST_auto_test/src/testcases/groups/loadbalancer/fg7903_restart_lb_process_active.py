'''
Created on Sep 1, 2015

@author: xzhao015
'''
import random
import os
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fg7903_restart_lb_process_active(SDMTestCase):
    '''test Restart LB process on active LB board '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsBE = []
        self.acceptedAlarmsBE = []
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.fe = random.choice(self.allFEs)
        self.success = True
        self.exceptMsg = str()

    def test_restart_lb_process_active(self):
        """ Restart LB process on active LB board """
        if self.fe.hardware not in ['HPG6', 'HPG8', 'BONO24', 'BONO48', 'VMMHI']:
            LOGGER.warn("fg7903_restart_lb_process_active is only for BONO and HP")
            LOGGER.warn("skip fg7903_restart_lb_process_active")
            return
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case precheck")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("Test case post-check")
        LOGGER.debug("check the alarm")
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(self.expectedAlarmsBE, self.acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("fg7903_restart_lb_process_active success!\n")
        else:
            LOGGER.error("fg7903_restart_lb_process_active failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)

    def _runTestCase(self):
        ''' Restart LB process on active LB board '''
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)
        LOGGER.debug("Restart Load Balancer active board on FE " + self.fe.id + " at: " + startTime)

        LOGGER.debug("Get active load balancer board")
        activeLB = self.sdmManager.asrloadbalancerManager.getActiveLB(self.fe)
        LOGGER.info("Restart active load balancer process on board " + activeLB + " on " + self.fe.id)
        self.sdmManager.asrloadbalancerManager.restartLBProcess(self.fe, activeLB)
        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", self.fe.id)
        return startTime
