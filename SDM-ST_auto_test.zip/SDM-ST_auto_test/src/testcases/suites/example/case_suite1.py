'''
Created on May 15, 2015

@author: Andy SUN
'''

# Test items to be run
TEST_ITEMS = ["src/testcases/groups/example/casegroup1",
              "src/testcases/groups/example/casegroup2",
              "src/testcases/groups/example/casegroup3"]
