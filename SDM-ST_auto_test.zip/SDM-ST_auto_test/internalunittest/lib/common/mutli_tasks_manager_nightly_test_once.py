"""
@file mutli_tasks_manager_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-09-10
@brief MultiTasksManager UT
"""

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.common.multi_tasks_manager import MultiTasksManagerError
import time

LOGGER = Logger.getLogger(__name__)

class mutli_tasks_manager_nightly_test_once(SDMTestCase):
    """Unit test for MultiTasksManager class.
    """

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.info = "Verify MultiTasksManager"

    def _boolFunction(self, value=True, sleep=1):
        """Return a bool value"""
        LOGGER.debug("in _boolFunction: %s", self.info)
        time.sleep(sleep)
        return value

    def _valueFunction(self, *args, **kwargs):
        """Return a value"""
        LOGGER.debug("in _valueFunction: %s", self.info)
        returnValue = "".join([value for value in args])
        returnValue += kwargs["key1"] + kwargs["key2"]
        LOGGER.debug("_valueFunction return value: %s", returnValue)
        return returnValue

    def _exceptionFunction(self, flag=True):
        """raise exception is flag is True"""
        if flag:
            raise BaseException, self.info
        else:
            return "_exceptionFunction"

    def test_01_InvalidTaskType(self):
        """Invalid task type"""
        LOGGER.info('[Test Case 01] Invalid task type')
        self.sdmManager.multiTasksManager.register(self._boolFunction)
        fun = self.sdmManager.multiTasksManager.runMultiTasks
        self.assertRaises(MultiTasksManagerError, fun, "invalid")

    def test_02_AllTasksSuccess(self):
        """All tasks Success"""
        LOGGER.info('[Test Case 02] All tasks success')
        self.sdmManager.multiTasksManager.register(self._exceptionFunction, False)
        self.sdmManager.multiTasksManager.register(self._exceptionFunction, False)
        result = self.sdmManager.multiTasksManager.runMultiTasks()
        self.assertTrue(result)

    def test_03_SomeTasksFailures(self):
        """Some tasks Failures"""
        LOGGER.info('[Test Case 03] Some tasks failures')
        self.sdmManager.multiTasksManager.register(self._exceptionFunction)
        self.sdmManager.multiTasksManager.register(self._exceptionFunction, False)
        self.sdmManager.multiTasksManager.register(self._exceptionFunction, True)
        result = self.sdmManager.multiTasksManager.runMultiTasks()
        self.assertFalse(result)

        # Check the share information should be clean
        self.sdmManager.multiTasksManager.register(self._exceptionFunction, False)
        self.sdmManager.multiTasksManager.register(self._exceptionFunction, False)
        result = self.sdmManager.multiTasksManager.runMultiTasks()
        self.assertTrue(result)

    def test_04_CheckTaskValues(self):
        """Check Task Return Value"""
        LOGGER.info('[Test Case 04] Check tasks return values')
        tasks = self.sdmManager.multiTasksManager
        tasks.register(self._boolFunction, sleep=5)
        tasks.register(self._boolFunction, sleep=3)
        tasks.register(self._boolFunction, False)
        tasks.register(self._boolFunction, False, sleep=2)
        tasks.register(self._boolFunction, True, sleep=4)
        result = tasks.runMultiTasks(tasks.TASK_RETURN_VALUES)
        self.assertEqual(len(result), 5)
        self.assertTrue(result[0])
        self.assertTrue(result[1])
        self.assertFalse(result[2])
        self.assertFalse(result[3])
        self.assertTrue(result[4])

        tasks.register(self._valueFunction, "arg1", "arg2", key1="kwarg1", key2="kwarg2")
        tasks.register(self._valueFunction, "arg3", "arg4", key1="kwarg3", key2="kwarg4")
        tasks.register(self._valueFunction, "arg5", "arg6", key1="kwarg5", key2="kwarg6")
        result = tasks.runMultiTasks(tasks.TASK_RETURN_VALUES)
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0], "arg1arg2kwarg1kwarg2")
        self.assertEqual(result[1], "arg3arg4kwarg3kwarg4")
        self.assertEqual(result[2], "arg5arg6kwarg5kwarg6")

    def test_05_CheckTaskValuesWithException(self):
        """Check Task Return Value with exception"""
        LOGGER.info('[Test Case 05] Check tasks return values with exception')
        tasks = self.sdmManager.multiTasksManager
        tasks.register(self._exceptionFunction)
        tasks.register(self._exceptionFunction, False)
        tasks.register(self._exceptionFunction)
        tasks.register(self._exceptionFunction, True)
        tasks.register(self._exceptionFunction, False)
        result = tasks.runMultiTasks(tasks.TASK_RETURN_VALUES)
        self.assertEqual(len(result), 5)
        self.assertEqual(result[0], None)
        self.assertEqual(result[1], "_exceptionFunction")
        self.assertEqual(result[2], None)
        self.assertEqual(result[3], None)
        self.assertEqual(result[4], "_exceptionFunction")

        tasks.register(self._exceptionFunction, False)
        tasks.register(self._exceptionFunction, False)
        tasks.register(self._exceptionFunction, False)
        result = tasks.runMultiTasks(tasks.TASK_NO_RETURN)
        self.assertTrue(result)

        tasks.register(self._exceptionFunction, False)
        tasks.register(self._exceptionFunction)
        tasks.register(self._exceptionFunction, False)
        result = tasks.runMultiTasks(tasks.TASK_NO_RETURN)
        self.assertFalse(result)
