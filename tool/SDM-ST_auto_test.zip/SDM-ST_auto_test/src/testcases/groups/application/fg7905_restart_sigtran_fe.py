'''
Created on Sept 2, 2015

@author: Tangi Lavanant
weblink_id=3KJ-00117-0044-QPZZA

'''
import os
import time

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.hardware.hardware_machine_manager import HW_V8650
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fg7905_restart_sigtran_fe(SDMTestCase):
    '''
    test kill of board with sigtran processes on one FE of the testbed
    '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.success = True
        self.exceptMsg = ""
        self.allFEs = self.testEnv.testBed.getFrontends().values()

    def test_restartSS7(self):
        """
        test kill of board with sigtran processes on one FE of the testbed
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("Test case post-check")
        time.sleep(10)
        LOGGER.debug("check the alarm")
        exceptMsg = str()
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])

    def _runTestCase(self):
        ''' test restart Sigtran on 1 FE '''
        LOGGER.debug("Start to choose one FE to test this case")
        fes = self.testEnv.testBed.getFrontends()
        feID, fe = fes.popitem()  # will return one over all FEs (no order in a dictionary)
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        if fe.hardware == HW_V8650:
            LOGGER.debug("On VMMHI SS7 is located on pilot, so lets take StanbyPilot")
            if self.sdmManager.mcasMachineManager.getMatedPairState(fe, 1) == 'ACTIVE' :
                ss7Boards = '0-0-9'
            else:
                ss7Boards = '0-0-1'
        else:
            ss7Boards = fe.getStationListbyProductRole('ss7')
            ss7Board, _ = ss7Boards.popitem()
        LOGGER.info("SS7Board " + ss7Board + " will be killed on " + feID)
        try:
            self.sdmManager.mcasMachineManager.stationfwRestartNonPilot(fe, ss7Board)
        except BaseException, msg:
            self.exceptMsg += str(msg)
            self.success = False
            LOGGER.error("kill SS7 board on FE :" + ss7Board + " fail")
        else:
            LOGGER.debug("kill aSS7 board on FE :" + ss7Board + " successful")
        CommonAssert.timedAssert(3600, 30, self.sdmManager.testEnvAsserts.assertStationOK, \
                                        fe, ss7Board, logLevel='debug')

        LOGGER.info("Sigtran board on FE: " + str(feID) + " has been killed and station is up again")
        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", fe.id)
        return startTime
