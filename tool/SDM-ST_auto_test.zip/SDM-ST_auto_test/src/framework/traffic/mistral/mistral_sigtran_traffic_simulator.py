"""
@file
Created on Mar 10, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines MistralSIGTRANTrafficSimulator class
"""

from framework.traffic.sigtran_traffic_simulator import SIGTRANTrafficSimulator

class MistralSIGTRANTrafficSimulator(SIGTRANTrafficSimulator):
    """
    @details This class describes a Mistral traffic as defined in configuration.xml.
    """

    def __init__(self):
        """
        MistralSIGTRANTrafficSimulator class constructor
        """
        super(MistralSIGTRANTrafficSimulator,self).__init__()
        self.mistralIp = ""
        self.trafficProfileId = ""
