#! /usr/bin/perl -w

BEGIN { unshift @INC, "/MDS/perf_tool/lib"; }

use Spreadsheet::WriteExcel;

my @XLSCOL = qw/A B C D E F G H I J K L M N/;
my %charts;
my @headers;

if ( @ARGV < 1 ) {
	print "Usage: perl $0 dir\n";
	exit 1;
}

my $dir = $ARGV[0];
die "$dir is not a directory: $!" unless -d $dir;
die "$dir cannot be written: $!" unless -w $dir;
$_ = `ls $dir | grep txt`;
my @files = split;
print "Will Handle TXT Files: @files", "\n";

my $xlsfile = "$dir/process.xls";

eval {

my $workbook = Spreadsheet::WriteExcel->new("$xlsfile");

foreach my $txtfile (@files) {  

	# read file
	print "Now trans file: $txtfile...\n";
	my $sheetname = $txtfile;
	$sheetname =~ s/.txt//;
	my $worksheet = $workbook->add_worksheet("$sheetname");
	my $col = 0;
	my $row = 0;

	open TXT, "<", "$dir/$txtfile";
	
	# write excel data
	while (<TXT>) {
		#print $_;
		@fields = split; 
		#print "field[0]=$fields[0], field[1]=$fields[1]\n";
		if ($row == 0) { @headers = @fields; }

		foreach my $cell (@fields) {
			if ( $row == 0 ) { $worksheet->write_string($row, $col, "$fields[$col]"); }
			else { $worksheet->write($row, $col, "$fields[$col]"); }
			$col++;
		}
		$row++;
		$col = 0;
	}
	close TXT;
   
      # add chart sheet
	#chomp(my $hostname = `hostname|awk -F"-" '{print $1}'`);
        my $hostname=substr(`hostname`,0,index(`hostname`, "-"));
        my $chartname = "$hostname"."_"."$sheetname";
	my $chart = $workbook->add_chart(type=>'line', name=>"$chartname");
#	print "Draw chart $chartname <@headers> ...\n";

	$chart->set_title(name => "$chartname");
        if ( $sheetname =~ /mem/ ) {
	   $chart->set_y_axis(name => "Memory (M)");
        } elsif ( $sheetname =~ /cpu/ ) {
           $chart->set_y_axis(name => "CPU%");
        }
	my $se_index = 0;
		
	foreach my $serie (@headers) {			
           my $se_col = $XLSCOL[$se_index];
	     $chart->add_series(
			name => "$serie",
			values => "=$sheetname!\$$se_col\$2:\$$se_col\$$row",
		);
       	$se_index++;	
       }	  
}
};


if ($@) {
	print "An exception catched: $@\n";
}
