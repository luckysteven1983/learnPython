#!/bin/bash

#########################################################################
#  Usage: $0 <pilot process> [pilot process2 ....]
#########################################################################
for process in "$@"
do
  echo $process
  #In case there are more than one top file for one station, we use the latest one.
  top_file=`ls top_*`
  #In case there is no top file for some station, we ignore it.
  #//Case res is valued by bytes, transfer it to Mb;
  #//Case res is valued by kilo bytes, transfer it to Mb;
  #//Case res is valued by Mega bytes, ignore its unit;
  #// Case res is valued by Giga bytes, transfer it to Mb
  echo ${process} > ${process}_memory.txt
  grep $process $top_file |awk '{ if ($6 ~/[1-9]$/)  {printf "%.8f\n", $6/1024/1024} else if ($6 ~/k$/) {gsub("k",""); printf "%.4f\n", $6/1024} else if ($6 ~/m$/){gsub("m","");print $6} else if ($6 ~/g$/) {printf "%.2f\n", $6*1024} }' >> ${process}_memory.txt

  echo ${process} > ${process}_cpu.txt
  grep $process $top_file |awk '{print $9}' >> ${process}_cpu.txt

  paste ${process}_cpu.txt ${process}_memory.txt > ${process}.txt
  awk 'BEGIN{print "Process    Avg(cpu)    Avg(mem)"} NR==1 { next; } {cpu+=$1;mem+=$2;++num;next} END {printf "%-10s  %6.2f %10.2f\n", "'"$process"'", cpu/num, mem/num}' ${process}.txt >> ${process}_avg.result
  title=${process}.AvgCPU
  maxcpu=${process}.MaxCPU
  awk 'BEGIN{print "'"$title"'" "\t" "'"$maxcpu"'"; max=0} NR==1 { next; } {cpu+=$1;if ($1>max) max=$1;++num;next} END {printf "%6.2f\t%6.2f\n",cpu/num,max}' ${process}.txt > ${process}_avg.xls
  rm  ${process}.txt
done


