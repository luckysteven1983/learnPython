'''
Created on Mar 23, 2015

@author: Xia Zhao
'''
import os
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class LinuxProcessManagerError(BaseException):
    """If error, raise it."""
    pass

class LinuxProcessManager(object):
    '''
    LinuxProcessManager will handle all standard linux basic commands:
    kill process
    check process is alive using "ps" command
    get pid of process
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def isAlive(self, lab, pid=".", processName=".", station=None, logLevel="error"):
        '''
        use ps -eo pid,cmd | egrep -i '[0-9]+ processName'| egrep pid to check the process is alive
        @param lab: the Lab object
        @param pid: string, the pid number of the process, the default value is ".", means all pid
        @param processName: string, the name of the process, default value is ".", means all process
        @param station: List, the list of the stations. Default value is None.
                if the station is None, this function will check the process on active pilot.
        @param logLevel if "error" display as error logger message, else debug level

        @verbatim
        PM=LinuxProcessManager(...)
        without station: PM.isAlive(lab,pid,processName)
                        if process alive on active pilot, No exception raised; otherwise, raise an exception
        with station: PM.isAlive(lab,pid,processName,station)
                       if process on all stations are alive, No exception raised
                       if process on all stations are not alive,
                           raise an exception with an error message and the failed stations
        @endverbatim
        '''
        cmd = "ps -eo pid,cmd | egrep -i '[0-9]+ (/.+/)*%s' | egrep %s | egrep -v egrep" %(processName, pid)
        if station:
            result = True
            stationFailed = []
            LOGGER.debug("Checking process " + processName + " is alive on all stations: " + str(station))
            for stationIndex in station:
                rshCmd = "rsh %s %s" %(stationIndex, cmd)
                exitStatus, stdout = self.sshManager.run(lab.oamIpAddress, rshCmd)
                if not exitStatus:
                    LOGGER.debug("process " + processName + " is alive on station " + stationIndex)
                    LOGGER.debug("\n" + stdout + "\n")
                else:
                    if logLevel.lower() == "error":
                        LOGGER.error("%s: %s: %s: %s", lab.id, stationIndex, processName, msgs.PROCESS_NOT_ALIVE)
                    else:
                        LOGGER.debug("%s: %s: %s: %s", lab.id, stationIndex, processName, msgs.PROCESS_NOT_ALIVE)
                    result = False
                    stationFailed.append(stationIndex)

            if not result:
                raise LinuxProcessManagerError, msgs.PROCESS_NOT_ALIVE

        else:
            LOGGER.debug("Checking process " + processName + " is alive on active pilot")
            exitStatus, stdout = self.sshManager.run(lab.oamIpAddress, cmd)

            if not exitStatus:
                LOGGER.debug("process " + processName + " is alive on active pilot")
                LOGGER.debug("\n" + stdout + "\n")
            else:
                if logLevel.lower() == "error":
                    LOGGER.error("%s: active pilot: %s %s ", lab.id, processName, msgs.PROCESS_NOT_ALIVE)
                else:
                    LOGGER.debug("%s: active pilot: %s %s ", lab.id, processName, msgs.PROCESS_NOT_ALIVE)
                raise LinuxProcessManagerError, msgs.PROCESS_NOT_ALIVE


    def isAliveOnServer(self, serverIp, user, pid=".", processName=".", logLevel="error"):
        '''
        use ps -eo pid,cmd | egrep -i '[0-9]+ processName'| egrep pid to check the process is alive
        @param serverIp: host ip address
        @param user: name to use for login
        @param pid: string, the pid number of the process, the default value is "." meaning all pids
        @param processName: string, the name of the process, default value is "." meaning all processes
        @param logLevel if "error" display as error logger message, else debug level
        '''
        LOGGER.debug("Checking process " + processName + " is alive on " + serverIp)
        cmd = "ps -eo pid,cmd | egrep -i '[0-9]+ (/.+/)*%s' | egrep %s | egrep -v egrep" %(processName, pid)
        exitStatus, stdout = self.sshManager.run(serverIp, cmd, user)

        if not exitStatus:
            LOGGER.debug("process " + processName + " is alive on " + serverIp)
            LOGGER.debug("\n" + stdout + "\n")
        else:
            txtLog = "Server: " + serverIp + " - process: " + processName + ": " + msgs.PROCESS_NOT_ALIVE
            if logLevel.lower() == "error":
                LOGGER.error(txtLog)
            else:
                LOGGER.debug(txtLog)
            raise LinuxProcessManagerError, msgs.PROCESS_NOT_ALIVE

    def getPid(self, lab, processName, station=None):
        '''
        use pidof processName to get the pid list
        @param lab: the Lab object
        @param processName: string, the name of the process
        @param station: string, for example: 0-0-2, only support one station.
                        default value is None. if None, will check active pilot.

        @verbatim
        PM=LinuxProcessManager(...)
        without station: PM.getPid(lab,processName)
                        if get pid on active pilot success, return ['pid1', 'pid2']
                        otherwise, raise an exception
        with station: PM.getPid(lab,processName,station)
                        if get pid success on station, return ['pid1', 'pid2']
                        otherwise, raise an exception
        @endverbatim
        '''

        if station:
            cmd = "rsh " + station + " pidof " + processName
        else:
            cmd = "pidof " + processName
        [_, out] = self.sshManager.run(lab.oamIpAddress, cmd)
        if out:
            result = out.split()
            LOGGER.debug("get " + processName + " PID success")
            LOGGER.debug("PID of " + processName + " is:\n" + str(result))
            return result
        else:
            LOGGER.error("%s: %s: %s", lab.id, processName, msgs.GET_PID_FAIL)
            raise LinuxProcessManagerError, msgs.GET_PID_FAIL


    def getPidOnServer(self, serverIp, user, processName):
        '''
        use pidof processName to get the pid list
        @param serverIp: host ip address
        @param user: name to use for login
        @param processName: name of the process
        '''

        cmd = "pidof " + processName
        _, out = self.sshManager.run(serverIp, cmd, user)
        if out:
            result = out.split()
            LOGGER.debug("get " + processName + " PID success")
            LOGGER.debug(processName + " PID:\n" + str(result))
            return result
        else:
            LOGGER.error("%s: %s: %s", serverIp, processName, msgs.GET_PID_FAIL)
            raise LinuxProcessManagerError, msgs.GET_PID_FAIL

    def getPidbyPS(self, lab, processName, station=None, logLevel='error'):
        '''
        use "ps -eo pid,cmd | egrep '[0-9]+ processName' | egrep -v egrep" to get the pid list
        In case we don't have the full name of the process,
        for eg: get the pid of Oam*

        @param lab: the Lab object
        @param processName: string, the name of the process
        @param station: string, for example: 0-0-2, only support one station.
                        default value is None. if None, will check active pilot.

        @verbatim
        PM=LinuxProcessManager(...)
        without station: PM.getPidbyPS(lab,processName)
                        if get pid on active pilot success, return ['pid1', 'pid2']
                        otherwise, raise an exception
        with station: PM.getPidbyPS(lab,processName,station)
                        if get pid success on station, return ['pid1', 'pid2']
                        otherwise, raise an exception
        @endverbatim
        '''

        cmd = "ps -eo pid,cmd | egrep -i '[0-9]+ (/.+/)*%s' | egrep -v egrep" %processName
        if station:
            cmd = "rsh %s %s" %(station, cmd)
        else:
            station = 'active pilot'
        rc, out = self.sshManager.run(lab.oamIpAddress, cmd)
        if not rc:
            result = [line.split()[0] for line in out.split(os.linesep)]
            LOGGER.debug("%s: %s: PID of %s is:\n%s", lab.id, station, processName, str(result))
            return result
        else:
            if logLevel == 'error':
                LOGGER.error("%s: %s: %s: %s", lab.id, station, processName, msgs.GET_PID_FAIL)
            else:
                LOGGER.debug("%s: %s: %s: %s", lab.id, station, processName, msgs.GET_PID_FAIL)
            raise LinuxProcessManagerError, msgs.GET_PID_FAIL

    def getPidbyPSOnServer(self, serverIp, user, processName):
        '''
        use "ps -eo pid,cmd | egrep '[0-9]+ processName' | egrep -v egrep" to get the pid list
        In case we don't have the full name of the process,
        @param serverIp: host ip address
        @param user: name to use for login
        @param processName: name of the process
        '''

        cmd = "ps -eo pid,cmd | egrep -i '[0-9]+ (/.+/)*%s' | egrep -v egrep" %processName
        rc, out = self.sshManager.run(serverIp, cmd, user)
        if not rc:
            result = []
            for line in out.split(os.linesep):
                result.append(line.split()[0])
            LOGGER.debug("%s: get %s PID success", serverIp, processName)
            LOGGER.debug("%s: %s PID:\n%s", serverIp, processName, str(result))
            return result
        else:
            LOGGER.error("%s: %s: %s", serverIp, processName, msgs.GET_PID_FAIL)
            raise LinuxProcessManagerError, msgs.GET_PID_FAIL

    def killAllProcess(self, lab, processName, station=None):
        '''
        use killall processName to kill process
        @param lab: the Lab object
        @param processName: string, the name of the process
        @param station: string, for example: 0-0-2, default value is None.
                       if None, will kill the process on active pilot.

        @verbatim
        PM=LinuxProcessManager(...)
        without station: PM.killAllProcess(lab, processName)
                        if kill process on active pilot fail, raise an exception
        with station: PM.killAllProcess(lab, processName, station)
                        if kill process fail on station, raise an exception
        @endverbatim
        '''
        if station:
            LOGGER.debug("%s: kill process %s on %s", lab.id, processName, station)
            cmd = "rsh " + station + " killall " + processName
        else:
            LOGGER.debug("%s: kill process %s on active pilot", lab.id, processName)
            cmd = "killall " + processName
        [rc, _] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not rc:
            LOGGER.debug("%s: kill process %s success!", lab.id, processName)
        else:
            LOGGER.error("%s: kill process %s fail!", lab.id, processName)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL

    def killProcess(self, lab, processName, station=None, getPidtype=1):
        '''
        use kill -9 pid to kill process
        @param lab: the Lab object
        @param processName: string, the name of the process
        @param station: string, for example: 0-0-2, default value is None.
                       if None, will kill the process on active pilot.
        @param getPidtype: if 1, use ps -ef command to get pid list
                     if 2: use pidof command to get pid list

        @verbatim
        PM=LinuxProcessManager(...)
        without station: PM.killProcess(lab, processName)
                        if kill process on active pilot fail, raise an exception
        with station: PM.killProcess(lab, processName, station)
                        if kill process fail on station, raise an exception
        if just know part of the process name, use the default type value
        @endverbatim
        '''
        pidlist = []
        pidStr = ""
        if getPidtype == 1:
            pidlist = self.getPidbyPS(lab, processName, station)
        if getPidtype == 2:
            pidlist = self.getPid(lab, processName, station)
        for pid in pidlist:
            pidStr = pidStr + pid + " "

        if station:
            LOGGER.debug("%s: kill process %s on %s", lab.id, processName, station)
            cmd = "rsh " + station + " kill -9 " + pidStr
        else:
            LOGGER.debug("%s: kill process %s on active pilot", lab.id, processName)
            cmd = "kill -9 " + pidStr
        [rc, _] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not rc:
            LOGGER.debug("%s: kill process %s success!", lab.id, processName)
        else:
            LOGGER.error("%s: kill process %s fail!", lab.id, processName)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL


    def killProcessOnServer(self, serverIp, user, processName, getPidtype=1):
        '''
        use kill -9 pid to kill process
        @param serverIp: host ip address
        @param user: name to use for login
        @param processName: string, the name of the process
        @param getPidtype: if 1, use ps -ef command to get pid list
                     if 2: use pidof command to get pid list
        '''
        pidlist = []
        pidStr = ""
        if getPidtype == 1:
            pidlist = self.getPidbyPSOnServer(serverIp, user, processName)
        if getPidtype == 2:
            pidlist = self.getPidOnServer(serverIp, user, processName)
        for pid in pidlist:
            pidStr = pidStr + pid + " "

        LOGGER.debug("Kill process %s on %s", processName, serverIp)
        cmd = "kill -9 " + pidStr
        rc, _ = self.sshManager.run(serverIp, cmd, user)
        if not rc:
            LOGGER.debug("Kill process %s on %s: success!", processName, serverIp)
        else:
            LOGGER.error("Kill process %s on %s: failed!", processName, serverIp)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL

    def killProcessbyPid(self, lab, pidList, station=None, signal=9):
        '''
        use kill signal pid to kill process, default signal is -9
        @param lab: the Lab object
        @param pidList: List, the list of the pid
        @param station: string, for example: 0-0-2, default value is None.
                       if None, will kill the process on active pilot.
        @param signal the signal to kill (-6, -9, -15, ...)
        @verbatim
        PM=LinuxProcessManager(...)
        without station: PM.killProcessbyPid(lab, pidlist)
                        if kill process on active pilot fail, raise an exception
        with station: PM.killProcess(lab, pidlist, station)
                        if kill process fail on station, raise an exception
        @endverbatim
        '''
        if not pidList:
            LOGGER.error("%s: %s: pidlist is empty!", lab.id, msgs.KILL_PROCESS_FAIL)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL

        pidStr = ""
        for pid in pidList:
            pidStr = pidStr + pid + " "

        cmd = " kill -" + str(signal) + ' ' + pidStr
        if station:
            LOGGER.debug("%s: kill process on %s", lab.id, station)
            cmd = "rsh " + station + cmd
        else:
            LOGGER.debug("%s: kill process on active pilot", lab.id)
        LOGGER.debug("cmd is: %s", cmd)
        [rc, _] = self.sshManager.run(lab.oamIpAddress, cmd)
        if not rc:
            LOGGER.debug("%s: kill process success!", lab.id)
        else:
            LOGGER.error("%s: %s!", lab.id, msgs.KILL_PROCESS_FAIL)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL


    def killProcessbyPidOnServer(self, serverIp, user, pidList):
        '''
        use kill -9 pid to kill process
        @param serverIp: host ip address
        @param user: name to use for login
        @param pidList: List, the list of the pid
        '''
        if not pidList:
            LOGGER.error("Server %s: %s: pidlist is empty!", serverIp, msgs.KILL_PROCESS_FAIL)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL

        pidStr = ""
        for pid in pidList:
            pidStr = pidStr + pid + " "

        LOGGER.debug("Kill process on %s", serverIp)
        cmd = "kill -9 " + pidStr
        LOGGER.debug("cmd is: %s", cmd)
        rc, _ = self.sshManager.run(serverIp, cmd, user)
        if not rc:
            LOGGER.debug("%s: kill process success!", serverIp)
        else:
            LOGGER.error("%s: %s!", serverIp, msgs.KILL_PROCESS_FAIL)
            raise LinuxProcessManagerError, msgs.KILL_PROCESS_FAIL

    def getProcessPids(self, lab, processName):
        """Get given process pid list on each blade and return a dictionary

        @param lab            one lab object
        @param processName    the string type process name such as processi, processu ...
        @return               a dict with blade as key and process list as value
        """
        processOnBlade = dict()
        for blade in lab.getAllBlade():
            LOGGER.debug("%s: %s: check process %s", lab.id, blade, processName)
            try:
                processList = self.getPidbyPS(lab, processName, blade, 'debug')
                processOnBlade[blade] = processList
            except LinuxProcessManagerError:
                LOGGER.debug("%s: %s: no process %s", lab.id, blade, processName)
        return processOnBlade

    def advancedKillProcess(self, lab, processName, blades=None):
        """Kill process on given blade with killProcessbyPid

        Kill process on given blade. If no blade is given, kill the process on all blades.

        Return value:
           If get or kill process fails when blades is given, raise exception (see getPidbyPS and
           killProcessbyPid in LinuxProcessManager). If blades is None, the method will get the
           process PID on each blade, and if failure on one blade, it will skip the blade. If no
           process is found on given blade raise exception LinuxProcessManagerError

        @param lab       one lab object
        @param processName    the string type process name such as processi, processu ...
        @param blades    a blade list in which, the process will be killed

        @verbatim
        1) killedProcess = processObj.killProcess2(lab, 'PDLSI')
            Kill PDLSI on all blades of lab. And the killedProcess is a dictionary like below
            {'0-0-2': [27056, 27053], '0-0-3': [37056, 23053], ...}, where, the 27056, 27053, 37056
            and 23053 are the just killed process PID on the corresponding blade.

        2) killedProcess = processObj.killProcess2(lab, 'PDLSI', ['0-0-2'])
            Kill PDLSI on blade 0-0-2 of lab. And the killedProcess is a dictionary like below
            {'0-0-2': [27056, 27053]}, where, the 27056 and 27053 are the just killed process PID on
            the blade 0-0-2.
        @endverbatim
        """
        processOnBlade = dict()
        if not blades:
            # No blades is given, check the process on each blade
            processOnBlade = self.getProcessPids(lab, processName)
        else:
            # Check process on given blade.
            for blade in blades:
                processOnBlade[blade] = self.getPidbyPS(lab, processName, blade)
        # kill process on processOnBlade dictionary
        LOGGER.debug("%s: processOnBlade = %s", lab.id, str(processOnBlade))
        if not processOnBlade:
            errorMsg = "%s: %s on all blades" % (lab.id, msgs.NO_PROCESS_FOUND)
            LOGGER.error(errorMsg)
            raise LinuxProcessManagerError, errorMsg
        for blade in processOnBlade:
            self.killProcessbyPid(lab, processOnBlade[blade], blade)
        LOGGER.debug("%s: Kill process done", lab.id)
        return processOnBlade

    def advancedWaitProcess(self, lab, processName, processOnBlade, duration=1800, interval=10, logLevel='error'):
        """Wait process in service on given blade in duration.

        Return value:
        1) If process can't be create after duration timeout, raise exception.
        2) If process can be created but the new process PID has intersection with that in
        processOnBlade. raise exception.
        3) if all successful, no return value.

        @param lab       one lab object
        @param processName    the string type process name such as processi, processu ...
        @param processOnBlade   a process dictionary.
        @param duration  a time (unit is second) in when the process can be restarted
        @param interval  a time (unit is second) the method will sleep for next check.

        @verbatim
        processOnBlade = {'0-0-2': [27056, 27053], '0-0-3': [37056, 23053]}
        processObj.advancedWaitProcess(lab, 'PDLSI', processOnBlade)

        1) If the PDLSI can't be IS in 1800 seconds, raise exception.
        2) If the PDLSI can be IS in 1800 seconds, but the new process PID is like below
            {'0-0-2': [27056, 4l083], '0-0-3': [67756, 23659]}
           raise exception because process 27056 on blade 2 is the same with given in
           processOnBlade.
        3) if not above, successful and no return value
        @endverbatim
        """
        LOGGER.debug("%s: waiting process %s restart", lab.id, processName)
        self._processAlive(lab, processName, processOnBlade, duration, interval, logLevel)

    def advancedKillWaitProcess(self, lab, processName, blades=None, duration=1800, interval=10, logLevel='error'):
        """Kill process on blades and wait them restart.

        The method will directly call advancedKillProcess and advancedWaitProcess. Check prameter
        meaning in advancedKillProcess and advancedWaitProcess.

        If error, raise exception, or no return value.
        """
        pidOnBlade = self.advancedKillProcess(lab, processName, blades)
        self.advancedWaitProcess(lab, processName, pidOnBlade, duration, interval, logLevel)

    def _processAlive(self, lab, processName, processOnBlade, duration, interval, logLevel='error'):
        """Check process can be alive in duration on given blade list.
        """
        CommonAssert.timedAssert(duration, interval,
                                 self._assertFalse, processName, processOnBlade, lab, logLevel)

    def _assertFalse(self, processName, processOnBlade, lab, logLevel='debug'):
        """Check PID is not equal between old and new processes.
        """
        for blade in processOnBlade:
            newProcess = self.getPidbyPS(lab, processName, blade, logLevel)
            LOGGER.debug("%s: %s: %s: new PID %s",
                         lab.id, blade, processName, str(newProcess))
            oldPidSet = set(processOnBlade[blade])
            newPidSet = set(newProcess)
            LOGGER.debug("%s: %s: old pid %s for %s", lab.id, blade, str(oldPidSet), processName)
            LOGGER.debug("%s: %s: new pid %s for %s", lab.id, blade, str(newPidSet), processName)
            errorMsg = lab.id + ": " + blade + ": " + processName + ": old pid is same with the new one"
            CommonAssert.assertFalse(oldPidSet.intersection(newPidSet), errorMsg, logLevel)
