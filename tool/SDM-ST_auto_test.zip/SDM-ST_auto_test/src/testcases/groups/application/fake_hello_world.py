'''
Created on Feb 10, 2015

@author: yohann
'''
import unittest

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)

class fake_hello_world(SDMTestCase):
    '''This class defines a basic test'''

    def setUp(self):
        LOGGER.debug("setUp")
        LOGGER.debug("testEnv id: %s", self.testEnv.id)


    def tearDown(self):
        LOGGER.debug("tearDown")

    def testHelloWorld(self):
        ''' This is a basic test'''
        LOGGER.info("testHelloWorld")
        LOGGER.debug("Detailed information, typically of interest only when diagnosing problems.")
        LOGGER.info("Confirmation that things are working as expected. \
        This will be displayed in Console Output. Please only put short info here")
        LOGGER.warning("An indication that something unexpected happened, or indicative of some problem in the future.")
        LOGGER.error("Due to a more serious problem, the software has not been able to perform some function.")
        LOGGER.critical("A serious error, indicating that the program itself may be unable to continue running.")
        self.logLinksPrint()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'EmptyTest.testName']
    unittest.main()

