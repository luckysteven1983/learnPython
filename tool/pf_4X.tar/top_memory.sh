#!/bin/bash

function mem_filter {
gawk '
$0 ~ /top -/ {Time=$3;}
$0 ~ /Mem:/ { gsub("k","");Mem=$0;}
$0 ~ /Swap:/ { gsub("k",""); printf("Time: %s\t%s\t%s\n",Time,Mem,$0); }
'
}
echo -e "Station\t AvgMem(M) \t MinMem(M) \t MaxMem(M) \t MaxTime" > top_mem.report
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|sort`
do
  ls -lrt |grep top_${sta} > /dev/null
  if [ $? -eq 0 ]; then
     file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'`
     cat $file | mem_filter |awk 'BEGIN {printf("%8s\t%10s\t%10s\t%10s\t%10s\t%8s\t%8s\t%8s\t%8s\t%8s\n","Time","MemTotal","MemUsed","MemFree","MemBuff","SwapTotal","SwapUsed","SwapFree","SwapCached","RealUsedMem")} { printf("%8s\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\n",$2,$4/1024,$6/1024,$8/1024,$10/1024,$13/1024,$15/1024,$17/1024,$19/1024,($6-$10-$19)/1024);}' > Sta_${sta}_mem.txt
     cat Sta_${sta}_mem.txt|awk '{print $1, $10}' |grep -v Time > tmp
     awk '{ if(min=="") {min=max=$2}; if($2>=max) {max=$2;Time=$1;}; if($2<=min) {min=$2}; total+=$2; count+=1;} END { printf("%7s\t%8.2f\t%8.2f\t%8.2f\t%8s\n", "'"$sta"'", total/count, min, max, Time);}' tmp >> top_mem.report
     rm tmp
  fi
done


echo -e "OAM_AVG_MEM(M)" > oam_mem.summary
cat top_mem.report|awk '{ if ($1 ~/A|B/) { print $0 } }' > oam_mem.tmp
awk '{ if(avg=="") avg=$2; if ($2 >= avg) avg=$2 } END { print avg } ' oam_mem.tmp >> oam_mem.summary
rm oam_mem.tmp

echo "NONPILOT_AVG_MEM(M)" > nonpilot_mem.summary
awk '{ if($1 !~ /A|B|Station/) { total+=$2; count+=1;} } END { printf("%8.2f\n", total/count) } ' top_mem.report >> nonpilot_mem.summary 

paste oam_mem.summary nonpilot_mem.summary > top_mem.summary
cat top_mem.summary >> top_mem.report
