#!/bin/bash

#######################################################
#       usage: $0  <FE_CONFIG|BE_CONFIG>  <output dir> 
#######################################################  

currentpath=$(cd "$(dirname "$0")"; pwd)

if [ ! -d $2 ]
then
  echo "directory no exist! create it"
  mkdir -p $2
fi

for file in `cat $currentpath\/conf\/$1`
do
    cp $file $2
done 
