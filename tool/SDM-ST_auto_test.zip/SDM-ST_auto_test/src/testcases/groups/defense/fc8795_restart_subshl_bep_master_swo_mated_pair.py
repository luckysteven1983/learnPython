'''
Created on Sep 17, 2015

@author: xzhao015
'''
import random
import os
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.asserts.common_asserts import CommonAssert
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

TIMEOUT_3HOURS = 3*3600

class fc8795_restart_subshl_bep_master_swo_mated_pair(SDMTestCase):
    '''Blade HW fault: remove a BE MASTER non pilot blade and swo manual Mated pair on SLAVE '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsBE = []
        self.acceptedAlarmsBE = []
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.success = True
        self.exceptMsg = str()

    def test_restart_subshl_bep_master_swo_mated_pair(self):
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _restartSubshlBEpMaster(self):
        beList = self.testEnv.testBed.getNRG()
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(beList)[0]
        LOGGER.debug("Master BE is " + masterBE.id)

        LOGGER.debug("%s: Choose a non-pilot station", masterBE.id)
        nonPilotStation = random.choice(self.sdmManager.mcasMachineManager.getMachinesNotVHost(masterBE))
        LOGGER.debug("%s: non-pilot station %s has been chosen", masterBE.id, nonPilotStation)

        LOGGER.debug("%s: check non-pilot station %s is in good status", masterBE.id, nonPilotStation)
        self.testEnvAsserts.assertStationOK(masterBE, nonPilotStation)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.info("Restart board " + nonPilotStation + " on master BE " + masterBE.id + " at: " + startTime)

        self.assertTrue(self.sdmManager.mcasMachineManager.removeMachine(masterBE, nonPilotStation))
        self.assertTrue(self.sdmManager.mcasMachineManager.powerOffMachine(masterBE, nonPilotStation))
        self.assertTrue(self.sdmManager.mcasMachineManager.powerOnMachine(masterBE, nonPilotStation))
        self.assertTrue(self.sdmManager.mcasMachineManager.restoreMachine(masterBE, nonPilotStation))

        CommonAssert.timedAssert(TIMEOUT_3HOURS, 60, self.testEnvAsserts.assertStationOK, masterBE, nonPilotStation,
                                 'COMPL', 'debug')

    def _swoMatedPair(self):
        belist = self.testEnv.testBed.getNRG()

        LOGGER.debug("Get master BE")
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is " + masterBE.id)

        beStates = dict((beObj.id, self.sdmManager.databaseStateManager.getState(beObj)) for beObj in belist)
        LOGGER.debug("BE state before: %s", str(beStates))

        LOGGER.debug("Switch over")
        self.sdmManager.databaseManager.matedPairSwo(belist)

        newStates = dict((beObj.id, self.sdmManager.databaseStateManager.getState(beObj)) for beObj in belist)
        LOGGER.debug("BE states after: %s", str(newStates))

        LOGGER.debug("Get new master BE after switch over")
        newMasterBE = self.sdmManager.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("new Master BE is " + newMasterBE.id)

        self.assertNotEqual(masterBE.id, newMasterBE.id, "new master BE id should not equal to original master BE id")

        self.assertEqual(beStates.values().sort(), newStates.values().sort(), "Other BE states are changed!")

    def _runTestCase(self):
        """Execute test case"""

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        multiTasks = self.sdmManager.multiTasksManager
        LOGGER.info("run test case fc8795_restart_subshl_bep_master_swo_mated_pair")
        multiTasks.register(self._restartSubshlBEpMaster)
        multiTasks.register(self._swoMatedPair)
        if not multiTasks.runMultiTasks():
            LOGGER.error("fc8795_restart_subshl_bep_master_swo_mated_pair failure")
            raise BaseException
        return startTime

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.info("test case precheck")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.info("Test case post-check")
        LOGGER.debug("check the alarm")
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(self.expectedAlarmsBE, self.acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("fc8795_restart_subshl_bep_master_swo_mated_pair success!\n")
        else:
            LOGGER.error("fc8795_restart_subshl_bep_master_swo_mated_pair failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)
