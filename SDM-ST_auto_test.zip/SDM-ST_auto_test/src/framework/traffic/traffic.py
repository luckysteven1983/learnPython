'''
Traffic class

Mother class used to start, stop and check qos on traffics.

@author: yohannm
'''

class Traffic(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''

    def start(self, killIfExists=False):
        """
        Starts this traffic
        """
        pass

    def checkErrors(self):
        """
        Checks the number of requests and errors for this traffic
        """
        pass

    def checkQoS(self):
        """
        Checks this traffic
        """
        pass

    def stop(self):
        """
        Stops this traffic
        """
        pass

class BadQosException(BaseException):
    """If error, raise it."""
    pass
