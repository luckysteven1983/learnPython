"""
@file
Created on Mar 10, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines TgenLDAPTrafficSimulator class
"""

from framework.traffic.ldap_traffic_simulator import LDAPTrafficSimulator

class TgenLDAPTrafficSimulator(LDAPTrafficSimulator):
    """
    @details This class describes a tgen traffic as defined in configuration.xml.
    """

    def __init__(self, sshManager):
        """
        TgenLDAPTrafficSimulator class constructor
        """
 
        super(TgenLDAPTrafficSimulator, self).__init__(sshManager)
        self.application = None
        self.server = None
