#!/bin/bash

#######################################################
#       usage: $0 <PT tool logs directory>
#       $LOG_DIR=<PT tool logs directory>
#######################################################  

currentpath=$(cd "$(dirname "$0")"; pwd)
hostname=`hostname|awk -F"-" '{print $1}'`
echo $currentpath
cd $1
RT="";
DB="";
feflag=0;
beflag=0;
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
 do
  no=`rsh STATION_$sta 'ps -ef|grep PDLS|grep -v gmetric|grep -v grep|wc -l'`
  if [ $no -gt 0 ]; then
   if [ $feflag -eq 0 ]; then
       RT=${RT}$sta;
   else
      RT=${RT}"_"$sta
    fi
    let feflag++;
  else
     echo "$sta is DB blade"
     if [ $beflag -eq 0 ]; then
              DB=${DB}$sta;
     else
              DB=${DB}"_"$sta
     fi
     let beflag++;
   fi
done

################################################################
# The tool will save the result under directory $LOG_DIR/Result.
################################################################
if [ -d $1/Result ]
then
  echo "directory exist! clear it"
  rm -r $1/Result;mkdir $1/Result
else
  echo "directory no exist! create it"
  mkdir -p $1/Result
fi

echo Hostname > $1/Result/cmp_${hostname}_report.xls  
echo `hostname|awk -F"-" '{print $1}'` >> $1/Result/cmp_${hostname}_report.xls

###############################################################
# If all the simp logs are stored in $LOG_DIR, parse them.
###############################################################
echo "Parsing simp data ......."
$currentpath/simp.sh $1 
echo "Parsing simp data done."
echo "------------------------------------------------------------------------------------------------">$1/Result/report_${hostname}
echo "                            Simp Statistics  Result                                             ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat simp.result >> $1/Result/report_${hostname}
rm simp.result 


###############################################################
# Hottest CPU and average CPU usage statistics
###############################################################
cd $1/Done
echo "Parsing cpu data ......"
$currentpath/nonpilot_cpu.sh 
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "                            Hottest CPU and average CPU Usage Statistics  Result             ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat cpu.result >> $1/Result/report_${hostname}

paste $1/Result/cmp_${hostname}_report.xls cpu.result > $1/Result/cmp_${hostname}_report.tmp
cat $1/Result/cmp_${hostname}_report.tmp
mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls
rm cpu.result
echo "Parsing cpu data done."

################################################################
# FE memory statistics
# Memory=used - buffer - cache
################################################################
echo "Parsing memory data ......"
$currentpath/nonpilot_memory.sh
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "                            Memory Usage Statistics  Result                                  ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat memory.result >> $1/Result/report_${hostname}
paste $1/Result/cmp_${hostname}_report.xls memory.xls > $1/Result/cmp_${hostname}_report.tmp
mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls

rm memory.result memory.xls
echo "Parsing memory data done."


################################################################
# Run queue statistics
################################################################
echo "Parsing run queue data ......"
$currentpath/nonpilot_vmstat.sh
echo "-----------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "                            Run Queue Statistics  Result                                  ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat runque.xls >> $1/Result/report_${hostname}
paste $1/Result/cmp_${hostname}_report.xls runque.xls > $1/Result/cmp_${hostname}_report.tmp
mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls

rm runque.xls
echo "Parsing run queue data done."
################################################################
# COMPACT Process Statistics
################################################################
echo "Parsing PDLSI/L/U cpu & memory data ......"

for process in `grep PDLS top_*|awk -F "log:" '{print $2}'|awk '{print $NF}'|sort|uniq`
do
   ${currentpath}/cmp_process.sh $process $RT
   cat ${process}_avg.result >> cmp_process_avg_cpu.result
   paste $1/Result/cmp_${hostname}_report.xls ${process}_avg.xls > $1/Result/cmp_${hostname}_report.tmp
   mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls
   rm ${process}_avg.result ${process}_avg.xls 
done

for process in ndbd
do
    ${currentpath}/cmp_process.sh $process $DB
    cat ${process}_avg.result >> cmp_process_avg_cpu.result
    paste $1/Result/cmp_${hostname}_report.xls ${process}_avg.xls > $1/Result/cmp_${hostname}_report.tmp
    mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls
    rm ${process}_avg.result ${process}_avg.xls
done

echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "                            PDLSI/L/U ndbd GdmpServer Average CPU Usage Statistics  Result      ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat cmp_process_avg_cpu.result >> $1/Result/report_${hostname}
rm cmp_process_avg_cpu.result
echo "Parsing PDLSI/L/U cpu & memory data done."
mv *.txt $1/Result

##############################################################
#Transfer PDLSI/L/U cpu and memory data to Excel Chart
##############################################################
$currentpath/txt2excel_dir_chart.pl $1/Result

##############################################################
# PDLSI/L G2 Measurements Statistics
##############################################################
echo "Parsing PDLSI/L G2 measurements data ......."
$currentpath/fe_g2_meas.sh 
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "                           PDLSI/L G2 Measurements Statistics  Result                           ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat fe_g2_meas.result >> $1/Result/report_${hostname}
paste $1/Result/cmp_${hostname}_report.xls pdlsi_g2_meas.xls > $1/Result/cmp_${hostname}_report.tmp
mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls
paste $1/Result/cmp_${hostname}_report.xls pdlsl_g2_meas.xls > $1/Result/cmp_${hostname}_report.tmp
mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls

rm fe_g2_meas.result pdlsi_g2_meas.xls pdlsl_g2_meas.xls
echo "Parsing PDLSI/L G2 measurements data done."

##############################################################
#COMPACT bandwidth statistics
##############################################################
echo "Parsing bandwidth data ......"
$currentpath/bandwidth_meas_ATCA.sh FE
for type in OAM Diameter TOTAL
do
  if [ `cat bandwidth.result|grep $type | wc -l` -gt 0 ]; then
   echo -e "${type}.Avg.In.Bw(Mbps)t${type}.Max.In.BW(Mbps)t${type}.Avg.Out.BW(Mbps)t${type}.Max.Out.BW(Mbps)" > ${type}.xls
   cat bandwidth.result|grep $type | awk '{ print $2 "t" $3 "t" $4 "t" $5 }' >>  ${type}.xls
   paste $1/Result/cmp_${hostname}_report.xls ${type}.xls > $1/Result/cmp_${hostname}_report.tmp
   mv $1/Result/cmp_${hostname}_report.tmp $1/Result/cmp_${hostname}_report.xls
   rm ${type}.xls
 fi
done
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "                            COMPACT Bandwidth Statistics  Result                                ">>$1/Result/report_${hostname}
echo "------------------------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat bandwidth.result >> $1/Result/report_${hostname}

echo "Parsing bandwidth  data done."
rm bandwidth.result

