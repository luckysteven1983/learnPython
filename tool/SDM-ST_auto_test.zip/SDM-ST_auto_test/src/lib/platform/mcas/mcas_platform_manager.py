'''
Created on Nov 2, 2015
@author: Tangi Lavanant
'''

from framework.asserts.common_asserts import CommonAssert
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import McasApplicationManagerError


LOGGER = Logger.getLogger(__name__)
MCAS_ASTART_TIMEOUT = 1200
CMD_ASTOP = '/etc/Astop '
CMD_ASTART = '/etc/Astart '

class McasPlatformManagerError(BaseException):
    """If error, raise it."""
    pass

class McasPlatformManager(object):
    '''
    McasPlatformManager is used to make Astop or Astart.
    timers are defined
    ASTART_TIMEOUT = 1200 can be used to wait for platform recover
    '''

    def __init__(self, sshManager, subshlManager, linuxProcessManager):
        '''
        Constructor
        '''
        self._sshManager = sshManager
        self._subshl = subshlManager
        self._CA = CommonAssert
        self._linuxProcessManager = linuxProcessManager

    def runAstop(self, lab, blade=None):
        '''
        @param lab : the hostname/IP of the lab
        @param blade : indicate which board we stop
        board number = 0-0-2
        Usage :
        self.mcasPlatformManager.runAstop(lab)
        self.mcasPlatformManager.runAstop(lab,0-0-2)
        '''
        LOGGER.debug('Launching Astop all ...')
        cmd = CMD_ASTOP + 'all' if blade is None else 'local ' + blade
        exceptionMessage = lab.id + ": " + cmd + ": " + msgs.MCAS_ASTOP_FAILS
        try:
            self._subshl.run(lab, cmd)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

    def runAstart(self, lab, blade=None):
        '''
        @param lab : the hostname/IP of the lab
        @param blade : indicate which board we start
        board number = 0-0-2
        Usage :
        self.mcasPlatformManager.runAstart(lab)
        self.mcasPlatformManager.runAstart(lab,0-0-2)
        '''
        LOGGER.debug('Launching Astart all ...')
        cmd = CMD_ASTART + 'all' if blade is None else 'local ' + blade
        exceptionMessage = lab.id + ": " + cmd + ": " + msgs.MCAS_ASTART_FAILS
        try:
            self._subshl.run(lab, cmd)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage

