'''
Created on Jan 28, 2015

@author: yohannm
'''
import argparse
import importlib
import os.path
import re
import time
import unittest
from unittest.loader import defaultTestLoader

import xmlrunner

from framework import arch
from framework.asserts.common_asserts import CommonAssert
from framework.asserts.platform_asserts import PlatformAsserts
from framework.asserts.test_env_asserts import TestEnvAsserts
from framework.common import Utils
from framework.configuration import Configuration
from framework.env_checker import EnvChecker
from framework.sdm_manager import SdmManager
from framework.sdm_test_case import SDMTestCase
from framework.traffic.traffic_manager import TrafficManager
from framework.version_manager import VersionManager
from lib.alarm.alarms_checker import AlarmsChecker
from lib.alarm.current_alarm_manager import CurrentAlarmManager
from lib.common.lab_recoverer import LabRecover
from lib.common.multi_tasks_manager import MultiTasksManager
from lib.core_check.core_check_manager import CoreCheckManager
from lib.database.ddm.database_manager import DatabaseManager
from lib.database.ddm.database_state_manager import DatabaseStateManager
from lib.database.ddm.database_topology_manager import DatabaseTopologyManager
import lib.exceptions_messages as eMsgs
from lib.health_check.health_check_manager import HealthCheckManager
from lib.loadbalancer.asr_load_balancer_manager import ASRLoadBalancerManager
from lib.loadbalancer.malban.malban_manager import MalbanManager
from lib.loadbalancer.malban.malban_process_manager import MalbanProcessManager
from lib.loadbalancer.se_load_balancer_manager import SELoadBalancerManager
from lib.logging.logger import Logger
from lib.measurement.measurement_manager import MeasurementManager
from lib.platform.linux_process_manager import LinuxProcessManager
from lib.platform.mcas.mcas_platform_manager import McasPlatformManager
from lib.platform.mcas.mcas_application_manager import McasApplicationManager
from lib.platform.mcas.mcas_machine_manager import MCASMachineManager
from lib.platform.mcas.subshl.subshl_manager import SubshlManager
from lib.ssh.ssh_manager import SshManager


# from lib.database.ddm.database_log_manager import DatabaseLogManager
# import shutil
LOGGER = Logger.getLogger(__name__)

SELF_HEALING_TIMEOUT = 7200 # seconds
SELF_HEALING_INTERVAL = 900

def findTestModule(fileName):
    """Return test items by file name."""
    pathName = arch.BASEDIR + os.sep + arch.CASEDIR
    # add '.py'
    fileName = fileName + arch.PYTHONSUFFIX
    testModule = Utils.findFile(pathName, fileName)
    if not testModule:
        LOGGER.error('Not find %s in %s and its subdir', fileName, pathName)
    else:
        # remove '.py'
        testModule = testModule[:-len(arch.PYTHONSUFFIX)]
    return testModule

def verifyFileExist(testItems):
    """Verify all test file in testItem exists."""
    for testItem in testItems:
        if not os.path.isfile(testItem + arch.PYTHONSUFFIX):
            raise JenkinsWorkerException, '%s: %s' % (eMsgs.TEST_ITEM_NOK, testItem)

def testSuiteInit(testItem):
    """
    Returns a testSuite class loaded from a test case
    """
    if testItem.startswith(arch.BASEDIR + os.sep):  # remove 'src/'
        testItem = testItem[len(arch.BASEDIR + os.sep):]
    testItem = testItem.replace(os.sep, '.')
    shortClassName = testItem.split('.')[-1]
    module = importlib.import_module(testItem)
    testClass = getattr(module, shortClassName)
    return defaultTestLoader.loadTestsFromTestCase(testClass)

def envTopology(testEnv, sdmManager):
    """display the topology of test environment"""

    proxyFeELList = testEnv.testBed.getProvFrontends().values()
    proxyFeList = []
    for proxyFeEL in proxyFeELList:
        proxyFe = "-FE" + str(proxyFeEL.productRole.FE_Key) + "<Proxy> : " + str(proxyFeEL.id) + "(" + \
                  proxyFeEL.oamIpAddress + ")"
        proxyFeList.append(proxyFe)
        proxyFeList.sort()
    feproxytopo = "\n".join(proxyFeList) + "\n"

    feELList = testEnv.testBed.getFrontends().values()
    feList = []
    for feEL in feELList:
        fe = "-FE" + str(feEL.productRole.FE_Key) + " : " + str(feEL.id) + "(" + feEL.oamIpAddress + ")"
        feList.append(fe)
        feList.sort()
    fetopo = "\n".join(feList) + "\n"

    _, nrgnumList = sdmManager.databaseTopologyManager.getNRG(feELList[0])
    nrgtopo = ""
    for nrgnum in nrgnumList:
        nrgList = []
        for labEL in testEnv.testBed.getNRG(nrg=str(nrgnum)):
            nrgList.append("-BE" + labEL.zoneId + ": " + labEL.id + "(" + labEL.oamIpAddress + ")")
            nrgList.sort()
        nrgtopo += "-NRG" + str(nrgnum) + ":\n   " + "\n   ".join(nrgList) + "\n"

    LOGGER.info("Topology of labs : \n" + feproxytopo + fetopo + nrgtopo)


def getFailureTCPattern(matchedTCs):
    """Return compiled re pattern in a list"""
    patternList = list()
    for tc in matchedTCs:
        # Suppose no ' or " as a part of regular expression for test case name
        # If we input .* as Jenkins parameter, it will expand .*. If we input '.*' to Jenkins, it will keep the ' and
        # pass directly '.*' to JenkinsWorker not .* that is what expected. So strip ' or " for pattern.
        tc = tc.strip("'\"")
        LOGGER.debug("matched failure case pattern: %s", tc)
        try:
            patternList.append(re.compile(tc))
        except re.error as arg:
            LOGGER.error("Invalid expression: '%s' (%s)", tc, arg)
            raise re.error(str(arg))
    return patternList

class JenkinsWorkerException(BaseException):
    """If error, raise it."""
    pass

class JenkinsWorker(object):
    """
    framework main class.
    """

    def __init__(self, params):
        '''
        Constructor
        '''
        self.testenv = params.testenv
        self.testItems = params.testitems
        self.internalunittestpattern = params.internalunittest_pattern
        self.loops = params.loops
        self.trafficprofile = None
        self.trafficStabilityRun = None
        self.timerStabilityTraffic = 0
        self.resultDict = {}
        if params.trafficprofile:
            self.trafficprofile = params.trafficprofile
        if params.timerFirstQos:
            self.timerFirstQos = params.timerFirstQos
        else:
            self.timerFirstQos = 10
        # Update attributes for traffic stability
        if params.TrafficStabilityRun:
            self.timerStabilityTraffic = params.TrafficStabilityRun
            self.trafficStabilityRun = 1
        self.healthcheck = True
        if params.nohealthcheck:
            self.healthcheck = False

        if params.stopOnFirstFailedTC:
            raise JenkinsWorkerException("Not support --stopOnFirstFailedTC again" 
                                         " and use --stopOnMatchedTCFailure instead")


        self.failureTCPattern = getFailureTCPattern(params.stopOnMatchedTCFailure)

        sshGateway = os.getenv("SSH_GATEWAY")
        sshUser = os.getenv("SSH_GATEWAY_USER")
        sshPassword = os.getenv("SSH_GATEWAY_PASSWORD")
        self.sshManager = SshManager(sshGateway, sshUser, sshPassword)
        self.versionManager = VersionManager(self.sshManager)
        self.jenkinsBuild = os.environ.get("BUILD_NUMBER")
        self.jenkinsJobURL = os.environ.get("JOB_URL")
        self.multiTasksManager = MultiTasksManager()
        self.databaseStateManager = DatabaseStateManager(self.sshManager)

    def _restoreOriginalAutomaticSwo(self, testEnv):
        '''
        verify the parameter 'isAutoamticSwoEnabled' is equal to its initial state. If not, modify it accordingly

        @return void
        '''
        # Check the Automatic Swo parameter is in the right state on the BEs
        LOGGER.debug("Check the parameter 'isAutomaticSwoEnabled' is correctly set")
        for lab in testEnv.testBed.getBackends().values():
            initialParam = lab.productRole.isAutomaticSwoEnabled
            currentParam = self.databaseStateManager.isAutomaticSwoEnabled(lab)
            if initialParam != currentParam:
                LOGGER.warning("The parameter 'Automatic SWO' of the lab %s has changed during the test case !", lab.id)
                LOGGER.warning("the parameter 'Automatic SWO' of the lab %s will be reassigned to its original value",
                               lab.id)
                if initialParam == True:
                    self.databaseStateManager.enableAutomaticSwo(lab)
                elif initialParam == False:
                    self.databaseStateManager.disableAutomaticSwo(lab)
            else:
                LOGGER.debug("The parameter 'Automatic SWO' of the lab %s is set to its original value", lab.id)

    def _setAttributesOnTestCases(self, testEnv, sdmManager, testSuite):
        """
        trick to set attributes on test cases.

        This trick is used because test case instantiation is done by unittest
        not by the framework.
        """
        if not hasattr(testSuite, "_tests"):
            LOGGER.error("error while loading tests: " + str(testSuite))
            return
        for test in testSuite._tests:  # pylint: disable=protected-access
            if not isinstance(test, SDMTestCase):
                self._setAttributesOnTestCases(testEnv, sdmManager, test)
            else:
                test.testEnv = testEnv
                test.sdmManager = sdmManager
                test.timerStabilityTraffic = self.timerStabilityTraffic

    def _connectLabs(self, testEnv):
        """Invoke getClient first time to really connect labs.
        """
        LOGGER.info("Connecting to labs")
        for lab in testEnv.testBed.labs.values():
            threadName = self.multiTasksManager.register(self.sshManager.getClient, lab.oamIpAddress,
                                                         labCustomUser=lab.primaryAccount.login,
                                                         labCustomPw=lab.primaryAccount.password,
                                                         labRootPw=lab.rootAccount.password)
            LOGGER.debug("Connection to lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        LOGGER.debug("Wait connection complete on all labs")
        if not self.multiTasksManager.runMultiTasks():
            LOGGER.error(eMsgs.LAB_CONNECTION_FAILURE)
            raise JenkinsWorkerException, eMsgs.LAB_CONNECTION_FAILURE

    def _getClientOnRouter(self, router):
        """ Initial connection to the routers
        """
        client = self.sshManager.getClient(router.ip, router.account.login, router.account.password, useKey=False)
        router.channel = client.invoke_shell()

    def _connectRouters(self, testEnv):
        """ Invoke getClient first time to really connect routers.
        """
        LOGGER.info("Connecting to routers")
        doneRouterIds = []
        for lab in testEnv.testBed.labs.values():
            for connection in lab.connections:
                if connection.router.id not in doneRouterIds:
                    threadName = self.multiTasksManager.register(self._getClientOnRouter, connection.router)
                    LOGGER.debug("Connection to router '%s' in progress -> thread ID '%s'", connection.router.id,
                                 threadName)
                    doneRouterIds.append(connection.router.id)
        LOGGER.debug("Wait connection complete on all routers")
        if not self.multiTasksManager.runMultiTasks():
            LOGGER.error(eMsgs.ROUTER_CONNECTION_FAILURE)
            for lab in testEnv.testBed.labs.values():
                # can't connect to one or more routers. Delete all connections
                lab.connections = None

    def _buildTestItems(self):
        """Build test items"""
        testItems = []
        for testItem in self.testItems:
            # full name
            if os.sep in testItem:
                if arch.SUITEDIR in testItem:
                    if testItem.startswith(arch.BASEDIR + os.sep):  # remove 'src/'
                        testItem = testItem[len(arch.BASEDIR + os.sep):]
                    module = importlib.import_module(testItem.replace(os.sep, '.'))
                    testItems.extend(module.TEST_ITEMS)
                else:
                    testItems.append(testItem)
                continue
            # Need to search the test module
            testModule = findTestModule(testItem)
            if not testModule:
                raise JenkinsWorkerException, '%s: %s' % (eMsgs.TEST_ITEM_NOK, testItem)
            LOGGER.debug("testModule: " + testModule)
            if arch.SUITEDIR in testModule:
                if testModule.startswith(arch.BASEDIR + os.sep):  # remove 'src/'
                    testModule = testModule[len(arch.BASEDIR + os.sep):]
                module = importlib.import_module(testModule.replace(os.sep, '.'))
                testItems.extend(module.TEST_ITEMS)
            else:
                testItems.append(testModule)
        return testItems

    #### Need to disable the function, because it will take long time.
    # And will re-implement it in another ticket.
    # def _collectDDMlogs(self, testEnv, caseLogDir):
    #    """Collect DDM logs for testEnv"""
    #    databaseLogManager = DatabaseLogManager(self.sshManager)
    #    for lab in testEnv.testBed.labs.values():
    #        LOGGER.debug("Collect DDM logs for %s", lab.id)
    #        logName = databaseLogManager.collectDDMLog(lab)
    #        # Need to move the log file from cache dir to case dir
    #        shutil.move(logName, caseLogDir)

    def _runTestCases(self, configuration, testEnv, sdmManager):
        """Run test cases"""

        testRunner = xmlrunner.XMLTestRunner(output="test-reports")

        if self.healthcheck:  # health check test case
            testItem = "testcases.groups.common.env_health_check"
            testSuite = testSuiteInit(testItem)
            self._setAttributesOnTestCases(testEnv, sdmManager, testSuite)
            LOGGER.debug("run " + testItem)
            # all logs will now be written in the TC log file
            testItem = testItem.split(".")[-1]
            mainHandler, message = Logger.switchToTcLog(LOGGER, testItem)
            result = testRunner.run(testSuite)
            if not result.wasSuccessful():  # If the health check failure, stop framework.
                self.sshManager.closeAllClients()
                raise JenkinsWorkerException, eMsgs.ENV_HEALTH_NOK
            # all logs will now be written in the main log file
            Logger.switchToMainLog(LOGGER, mainHandler)
            LOGGER.info("detailed Health Check log is here : " + message)

        if self.trafficprofile:  # starts as a testCase all traffics defined in configuration file
            testItem = "testcases.groups.common.start_all_traffics"
            testSuite = testSuiteInit(testItem)
            testSuite._tests[0].sdmManager = sdmManager  # pylint: disable=protected-access
            testSuite._tests[0].trafficProfile = configuration.trafficProfiles[self.trafficprofile]  # pylint: disable=protected-access
            testSuite._tests[0].testEnv = configuration.testEnvs[self.testenv]  # pylint: disable=protected-access
            LOGGER.debug("run " + testItem)
            # all logs will now be written in the TC log file
            testItem = testItem.split(".")[-1]
            mainHandler, message = Logger.switchToTcLog(LOGGER, testItem)
            testRunner.run(testSuite)
            # all logs will now be written in the main log file
            Logger.switchToMainLog(LOGGER, mainHandler)
            LOGGER.info("detailed Start Traffic log is here : " + message)

        if len(sdmManager.trafficManager.startedTraffics) != 0:
            testItem = "testcases.groups.common.check_QoS_all_traffics"
            testSuite = testSuiteInit(testItem)
            testSuite._tests[0].sdmManager = sdmManager  # pylint: disable=protected-access
            testSuite._tests[0].timerFirstQos = self.timerFirstQos  # pylint: disable=protected-access
            LOGGER.debug("run " + testItem)
            # all logs will now be written in the TC log file
            testItem = testItem.split(".")[-1]
            mainHandler, message = Logger.switchToTcLog(LOGGER, testItem)
            testRunner.run(testSuite)  # sdmTestSuite = SDMTestSuite(testEnv, testSuite)
            # all logs will now be written in the main log file
            Logger.switchToMainLog(LOGGER, mainHandler)
            LOGGER.info("detailed Check QOS log is here : " + message)

        # Traffic Stability run requested
        if self.trafficStabilityRun:
            testItem = "testcases.groups.common.stability_traffics"
            testSuite = testSuiteInit(testItem)
            self._setAttributesOnTestCases(testEnv, sdmManager, testSuite)
            testSuite._tests[0].timerStabilityTraffic = self.timerStabilityTraffic  # pylint: disable=protected-access
            LOGGER.debug("run " + testItem)
            # all logs will now be written in the TC log file
            testItem = testItem.split(".")[-1]
            mainHandler, message = Logger.switchToTcLog(LOGGER, testItem)
            testRunner.run(testSuite)
            # all logs will now be written in the main log file
            Logger.switchToMainLog(LOGGER, mainHandler)
            LOGGER.info("detailed Traffic Stability log is here : " + message)

        # Test suite processing
        if self.testItems:
            for i in range(self.loops):
                # testRunner instanciated again so that xml test-result files
                # are not overwritten.
                testRunner = xmlrunner.XMLTestRunner(output="test-reports")
                if self.loops != 1:
                    LOGGER.info("test items loop %d", i)

                for testItem in self.testItems:
                    self.resultDict.update({testItem:{"runStatus":1, "resultStatus": "", "msg":""}})

                for testItem in self.testItems:
                    testSuite = testSuiteInit(testItem)
                    if not testSuite._tests:  # pylint: disable=protected-access
                        errorMsg = "No test found in testcase"
                        LOGGER.error(errorMsg + " " + testItem)
                        self.resultDict.update({testItem:{"runStatus":0, "resultStatus":1, "msg": errorMsg}})
                        continue
                    self._setAttributesOnTestCases(testEnv, sdmManager, testSuite)
                    for testCase in testSuite._tests:  # pylint: disable=protected-access
                        LOGGER.debug("*** run " + str(testCase) + " ***")
                        # all logs will now be written in the TC log file
                        tcName = str(testCase).split(" ")[1]
                        tcName = tcName.split(".")[-1].replace(")","")
                        mainHandler, message = Logger.switchToTcLog(LOGGER, tcName,i)
                        result = testRunner.run(testCase)
                        LOGGER.debug("End of testcase...")
                        manageTestCaseException = None
                        try:
                            self._manageTestCaseResult(result, testItem, sdmManager, testEnv, testCase)
                        except BaseException as baseException:
                            LOGGER.error("manageTestCase error: " + baseException.msg)
                            manageTestCaseException = baseException
                        # all logs will now be written in the main log file
                        Logger.switchToMainLog(LOGGER, mainHandler)
                        LOGGER.info("detailed Test Case log is here : " + message)
                        if manageTestCaseException:
                            raise manageTestCaseException # pylint: disable=raising-bad-type

                # end testItems loop
                # xml runner use timestamp with second as best precision in output
                # file name. Thus, if the loop takes less than 1s, xml output file
                # is overwritten...
                time.sleep(1)
            # end loops on all testItems

        # Internal tests once run requested
        if self.internalunittestpattern:
            testlist = unittest.TestLoader().discover(arch.DISCOVER_DIR,
                                                      pattern=self.internalunittestpattern,
                                                      top_level_dir='.')
            if testlist.countTestCases() == 0:
                raise JenkinsWorkerException, '%s: %s' % (eMsgs.TEST_PATTERN_NOK, self.internalunittestpattern)
            LOGGER.info("Number of Internal Tests Once to run is : " + str(testlist.countTestCases()))
            testrunnerXML = xmlrunner.XMLTestRunner(output=arch.RESULT_DIR)
            for testItem in testlist:
                self._setAttributesOnTestCases(testEnv, sdmManager, testlist)
                testrunnerXML.run(testItem)

        LOGGER.info("End of sanity. Stop all traffics...")
        try:
            sdmManager.trafficManager.stopAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

    def _manageTestCaseResult(self, result, testItem, sdmManager, testEnv, testCase):

        resultStatus = 0
        errMsg = ""
        if not result.wasSuccessful():
            resultStatus = 1
            errMsg = result._get_info_by_testcase().values()[0][0].err[1] # pylint: disable=protected-access

        self.resultDict.update({testItem:{"runStatus":0, "resultStatus":resultStatus, "msg":errMsg}})

        if not result.wasSuccessful():
            self._restoreOriginalAutomaticSwo(testEnv)
            # check whether stopping testsuite if testcase failure
            caseName = str(testCase).split('.').pop().rstrip(')')
            for pattern in self.failureTCPattern:
                if pattern.match(caseName):
                    errorMsg = eMsgs.STOP_ON_FAILED_TC + ": " + caseName
                    self._abortTestCasesExecution(errorMsg, sdmManager)
                    raise JenkinsWorkerException(errorMsg)

            #### Need to disable the function, because it will take long time.
            # And will re-implement it in another ticket.
            # # For failure case, we need to collect DDM log
            # # Get case log directory. the case string is like below
            # # test_kill_cluster_master (testcases.groups.defense.ez4323_kill_cluster_master.\
            # #                                                       ez4323_kill_cluster_master)
            # # we will get ez4323_kill_cluster_master
            # # We only save logs for ST case not UT case.
            # caseStr = str(testCase)
            # if caseStr.find(arch.CASEDIR) != -1:
            #    LOGGER.info("Collecting DDM log ...")
            #    caseLogDir = "log" + os.sep + caseStr.split('.').pop().rstrip(')')
            #    LOGGER.debug("case log dir: %s", caseLogDir)
            #    if not os.path.isdir(caseLogDir):
            #        LOGGER.debug("case dir not exist, so save logs to log dir")
            #        caseLogDir = "log"
            #    self._collectDDMlogs(testEnv, caseLogDir)

            LOGGER.info("Call recover all spas...")
            # between 2 test cases, we try to recover all spas on all test bed
            # in case of this is not done by the test case itself
            # If recover fails, the test suite will stop
            # Only done in case of test failure to save time
            try:
                sdmManager.labRecover.recoverAllSpa(testEnv.testBed, True)
            except BaseException, message:
                LOGGER.error(message)
            try:
                self._waitForSelfHealing(sdmManager, testEnv)
            except BaseException:
                self._abortTestCasesExecution(message, sdmManager)
                raise BaseException(message)
            LOGGER.info("Restart traffics if needed...")
            try:
                sdmManager.trafficManager.startTrafficsAgainIfNeeded()
            except BaseException as arg:
                LOGGER.error(arg.message)
        sdmManager.sshManager.checkConnections(testEnv)

    def _abortTestCasesExecution(self, message, sdmManager):
        LOGGER.error(message)
        LOGGER.info("End of sanity. Stop all traffics...")
        try:
            sdmManager.trafficManager.stopAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

    def _healthCheckFalseRaiseException(self, testEnv, healthCheckManager):
        LOGGER.info("Defense mechanism: rerunning healthCheck on testEnv " + testEnv.id
                    + ", waiting for lab to be recovered")
        if not healthCheckManager.runCheckAllOnTestBed(testEnv.testBed):
            raise BaseException("health check nok on " + testEnv.id)

    def _waitForSelfHealing(self, sdmManager, testEnv):
        LOGGER.info("running healthcheck on testEnv " + testEnv.id + " every "
                    + str(SELF_HEALING_INTERVAL) + "s for at most " + str(SELF_HEALING_TIMEOUT)
                    + "s to make sure lab is ready for next test")
        try:
            CommonAssert.timedAssert(SELF_HEALING_TIMEOUT, SELF_HEALING_INTERVAL,
                                     self._healthCheckFalseRaiseException,
                                     testEnv, sdmManager.healthCheckManager)
        except BaseException, msg:
            err = "testEnv " + testEnv.id + "not recovered automatically " + msg
            self._abortTestCasesExecution(err, sdmManager)
            raise BaseException(err)

    def _reportResult(self, resultDict):
        '''result processing'''

        tcOk = []
        tcKo = []
        tcNotrun = []
        tcKotmp = []
        listOfTest = []
        nbOk = 0
        nbKo = 0
        numAll = 0
        # get the test case count
        if self.testItems:
            listOfTest = self._buildTestItems()
            numAll = len(listOfTest)
        # result processing
        if numAll:
            for testCase in resultDict.keys():
                if resultDict[testCase]["runStatus"]:
                    tcNotrun.append(testCase)
                elif resultDict[testCase]["resultStatus"]:
                    tcKotmp.append(testCase)
                    tcKo.append(testCase + " errrormsg: " + str(resultDict[testCase]["msg"]))
                    nbKo += 1
                else:
                    tcOk.append(testCase)
                    nbOk += 1

            LOGGER.info("list of TC failed: \n" + "\n".join(tcKo) + "\n")
            LOGGER.info("list of TC passed: \n" + "\n".join(tcOk) + "\n")
            if nbOk + nbKo:
                LOGGER.info("list of TC not run: \n" + "\n".join(tcNotrun) + "\n")
                LOGGER.info("the percent of executed TC is: " + str(100 * (nbOk + nbKo) / numAll) + "%")
                LOGGER.info("the percent of success  TC is: " + str(100 * nbOk / (nbOk + nbKo)) + "%")
                LOGGER.info("the percent of failed   TC is: " + str(100 * nbKo / (nbOk + nbKo)) + "%")
            else:
                LOGGER.info("list of TC not run: \n" + "\n".join(listOfTest) + "\n")
                LOGGER.warning("the percent of executed TC is: 0%, no test item ran")

            if tcKotmp:
                tcRerun = tcNotrun + tcKotmp
            elif tcOk:
                tcRerun = []
            else:
                tcRerun = listOfTest

            LOGGER.info("the TC to rerun is: \n" + "\n".join(tcRerun) + "\n")

            tcRerun = "[\"" + "\",\n\t      \"".join(tcRerun) + "\"]"
            rerunFile = Utils.findDir("src/testcases/suites", "") + os.sep + "TCs_to_rerun.py"
            fRerun = open(rerunFile, 'w')
            fRerun.write("\"\"\"Test cases to be rerun\"\"\"\nTEST_ITEMS = " + tcRerun)
            fRerun.close()

            filename = str(self.jenkinsBuild) + "/artifact/src/testcases/suites/TCs_to_rerun.py"
            LOGGER.info("TCs_to_rerun file is : \n" + str(self.jenkinsJobURL) + "/" + filename)
        else:
            LOGGER.warning("there is no test items added.....")

    def _parseConfigFile(self):
        """Parse configuration xml"""

        configuration = Configuration()
        configuration.load(self.sshManager)
        try:
            testEnv = configuration.testEnvs[self.testenv]
        except KeyError:
            raise Exception("testenv " + self.testenv + " not found in config file")
        self._connectLabs(testEnv)
        self._connectRouters(testEnv)
        envChecker = EnvChecker(self.sshManager, self.versionManager, self.multiTasksManager, self.databaseStateManager)
        envChecker.checkInitialState(testEnv)
        return (configuration, testEnv)

    def _createSdmManager(self, configuration):
        """Create SDM Manager"""

        sdmManager = SdmManager()
        sdmManager.sshManager = self.sshManager
        sdmManager.multiTasksManager = self.multiTasksManager
        sdmManager.coreCheckManager = CoreCheckManager(self.sshManager, sdmManager.multiTasksManager)
        sdmManager.subshlManager = SubshlManager(self.sshManager)
        sdmManager.linuxProcessManager = LinuxProcessManager(self.sshManager)
        sdmManager.mcasMachineManager = MCASMachineManager(self.sshManager, sdmManager.subshlManager)
        sdmManager.mcasPlatformManager = McasPlatformManager(self.sshManager, sdmManager.subshlManager,
                                                                   sdmManager.linuxProcessManager)
        sdmManager.mcasApplicationManager = McasApplicationManager(self.sshManager,
                                                                   sdmManager.subshlManager,
                                                                   sdmManager.linuxProcessManager)
        sdmManager.versionManager = self.versionManager
        sdmManager.trafficManager = TrafficManager()
        sdmManager.healthCheckManager = HealthCheckManager(self.sshManager, sdmManager.multiTasksManager)
        sdmManager.currentAlarmManager = CurrentAlarmManager(self.sshManager, sdmManager.subshlManager)
        sdmManager.databaseStateManager = self.databaseStateManager
        sdmManager.trafficManager.databaseStateManager = sdmManager.databaseStateManager
        sdmManager.trafficManager.linuxProcessManager = sdmManager.linuxProcessManager
        sdmManager.databaseManager = DatabaseManager(self.sshManager,
                                                     sdmManager.linuxProcessManager)
        sdmManager.databaseTopologyManager = DatabaseTopologyManager(self.sshManager)

        sdmManager.platformAsserts = PlatformAsserts(self.sshManager)
        sdmManager.testEnvAsserts = TestEnvAsserts(self.sshManager,
                                                   sdmManager.currentAlarmManager,
                                                   sdmManager.coreCheckManager,
                                                   sdmManager.mcasMachineManager,
                                                   sdmManager.mcasApplicationManager,
                                                   sdmManager.databaseManager,
                                                   sdmManager.databaseStateManager,
                                                   sdmManager.trafficManager,
                                                   sdmManager.healthCheckManager,
                                                   sdmManager.databaseTopologyManager)
        sdmManager.alarmsCheckerManager = AlarmsChecker(self.sshManager, \
                                                        configuration.acceptedAlarms)
        sdmManager.labRecover = LabRecover(self.sshManager,
                                           sdmManager.mcasApplicationManager,
                                           sdmManager.mcasMachineManager)
        sdmManager.measurementManager = MeasurementManager(self.sshManager)
        sdmManager.malbanManager = MalbanManager(self.sshManager)
        sdmManager.malbanProcessManager = MalbanProcessManager(sdmManager.malbanManager)
        sdmManager.seloadbalancerManager = SELoadBalancerManager(self.sshManager, sdmManager.malbanProcessManager)
        sdmManager.asrloadbalancerManager = ASRLoadBalancerManager(self.sshManager,
                                                                   sdmManager.linuxProcessManager,
                                                                   sdmManager.mcasMachineManager)
        return sdmManager

    def start(self):
        """Start to run test cases.
        """
        (configuration, testEnv) = self._parseConfigFile()

        LOGGER.info("Test Labs are : " + str(testEnv.testBed.labs.keys()))

        sdmManager = self._createSdmManager(configuration)
        envTopology(testEnv, sdmManager)

        for elem in testEnv.testBed.version:
            versions = ["%s %s" % item for item in testEnv.testBed.version[elem].items()]
            LOGGER.info("%s version: %s", elem, ", ".join(versions))

        if self.testItems:
            self.testItems = self._buildTestItems()
            LOGGER.info("Test cases: \n" + "\n".join(self.testItems) + "\n")
            verifyFileExist(self.testItems)
        else:
            LOGGER.warning("No test item provided in command line")

        try:
            self._runTestCases(configuration, testEnv, sdmManager)
        except BaseException, msg:
            LOGGER.error(msg)
            if not self.internalunittestpattern:
                LOGGER.info("\n\n%s REPORT RESULT %s", "+"*50, "+"*50)
                self._reportResult(self.resultDict)
            self.sshManager.closeAllClients()
            raise BaseException(msg)
        else:
            if not self.internalunittestpattern:
                LOGGER.info("\n\n%s REPORT RESULT %s", "+"*50, "+"*50)
                self._reportResult(self.resultDict)
            self.sshManager.closeAllClients()

def main():
    """main function"""
    parser = argparse.ArgumentParser(description="run test cases based on"
                                     "hosts list, list of test cases and an "
                                     "optional configuration file")
    parser.add_argument("--testenv",
                        help="name of test environment (required)",
                        required=True)
    testGroup = parser.add_mutually_exclusive_group()
    # Exclusive parameters
    testGroup.add_argument("--testitems", help="provide a list of individual test"
                           " cases, group of testcases or test suites. This "
                           "parameter is required.", nargs="+", required=False)
    testGroup.add_argument("--internalunittest_pattern",
                           help="run test in internalunittest/ matching with given pattern. "
                           "*_test_once.py for example"
                           " This parameter is not required.", required=False)
    testGroup.add_argument("--TrafficStabilityRun",
                           help="time to wait in minutes for stability on traffic (optional)",
                           required=False)
    # End of exclusive parameters
    parser.add_argument("--timerFirstQos",
                        help="time to wait in minutes before first traffic QoS check (optional)",
                        required=False, default=10)
    parser.add_argument("--trafficprofile", help="name of traffic to be "
                        "started before first test (optional)", required=False)
    parser.add_argument("--nohealthcheck", help="skip initial health check", \
                        required=False, action="store_true")

    parser.add_argument("--stopOnFirstFailedTC", help="stop sanity at first failed testcase. This parameter is obsolete"
                        " and use new parameter stopOnMatchedTCFailure instead", required=False, action="store_true")

    parser.add_argument("--stopOnMatchedTCFailure", help="stop sanity if failed testcase in the case list."
                        " This should be a case list like ff0490_restart_gdmp_master, ff0493_restart_spas_fe"
                        " If ff0490_restart_gdmp_master or ff0493_restart_spas_fe fails, stop the sanity."
                        " And this can support regular expression, for example, input '.*' to stop the"
                        " framework when any case fails. And input '.*restart_gdmp*' '.*restart_spas*' to stop the"
                        " framework when any case whose name includes 'restart_gdmp' or 'restart_spa' fails",
                        type=str,
                        nargs="+",
                        default=[],
                        required=False)

    parser.add_argument("--loops", help="number of loops for test items considered as a whole. "
                        "If testitems is \"test1 test2\" and loops is 2, execution will be "
                        "test1 test2 test1 test2", \
                        required=False, default=1, type=int)
    args = parser.parse_args()

    LOGGER.info("\n\n%s ENV_CHECK %s", "+"*50, "+"*50)
    LOGGER.info("test environment: " + args.testenv)
    if args.testitems:
        LOGGER.info("test items: " + ", ".join(args.testitems))
    if args.trafficprofile:
        LOGGER.info("traffic profile is : " + args.trafficprofile)
    else:
        LOGGER.warning("traffic profile: NO TRAFFIC WILL BE LAUNCHED")
    if args.nohealthcheck:
        LOGGER.warning("!!! No Health Check will be performed!!!")
    if args.TrafficStabilityRun:
        LOGGER.info("Traffic Stability requested: " + args.TrafficStabilityRun + "mn")
    if args.internalunittest_pattern:
        LOGGER.info("test once pattern: " + args.internalunittest_pattern)
    if args.loops != 1:
        LOGGER.info("loops: %d", args.loops)
    jenkinsWorker = JenkinsWorker(args)
    jenkinsWorker.start()

if __name__ == '__main__':
    main()
