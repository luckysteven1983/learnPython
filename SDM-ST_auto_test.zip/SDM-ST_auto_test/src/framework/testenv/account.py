"""
Created on Mar 19, 2015
@author: Claude Le Du
"""

class Account(object):
    """
    Class to handle an account (login, password) to connect to a PC lab or other tools.
    """


    def __init__(self):
        """
        Constructor of Account class
        """
        
        self.login = ""
        self.password = ""
