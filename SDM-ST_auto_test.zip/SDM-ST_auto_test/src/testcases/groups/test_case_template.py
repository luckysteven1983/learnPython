"""
Created on Apr 23, 2015
modified on Nov 06, 2015 by Cassandra Lajeunie

@author: Xia Zhao

#weblink_id=test-sheet-number (example : 3KJ-00117-0510-QPZZA)
#delete the line above if there is no existing test sheet related to the testcase
"""
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from framework.common import Utils
from lib.alarm.alarms_config import AlarmsConfig
LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class test_case_template(SDMTestCase):
    """one test case template"""

    def setUp(self):
        """
        Init the managers you need
        eg:
        self.myDSM = self.sdmManager.databaseStateManager
        self.myDM = self.sdmManager.databaseManager
        self.myPA = self.sdmManager.platformAsserts
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        """
        self.logLinksPrint()#Used to get the log links in Junit XML results

        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        # defined the expected alarms and accepted alarms
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.exceptMsg = "" # exception message linked to alarms
        
        #TC can be skipped in case all pre requisiste are not fullfilled
        #Example from TC es4806_check_sigtran_association_status.py: Skip this test case if some associations not active on FE
        #try:
        #    self.myHCM.runCheckSigtran(self.fe)
        #except BaseException:
        #    LOGGER.warning("TC Skipped since pre condition NOT fullfilled !")
        #    self.skipTest("This TC needs all associations active, some associations not active on FE:" + self.fe.id)

        LOGGER.debug("Here you can confirm test is being runned")

    def tearDown(self):
        """
        Use this function when you modify the lab directly to put back the original values at the
        end of the test. For instance when you update the measConfig of the lab.
        This function will be executed no matter what happen during the test case (fail /exception)
        """

    def test_template(self):
        """The test case
        Don't hesitate to log message, as show below
        Logger.debug("Detailed information, typically of interest only when diagnosing problems.")
        Logger.info("Confirmation that things are working as expected. \
        This will be displayed in Console Output. Please only put short info here")
        Logger.warning("An indication that something unexpected
        happened, or indicative of some problem in the near future
        (e.g. disk space low). The software is still working as expected.")
        Logger.error("Due to a more serious problem, the software has not been able to perform some function.")
        Logger.critical("A serious error, indicating that the program itself may be unable to continue running.")
        """

        # check the initial satus of the test env
        LOGGER.debug("check the Initial status of the test env")
        LOGGER.trace("Low level message")
        LOGGER.debug("Detailed information, typically of interest only when diagnosing problems.")
        LOGGER.info("Confirmation that things are working as expected.")
        LOGGER.warning("An indication that something unexpected happened, or indicative of some problem in the future.")
        LOGGER.error("Due to a more serious problem, the software has not been able to perform some function.")
        LOGGER.critical("A serious error, indicating that the program itself may be unable to continue running.")

        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        # get the start time of the TC
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, \
                                            self.testEnv.testBed.labs.values()[0])

        # the main part of the test case, eg:
        LOGGER.info("the main action of this test case")
        """
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getLabsInNRG("1")
        masterBE = self.myDSM.getMasterBE(belist)[0]
        Logger.debug("Master BE is "+masterBE.id)

        stations = masterBE.getAllBlade().keys()
        Logger.debug("the station list is: "+str(stations))

        LOGGER.debug("check the gdmps process on all stations is alive")
        self.myPA.assertProcessAliveOnStations(masterBE, process, stations)

        LOGGER.debug("restart gdmps on all stations")
        self.myDM.restartProcess(masterBE, processRestart, stations)

        LOGGER.debug("check the gdmps process on all stations can be recover")
        self.myPA.assertProcessAliveOnStations(masterBE, process, stations)
        """

        LOGGER.debug("check the alarms")
        # check the alarms on ONE node, make sure that all expect alarm are raised, and no abnormal alarms, eg:
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared (done in assertEndState)
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(self.testEnv.testBed.labs.values()[0], myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
            #LOGFILE[1] is a csv file used to save alarms raised since test case is running
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.exception("%s: alarm check fail", self.testEnv.testBed.labs.values()[0].id)

        # check the end status of the test env, make sure that the test env can be recover
        LOGGER.debug("check the end status of the test env")
        # LOGFILE[2] is a csv file used to save active alarms after test case end
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
