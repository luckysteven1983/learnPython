'''
Created on Apr 29, 2015

@author: Xia Zhao

'''
import unittest
from framework.sdm_test_case import SDMTestCase
from framework.testenv.lab import Lab
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
OAMGSUITE_PROCESS_NAME = "OamGSUITE"

class mcas_application_manager_nightly_test_once(SDMTestCase):
    ''' Test for McasApplicationManager
    '''

    def setUp(self):
        LOGGER.info("McasApplicationManagerTest Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.proxyFes = self.testEnv.testBed.getProvFrontends()
        if len(self.proxyFes) > 0:
            _, self.proxyFe = self.proxyFes.popitem()
            self.withProxyFe = True
        else:
            self.withProxyFe = False
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        self.maManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager

    def tearDown(self):
        pass


    def test_01_getSPAVersion_success(self):
        LOGGER.info("unit test: get spa version success")
        self.assertRegexpMatches(self.maManager.getSPAVersion(self.fe, 'sdm'), '[0-9]{3}')
        self.assertRegexpMatches(self.maManager.getSPAVersion(self.fe, 'oam'), '[0-9]{3}')
        self.assertRegexpMatches(self.maManager.getSPAVersion(self.be, 'oambe'), '[0-9]{3}')
        if self.withProxyFe:
            self.assertRegexpMatches(self.maManager.getSPAVersion(self.proxyFe, 'proxy'), '[0-9]{3}')


    def test_02_getSPAVersion_fail(self):
        LOGGER.info("unit test: get spa version fail, check exception raised")
        self.assertRaises(BaseException, self.maManager.getSPAVersion, self.be, 'sdm')
        self.assertRaises(BaseException, self.maManager.getSPAVersion, self.fe, 'oambe')
        if self.withProxyFe:
            self.assertRaises(BaseException, self.maManager.getSPAVersion, self.proxyFe, 'xyz')
        self.assertRaises(BaseException, self.maManager.getSPAVersion, self.be, 'abc')


    def test_03_getSPAStatus_success(self):
        LOGGER.info("unit test: get spa status success")
        statusSDM = self.maManager.getSPAStatus(self.fe, 'sdm')
        LOGGER.debug("get fe sdm spa output:\n" + str(statusSDM))
        self.assertEqual(statusSDM['SPA STATE'], 'IS')
        self.assertEqual(statusSDM['0-0-2'], 'IS')
        self.assertEqual(statusSDM['SSN']['311'], 'IS')

        statusOAM = self.maManager.getSPAStatus(self.fe, 'oam')
        LOGGER.debug("get fe oam spa output:\n" + str(statusOAM))
        self.assertEqual(statusOAM['SPA STATE'], 'IS')
        self.assertIn(statusOAM['0-0-1'], ['IS', 'OOS'])
        self.assertIn(statusOAM['0-0-9'], ['IS', 'OOS'])
        self.assertEqual(statusOAM['SSN']['256'], 'IS')

        if self.withProxyFe:
            statusPROXY = self.maManager.getSPAStatus(self.proxyFe, 'proxy')
            LOGGER.debug("get fe proxy spa output:\n" + str(statusPROXY))
            self.assertEqual(statusPROXY['SPA STATE'], 'IS')
            self.assertIn(statusPROXY['0-0-1'], ['IS', 'OOS'])
            self.assertIn(statusPROXY['0-0-9'], ['IS', 'OOS'])
            self.assertEqual(statusPROXY['SSN']['256'], 'IS')

        statusOAMBE = self.maManager.getSPAStatus(self.be, 'oambe')
        LOGGER.debug("get be oam spa output:\n" + str(statusOAMBE))
        self.assertEqual(statusOAMBE['SPA STATE'], 'IS')
        self.assertIn(statusOAMBE['0-0-9'], ['IS', 'OOS'])
        self.assertIn(statusOAMBE['0-0-1'], ['IS', 'OOS'])
        self.assertEqual(statusOAMBE['SSN']['256'], 'IS')


    def test_04_getSPAStatus_fail(self):
        LOGGER.info("unit test: get spa status fail, check exception raised")
        self.assertRaises(BaseException,
                                self.maManager.getSPAStatus, self.fe, 'oambe')
        self.assertRaises(BaseException,
                                self.maManager.getSPAStatus, self.fe, 'OAMBE099')
        self.assertRaises(BaseException,
                                self.maManager.getSPAStatus, self.be, 'sdm')
        self.assertRaises(BaseException,
                                self.maManager.getSPAStatus, self.be, 'abc')
 
    def test_05_getAllSPAStatus_success(self):
 
        spaStateSDM1 = {'SPA NAME': 'SDM[0-9]{3}', 'SPA STATE': 'IS',
                        'SSN': '311', 'SSN STATE': 'IS'}
        spaStateSDM3 = {'SPA NAME': 'SDM[0-9]{3}', 'SPA STATE': 'IS',
                        'SSN': '313', 'SSN STATE': 'IS'}
        spaStateSDM4 = {'SPA NAME': 'SDM[0-9]{3}', 'SPA STATE': 'IS',
                        'SSN': '6', 'SSN STATE': 'IS'}
        spaStateSDM5 = {'SPA NAME': 'SDM[0-9]{3}', 'SPA STATE': 'IS',
                        'SSN': '9', 'SSN STATE': 'IS'}
        spaStateSDM = {'311': spaStateSDM1,
                       '313': spaStateSDM3,
                       '6': spaStateSDM4,
                       '9': spaStateSDM5}
 
        spaBE = self.maManager.getAllSPAStatus(self.be)
        LOGGER.debug("get be all spa output:\n" + str(spaBE))
 
        spaFE = self.maManager.getAllSPAStatus(self.fe)
        LOGGER.debug("get fe all spa output:\n" + str(spaFE))
        for ssnKey in spaFE['SDM'].keys():
            if ssnKey in spaStateSDM.keys():
                for keyValue in spaStateSDM1.keys():
                    self.assertRegexpMatches(spaFE['SDM'][ssnKey][keyValue], spaStateSDM[ssnKey][keyValue])
 
    def test_06_getAllSPAStatus_fail(self):
        LOGGER.info("unit test: get all spa status fail, check exception raised")
        self.fe1 = Lab()
        self.fe1.productRole = None
        self.assertRaises(BaseException,
                                self.maManager.getAllSPAStatus, self.fe1)
 
    def xtest_07_removeSPA_success(self):
        LOGGER.info("unit test: remove SPA success")
        self.maManager.removeSPA(self.fe, 'oam')
 
    def xtest_08_removeSPA_fail(self):
        LOGGER.info("unit test: remove SPA fail, check exception raised")
        self.assertRaises(BaseException,
                                self.maManager.removeSPA, self.fe, 'oam')
 
    def xtest_09_deleteSPA_success(self):
        LOGGER.info("unit test: delete proc SPA success")
        self.maManager.deleteSPA(self.fe, 'oam')
 
    def xtest_10_deleteSPA_fail(self):
        LOGGER.info("unit test: delete proc SPA fail, check exception raised")
        self.assertRaises(BaseException, self.fe.id + ": " + 'oam' + ": " + msgs.DEL_PROC_SPA_FAIL,
                                self.maManager.deleteSPA, self.fe, 'oam')
 
    def xtest_11_installSPA_success(self):
        LOGGER.info("unit test: install proc SPA success")
        self.maManager.installSPA(self.fe, 'oam')
 
    def xtest_12_installSPA_fail(self):
        LOGGER.info("unit test: install proc SPA fail, check exception raised")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'oam' + ": " + msgs.INSTALL_PROC_SPA_FAIL,
                                self.maManager.installSPA, self.fe, 'oam')
 
    def xtest_13_restoreSPA_success(self):
        LOGGER.info("unit test: rst SPA success")
        self.maManager.restoreSPA(self.fe, 'oam')
 
    def xtest_14_restoreSPA_fail(self):
        LOGGER.info("unit test: rst SPA fail, check exception raised")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'oam' + ": " + msgs.RST_SPA_FAIL,
                                self.maManager.restoreSPA, self.fe, 'oam')
 
    def xtest_15_restartSPA(self):
        LOGGER.info("unit test: restart OAM SPA success")
        self.maManager.restartSPA(self.fe, 'oam')
        LOGGER.info("unit test: restart SDM SPA success")
        self.maManager.restartSPA(self.fe, 'SDM')
        LOGGER.info("unit test: restart OAMBE SPA success")
        self.maManager.restartSPA(self.be, 'oambe')
 
    def test_16_assertNoSPA_success(self):
        LOGGER.info("try to assert spa oambe is not on fe")
        self.maManager.assertNoSPA(self.fe, 'oambe')
        LOGGER.info("try to assert spa oam is not on be")
        self.maManager.assertNoSPA(self.be, 'oam')
        LOGGER.info("try to assert spa sdm is not on be")
        self.maManager.assertNoSPA(self.be, 'sdm')
 
    def test_17_assertNoSPA_failed(self):
        LOGGER.info("try to assert spa oambe is on be")
        self.assertRaisesRegexp(BaseException, self.be.id + ": " + 'oambe' + ": " + msgs.ASSERT_NO_SPA_FAIL,
                                self.maManager.assertNoSPA, self.be, 'oambe')
        LOGGER.info("try to assert spa oam is on fe")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'oam' + ": " + msgs.ASSERT_NO_SPA_FAIL,
                                self.maManager.assertNoSPA, self.fe, 'oam')
        LOGGER.info("try to assert spa sdm is on fe")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'sdm' + ": " + msgs.ASSERT_NO_SPA_FAIL,
                                self.maManager.assertNoSPA, self.fe, 'sdm')
 
    def test_18_assertSPAStateOnce_success(self):
        LOGGER.info("try to assert spa oambe is IS")
        self.maManager.assertSPAState(self.be, 'oambe', 'IS')
        LOGGER.info("try to assert spa oam is IS")
        self.maManager.assertSPAState(self.fe, 'oam', 'IS')
        LOGGER.info("try to assert spa sdm is IS")
        self.maManager.assertSPAState(self.fe, 'sdm', 'IS')
 
    def test_19_assertSPAStateOnce_fail(self):
        LOGGER.info("try to assert spa oambe is not EQP")
        self.assertRaisesRegexp(BaseException, self.be.id + ": " + 'oambe' + ": " + msgs.ASSERT_SPA_STATE_FAIL,
                                self.maManager.assertSPAState, self.be, 'oambe', 'EQP')
        LOGGER.info("try to assert spa oam is not OOS")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'oam' + ": " + msgs.ASSERT_SPA_STATE_FAIL,
                                self.maManager.assertSPAState, self.fe, 'oam', 'OOS')
        LOGGER.info("try to assert spa sdm is not MOOS")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'sdm' + ": " + msgs.ASSERT_SPA_STATE_FAIL,
                                self.maManager.assertSPAState, self.fe, 'sdm', 'MOOS')
        LOGGER.info("try to assert spa oambe on fe is IS fail")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'oambe' + ": " + msgs.ASSERT_SPA_STATE_FAIL,
                                self.maManager.assertSPAState, self.fe, 'oambe', 'IS')
        LOGGER.info("try to assert spa oam on be is IS fail")
        self.assertRaisesRegexp(BaseException, self.be.id + ": " + 'oam' + ": " + msgs.ASSERT_SPA_STATE_FAIL,
                                self.maManager.assertSPAState, self.be, 'oam', 'IS')
    def test_20_getOAMService_success(self):
        LOGGER.info("unit test: get get OAM Service success")
        serviceList = self.maManager.getOAMService(self.fe)
        LOGGER.debug(str(serviceList))
        self.assertIn('OamGSUITE', serviceList)
 
    def test_21_killOAM_success(self):
        LOGGER.info("unit test: kill OAM Service success")
        activePilot = self.mcasMachineManager.getActivePilot(self.fe)
        self.maManager.killOamAndWaitRecover(self.fe, activePilot, OAMGSUITE_PROCESS_NAME)
 
    def test_22_abortSPA_success(self):
        LOGGER.info("unit test: abort SPA success")
        self.maManager.abortSPA(self.fe, 'oam')
 
    def test_23_abortSPA_fail(self):
        LOGGER.info("unit test: abort SPA fail, check exception raised")
        self.assertRaisesRegexp(BaseException, self.fe.id + ": " + 'abc' + ": " + msgs.ABT_SPA_FAIL,
                                self.maManager.abortSPA, self.fe, 'abc')
 
    def test_24_installSPA_success(self):
        LOGGER.info("unit test: install proc SPA success")
        self.maManager.installSPA(self.fe, 'oam')
 
    def test_25_restoreSPA_success(self):
        LOGGER.info("unit test: rst SPA success")
        self.maManager.restoreSPA(self.fe, 'oam')
 
    def test_30_assertSPAStateOnStations_success(self):
 
        bePilot = self.mcasMachineManager.getActivePilotAsStation(self.be)
        # beSTation = self.be.getStationsFromBlades(pilot)
        LOGGER.info("try to assert spa oambe is IS")
        self.maManager.assertSPAStateOnStations(self.be, 'oambe', 'IS', [bePilot])
 
        fePilot = self.mcasMachineManager.getActivePilotAsStation(self.fe)
        LOGGER.info("try to assert spa oam is IS")
        self.maManager.assertSPAStateOnStations(self.fe, 'oam', 'IS', [fePilot])
 
        LOGGER.info("try to assert spa sdm is IS")
        self.maManager.assertSPAStateOnStations(self.fe, 'sdm', 'IS', self.fe.getStationListbyProductRole('RT').values())
 
        LOGGER.info("try to assert spa sdm is IS")
        self.maManager.assertSPAStateOnStations(self.fe, 'sdm', 'IS', [self.fe.getStationListbyProductRole('RT').values()[-1]])
 
        # must give an error (spa is  not existent)
        bePilot = self.mcasMachineManager.getActivePilotAsStation(self.be)
        LOGGER.info("try to assert spa oam is IS")
        try:
            self.maManager.assertSPAStateOnStations(self.be, 'oam', 'IS', [bePilot])
        except AssertionError:
            print ' ( Expected Error ) '
 
 
    def test_31_assertSPAStateOnStations_expectedError(self):
 
        # must give an error (spa 'oam'  not existent on a BE)
        bePilot = self.mcasMachineManager.getActivePilotAsStation(self.be)
        LOGGER.info("try to assert spa oam is IS")
        try:
            self.maManager.assertSPAStateOnStations(self.be, 'oam', 'IS', [bePilot])
        except AssertionError:
            print ' ( Expected Error ) '
 
    def test_32_assertSPAStateOnStations_success(self):
 
        self.maManager.assertLocalProcessState(self.be, 'oambe', 'IS')
        self.maManager.assertLocalProcessState(self.fe, 'oam', 'IS')
        self.maManager.assertLocalProcessState(self.fe, 'SDM', 'IS')


if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
