"""
Created on Sept 23, 2015
@author: Claude Le Du
"""

class Router(object):
    """
    @details This class describes a router interface
    """

    def __init__(self, routerId, routerIp, routerType, account, prompt):
        self.routerId = routerId
        self.routerIp = routerIp
        self.type = routerType
        self.account = account
        self.prompt = prompt

    def clearARPTables(self):
        """ Run "clear arp-cache" command on router """
        raise NotImplementedError("Not implemented")

    def showVlan(self, port=False):
        """ Run "show vlan" command on router """
        raise NotImplementedError("Not implemented")

    def showInterfaces(self):
        """ Run "show interfaces port" command on router """
        raise NotImplementedError("Not implemented")

    def interfaceUp(self, interface):
        """ Set given interface up on router """
        raise NotImplementedError("Not implemented")

    def interfaceDown(self, interface):
        """ Set given interface down on router """
        raise NotImplementedError("Not implemented")

    def enableVlan(self, vlan):
        """ Enable given vlan """
        raise NotImplementedError("Not implemented")

    def disableVlan(self, vlan):
        """ Disable given vlan """
        raise NotImplementedError("Not implemented")
