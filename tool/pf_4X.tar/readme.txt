perf_tool is a series tools that extracts our concerned performance data among the logs collected by pt_tool.

It has some dependency of pt_tool, such as directory dependency. Which means you must have executed "pt done" and create Done directory under $LOG_DIR.

Also, bandwidth dependons the configuration of "log.ini" and lab's IP plan.

If you use a different IP plan, you should make some modifications accordingly.

Now, I will show the usage of this tool:

First, you should extract perf_tool.tar to directory /MDS. This is mandatory.

Second, analysis oam performance data:

Example: /MDS/perf_tool/report.sh /PLATsoftware/pt/1FE.3NRG.3PDLS.100ms.1E-5.HP15

The tool will create a dir Result under /PLATsoftware/pt/1FE.3NRG.3PDLS.100ms.1E-5.HP15.

And you will get the final report and process.xls:

------------------------------------------------------------------------------------------------
                            Oam CPU Statistics  Result                                          
------------------------------------------------------------------------------------------------
Max(pilot_cpu) Avg(pilot_cpu)
100.0%         2.4%
------------------------------------------------------------------------------------------------
                            OamCOMM Average CPU Usage Statistics  Result                        
------------------------------------------------------------------------------------------------
Process  Avg(cpu)
oamCOMM  0.00
------------------------------------------------------------------------------------------------
                            Oam Bandwidth Statistics  Result                                    
------------------------------------------------------------------------------------------------
Router      AvgIn(Mb/s) AvgOut(Mb/s)
route242        244.60  745.68
route243        5.25    5.13

The cpu and memory of oamCOMM will be save in process.xls. You can copy the chart as your test report.

Third, analysis fe performance data:

Example: /MDS/perf_tool/fe_report.sh /PLATsoftware/pt/1FE.3NRG.3PDLS.100ms.1E-5.HP15

------------------------------------------------------------------------------------------------
                            Simp Statistics  Result                                             
------------------------------------------------------------------------------------------------
Type    Total Success   Total Failed    Total Failed3004        Total Failed5012        Total Lost      Total TPS       Qos
HSS     134019987       460             0                        321                        0          17322.62         2.40e-06
LTE     140954406       6               0                          6                        0          17479.15         4.26e-08
Total   274974393       466             0                        327                        0          34801.77         1.19e-06
------------------------------------------------------------------------------------------------
                            FE Hottest CPU and average CPU Usage Statistics  Result             
------------------------------------------------------------------------------------------------
Max(cpu) Avg(cpu)
40.7%    23.8%
------------------------------------------------------------------------------------------------
                            FE Memory Usage Statistics  Result                                  
------------------------------------------------------------------------------------------------
Avg(mem)(M)
3027.55
------------------------------------------------------------------------------------------------
                            PDLSI/L/U Average CPU Usage Statistics  Result                      
------------------------------------------------------------------------------------------------
Process  Avg(cpu)
PDLSI1  93.35
PDLSI2  92.85
PDLSI3  93.53
PDLSL1  82.29
PDLSL2  81.95
PDLSL3  82.28
PDLSU1  0.47
------------------------------------------------------------------------------------------------
                            FE Bandwidth Statistics  Result                                     
------------------------------------------------------------------------------------------------
Router      AvgIn(Mb/s) AvgOut(Mb/s)
route242        244.60  745.68
route243        5.25    5.13
 
Forth, analysis be performance data:

Example: /MDS/perf_too/be_report.sh /PLATsoftware/mielke/pt/Stability/run-20130213/HP18 

------------------------------------------------------------------------------------------------
                            BE Hottest CPU and average CPU Usage Statistics  Result             
------------------------------------------------------------------------------------------------
Max(cpu) Avg(cpu)
63.5%    18.9%
------------------------------------------------------------------------------------------------
                            BE Memory Usage Statistics  Result                                  
------------------------------------------------------------------------------------------------
Avg(mem)(M)
30683.64
------------------------------------------------------------------------------------------------
                            GdmpServer & ndbmtd Average CPU Usage Statistics  Result            
------------------------------------------------------------------------------------------------
Process  Avg(cpu)
GdmpServer      222.06
ndbmtd  149.30
------------------------------------------------------------------------------------------------
                            BE Bandwidth Statistics  Result                                     
------------------------------------------------------------------------------------------------
Router      AvgIn(Mb/s) AvgOut(Mb/s)
route242        399.23  109.54
route243        0.06    0.06

