"""
@file rcv_menu.py
@ingroup SDMSQA
@author Cassandra Lajeunie
@date 2015-11-02
@brief Run RCV menu command and return the response. Based on FV1

Allow to insert/review/update/delete rcv entries
"""
from lib.logging.logger import Logger
import datetime

LOGGER = Logger.getLogger(__name__)

class RcvMenuManager(object):
    """
    Used to Run a RCV menu command (operation + command) and return the response.
    """

    opeDict = {"VFY":3, "NEW":4, "OUT":5, "CHG":6}

    def __init__(self, sshManager):
        """Init RcvMenuManager instance with sshManager.
        @param sshManager: SSH or other protocol instance used for remote command execution
        """
        self._sshManager = sshManager

    def _operationIsAllowed(self, operation):
        """
        Identify if the operation is an allowed one
        @param operation: string, the operation to perform
        @return boolean
        """
        if operation not in self.opeDict:
            LOGGER.debug("the operation ' %s ' you try to do is not an allowed one, please use one of the following : \n -new: create an entry \n -vfy: review an entry \n -chg: update an entry \n -out: delete an entry" %operation)
            return False
        else:
            return True

    def _commandInput(self, lab, cmd_string):
        """
        Write the standard command list in the form.in file and copy it to the /tmp repository of the lab
        @param lab: a lab object
        @param cmd_string: the commands
        @return filename
        """
        theDate = str(datetime.datetime.now()).replace(" ","_")
        fileName = "/tmp/form"+ theDate +".in"
        cmd = "echo '" + cmd_string + "' > '" + fileName + "'"
        LOGGER.debug("create a tmp file containing " + cmd_string)
        self._sshManager.run(lab.oamIpAddress, cmd)
        LOGGER.debug("execute command : chmod 777 " + fileName)
        self._sshManager.run(lab.oamIpAddress,"chmod 777 "+ fileName)
        return fileName

    def _outputReturn(self, cmd_rt):
        """
        Output the selected output message of the operation
        If operation is vfy, return verified form info
        If operation fail, return the error message
        @param cmd_rt : return message of the operation
        @return String
        """
        return cmd_rt[:cmd_rt.rfind("attaching to MSGH")]

    def run_rcv(self, lab, rcvCmd):
        """
        perform an operation using the rcvCmd string with sendRC command
        You can only send ONE operation on ONE form at a time
        @param lab: a Lab object
        @param rcvCmd: the string sent to the SendRC command
        @return [returnCode,msg]: the returnCode of the operation and the message to display
        @verbatim
        cmd = FORM=CR_NODEEQUIPMENT&CHG\n\"UNIT ID\"=\"1235\"\n\"DATE OF MANUFACTURE\"=\"1\"\nCHG
        rcv.run(lab, cmd)
        see unittest for more examples

        some advice concerning the rcvCmd parameter :
        1.the elements of the command have to be in upper case and separated by \n
        2.the first element is the form and action (does not contain quotes) : \
        FORM=FORM_NAME&OPERATION.
        3.allowed operations are NEW, VFY, CHG and OUT
        4.last element is the action (does not contain quotes)
        5.the other elements are the fields and corresponding values: \
        "FIELD NAME"="FIELD VALUE"
        6.the form name is same with the it's name in database
            note:the FORM name in CMDSTRING use the DB like form naming convention,\
             so when get the form name in the rcvmenu then find the corresponding name\
             in following file
            1> http://inserv.ih.lucent.com/~compas1/ and search COMPAS ID:189402 \
            find doc(rcplatodin.item line)
            2> /opt/config/data/RCform2DBmappings
        7.for vfy/out, form and the whole base key field(same as operate manually)\
         is added for new, the form and the whole field is added, for chg,\
          the whole basic key field and the field plan to update is added

        example of output for a vfy operation:
        ----- stdout :
        UNIT ID=1235
        DATE OF MANUFACTURE=0
        DATE OF LAST SERVICE=0
        INV UNIT TYPE=0
        MANUFACTURING DATA=0
        SERIAL NUMBER=0
        UNIT POSITION=0
        VENDOR NAME=0
        VENDOR UNIT FAMILY TYPE=0
        VENDOR UNIT TYPE NUMBER=0
        VERSION NUMBER=0
        CLEI CODE=0
        attaching to MSGH ...
        registering 22451/cs/sn/utest/rc/sendRC with MSGH ...
        initializing timers ...
        building RCplatTextReq msg for /tmp/form2015-11-09_10:47:57.920483.in...
        sending RCplatTextReq message ...
        set a 300 second timer for waiting ...
        wait for an event ...
        received an RCplatTextReqAck msg ...
        SUCCESS for /tmp/form2015-11-09_10:47:57.920483.in, forms = 1.
        output file is /tmp/RC9537v.
        all done. good bye !!!

        
        output for other successfull operation:
         ----- stdout :
        attaching to MSGH ...
        registering 23060/cs/sn/utest/rc/sendRC with MSGH ...
        initializing timers ...
        building RCplatTextReq msg for /tmp/form2015-11-09_10:48:04.537924.in...
        sending RCplatTextReq message ...
        set a 300 second timer for waiting ...
        wait for an event ...
        received an RCplatTextReqAck msg ...
        SUCCESS for /tmp/form2015-11-09_10:48:04.537924.in, forms = 1.
        No output file was sent.
        all done. good bye !!!

        @endverbatim
        """
        operation = rcvCmd.split("\n")[-1]
        if self._operationIsAllowed(operation):
            fileName = self._commandInput(lab, rcvCmd)
            sendRcCmd = " /cs/sn/utest/rc/sendRC -c plat " + fileName
            rc, stdout = self._sshManager.run(lab.oamIpAddress, sendRcCmd)

            msg = ""
            if rc:
                returnCode = self.opeDict[operation]
                msg += operation + " rcvmenu failed\n"
                LOGGER.error(operation + " rcvmenu failed")
                output = self._outputReturn(stdout)
                msg += "error info is: " + str(output) + "\n please check the docstring to make sure you wrote the command correctly \n"
                LOGGER.error("error info is: " + str(output))
                LOGGER.error("please check the docstring to make sure you wrote the command correctly")
            else:
                returnCode = 0
                msg += operation + " rcvmenu successfully\n"
                LOGGER.debug(operation + " rcvmenu successfully")
                if operation == "vfy":
                    output = self._outputReturn(stdout)
                    msg += "vfy table info is: " + str(output) + "\n"
                    LOGGER.debug("vfy table info is: " + str(output))
            self._sshManager.run(lab.oamIpAddress, "rm "+fileName)
        else:
            returnCode = 7
            msg = "The operation you try to perform is not part of the allowed ones"
            LOGGER.error("the operation %s you try to perform is not an allowed one, please check the docstring" %operation)
        return returnCode, msg