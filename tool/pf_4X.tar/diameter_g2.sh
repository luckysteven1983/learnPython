#!/bin/bash

###############################################
# Usage: $0 <debug log directory>
##############################################
currentpath=$(cd "$(dirname "$0")"; pwd)
cd $1
for file in `ls -lrt|grep debug|awk '{print $9}'`
do    
   grep -B 2 -A 29 "line:1852" $file >> PDLSL
   grep -B 2 -A 32 "line:1720" $file >> PDLSI
done
for key in PDLSL PDLSI
do
   for process in `grep ${key} top_*|awk '{print $NF}'|sort|uniq`
	do 
        if [ $key="PDLSL" ]
             then 
                grep -B 1 -A 30 ${process} ${key} > ${process}
             else 
                grep -B 1 -A 33 ${process} ${key} > ${process}
        fi
        
        for sta in 2 4 5 6 7 8 10 12 13 14 15 16
        do
             if [ $key="PDLSL" ]
             then 
                grep -A 31 0-0-${sta}  ${process} > ${process}_0-0-${sta}
             else 
                grep -A 34 0-0-${sta}  ${process} > ${process}_0-0-${sta}
             fi
             
#            grep "+++"  ${process}_0-0-${sta}|awk '{print $3 "-" $4}' > ${process}_0-0-${sta}.time
             
             for measure in `cat ${currentpath}/conf/${key}_G2|awk '{print $1}'`
             do
               echo 0-0-${sta} > ${process}_0-0-${sta}.${measure}
               grep ${measure} ${process}_0-0-${sta} | awk -F:  '{print $2}' >> ${process}_0-0-${sta}.${measure}
             done   
             rm ${process}_0-0-${sta}
         done
         
         for measure in `cat ${currentpath}/conf/${key}_G2|awk '{print $1}'`
         do
             paste ${process}_0-0-2.${measure} ${process}_0-0-4.${measure} ${process}_0-0-5.${measure} ${process}_0-0-6.${measure} ${process}_0-0-7.${measure} ${process}_0-0-8.${measure} ${process}_0-0-10.${measure} ${process}_0-0-12.${measure} ${process}_0-0-13.${measure} ${process}_0-0-14.${measure} ${process}_0-0-15.${measure} ${process}_0-0-16.${measure} > ${process}_${measure}.txt
             rm ${process}_0-0-2.${measure} ${process}_0-0-4.${measure} ${process}_0-0-5.${measure} ${process}_0-0-6.${measure} ${process}_0-0-7.${measure} ${process}_0-0-8.${measure} ${process}_0-0-10.${measure} ${process}_0-0-12.${measure} ${process}_0-0-13.${measure} ${process}_0-0-14.${measure} ${process}_0-0-15.${measure} ${process}_0-0-16.${measure} 
         done
          
      rm ${process}                
   done
   rm  ${key}
done
