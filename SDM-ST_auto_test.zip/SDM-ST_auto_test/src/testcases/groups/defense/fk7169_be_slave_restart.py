'''
Created on Oct 14, 2015

@author: Tangi Lavanant
#weblink_id=3KJ-00117-5621-QPZZA
'''


import os
import time
import unittest

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_state_manager import DDM_DB_NDB_WAIT_REACHEABLE
from lib.health_check.health_check_manager import HEALTH_CHECK_ASSERT_TIME_INTERVAL
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import SPA_STATE_ASSERT_TIME
from lib.platform.mcas.mcas_platform_manager import MCAS_RESTART_PF_BEFORE_CHECK_TIMER, \
    MCAS_RESTART_PF_TIMEOUT


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fk7169_be_slave_restart(SDMTestCase):
    """
    Goal of the test is :
    Traffic at 100% of max dynamic capacity for VoLTE MixRef + vBE SLAVE restart- 50ms +2E-4PL
    Only restart vBE SLAVE restart is done here
    Traffic done by other tools
    pfboot on BE slave
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_pfboot_slave_BE(self):
        """restart by pfboot on slave BE

        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.info("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.info("run test case test_pfboot_slave_BE")
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        # Half cluster reset on any slave BE.
        slaveBE = self.sdmManager.databaseStateManager.getSlaveBE(self.allBEs)[0]
        LOGGER.info("fw pfboot on slave BE %s", slaveBE.id)
        self.sdmManager.mcasPlatformManager.restartPlatformByPfboot(slaveBE)
        # wait 10 min as we can not assert NDB state during this time
        LOGGER.info("Waiting %i seconds for NDB to be up on slave BE %s",
                     MCAS_RESTART_PF_BEFORE_CHECK_TIMER + MCAS_RESTART_PF_TIMEOUT , slaveBE.id)
        time.sleep(DDM_DB_NDB_WAIT_REACHEABLE)
        # We need to wait all NDB become started.
        CommonAssert.timedAssert(MCAS_RESTART_PF_TIMEOUT, SPA_STATE_ASSERT_TIME,
                                 self.sdmManager.databaseStateManager.assertNdbState,
                                 slaveBE, 'started', logLevel='debug')
        LOGGER.info("Waiting for OAMBE SPA state to be IS")
        CommonAssert.timedAssert(MCAS_RESTART_PF_TIMEOUT, SPA_STATE_ASSERT_TIME,
                                  self.sdmManager.mcasApplicationManager.assertSPAState,
                                        slaveBE, 'oambe', 'IS', logLevel='debug')
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        CommonAssert.timedAssert(MCAS_RESTART_PF_TIMEOUT, HEALTH_CHECK_ASSERT_TIME_INTERVAL,
                                 self.sdmManager.healthCheckManager.runCheckAll, slaveBE)
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.info("test case post-check")
        time.sleep(10)
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)

if __name__ == "__main__":
    unittest.main()
