"""
@file env_health_check.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-16
@brief env health check before test case execution
"""

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class env_health_check(SDMTestCase):
    """Env Health Check
    """

    def test_env_health_check(self):
        """run health check in parallel
        """
        multiTasks = self.sdmManager.multiTasksManager
        LOGGER.info("Clear alarm on all Labs in progress")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        for lab in self.testEnv.testBed.labs.values():
            threadName = multiTasks.register(self.sdmManager.currentAlarmManager.clearActiveAlarm, lab)
            LOGGER.debug("Clear alarm on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        LOGGER.debug("Wait clear alarm complete on all Labs")
        if not multiTasks.runMultiTasks():
            LOGGER.error("Clear alarm failure")
            raise BaseException
        LOGGER.info("Health check on all Labs in progress")
        for lab in self.testEnv.testBed.labs.values():
            threadName = multiTasks.register(self.sdmManager.healthCheckManager.runCheckAll, lab)
            LOGGER.debug("Health check on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        LOGGER.debug("Wait health check complete on all Labs")
        if not multiTasks.runMultiTasks():
            LOGGER.error("Health check failure")
            raise BaseException
