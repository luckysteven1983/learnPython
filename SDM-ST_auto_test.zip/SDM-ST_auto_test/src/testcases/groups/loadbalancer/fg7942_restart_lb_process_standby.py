'''
Created on Sept 04, 2015

@author: Claude Le Du
'''

import random
import os
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fg7942_restart_lb_process_standby(SDMTestCase):
    """ Restart Load Balancer standby process on FE """


    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsBE = []
        self.acceptedAlarmsBE = []
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.fe = random.choice(self.allFEs)
        self.success = True
        self.exceptMsg = ""


    def test_restart_lb_process_standby(self):
        """ Restart Load Balancer standby process on FE """
        if self.fe.hardware not in ["HPG6", "HPG8", "BONO24", "BONO48", "VMMHI"]:
            LOGGER.warn("fg7942_restart_lb_process_standby is only for BONO and HP")
            LOGGER.warn("Skipping fg7942_restart_lb_process_standby...")
            return
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)


    def _precheck(self):
        """Test case pre-check and return current active alarm list """
        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        """ Restart Load Balancer standby process on FE """
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)
        LOGGER.debug("Restart Load Balancer standby process on FE " + self.fe.id + " at: " + startTime)

        LOGGER.debug("Get standby load balancer board")
        standbyLB = self.sdmManager.asrloadbalancerManager.getStandbyLB(self.fe)
        LOGGER.info("Restart standby load balancer process on board " + standbyLB + " on " + self.fe.id)
        self.sdmManager.asrloadbalancerManager.restartLBProcess(self.fe, standbyLB)
        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", self.fe.id)
        return startTime


    def _postcheck(self, startTime):
        """ Test case post-check"""
        LOGGER.debug("Test case post-check")
        LOGGER.debug("Check the alarms")
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(self.expectedAlarmsBE, self.acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("fg7942_restart_lb_process_standby success!\n")
        else:
            LOGGER.error("fg7942_restart_lb_process_standby failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)

