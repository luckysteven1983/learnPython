#!/bin/bash

#######################################################
#       usage: $0 <PT tool logs directory>
#       $LOG_DIR=<PT tool logs directory>
#######################################################  
if [ $# -ne 1 ];
then
  echo $0 LOG_DIR
  echo
fi
log_dir=$1

tool_dir=$(cd "$(dirname "$0")"; pwd)
cd $log_dir
################################################################
# The tool will save the result under directory $LOG_DIR/Result.
################################################################
if [ -d $1/Result ]
then
  rm -r $1/Result;mkdir $1/Result
else
  mkdir -p $1/Result
fi

echo Hostname > $1/Result/fe_${hostname}_report.xls  
hostname=`hostname|awk -F"-" '{print $1}'`
echo `hostname|awk -F"-" '{print $1}'` >> $1/Result/fe_${hostname}_report.xls

HW=`grep 'name="HARDWARE"' /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `
if [[ "$HW" =~ "HP" ]];then
    ## HPblade case
    HW="HP"
elif [[ "$HW" =~ "BONO" ]];then
        ##  case
        HW="BONO"
else
        ## ROUZIC case
        HW="ROUZIC"   
fi

###############################################################
# If all the simp logs are stored in $LOG_DIR, parse them.
###############################################################
ls -lrt | awk '{ print $9 }' | grep "tar"  > /dev/null
if [ $? -eq 0 ]
then
  for tar_file in `ls *.tar`
  do
     tar xf $tar_file > /dev/null
  done
fi

simp_num=`ls -lrt simp*|wc -l`
if [ $simp_num -gt 0 ]
then 
  echo "Parsing simp data ......."
  $tool_dir/simp.sh $log_dir
  echo "Parsing simp data done."
  echo "------------------------------------------------------------------------------">$1/Result/report_${hostname}
  echo "|               Diameter Traffic Statistics  Result                          |">>$1/Result/report_${hostname}
  echo "------------------------------------------------------------------------------">>$1/Result/report_${hostname}
  cat simp.result >> $1/Result/report_${hostname}
  rm simp.result 
fi


###############################################################
#FE Hottest CPU and average CPU usage statistics
###############################################################
cd $log_dir/Done
echo "Parsing cpu data ......"
$tool_dir/top_cpu.sh 
echo "---------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "|            FE Hottest CPU and average CPU Usage Statistics  Result             |">>$1/Result/report_${hostname}
echo "----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat top_cpu.report >> $1/Result/report_${hostname}
paste $1/Result/fe_${hostname}_report.xls top_cpu.summary > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls
echo "Parsing cpu data done."

if [[ "$HW" = "HP" ]]; then
	$tool_dir/iLB_cpu.sh
        if [ -f iLB_cpu.result ];
        then
		echo "-------------------------------------------------------------------------------">>$1/Result/report_${hostname}
		echo "|           ILB Hottest CPU and average CPU Usage Statistics  Result          |">>$1/Result/report_${hostname}
		echo "-------------------------------------------------------------------------------">>$1/Result/report_${hostname}
		cat iLB_cpu.result >> $1/Result/report_${hostname}
		rm iLB_cpu.result
        fi
fi 
################################################################
# FE memory statistics
# Memory=used - buffer - cache
################################################################
echo "Parsing memory data ......"
$tool_dir/top_memory.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "|                  FE Memory Usage Statistics  Result                             |">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat top_mem.report >> $1/Result/report_${hostname}
paste $1/Result/fe_${hostname}_report.xls oam_mem.summary > $1/Result/fe_${hostname}_report.tmp
paste $1/Result/fe_${hostname}_report.tmp nonpilot_mem.summary > $1/Result/fe_${hostname}_report.xls
rm $1/Result/fe_${hostname}_report.tmp
mv *mem.txt $1/Result
echo "Parsing memory data done."


################################################################
# FE run queue statistics
################################################################
echo "Parsing run queue data ......"
$tool_dir/nonpilot_vmstat.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "|                    FE Run Queue Statistics  Result                              |">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat runque.xls >> $1/Result/report_${hostname}
paste $1/Result/fe_${hostname}_report.xls runque.xls > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls
rm runque.xls
echo "Parsing run queue data done."
################################################################
# FE process statistics
################################################################
echo "Parsing PDLSI/L/U cpu & memory data ......"
#dir=`pwd`
#echo "Current direcotry is $dir"
$tool_dir/top_process.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "|                  PDLSI/L/U Average CPU Usage Statistics  Result                 |">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat top_process.report >> $1/Result/report_${hostname}
paste $1/Result/fe_${hostname}_report.xls top_process.summary > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls
echo "Parsing PDLSI/L/U cpu & memory data done."
mv *.txt $1/Result

##############################################################
#Transfer PDLSI/L/U cpu and memory data to Excel Chart
##############################################################
$tool_dir/txt2excel_dir_chart.pl $1/Result


##############################################################
# PDLSI/L/U G2 Measurements Statistics
##############################################################
echo "Parsing PDLSI/L/U G2 measurements data ......."
$tool_dir/fe_g2_meas.sh 
echo "----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "|          PDLSI/L/U G2 Measurements Statistics  Result                          |">>$1/Result/report_${hostname}
echo "---------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat fe_g2_meas.result >> $1/Result/report_${hostname}
paste $1/Result/fe_${hostname}_report.xls pdlsi_g2_meas.xls > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls
paste $1/Result/fe_${hostname}_report.xls pdlsl_g2_meas.xls > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls
paste $1/Result/fe_${hostname}_report.xls pdlsu_g2_meas.xls > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls

rm fe_g2_meas.result pdlsi_g2_meas.xls pdlsl_g2_meas.xls pdlsu_g2_meas.xls
echo "Parsing PDLSI/L G2 measurements data done."

mv pdlsi_g2.txt pdlsl_g2.txt pdlsu_g2.txt $1/Result
####Add in 2014/04/27 to support PDLSX G2 measurements ########################################
mkdir $1/Result/PDLSX_MEAS
mv PDLS*.txt $1/Result/PDLSX_MEAS

##############################################################
# PDLSI/L/U cpu, memory and MEAS data to New Excel Chart
##############################################################
$tool_dir/chart.sh $1

###############################################################################################
#FE bandwidth statistics
##############################################################
echo "Parsing bandwidth data ......"
$tool_dir/bandwidth_meas.sh 
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "|              FE Bandwidth Statistics  Result                                    |">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat bandwidth.report >> $1/Result/report_${hostname}
mv ms_ip_data_meas.txt $1/Result
paste $1/Result/fe_${hostname}_report.xls bandwidth.summary > $1/Result/fe_${hostname}_report.tmp
mv $1/Result/fe_${hostname}_report.tmp $1/Result/fe_${hostname}_report.xls
echo "Parsing bandwidth  data done."

##############################################################
#FE lab status and configuration
##############################################################
echo "##################### FE version information ######################" >> $1/Result/report_${hostname}
$tool_dir/check_fe_version.sh
cat fe_version_info.result >> $1/Result/report_${hostname}
rm fe_version_info.result
echo "Cellect FE version information done."


echo "###################### Lab Status information ####################" >> $1/Result/report_${hostname}
pilot_number=`uname -n|awk -F "-" '{print $NF}'`
$tool_dir/check_lab_status.exp FE
cat lab_status.result >> $1/Result/report_${hostname}
rm lab_status.result
echo "Cellect Lab Status information done."

echo "##################### PDLS Number information ####################" >> $1/Result/report_${hostname}
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'`
do
  echo "===========================$sta======================================" >> $1/Result/report_${hostname}
  ssh $sta 'ps -ef|grep PDLS |grep -v gmetric_cpu.sh | grep -v grep' >> $1/Result/report_${hostname}
done
echo "Collect PDLS Number information done."

echo "##################### Wan delay information ######################" >> $1/Result/report_${hostname}
$tool_dir/check_delay_lost.sh
cat check_delay_lost.result >>  $1/Result/report_${hostname} 
rm check_delay_lost.result
echo "Collect wan delay information done."

echo "#################### Core dump information ######################" >> $1/Result/report_${hostname}
ls -lrt /sncore/*/* |grep sncore|grep -v ":$" >> $1/Result/report_${hostname}
echo "Collect core dump information done."


echo "#################### FE TCP parameters ##########################" >> $1/Result/report_${hostname}
$tool_dir/collect_tcp_parameter.sh
cat check_tcp_params.log >>  $1/Result/report_${hostname}
rm check_tcp_params.log

$tool_dir/collect_fe_paramters.sh  $1/Result/Configuration
cat  $1/Result/report_${hostname}
