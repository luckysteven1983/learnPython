"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines PtoolDiameterTrafficSimulator class
"""
from framework.traffic.diameter_traffic_simulator import DiameterTrafficSimulator

class PtoolDiameterTrafficSimulator(DiameterTrafficSimulator):
    """
    @details This class offers the commands to control a ptool simulator.
    """

    def __init__(self, sshManager):
        """ PtoolDiameterTrafficSimulator class constructor """

        super(PtoolDiameterTrafficSimulator, self).__init__(sshManager)
        self.application = ""
        self.transport = ""
