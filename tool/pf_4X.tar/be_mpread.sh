#!/bin/bash

#Usage: $0  <mpread.log>

echo Time > time.txt
cat $1|awk '{ if ( $0 ~ /[0-9][0-9]:[0-9][0-9]/) print $4}' >> time.txt
echo DB_access > db_access.txt
cat $1|grep "DB access"| awk '{print $3}' >> db_access.txt
echo Global_Status > global_status.txt
cat $1|grep "Global Status" | awk '{ gsub("Global Status     ",""); gsub(" ","_"); print $0}' >> global_status.txt
echo Global_chekpoint > checkpoint.txt
cat $1|grep "Global checkpoint"|awk '{print $3}' >> checkpoint.txt
echo Size_of_data > data_size.txt
cat $1|grep "Size of data"|awk '{print $4}' >> data_size.txt

paste time.txt db_access.txt global_status.txt checkpoint.txt data_size.txt |uniq > mpread.result

rm time.txt db_access.txt global_status.txt checkpoint.txt data_size.txt


