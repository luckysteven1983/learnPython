'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.traffic.telecom_traffic_simulator import TelecomTrafficSimulator

class LDAPTrafficSimulator(TelecomTrafficSimulator):
    '''
    classdocs
    '''


    def __init__(self, sshManager=None):
        '''
        Constructor
        '''

        super(LDAPTrafficSimulator,self).__init__(sshManager)
