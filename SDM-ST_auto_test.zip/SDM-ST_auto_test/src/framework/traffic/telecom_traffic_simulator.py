'''
high level telecom traffic simulator class

for diameter, map, etc.

@author: yohannm
'''
from framework.traffic.traffic_simulator import TrafficSimulator

class TelecomTrafficSimulator(TrafficSimulator):
    '''
    classdocs
    '''


    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        super(TelecomTrafficSimulator,self).__init__(sshManager)
