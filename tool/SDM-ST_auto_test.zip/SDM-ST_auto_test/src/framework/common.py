'''
Created on Feb 13, 2015

@author: yohann
'''
import os
from datetime import datetime
from lib.logging.logger import Logger
LOGGER = Logger.getLogger(__name__)

class Utils(object):
    """Common functions
    """

    PROJECT_NAME = "sdm-auto-test"

    @staticmethod
    def findDir(dirName, envVariable):
        """find the given dir
        """
        dirFound = False
        localDir = os.environ.get(envVariable)
        if localDir and os.path.isdir(localDir):
            dirFound = True

        directories = os.getcwd().split(os.sep)
        while directories and not dirFound:
            localDir = os.path.join(os.sep.join(directories), dirName)
            if os.path.isdir(localDir):
                dirFound = True
                break
            directories.pop()
        if not dirFound:
            LOGGER.warn(dirName + " directory not found")
            raise Exception(dirName + " directory not found")
        return localDir

    @staticmethod
    def findFile(pathName, fileName):
        """Find the given file name under path directory and subdirectories"""
        for root, _, files in os.walk(pathName):
            if fileName in files:
                return os.path.join(root, fileName)
        return None

    @staticmethod
    def getCurrentLabTime(sshManager, lab, isString=True):
        """Get current lab time.

        If isString is True by default, the return value is string like '2015-10-10 11:22:33'. If
        isString is False, the return value is a datetime type like datetime.datetime(2015, 10,
        10, 11, 22, 33).

        Keyword arguments:
        sshManager -- one MultiMcasSshManager object
        lab -- one lab object
        isString -- flag indicating a string type value is returned or not (default True)
        """
        response = sshManager.run(lab.oamIpAddress, "date '+%F %T'")
        if int(response[0]):
            LOGGER.warn(lab.id + ": Can not get lab time")
            raise Exception("Can not get lab time")
        curTime = response[1]
        curTime = datetime.strptime(curTime.strip(), '%Y-%m-%d %H:%M:%S')
        return str(curTime) if isString else curTime


    @staticmethod
    def convertStringToDatetime(dateString):
        """
        Convert a string representing a date to a datetime object
        the format of date is supposed to be '%Y-%m-%d %H:%M:%S'
        """
        return datetime.strptime(dateString, '%Y-%m-%d %H:%M:%S')


    @staticmethod
    def convertDdmGateTimeToDatetime(ddmGateString, asString=True):
        """
        Convert a string representing a date in a ddmGateSupervisor format to a date instance
        the format of /var/local/nectar/log/ddmGateSupervisor.log is :
            www MMM DD hh:mm:ss yyyy    Ex: Mon May 11 11:44:30 2015
        NB: the weekday can be given or not (if given it is removed because unuseful here)
        @param ddmGateString : the ddmGateSupervisor date as a string
        @asString : result as a string or datetime object
        """
        dateDdm = ddmGateString.split()
        ddmGateString = dateDdm[1:] if len(dateDdm) == 5 else dateDdm  # remove weekday if given
        dateObject = datetime.strptime(' '.join(ddmGateString), '%b %d %H:%M:%S %Y')
        if asString:
            return datetime.strftime(dateObject, '%Y-%m-%d %H:%M:%S')
        else:
            return dateObject


