'''
Created on Mar 30, 2015

@author: Xia Zhao
'''
import unittest
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
LOGGER = Logger.getLogger(__name__)

class database_manager_killndb_test_once(SDMTestCase):


    def setUp(self):
        LOGGER.info("DatabaseManagerkillndbTest Test")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.host1 = self.testEnv.testBed.getBackends().popitem()
        self.databaseManager = self.sdmManager.databaseManager

    def tearDown(self):
        pass

    def test_1_killndb_success(self):
        LOGGER.info('try to be success: kill ndb on 0-0-2')
        self.databaseManager.killNDB(self.host1, '0-0-2')

    def test_2_killndb_fail(self):
        LOGGER.info('try to be fail: kill ndb on 0-0-17')
        self.assertRaises(BaseException, self.databaseManager.killNDB, self.host1, '0-0-17')



if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
