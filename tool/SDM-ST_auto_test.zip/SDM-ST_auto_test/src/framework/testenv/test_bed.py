'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.testenv.backend import Backend
from framework.testenv.frontend import Frontend
from framework.testenv.provfrontend import ProvFrontend

class TestBed(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        self.labs = dict()
        """ Test Bed version for SDM DDM MCAS (assuming all nodes at same versions) """
        self.version = {}

    def _getLabs(self, roleClass):
        labsDict = dict()
        for lab in self.labs.values():
            if isinstance(lab.productRole, roleClass):
                labsDict[lab.id] = lab
        return labsDict

    def getBackends(self):
        return self._getLabs(Backend)

    def getFrontends(self):
        return self._getLabs(Frontend)

    def getProvFrontends(self):
        return self._getLabs(ProvFrontend)

    def getNRG(self, nrg="1"):
        '''get the lab list of the nrg
        @param nrg: string, the nrg number
        @return: list, the lab list of the nrg
        '''
        labsDict = self._getLabs(Backend)
        return [lab for lab in labsDict.values() if lab.productRole.networkReplicatedGroup == nrg]
        
    def getLabIdInNRG(self, nrg="1"):
        '''
        get the lab list of the nrg
        @param nrg: string, the nrg number
        @return: list, the lab.id list of the nrg
        '''
        labsDict = self._getLabs(Backend)
        return [lab.id for lab in labsDict.values() if lab.productRole.networkReplicatedGroup == nrg]
