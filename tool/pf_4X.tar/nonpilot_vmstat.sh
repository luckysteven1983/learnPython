#!/bin/bash

for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
  do
     if [ `ls -lrt vmstat_${sta}_*|tail -1|awk '{print $9}'|wc -l` -eq 0 ]; then
          echo "vmstat_${sta} doesn't exist!" 
     else
         file=`ls -lrt vmstat_${sta}_*|tail -1|awk '{print $9}'`   
         cat $file | grep -v proc |grep -v r > tmp
         awk 'BEGIN { max=0; } { que+=$1; if ( $1 > max) max=$1; num++;next;} END { printf "%s\t%d\t%d\n","'"$sta"'", que/num, max } ' tmp >> runque.txt 
     fi
  done 

cat runque.txt |awk 'BEGIN { print "AvgRunQue\tMaxRunQue"; max=0; } { que+=$2; if ( $3>max ) max=$3; num++; next; } END { printf "%d\t%d\n", que/num, max}' > runque.xls

rm runque.txt tmp 
