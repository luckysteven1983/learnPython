'''
Created on Dec 1, 2015

@author: Cassandra Lajeunie
'''

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)

class casegrouptestskip(SDMTestCase):
    '''This class defines tests'''

    def setUp(self):
        LOGGER.debug("setUp")
        LOGGER.debug("testEnv id: %s", self.testEnv.id)

    def tearDown(self):
        LOGGER.debug("tearDown")

    def test_case(self):
        ''' This is a basic test'''
        LOGGER.info("skipped test")
        self.skipTest("skiped for test purpose")
