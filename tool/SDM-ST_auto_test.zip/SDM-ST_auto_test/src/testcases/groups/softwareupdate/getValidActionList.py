#/usr/local/bin/python
'''
Created on May 5, 2015
@author: FrankZh

provide the command to get valid SU actions currently
'''

#import os
import sys
import getopt

from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from lib.softwareupdate.sdm_su_common_func import SdmSuUtils

LOGGER = Logger.getLogger(__name__)

class SuValidActions(object):
    """
    Usage: getValidActionList LabOamIp. For example:
           python ./src/testcases/groups/softwareupdate/getValidActionList.py  135.242.137.57

    options:
    -h, --help       show help

    """

    def __init__(self, argv):
        '''
        call parent __init__ also
        '''
        self.argv = argv
        self.ipPilotF = ''

    def usage(self):
        '''
        print usage
        '''
        print self.__doc__

    def parseOptions(self, argv):
        '''
        parse argv
        '''
        if len(argv) == 1:
            print '\n' + "Command format Error" + '\n'
            self.usage()
            sys.exit(2)
        else:
            try:
                opts, args = getopt.getopt(argv[1:], "h", ["help"])
            except getopt.GetoptError:
                print '\n' + "getValidActionList.py getopt Error" + '\n'
                self.usage()
                sys.exit(2)

        for opt in opts:
            if opt in ("-h", "--help"):
                self.usage()
                sys.exit(2)

        if not args[0]:
            LOGGER.error("lab ip should not be NULL")
            self.usage()
            sys.exit(2)
        self.ipPilotF = args[0]


    def startCheck(self):
        """
        start SU actions
        """
        self.parseOptions(self.argv)
        sshMngr = SshManager()

        print SdmSuUtils.getValidAction(sshMngr, self.ipPilotF)

        sshMngr.closeAllClients()

if __name__ == "__main__":
    suCheck = SuValidActions(sys.argv)
    suCheck.startCheck()
