"""
package including unittest.TestCase children classes to add new asserts,
example: assertNoCore(), assertNoAlarm(), etc.
"""