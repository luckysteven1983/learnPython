'''
Created on Nov 2, 2015

@author: Cassandra Lajeunie
'''

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
RCV_MENU_COMMAND_NEW = "FORM=CR_NODEEQUIPMENT&NEW\n\"UNIT ID\"=\"1235\"\n\"DATE OF MANUFACTURE\"=\"0\"\n\
\"DATE OF LAST SERVICE\"=\"0\"\n\"INV UNIT TYPE\"=\"0\"\n\"MANUFACTURING DATA\"=\"0\"\n\"SERIAL NUMBER\"=\"0\"\n\
\"UNIT POSITION\"=\"0\"\n\"VENDOR NAME\"=\"0\"\n\"VENDOR UNIT FAMILY TYPE\"=\"0\"\n\"VENDOR UNIT TYPE NUMBER\"=\"0\"\n\
\"VERSION NUMBER\"=\"0\"\n\"CLEI CODE\"=\"0\"\nNEW"
RCV_MENU_COMMAND_VFY = "FORM=CR_NODEEQUIPMENT&VFY\n\"UNIT ID\"=\"1235\"\nVFY"
RCV_MENU_COMMAND_CHG = "FORM=CR_NODEEQUIPMENT&CHG\n\"UNIT ID\"=\"1235\"\n\"DATE OF MANUFACTURE\"=\"1\"\nCHG"
RCV_MENU_COMMAND_OUT = "FORM=CR_NODEEQUIPMENT&OUT\n\"UNIT ID\"=\"1235\"\nOUT"
RCV_MENU_COMMAND_FAKE = "FORM=CR_NODEEQUIPMENT&FAKE\n\"UNIT ID\"=\"1235\"\nFAKE"

class rcv_menu_manager_weekly_test_once(SDMTestCase):
    '''
    Test for rcv_menu_manager
    '''

    def setUp(self):
        LOGGER.info("rcv_menu Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.proxyFes = self.testEnv.testBed.getProvFrontends()
        if self.proxyFes:
            _, self.proxyFe = self.proxyFes.popitem()
            self.withProxyFe = True
        else:
            self.withProxyFe = False
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.rcv = self.sdmManager.rcvMenuManager

    def tearDown(self):
        pass

    def test_01_not_allowed_operation(self):
        LOGGER.info("unit test: operation is not an allowed one")
        self.rcv.run_rcv(self.fe, RCV_MENU_COMMAND_FAKE)

    def test_02_successfull_operations(self):
        LOGGER.info("successfull set of operations")
        LOGGER.info("successfull new command")
        self.rcv.run_rcv(self.fe, RCV_MENU_COMMAND_NEW)

        LOGGER.info("successfull vfy command")
        self.rcv.run_rcv(self.fe, RCV_MENU_COMMAND_VFY)

        LOGGER.info("successfull chg command")
        self.rcv.run_rcv(self.fe, RCV_MENU_COMMAND_CHG)

        LOGGER.info("successfull out command")
        self.rcv.run_rcv(self.fe, RCV_MENU_COMMAND_OUT)

    def test_03_vfy_operation_not_successfull(self):
        LOGGER.info("not successfull vfy command")
        self.rcv.run_rcv(self.fe, RCV_MENU_COMMAND_VFY)