"""
@file database_manager_swo_weekly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-05-12
@brief change BE state
"""

import unittest
import time
import lib.exceptions_messages as eMsgs
from framework.sdm_test_case import SDMTestCase
from lib.database.ddm.database_manager import DatabaseManagerError
from framework.asserts.common_asserts import CommonAssert
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class database_manager_swo_weekly_test_once(SDMTestCase):
    """Unit test for HealthCheck class.
    """
    def setUp(self):
        LOGGER.info("TestDBSwithOver Test Once")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.bes = self.testEnv.testBed.getLabsInNRG()

    def test_01_Change_BE_State(self):
        """Change change state
        """
        LOGGER.info('[Test case 01] Check BE status change')
        LOGGER.debug('Find slave BE')
        slaveBe = None

        for be in self.bes:
            if self.sdmManager.databaseStateManager.getState(be).lower() == 'slave':
                LOGGER.debug('%s is slave', be.id)
                slaveBe = be
                break
        else:
            LOGGER.debug('No slave BE so nothing to do')

        if slaveBe:
            LOGGER.debug('Change slave BE to stop')
            self.sdmManager.databaseManager.setState(slaveBe, 'stop', finalState='MATED_PAIR_STOP')
            LOGGER.debug('sleep a while and change it back')
            time.sleep(5)
            self.sdmManager.databaseManager.setState(slaveBe, 'slave', 1800)
            LOGGER.debug('Should wait the BE become security before next test case')
            time.sleep(5)
            CommonAssert.timedAssert(10800, 300, self._assertGlobalStatus, slaveBe)

    def _assertGlobalStatus(self, lab):
        """Assert BE status is 'secured'
        """
        beState = self.sdmManager.databaseStateManager.getState(lab, 'Global Status').lower()
        self.assertTrue(beState.find('secured') != -1, 'debug')

if __name__ == "__main__":
    unittest.main()

