'''
Created on Nov 2, 2015

@author: Tangi Lavanant

'''

import unittest
from framework.asserts.common_asserts import CommonAssert
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_platform_manager import FW_LLSTA


LOGGER = Logger.getLogger(__name__)
MCAS_INTERVAL_CHECK = 30

class mcas_platform_manager_nightly_test_once(SDMTestCase):
    '''
    Test for McasPlatformManager
    '''

    def setUp(self):
        LOGGER.info("McasPlatform Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.mcasPlatformManager = self.sdmManager.mcasPlatformManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts

    def tearDown(self):
        pass

    def test_01_runFw_success(self):
        '''
        This test run "fw llsta" equivalent on fe
        '''
        LOGGER.info("test_01_runFw_success")
        CommonAssert.assertFalse(self.mcasPlatformManager.runFw(self.fe, FW_LLSTA)[0],
                                  'the command was not ran as expected', 'error')

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
