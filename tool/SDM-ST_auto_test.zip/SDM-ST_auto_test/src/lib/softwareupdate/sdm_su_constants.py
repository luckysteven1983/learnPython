'''
Created on Apr 9, 2015
@author: FrankZh

this module defines some constants
'''

class SdmSuConst(object):
    """
    SDM SU Constants
    """
    RECONNECT_INTERVAL = 30

    RST_SUCCESS = 1
    RST_FAILURE = 0
    RST_EXCEPTION = 2
    RST_ACTNOTALLOWED = 3
    RST_LPROCRUNNING = 4
    RST_RPROCRUNNING = 5
    RST_POST_SU_FAILURE = 6
    RST_SU_NOT_PROCEED = 7
    RST_SU_IGNORED = 8
    RST_SU_COMMIT_DONE = 9
    RST_SU_DOWNLOAD_NOT_DONE = 10
    RST_SU_DONE_BEFORE = 11
    RST_ACTION_NOT_STARTED = 12
    SU_USER = 'rmtadm'
    SU_USER_PASSWD = 'COM_cc_n1'
    ROOT_USER = 'root'
    AINET_USER = 'ainet'
    AINET_PASSWD = 'ainet1'

    SUSTATE = {'IP':'INPROG', 'SU':'SUCCESS', 'PA':'PAUSED', 'FA':'FAILED'}
    SPASTATUS = {'IN_SERVICE': 'IS', 'EQUIP': 'EQP', 'MOOS': 'MOOS', 'OUT_OF_SERVICE':'OOS'}
    LABROLE = {'BE': 'BackEnd', 'FE': 'FrontEnd', 'PFE': 'ProvFrontend'}

    CMD_SOFTWAREINVENTORY = '/PLATsoftware/OAM/bin/softwareInventory'
    SOFTWARE_INVENTORY_DATA_FILE = '/PLATsoftware/SU/xmc/oam/softwareInventory'
    REMOTE_ACTION_STATUS_FILE = '/PLATsoftware/SU/xmc/oam/actionStatus'
    REMOTE_SUAGENT_FILE = '/PLATsoftware/SU/xmc/oam/OAMSUAgent.xml'
    LOCAL_SU_REPOSITORY_DIR = './log/softwareupdate/repository/'
    SU_CACHE_DIR = './cache/softwareupdate/'
    LOCAL_SU_Conf_DIR = './src/testcases/groups/softwareupdate/suconf/'
    LOCAL_SU_Conf_FILE = './src/testcases/groups/softwareupdate/su_conf/conf.ini'
    SUPROCESSNAME = 'SDM_SU_RUNNING'

    #steps defined for performing SU
    DOWNLOAD = 'download'
    APPLY = 'apply'
    COMMIT = 'commit'
    BACKOUT = 'backout'
    EFX_BACKOUT = 'efx_backout'

    NULLVERSION = '0.0'
