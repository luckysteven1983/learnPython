"""
Created on Sept 20, 2015

@author: Beaufils Serge - Le Maout Bruno

"""

import random
import time

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.core_check.core_check_manager import CoreCheckManager
from lib.core_check.core_utilities import CoreUtilities
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import SPA_TIMEOUT

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)
TEMPO_RESTART_PDLS = 15 * 60 # if blade is killed twice within 15 minutes, the spa restart.

class fr9124_kill_random_pdls(SDMTestCase):
    """test case : generation of PDLS core with kill -6 command
    and check if no blade restart
    https://atlassianwave.web.alcatel-lucent.com/jira/browse/SDM-9124
    """

    def setUp(self):
        """
        Init the managers you need
        """
        self.logLinksPrint()  # Used to get the log links in Junit XML results

        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        # defined the expected alarms and accepted alarms
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.linuxProcessManager = self.sdmManager.linuxProcessManager
        self.mcasAppManager = self.sdmManager.mcasApplicationManager
        self.sshManager = self.sdmManager.sshManager
        self.coreUtils = CoreUtilities(self.sshManager)
        LOGGER.debug("Running fr9124_kill_random_pdls")
        self.exceptMsg = ""

        # need to have a local instance of  CoreCheckManager in order to make
        # changes in directory list
        self.localCoreCheckManager = CoreCheckManager(self.sshManager, None)


    def test_kill_random_pdls(self):

        # wait 15 minutes to be sure we do not kill the pdls twice in less than 15 minutes
        LOGGER.info("Wait 15 minutes. if pdls is killed twice in less than 15 minutes, spa restart")
        time.sleep(TEMPO_RESTART_PDLS)

        # check the initial satus of the test env
        LOGGER.debug("check the Initial status of the test env")

        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("Start to choose the FEs to test this case")
        fes = self.testEnv.testBed.getFrontends()

        # Keep only /sncore directory in local copy of coreCheckManager
        for dirCore in self.localCoreCheckManager.showCoreDir().keys():
            if dirCore != '/sncore':
                self.localCoreCheckManager.removeCoreDir(dirCore)

        # Loop on all FE
        for feID, fe in fes.iteritems():

            bladesORI = fe.getStationListbyProductRole("RT").keys()
            blades = bladesORI
            # Reference time to clean core generated during the loop
            feStartTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe, isString=True)

            # cores will be deleted on these blades
            bladesToClean = []

            # --- loop over all blades of the current FE
            for _ in range(len(blades)):

                bladeId = random.choice(blades)
                blades.remove(bladeId)

                LOGGER.debug("Will kill on FE: " + str(feID))

                stationToKill = fe.getStationListbyProductRole('RT')[bladeId]
                LOGGER.debug("Blade : %s", bladeId)

                PIDlist = self.linuxProcessManager.getPidbyPS(fe, "PDLS", bladeId)
                PIDkill = random.choice(PIDlist)

                self.linuxProcessManager.killProcessbyPid(fe, [PIDkill], bladeId, signal=6)
                LOGGER.debug("kill -6 Process : %s on Blade %s", PIDkill, bladeId)

                # start of loop for timeout
                startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe, isString=False)
                delta = 0

                # loop ( max 10 min) after kill -6 PDLSx : maximum waiting time to get SPA IS
                while delta < SPA_TIMEOUT:

                    # tempo before to check SPA status
                    time.sleep(10)
                    spaStatus = self.mcasAppManager.getSPAStatus(fe, 'sdm')[bladeId]
                    LOGGER.debug ('%s : SPA SDM is %s', feID, spaStatus)

                    if spaStatus == 'IS':
                        LOGGER.debug ('%s : test OK , spa OK with no restart of blade %s', feID, bladeId)
                        bladesToClean.append(bladeId)
                        break

                    else:
                        statusLine = self.sdmManager.mcasMachineManager.getMachineInfo(fe, machine=bladeId)[0]
                        machStatus = statusLine.split()[3]
                        if machStatus != 'COMPL':
                            LOGGER.error('blade %s restarted', bladeId)
                            # -- Core is not deleted on restarted blade because restart is on going.
                            LOGGER.debug('Blade %s restart is not expected, thus Keeping core for debugging.', bladeId)
                            # --- checkMachineStatus raises an exception if not COMPL
                            CommonAssert.timedAssert(1200, 60, self.sdmManager.mcasMachineManager.checkMachineStatus,
                                                            fe, machine=bladeId)
                            # --- blade is now OK. core file is not deleted.
                            LOGGER.debug('blade %s is now OK. ' , bladeId)

                            # --- test is KO because blade has restarted => raise exception
                            raise Exception('blade ' + bladeId + ' has restarted after kill -6 PDLS : test KO')

                        LOGGER.debug ('%s : machine %s is COMPL', feID, bladeId)
                        bladesToClean.append(bladeId)
                    currTim = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe, isString=False)
                    delta = (currTim - startTime).seconds

                # --- here we exit from the loop. 2 cases :
                # - the timeout has been reached because spa is still KO
                # - the test for this blade is OK, spa IS and no restart of station

                # --- if timeout reached : spa still not IS
                if delta >= SPA_TIMEOUT:
                    # time out 10 mn reached test KO
                    LOGGER.error("%s : SPA SDM still not IS on %s after 10 minutes", feID, bladeId)
                    self.mcasAppManager.assertSPAStateOnStations(fe, 'SDM', 'IS', [stationToKill])

                LOGGER.info (' ===================== End test %s %s ====================== ', feID, bladeId)
                # tempo before next blade
                time.sleep(10)

            # --- clean core files at the end
            LOGGER.info('clean all cores on restarted blades on FE %s', feID)
            # --- remove duplicates
            bladesToClean = list(set(bladesToClean))
            LOGGER.info("List of cleaned blades, keeping cores for debug on other blades : %s ",str(bladesToClean))
            self.coreUtils.cleanPdlsCoreFiles(fe, feStartTime, bladesToClean)
