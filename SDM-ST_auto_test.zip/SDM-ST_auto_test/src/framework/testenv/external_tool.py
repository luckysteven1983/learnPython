'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.testenv.resource_intensive import ResourceIntensive
from framework.testenv.disposable import Disposable


class ExternalTool(ResourceIntensive, Disposable):
    '''
    classdocs
    '''


    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        super(ExternalTool, self).__init__()
        self.toolIpAddress = ""
        self.account = None
        self.sshManager = sshManager
