#!/bin/bash

echo "Router     " "AvgIn(Mb/s)" "AvgOut(Mb/s)" > bandwidth.result
for route in `ls -lrt route24*.log|awk '{print $9}'`
do
  name=`echo $route|awk -F"_" '{print $1}'`
  cat $route|sed -n -e '/1\/[0-9]/p' -e '/InBits\/s/p'|grep -v show|grep -v "*"|grep -v vlan|grep -v VRRP > ${name}.tmp

   hostname=`uname -n|awk -F"-" '{print $1}'`
   vlan=`grep ${hostname}_GDMP $route|head -1|awk '{print $6, $7}'|tr -d "\r\n"|awk '{print $1, $2, "members port"}'`
   port=`grep "${vlan}" $route |head -1 | awk '{print $5}'`
   cat ${name}.tmp|grep -A1 -w $port |grep "InBits"|sed -n -e 's/,//p'|awk '{print $3/1024/1024 "\t" $6/1024/1024}' > ${name}_interface_$k.txt

  awk '{ inbits += $1; outbits += $2;  ++num } END { if (num!=0) {printf "%s\t%.2f\t%.2f\n","'"$name"'", inbits/num,  outbits/num} else { printf "%s\t%.2f\t%.2f\n","'"$name"'",0,0}} ' ${name}_interface_$k.txt >> bandwidth.result
  rm  ${name}.tmp ${name}_interface_$k.txt
done
