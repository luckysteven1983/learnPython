"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines JmeterTrafficProfile class
"""

class JmeterTrafficProfile(object):
    """
    @details This class describes a Jmeter traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        JmeterTrafficProfile class constructor
        """

        self.interface = ""
        self.workspace = ""
        self.tps = ""
        self.FE_Key = ""
        self.jmeterDir = ""  # jmeter location on PC lab
