"""
@file mcas_user_manager.py
@ingroup SDMSQA
@author Jiaxi Jin
@date 2015-09-16

@brief Manage new created MCAS user and SSH key installation between lab and server

This file prepares the authentication for SSH connection established between new mCAS user and server.
"""

import re

from lib.ssh.ssh_manager import SshManager
from lib.logging.logger import Logger
import lib.exceptions_messages as msgs

LOGGER = Logger.getLogger(__name__)

class Account(object):
    """Default Account information"""
    MCASUSER = 'rmtadm'
    MCASPW = 'COM_cc_n1'
    SERVERUSER = 'jenkins'
    SERVERPW = 'jenkins'

class MCASUserManagerError(Exception):
    """Raise it if error"""
    pass

class MCASUserManager(object):
    """MCAS user manager

    Manage user operations like create and remove user, generate ssh key and add auth on server for mCAS user.
    """

    def __init__(self, sshManager=None):
        """Init MCASUserManager instance with sshManager.

        @param sshManager    ssh manager object
        """
        self._sshManager = SshManager() if sshManager is None else sshManager

    def addUserAuthOnServer(self, ip, user, password, serverUser, serverPw, serverIP):
        """Generate SSH key for mCAS user and add authentication on remote server

        @param ip   the IP address of mCAS server (Active Pilot)
        @param user   the user name on mCAS
        @param mcasPw   password of user on mCAS
        @param serverUser   the user name on server
        @param serverPw    password of user on server
        @param serverIP    the address of server
        """
        # Generate SSH key
        cmd = 'mkdir -p ~/.ssh && rm -f ~/.ssh/id_rsa* && ssh-keygen -t rsa -N "" -f ~/.ssh/id_rsa'
        sshClient = self._sshManager.getClient(ip, user, password)
        if self._sshManager.run(ip, cmd, user)[0]:
            msg = "%s for %s on lab %s" %(msgs.SSHKEY_GEN_FAILURE, user, ip)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)
        # Create .ssh directory on remote server.
        cmd = 'mkdir -p ~/.ssh'
        self._sshManager.getClient(serverIP, serverUser, serverPw)
        if self._sshManager.run(serverIP, cmd, serverUser)[0]:
            msg = "%s for %s on server %s" %(msgs.CREATE_SSH_DIR_FAILURE, serverUser, serverIP)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)
        # Copy ssh key to remote server
        chan = sshClient.invoke_shell()
        remoteKeyName = 'id_rsa.pub_lab_%s_labuser_%s_serveruser_%s' %(ip, user, serverUser)
        cmd = 'scp -oStrictHostKeyChecking=no ~/.ssh/id_rsa.pub %s@%s:~/.ssh/%s' %(serverUser, serverIP, remoteKeyName)
        self._isExpectedString(chan, cmd, '[Pp]assword:', 10)
        self._isExpectedString(chan, serverPw, '100%')
        chan.close()
        # Add authentication
        cmd = 'cat ~/.ssh/%s >> ~/.ssh/authorized_keys' %remoteKeyName
        self._sshManager.getClient(serverIP, serverUser, serverPw)
        if self._sshManager.run(serverIP, cmd, serverUser)[0]:
            msg = "%s for %s on lab %s" %(msgs.SSH_AUTH_FAILURE, user, ip)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)
        # Sync to the other pilot after previous steps are done due to known_hosts exist here.
        fields = self._sshManager.run(ip, 'hostname')[1].split('-')
        fields[-1] = str(10 - int(fields[-1]))
        pilotHostname = ('-').join(fields)
        cmd = 'rsync -aH /home/%s/.ssh %s:/home/%s' %(user, pilotHostname, user)
        if self._sshManager.run(ip, cmd)[0]:
            msg = "%s on lab %s" %(msgs.SYNC_SSH_DIR_FAILURE, ip)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)

    def deleteMCASUser(self, ip, user):
        """Delete given MCAS user

        if error, raise MCASUserManagerError

        @param ip    mCAS active pilot address
        @param user    user name to be created on mCAS
        """
        deleteUser = '/usr/sbin/AcctMgt -del %s' %user
        self._sshManager.run(ip, deleteUser)
        deleteHome = 'rsh 0-0-1 rm -rf /home/%s && rsh 0-0-9 rm -rf /home/%s' %(user, user)
        self._sshManager.run(ip, deleteHome)

    def createMCASUser(self, ip, user, password):
        """Create MCAS user with given user and password

        if error, raise MCASUserManagerError

        @param ip    mCAS active pilot address
        @param user    user name to be created on mCAS
        @param password    user password
        """
        # Add user
        addUser = '/usr/sbin/AcctMgt -add -d /home/%s -m -g adm -G wheel,ainet %s' %(user, user)
        if self._sshManager.run(ip, addUser)[0]:
            msg = "%s %s on %s" %(msgs.ADD_USER_FAILURE, user, ip)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)
        # Change password
        changePassword = '/usr/sbin/AcctMgt -passwd %s' %user
        chan = self._sshManager.getClient(ip).invoke_shell()
        self._isExpectedString(chan, changePassword, 'New Password:', 10)
        self._isExpectedString(chan, password, 'Re-enter new Password:', 10)
        self._isExpectedString(chan, password, 'AcctMgt: Completed')
        chan.close()
        # Disable password expired
        if self._sshManager.run(ip, 'chage -M -1 %s' %user)[0]:
            msg = "%s for %s on %s" %(msgs.DISABLE_PASSWORD_EXPIRED_FAILURE, user, ip)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)

    def _isExpectedString(self, chan, sendString, expectString, timeout=60):
        """If expectString is not expected after sending sendString, raise MCASUserManagerError"""
        buff, _ = SshManager.sendStringRoutine(chan, sendString, expectString, timeout)
        pattern = re.compile(expectString)
        if pattern.search(buff) is None:
            msg = "%s %s after sending %s" %(msgs.EXPECT_STRING_FAILURE, expectString, sendString)
            LOGGER.error(msg)
            raise MCASUserManagerError(msg)

    def sshSetup(self, serverIP, mcasIP, serverUser=Account.SERVERUSER, serverPw=Account.SERVERPW,
                 mcasUser=Account.MCASUSER, mcasPw=Account.MCASPW):
        """
        Establish ssh connection between mCAS and server and save the setup env to further usage

        @param serverIP   the address of server
        @param mcasIP   the IP address of mCAS server (Active Pilot)
        @param serverUser   the user name on server
        @param serverPw   password
        @param mcasUser   the user name to be created on mCAS server
        @param mcasPw   password to be created on mCAS

        MCASUserManager.sshSetup(mcasIP, serverIP)
        """
        self.deleteMCASUser(mcasIP, mcasUser)
        self.createMCASUser(mcasIP, mcasUser, mcasPw)
        self.addUserAuthOnServer(mcasIP, mcasUser, mcasPw, serverUser, serverPw, serverIP)
