#!/bin/bash

select_file(){
  # $1 = cpu, mem
  # $2 = PDLS, Oam
  for file in `ls $view/Result/*$2*$1.txt`
  do
     name=`echo $file | awk -F "Result" '{ print $2 }'`
     proc=`echo $name | awk -F _ '{ print $2 }'`
     cp $file $view/Result/PROCESS_$1_Chart/data/$proc.txt
     echo $proc >> $view/Result/PROCESS_$1_Chart/data/CUSTO_$2.txt
  done
  if [ $1 = "mem" ] && [ ! -f $view/Result/PROCESS_$1_Chart/data/CUSTO_Station.txt ]; then
    for file in `ls $view/Result/Sta*$1.txt`
    do
       name=`echo $file | awk -F "Result" '{ print $2 }'`
       proc=`echo $name | awk -F _ '{ print $2 }'`
       cp $file $view/Result/PROCESS_$1_Chart/data/$proc.txt
       echo $proc >> $view/Result/PROCESS_$1_Chart/data/CUSTO_Station.txt
    done
  fi
}

process_chart(){
  # $1 = cpu, mem
  mkdir -p $view/Result/PROCESS_$1_Chart/data
  cp $tool_dir/PROCESS_CPU_MEM_Template.xls $view/Result/PROCESS_$1_Chart/PROCESS_$1_Chart.xls
  cp $view/Result/top_dates.txt $view/Result/PROCESS_$1_Chart/data/DATES.txt
  cp $view/Result/top_oam_dates.txt $view/Result/PROCESS_$1_Chart/data/DATES_oam.txt
  echo %$1 > $view/Result/PROCESS_$1_Chart/data/CUSTO.txt
  select_file $1 PDLS 
  select_file $1 Oam 
  $tool_dir/txt2excel.pl $view/Result/PROCESS_$1_Chart/data PROCESS_data.xls
  rm $view/Result/PROCESS_$1_Chart/data/*.txt
}

pdls_meas_chart(){
  #$1 = PDLSU, PDLSL, PDLSI, PDLSM
  mkdir -p $view/Result/$1_MEAS_Chart/data
  cp $tool_dir/PDLS_MEAS_Chart_Template.xls $view/Result/$1_MEAS_Chart/$1_MEAS_Chart.xls
  cp $view/Result/PDLSX_MEAS/DATES.txt $view/Result/$1_MEAS_Chart/data/
  for file in `ls $view/Result/PDLSX_MEAS/$1*.txt`
  do
    name=`basename $file | cut -c 6-`
    cp $file $view/Result/$1_MEAS_Chart/data/$name
    echo `basename $file | cut -c 8- | cut -d'.' -f1` >> KPI.txt
  done
  echo $1 >> $view/Result/$1_MEAS_Chart/data/CUSTO.txt
  echo "Measurements" >> $view/Result/$1_MEAS_Chart/data/CUSTO.txt
  cat KPI.txt | sort | uniq >>  $view/Result/$1_MEAS_Chart/data/CUSTO.txt
  $tool_dir/txt2excel.pl $view/Result/$1_MEAS_Chart/data $1_MEAS_data.xls
  rm $view/Result/$1_MEAS_Chart/data/*.txt
  rm KPI.txt
}

view=$1
tool_dir=$(cd "$(dirname "$0")"; pwd)

########   CPU/MEM
process_chart cpu
process_chart mem

########   MEAS
echo "Dates" >> $1/Result/PDLSX_MEAS/DATES.txt
cat $1/Result/PDLSX_MEAS/PDLS_MEAS_DATES.txt >> $1/Result/PDLSX_MEAS/DATES.txt
pdls_meas_chart PDLSU
pdls_meas_chart PDLSI
pdls_meas_chart PDLSL
pdls_meas_chart PDLSM
rm $1/Result/PDLSX_MEAS/DATES.txt


