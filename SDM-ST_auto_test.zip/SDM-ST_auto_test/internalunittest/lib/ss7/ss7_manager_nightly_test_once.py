'''
Created on Nov 5, 2015

@author: xzhao015
'''
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.ss7.ss7_manager import SS7ManagerError


LOGGER = Logger.getLogger(__name__)

class ss7_manager_nightly_test_once(SDMTestCase):
    ''' Test for ss7Manager
    '''

    def setUp(self):
        """Setup env"""
        LOGGER.info("SS7 Manager nightly Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.ss7Manager = self.sdmManager.ss7Manager

    def test_01_get_master_s7sch_success(self):
        LOGGER.info("test_01_get_master_s7sch_success")
        processName, machine = self.ss7Manager.getMasterS7SCH(self.fe)
        self.assertRegexpMatches(processName, 'S7SCH')
        self.assertRegexpMatches(machine, '0-0-')

    def test_02_get_master_s7sch_fail(self):
        LOGGER.info("test_02_get_master_s7sch_fail")
        self.assertRaises(BaseException, self.ss7Manager.getMasterS7SCH, self.be)

    def test_03_get_master_sTsch_success(self):
        LOGGER.info("test_03_get_master_sTsch_success")
        processName, machine = self.ss7Manager.getMasterSTSCH(self.fe)
        self.assertRegexpMatches(processName, 'STSCH')
        self.assertRegexpMatches(machine, '0-0-')

    def test_04_get_master_sTsch_fail(self):
        LOGGER.info("test_04_get_master_sTsch_fail")
        self.assertRaises(BaseException, self.ss7Manager.getMasterSTSCH, self.be)

    def test_05_kill_master_s7sch_success(self):
        LOGGER.info("test_05_kill_master_s7sch_success")
        self.ss7Manager.killMasterS7SCH(self.fe)

    def test_06_kill_master_s7sch_fail(self):
        LOGGER.info("test_06_kill_master_s7sch_fail")
        self.assertRaises(BaseException, self.ss7Manager.killMasterS7SCH, self.be)

    def test_07_kill_master_sTsch_success(self):
        LOGGER.info("test_07_kill_master_sTsch_success")
        self.ss7Manager.killMasterSTSCH(self.fe)

    def test_08_kill_master_sTsch_fail(self):
        LOGGER.info("test_08_kill_master_sTsch_fail")
        self.assertRaises(BaseException, self.ss7Manager.killMasterSTSCH, self.be)

    def test_09_check_associations_established(self):
        LOGGER.info("test_09_check_associations_established")
        self.assertRaises(SS7ManagerError, self.ss7Manager.checkAssociationsEstablished, self.fe)
