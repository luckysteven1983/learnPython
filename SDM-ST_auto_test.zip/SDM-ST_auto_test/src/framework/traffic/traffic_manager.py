"""
@file
Created on April 03, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines TrafficManager class
"""
from pexpect import TIMEOUT

from framework.traffic.jmeter.jmeter_soap_traffic import JmeterSOAPTraffic
from framework.traffic.jmeter.jmeter_soap_traffic_simulator import JmeterSOAPTrafficSimulator
from framework.traffic.jmeter.jmeter_traffic_profile import JmeterTrafficProfile
from framework.traffic.ptool.ptool_diameter_traffic import PtoolDiameterTraffic
from framework.traffic.ptool.ptool_diameter_traffic_simulator import PtoolDiameterTrafficSimulator
from framework.traffic.ptool.ptool_traffic_profile import PtoolTrafficProfile
from framework.traffic.spectra.spectra_sigtran_traffic import SpectraSigtranTraffic
from framework.traffic.spectra.spectra_sigtran_traffic_simulator import SpectraSIGTRANTrafficSimulator
from framework.traffic.spectra.spectra_traffic_profile import SpectraTrafficProfile
from framework.traffic.tgen.tgen_ldap_traffic import TgenLDAPTraffic
from framework.traffic.tgen.tgen_ldap_traffic_simulator import TgenLDAPTrafficSimulator
from framework.traffic.tgen.tgen_traffic_profile import TgenTrafficProfile
from framework.traffic.traffic import BadQosException
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger


logger = Logger.getLogger(__name__)

class TrafficManagerException(BaseException):
    """If error, raise it."""
    pass

class TrafficManager(object):
    """ @details This class manages (starts, stops, checks QoS) all traffics defined in configuration.xml. """

    TRAFFIC_HELP_LINK = "For traffic setup, please visit: " + \
                        "https://atlassianwave.web.alcatel-lucent.com/confluence/display/SDM8650/" + \
                        "Running+traffic+%28tgen%2C+ptool%2C+Mistral%29+from+Jenkins"

    def __init__(self):
        """ TrafficManager class constructor """

        self.startedTraffics = []
        self.firstQoS = True
        self.nbTrafficProfiles = 0
        self.databaseStateManager = None
        self.linuxProcessManager = None
        self.errorMsg = ""
        self.badQosOccured = False


    def startAllTraffics(self, trafficProfile, testEnv):
        """
        @details This method starts all traffics defined in configuration.xml.
        @param trafficProfile Configuration attribute listing all SimulatorTrafficProfiles
        @param testEnv instance of TestEnv class containing a test environment (testEnv) from configuration file
        @exception Exception if at least one scenario couldn't start """

        logger.debug("Try to start all traffics")
        self.errorMsg = ""
        # the traffics must be killed and restarted if already exist
        killIfExists = True
        self.nbTrafficProfiles = len(trafficProfile.simulatorsTrafficProfiles)

        for aSimulatorTrafficProfile in trafficProfile.simulatorsTrafficProfiles:

            if isinstance(aSimulatorTrafficProfile, PtoolTrafficProfile):
                profileInfo = "FE Key: " + aSimulatorTrafficProfile.FE_Key \
                             + " scenario: " + aSimulatorTrafficProfile.scenario \
                             + " application: " + aSimulatorTrafficProfile.application \
                             + " transport: " + aSimulatorTrafficProfile.transport
                logger.debug("Ptool traffic profile found => " + profileInfo)
                simulFound = False
                for myTrafficSimulator in testEnv.trafficSimulators:
                    if isinstance(myTrafficSimulator, PtoolDiameterTrafficSimulator):
                        if (myTrafficSimulator.application == "all"
                            or myTrafficSimulator.application == aSimulatorTrafficProfile.application) \
                            and (myTrafficSimulator.transport == "all"
                                 or myTrafficSimulator.transport == aSimulatorTrafficProfile.transport):
                            logger.debug("Ptool traffic simulator found => host/ip: "
                                         + myTrafficSimulator.toolIpAddress)
                            simulFound = True
                            myTraffic = PtoolDiameterTraffic(aSimulatorTrafficProfile, myTrafficSimulator,
                                                             testEnv.testBed, self.databaseStateManager,
                                                             self.linuxProcessManager)
                            try:
                                myTraffic.start(killIfExists)
                                self.startedTraffics.append(myTraffic)
                            except BaseException as ex:
                                self.errorMsg += ex.message + " for " + myTraffic.trafficInfo + "\n"
                            break
                # end for loop
                if not simulFound:
                    self.errorMsg += msgs.PTOOL_TRAFFIC_SIMULATOR_NOT_FIT + ": " + profileInfo + "\n"

            elif isinstance(aSimulatorTrafficProfile, TgenTrafficProfile):
                profileInfo = "application: " + aSimulatorTrafficProfile.application + \
                             " scenario: " + aSimulatorTrafficProfile.scenario + \
                             " tps: " + aSimulatorTrafficProfile.tps
                logger.debug("Tgen traffic profile found => " + profileInfo)
                simulFound = False
                for myTrafficSimulator in testEnv.trafficSimulators:
                    if isinstance(myTrafficSimulator, TgenLDAPTrafficSimulator):
                        if myTrafficSimulator.application == aSimulatorTrafficProfile.application:
                            logger.debug("Tgen traffic simulator found => host/ip: " + myTrafficSimulator.toolIpAddress)
                            simulFound = True
                            myTraffic = TgenLDAPTraffic(aSimulatorTrafficProfile, myTrafficSimulator, testEnv.testBed)
                            try:
                                myTraffic.start(killIfExists)
                                self.startedTraffics.append(myTraffic)
                            except BaseException as ex:
                                self.errorMsg += ex.message + " for " + myTraffic.trafficInfo + "\n"
                            break
                # end for loop
                if not simulFound:
                    self.errorMsg += msgs.TGEN_TRAFFIC_SIMULATOR_NOT_FIT + ": " + profileInfo + "\n"

            elif isinstance(aSimulatorTrafficProfile, SpectraTrafficProfile):
                for myTrafficSimulator in testEnv.trafficSimulators:
                    if isinstance(myTrafficSimulator, SpectraSIGTRANTrafficSimulator):
                        myTraffic = SpectraSigtranTraffic(aSimulatorTrafficProfile, myTrafficSimulator, testEnv.testBed)
                        try:
                            myTraffic.start()
                            self.startedTraffics.append(myTraffic)
                            logger.debug("start " + myTraffic.trafficType + " traffic successful.")
                        except TIMEOUT:
                            self.errorMsg += "Timeout reached. No answer from Spectra for " + myTraffic.trafficInfo + "\n"
                        except BaseException as ex:
                            self.errorMsg += ex.message + " for " + myTraffic.trafficInfo + "\n"
                        break
                # end for loop
            elif isinstance(aSimulatorTrafficProfile, JmeterTrafficProfile):
                for myTrafficSimulator in testEnv.trafficSimulators:
                    if isinstance(myTrafficSimulator, JmeterSOAPTrafficSimulator):
                        myTraffic = JmeterSOAPTraffic(aSimulatorTrafficProfile, myTrafficSimulator, testEnv.testBed)
                        try:
                            myTraffic.start(killIfExists)
                            self.startedTraffics.append(myTraffic)
                            logger.debug("start " + myTraffic.trafficType + " traffic successful.")
                        except BaseException as ex:
                            self.errorMsg += "- " + ex.message + " for " + myTraffic.trafficInfo + "\n"
                        break
        # end for loop
        if self.errorMsg:
            logger.error(msgs.TRAFFIC_MANAGER_TRAFFIC_NOT_STARTED + ":\n" + self.errorMsg)
            logger.info(self.TRAFFIC_HELP_LINK)
            raise TrafficManagerException(msgs.TRAFFIC_MANAGER_TRAFFIC_NOT_STARTED + ":\n" + self.errorMsg)


    def startTrafficsAgainIfNeeded(self):
        """
        @details This method starts again all traffics that were successfully started by initial startAllTraffics
        The ones who failed are not tried this time.
        @exception Exception if at least one scenario couldn't start """

        self.errorMsg = ""
        # the traffics must not be killed and restarted if already exist
        killIfExists = False
        startedTraffics = self.startedTraffics
        self.startedTraffics = []
        for myTraffic in startedTraffics:
            try:
                myTraffic.start(killIfExists)
                self.startedTraffics.append(myTraffic)
            except TIMEOUT:
                self.errorMsg += "Timeout reached for " + myTraffic.trafficInfo + "\n"
            except BaseException:
                self.errorMsg += "-" + myTraffic.trafficInfo + "\n"

        if self.errorMsg:
            # logging is done in tgen/ptool.. traffic scripts themselves
            raise TrafficManagerException(msgs.TRAFFIC_MANAGER_TRAFFIC_NOT_STARTED + ":\n" + self.errorMsg)


    def _callTrafficMethod(self, myTraffic, method):
        """ Private method to call a traffic method and stop it in case of error
        @param myTraffic: current Traffic instance
        @param method: method from Traffic instance to be called
        @return stopTraffic: boolean indicating the traffic was stopped """

        logger.debug(myTraffic.trafficInfo)
        stopTraffic = False
        try:
            getattr(myTraffic, method)()
        except TIMEOUT:
            self.errorMsg += "Timeout reached for " + myTraffic.trafficInfo + "\n"
            logger.error(self.errorMsg)
            stopTraffic = True
        except BadQosException as ex:
            if self.firstQoS:
                # if a traffic has a bad QoS at first check, we stop it
                # an exception will be raised at the end of the loop
                stopTraffic = True
                self.badQosOccured = True
        except BaseException as ex:
            self.errorMsg += ex.message + " for " + myTraffic.trafficInfo + "\n"
            logger.error(self.errorMsg)
            stopTraffic = True
        if stopTraffic:
            # an exception has occurred, the traffic is going to be stopped
            try:
                myTraffic.stop()
            except BaseException as ex:
                self.errorMsg += ex.message + " for " + myTraffic.trafficInfo + "\n"
            logger.warning("This traffic will not be started anymore: " + myTraffic.trafficInfo)
        return stopTraffic


    def checkGlobalQoSAllTraffics(self):
        """
        @details This method checks the QoS for all traffics from the beginning. """

        anyTrafficStopped = False
        self.badQosOccured = False
        # remainingTraffics used to avoid updates on startedTraffics which is the loop generator
        remainingTraffics = list(self.startedTraffics)
        self.errorMsg = ""
        trafficInfos = ""
        for myTraffic in self.startedTraffics:
            if self._callTrafficMethod(myTraffic, "checkGlobalQoS"):
                remainingTraffics.remove(myTraffic)
                anyTrafficStopped = True
                trafficInfos += "- " + myTraffic.trafficInfo + "\n"

        self.startedTraffics = list(remainingTraffics)
        if self.firstQoS:
            self.firstQoS = False
            logger.info("Number of traffics started: " + str(len(self.startedTraffics)) + \
                        " (over " + str(self.nbTrafficProfiles) + " profiles)")
            if anyTrafficStopped and self.badQosOccured:
                # one or more traffics were stopped due to bad first QoS
                # logging is done in tgen/ptool.. traffic scripts themselves
                raise TrafficManagerException(msgs.TRAFFIC_MANAGER_TRAFFIC_STOPPED_BAD_FIRST_QOS + ":\n"
                                              + trafficInfos)
        if anyTrafficStopped and not self.badQosOccured:
            # one or more traffics were stopped due to another exception
            # logging is done in tgen/ptool.. traffic scripts themselves
            raise TrafficManagerException(self.errorMsg)


    def setQoSStartingPointAllTraffics(self):
        """
        @details This sets a starting point from which to calculate the QoS, for instance, after a disturbance.
        To get the QoS from this point, use trafficManager.checkQoSFinalPointAllTraffics.
        Checks the current number of requests and errors for all started traffics.
        The data is stored in the traffic instance. """

        self.errorMsg = ""
        # remainingTraffics used to avoid updates on startedTraffics which is the loop generator
        remainingTraffics = list(self.startedTraffics)

        for myTraffic in self.startedTraffics:
            if self._callTrafficMethod(myTraffic, "getRequestsAndErrors"):
                remainingTraffics.remove(myTraffic)

        self.startedTraffics = list(remainingTraffics)
        if self.errorMsg:
            # logging is done in tgen/ptool.. traffic scripts themselves
            raise TrafficManagerException(self.errorMsg)


    def checkQoSFinalPointAllTraffics(self, targetQos=0.000001):
        """
        @details Checks the current number of requests and errors for all started traffics and calculate
        the QoS from previous values.
        The previous values were set by trafficManager.setQoSStartingPointAllTraffics.
        So, to get the QoS after a disturbance, first call trafficManager.setQoSStartingPointAllTraffics
        and after some minutes, trafficManager.checkQoSFinalPointAllTraffics. """

        self.errorMsg = ""
        # remainingTraffics used to avoid updates on startedTraffics which is the loop generator
        remainingTraffics = list(self.startedTraffics)

        for myTraffic in self.startedTraffics:
            if self._callTrafficMethod(myTraffic, "getRequestsAndErrors"):
                remainingTraffics.remove(myTraffic)
                continue
            errors = myTraffic.nbErrorsEnd - myTraffic.nbErrorsStart
            requests = myTraffic.nbRequestsEnd - myTraffic.nbRequestsStart
            # requests can be 0 because we only take into account failed3004 and 5012 but not others ("failed" counter)
            if requests == 0:
                qos = 1
            else:
                qos = float(errors) / float(requests)
            if qos not in [0, 1]:
                qos = "{:1.8f}".format(qos)
            msg = myTraffic.trafficInfo + ") => QoS disturb.:" + \
                  str(qos) + " (requests: " + str(requests) + " errors: " + str(errors) + ")"
            logger.debug(msg)
            if float(qos) > targetQos:
                logger.error("Bad QoS: " + msg)

        self.startedTraffics = list(remainingTraffics)
        if self.errorMsg:
            # logging is done in tgen/ptool.. traffic scripts themselves
            raise TrafficManagerException(self.errorMsg)


    def checkDisturbanceAllTraffics(self, disturbances, trafficType, disturbName, hardware, sdmRelease):
        """
        @details This method checks for all started traffics if the number of errors after a disturbance is compliant
        with specification.
        The calling function must perform the right sleep duration (corresponding to disturbance specification)
        before calling.
        @param disturbances Object from Disturbances class handling the disturbances described in configuration file
        @param trafficType Type of traffic (provisioning, telecom)
        @param disturbName Name of the disturbance as described in configuration file
        @param hardware  Lab type: HP, Bono or Rouzic
        @param sdmRelease SDM release from Disturbances """

        self.errorMsg = ""
        # remainingTraffics used to avoid updates on startedTraffics which is the loop generator
        remainingTraffics = list(self.startedTraffics)
        for myTraffic in self.startedTraffics:
            if self._callTrafficMethod(myTraffic, "getRequestsAndErrors"):
                remainingTraffics.remove(myTraffic)
                continue
            disturbTime = disturbances.getDisturbance(trafficType, disturbName, hardware, sdmRelease)
            acceptedErrors = int(round(int(myTraffic.tps) * int(disturbTime) / 1000))
            nbErrors = myTraffic.nbErrorsEnd - myTraffic.nbErrorsStart  # errors due to the disturbance
            if nbErrors > acceptedErrors:
                logger.error("Too many traffic errors: " + str(nbErrors) + " Max. accepted: " + str(acceptedErrors))

        self.startedTraffics = list(remainingTraffics)
        if self.errorMsg:
            # logging is done in tgen/ptool.. traffic scripts themselves
            raise TrafficManagerException(self.errorMsg)


    def stopAllTraffics(self):
        """
        @details This method stops all traffics defined in configuration.xml """

        self.errorMsg = ""
        for myTraffic in self.startedTraffics:
            try:
                myTraffic.stop()
            except TIMEOUT:
                self.errorMsg += "Timeout reached for " + myTraffic.trafficInfo + "\n"
            except BaseException as ex:
                self.errorMsg += ex.message + " for " + myTraffic.trafficInfo + "\n"
                continue

        if self.errorMsg:
            # logging is done in tgen/ptool.. traffic scripts themselves
            raise TrafficManagerException(self.errorMsg)
