'''
Created on Aug 20, 2015

@author: Xia Zhao
'''
from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import SPA_TIMEOUT, \
    SPA_STATE_ASSERT_TIME


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0503_restart_pdlsx_fe_swo_pilot_master_slave(SDMTestCase):
    '''test kill all PDLSx processes on one FE of the testbed
    and swo control pilot on MASTER & SLAVE '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self._mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.databaseTopologyManager = self.sdmManager.databaseTopologyManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.success = True
        self.exceptMsg = ""

    def test_restart_pdls(self):
        ''' test kill pdls '''

        LOGGER.debug("Check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("Start to choose one FE to test this case")
        fes = self.testEnv.testBed.getFrontends()
        feID, fe = fes.popitem()  # will return one over all FEs (no order in a dictionary)
        LOGGER.info("Kill all pdls on FE: " + str(feID))

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.debug("Kill all pdls on FE at: " + startTime)

        # Kill one PDLS
        pdlsList = ["PDLSU1", "PDLSI1", "PDLSL1", "PDLSM1"]
        foundProcess = None
        for plds in pdlsList:
            processOnblades = self.sdmManager.linuxProcessManager.getProcessPids(fe, plds)
            if processOnblades:
                LOGGER.debug("Found process %s", plds)
                foundProcess = plds
                break
        else:
            raise BaseException, "No PDLS available"
        self.sdmManager.linuxProcessManager.advancedKillWaitProcess(fe, foundProcess, processOnblades.keys(),
                                                                    logLevel='debug')

        LOGGER.debug("Call mcasApplicationManager.assertSPAState to check spa status on all blades")
        CommonAssert.timedAssert(SPA_TIMEOUT, SPA_STATE_ASSERT_TIME,
                                  self.sdmManager.mcasApplicationManager.assertSPAStateOnStations,
                                 fe, "SDM", "IS", fe.getStationListbyProductRole('RT').values(), 'debug')
        LOGGER.debug("Call mcasMachineManager.checkMachineStatus to check op:status,machine=all is COMPL")
        CommonAssert.timedAssert(SPA_TIMEOUT, SPA_STATE_ASSERT_TIME,
                                  self.sdmManager.mcasMachineManager.checkMachineStatus, fe, logLevel='debug')


        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", feID)

        LOGGER.debug("swo control pilot on MASTER & SLAVE")
        beList = self.testEnv.testBed.getBackends().values()
        for be in beList:
            LOGGER.info("%s: swo control pilot", be.id)
            self.assertTrue(self.mcasMachineManager.pilotSwitchover(be))

        LOGGER.debug("Check the alarms")
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(fe, myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.error("%s: alarm check fail", feID)


        LOGGER.debug("Check the end status of the test env")
        try:
            labs = [lab for lab in self.testEnv.testBed.labs.values() if lab not in beList]
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: end state of test env check fail", feID)

        if self.success:
            LOGGER.debug("ff0503_restart_pdlsx_fe_swo_pilot_master_slave success!\n")
        else:
            LOGGER.error("ff0503_restart_pdlsx_fe_swo_pilot_master_slave failed!\n")
            LOGGER.error(self.exceptMsg)
            # spa recover done in jenkins worker
            raise Exception(self.exceptMsg)
