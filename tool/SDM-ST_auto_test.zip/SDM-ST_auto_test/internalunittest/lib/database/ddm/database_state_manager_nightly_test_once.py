'''
Created on Mar 30, 2015
Added Test 10 and 11 Jun 6, 2015 Tangi Lavanant
Changes Jul 10
@author: Xia Zhao
'''
import unittest
from lib.logging.logger import Logger
import lib.exceptions_messages as msgs
from framework.sdm_test_case import SDMTestCase
from framework.asserts.common_asserts import CommonAssert
logger = Logger.getLogger(__name__)

class database_state_manager_nightly_test_once(SDMTestCase):
    '''
    These tests once are supposed to cover code of database_state_manager
    '''

    def setUp(self):
        logger.info("DatabaseStateManagerTest Test")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.databaseStateManager = self.sdmManager.databaseStateManager
        bes = self.testEnv.testBed.getNRG()
        # Suppose there are two BEs at least in NRG 1, or some cases will fail
        self.master = self.databaseStateManager.getMasterBE(bes)[0]
        slaves = list(bes)
        slaves.remove(self.master)
        self.slave1 = slaves[0]
        self.slave2 = slaves[0]
        logger.debug("master BE is " + self.master.id + ", slave1 is " + self.slave1.id)

    def tearDown(self):
        pass

    def test_0_getState_success(self):
        """ checks getState is OK """
        state = self.databaseStateManager.getState(self.slave1)
        self.assertEqual(state, 'SLAVE')
        state = self.databaseStateManager.getState(self.master)
        self.assertEqual(state, 'MASTER')
        state = self.databaseStateManager.getState(self.slave1, 'DB access')
        self.assertEqual(state, 'OK_RO')
        state = self.databaseStateManager.getState(self.master, 'DB access')
        self.assertEqual(state, 'OK_RW')
        state = self.databaseStateManager.getState(self.slave1, 'Global Status')
        self.assertEqual(state, 'The slave is secured')

    def test_1_getState_failed(self):
        """ checks getState fails when called with an unknown DB state """
        self.assertRaisesRegexp(BaseException, msgs.GET_DATABASE_STATE_FAIL, \
                                 self.databaseStateManager.getState, self.slave1, 'DB accessABC')


    def test_2_getState_all_success(self):
        """ checks getState with different fields """
        state = self.databaseStateManager.getState(self.slave1, None)
        self.assertEqual(state['Operator Status'], 'SLAVE')
        self.assertEqual(state['DB access'], 'OK_RO')
        self.assertEqual(state['Global Status'], 'The slave is secured')

    def test_3_getMasterBE_1_client_failed1(self):
        """ checks getMasterBE with 1 master in the list 
        if there is one BE in one NRG, it should be N0_MATED_PAIR not Master, """
        clientList = [self.master]
        self.assertRaisesRegexp(BaseException, msgs.GET_MASTER_BE_FAIL, self.databaseStateManager.getMasterBE, clientList)

    def test_4_getMasterBE_1_client_failed2(self):
        """ checks getMasterBE with a slave in the list """
        clientList = [self.slave1]
        self.assertRaisesRegexp(BaseException, msgs.GET_MASTER_BE_FAIL, self.databaseStateManager.getMasterBE, clientList,)


    def test_5_getMasterBE_2_client_success(self):
        """ checks getMasterBE with 1 master and 1 slave in the list """
        clientList = [self.slave1, self.master]
        master = self.databaseStateManager.getMasterBE(clientList)
        self.assertEqual(master[0], self.master)

    def test_6_getMasterBE_2_client_failed(self):
        """ checks getMasterBE with 2 slaves in the list """
        clientList = [self.slave1, self.slave2]
        self.assertRaisesRegexp(BaseException, msgs.GET_MASTER_BE_FAIL, self.databaseStateManager.getMasterBE, clientList,)

    def test_7_getMasterBE_3_client_success(self):
        """ checks getMasterBE with 1 master and 2 slaves in the list """
        clientList = [self.slave1, self.master, self.slave2]
        master = self.databaseStateManager.getMasterBE(clientList)
        self.assertEqual(master[0], self.master)

    def test_8_getNDBState_success(self):
        """ checks getNDBState """
        self.databaseStateManager.getNDBState(self.slave1, '0-0-2')
        self.assertEqual(self.databaseStateManager.getNDBState(self.slave1, '0-0-2'), 'started')
        self.assertEqual(self.databaseStateManager.getNDBState(self.slave1, '2'), 'started')
        self.assertEqual(self.databaseStateManager.getNDBState(self.master, '0-0-10'), 'started')
        state = self.databaseStateManager.getNDBState(self.master)
        logger.debug(str(state))

    def test_9_StationassertNdbState(self):
        """
        This test is used to check if Assert of NP DB state is OK
        """
        logger.info(" Check if Station C is started")

        CommonAssert.timedAssert(30, 1, self.databaseStateManager.assertNdbState, \
                                        self.master, 'started', '0-0-10', 'debug')
        logger.info("Station C is started")

    def test_10_lab_assertNdbState(self):
        """
        This test is used to check if cluster DB state is started
        """
        logger.info("Check if cluster DB is started")

        # self.DM.setHalfClusterBE(self.client)
        CommonAssert.timedAssert(60, 5, self.databaseStateManager.assertNdbState, \
                                        self.master, 'started', logLevel='debug')
        logger.info("cluster DB is started")
   
    def test_11_lab_isAutomaticSwoEnabled(self):
        """
        This test is used to check if the "Automatic swo" parameter is enabled
        """
        logger.info("Check if Automatic swo is enabled")
        isEnabled = self.databaseStateManager.isAutomaticSwoEnabled(self.slave1)
        logger.info("--- Automatic swo is enabled : %s", isEnabled)

    def test_12_lab_disableAutomaticSwo(self):
        """
        Check disable Automatic swo is OK
        """
        logger.info("Change the 'Automatic swo' paramter to disable")
        self.databaseStateManager.disableAutomaticSwo(self.slave1)
        isEnabled = self.databaseStateManager.isAutomaticSwoEnabled(self.slave1)
        logger.info("--- Automatic swo is enabled : %s", isEnabled)

    def test_13_lab_enableAutomaticSwo(self):
        """
        Check enable Automatic swo is OK
        """
        logger.info("Change the 'Automatic swo' paramter to enable")
        self.databaseStateManager.enableAutomaticSwo(self.slave1)
        isEnabled = self.databaseStateManager.isAutomaticSwoEnabled(self.slave1)
        logger.info("--- Automatic swo is enabled : %s", isEnabled)

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
