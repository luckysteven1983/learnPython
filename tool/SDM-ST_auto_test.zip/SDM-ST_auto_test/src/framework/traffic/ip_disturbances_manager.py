"""
@file
Created on July 17th, 2015
@ingroup SDMSQA Automation
@author Serge Beaufils
@brief Manages GDMP and REPL IP Disturbances set on lab ( ADD SHOW DEL) for traffic
"""


import os
import re

from framework.testenv.backend import Backend
from framework.testenv.frontend import Frontend
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_PILOT


LOGGER = Logger.getLogger(__name__)


PREFIX_RC = '0-0-'
ROOT_DIR = '/etc/nectar/conf/'

DEFAULT_LATENCY = 50  # msec
DEFAULT_JITTER = 10  # msec
DEFAULT_PACKET_LOSS = 0.1  # %

TC_SET = "ssh -q {0} 'tc qdisc add dev {1} root netem "  # CAUTION : this one w/o the trailing quote
TC_SHOW = "ssh -q {0} 'tc qdisc show | grep netem'"
TC_DEL = "ssh -q {0} 'tc qdisc del dev {1} root netem'"



class ManageIpDisturbancesError(BaseException):
    """If error, raise it."""
    pass



class IpDisturbancesManager(object):
    """
    @details This class manages all IP disturbances on Ethernet interfaces (REPL/GDMP) for traffic
    @usage :
        self.feIpDisturb = IpDisturbancesManager(self.sdmManager.sshManager, self.fe [,gdmp=True] [,repl=True] )
        self.feIpDisturb.showIpDisturbance()
        self.feIpDisturb.setIpDisturbanceLatency(latency=100)
        self.feIpDisturb.setIpDisturbancePacketLoss(packetLoss=0.05)
        self.feIpDisturb.deleteIpDisturbance()
        self.feIpDisturb.setIpDisturbanceLatencyJitterPacketLoss(packetLoss=0.02)
                    ( Latency and Jitter will be default values = 50 and 10)
    @verbatim
        linux tc qdisc command is used to tweak kernel internal parameters and simulate network
        latency and/or packet loss
        See http://www.lartc.org/manpages/tc.txt
        and http://www.linuxfoundation.org/collaborate/workgroups/networking/netem
    """


    def __init__(self, sshManager, lab, gdmp=False, repl=False):
        """ IpDisturbancesManager class constructor """
        self._sshManager = sshManager
        self.lab = lab
        self._gdmp = gdmp
        self._repl = repl
        if lab.hardware[0:2] != 'HP' and lab.hardware != 'ROUZIC' and lab.hardware[0:4] != 'BONO' \
                and lab.hardware != 'VMMHI':
            self._raiseError(msgs.HARDWARE_NOT_SUPPORTED + lab.hardware)

        # make the list of Ethernet interfaces (GDMP and REPL)
        self.ethInterfaces = []
        if gdmp:
            self.ethInterfaces += self._getInterfaces('gdmp')
        if repl:
            # get REPL if any and compare to existing list (REPL is often the same as GDMP)
            for itf in self._getInterfaces('repl'):
                if not itf in self.ethInterfaces:
                    self.ethInterfaces.append(itf)

        # On FE HP, must avoid iLB blades .  Must include pilots
        blads = lab.getBladeListbymiddlewareRole(MIDDLEWARE_ROLE_PILOT).keys()
        if isinstance(lab.productRole, Frontend):
            blads += lab.getStationListbyProductRole('RT').keys()
        elif isinstance(lab.productRole, Backend):
            blads += lab.getStationListbyProductRole('DB').keys()
        self.boards = sorted(blads, key=alphanum_key)


    def _raiseError(self, excMsg):
        ''' routine to raise an error '''
        LOGGER.error(self.lab.id + ' : ' + excMsg)
        raise ManageIpDisturbancesError, self.lab.id + ' : ' + excMsg



    # ===============  Privates methods   =====================


    def _getInterfaces(self, interfaceName):
        '''
        get the eth interface names for interfaces as 'repl' or 'gdmi'
        @param interfaceName : the interface names = 'repl' 'gdmi'
        @return a list of interface. Ex : [ 'eth0.13', 'eth1.14' ]
        '''
        filName = ROOT_DIR + interfaceName + '.ini'
        cmd = 'grep DEVICE ' + filName
        rc, out = self._sshManager.run(self.lab.oamIpAddress, cmd)
        if rc == 0:
            return out.split('=')[1].strip().split('/')
        else:
            self._raiseError(msgs.CONF_FILE_MISSING + filName)


    def _manageIpDisturbance(self, operation, latencyValue=None, jitterValue=None, packetLossValue=None):
        '''
        Method to make the operations on a disturbance : ADD / SHOW / DEL
        @param sshClient : the paramiko SSH client on the lab where to set-display-delete the IP disturbance
        @param operation : Add / show or Del the disturbance
        @param latency : value of latency un msec. None means no latency disturbance set
        @param jitter : value of jitter un msec. None means no jitter set on latency
                        jitter is a variation in msec around the latency
        @param packetLoss : percentage of packet loss. None means no packet loss disturbance set
        '''

        if operation == 'SHOW':
            cmdRoot = TC_SHOW

        elif operation == 'DEL':
            cmdRoot = TC_DEL

        elif operation == 'ADD':
            latencyCmd = (' delay ' + str(latencyValue) + 'ms ')  if latencyValue is not None else ''
            latencyCmd += (str(jitterValue) + 'ms ')  if jitterValue is not None else ''
            packetCmd = (' loss ' + str(packetLossValue) + '% ')  if packetLossValue is not None else ''
            cmdRoot = TC_SET + latencyCmd + packetCmd + "'"  # dont forget the trailing quote

        else:
            self._raiseError(msgs.UNKNOWN_OPERATION + operation)

        # in the following loop : rc, return code of the command, is considered OK if :
        #        for ADD  : rc=0
        #    or  for SHOW : rc=0 or 1  (rc=1 when show with no IP dusturbance)
        #    or  for DEL  : rc=0 or 2  (rc=2 when Delete with no IP disturbance)
        outAll = ''
        for board in self.boards:
            for eth in self.ethInterfaces:
                cmd = cmdRoot.format(board, eth)
                LOGGER.debug(self.lab.id + ' : SSH Command on %s is below', eth)
                rc, out = self._sshManager.run(self.lab.oamIpAddress, cmd)
                if rc != 0 and (operation != 'SHOW' or rc != 1) and (operation != 'DEL' or rc != 2):
                    self._raiseError(msgs.COMMAND_FAILED + cmd + os.linesep + out)
                if operation == 'DEL' or rc == 2:  # it is an expected error msg : dont display it
                    out = ''
                outAll += '[' + board + '] ' + out + os.linesep
                if operation == 'SHOW':
                    break  # with SHOW command : only 1 loop for each interface

        return outAll.rstrip() if operation == 'SHOW' else None



    # ===============  Public  methods   =====================


    def showIpDisturbance(self):
        '''
        show IP disturbance set on the remote lab
        @return the output of the command. Each line is suffixed by '[blade] '
        '''
        return self._manageIpDisturbance(operation='SHOW')


    def deleteIpDisturbance(self):
        '''
        delete the IP disturbances set on the remote lab
        @return the output of the command (in fact nothing)
        NOTE : the method remove the IP disturbance on each blade but ONLY if
               there is one. If no IP disturbance on blade : no error, we
               continue to next blade
        '''
        return self._manageIpDisturbance(operation='DEL')


    def setIpDisturbanceLatency(self, latency=DEFAULT_LATENCY):
        '''
        set an IP disturbance  on a lab with Latency only (no jitter)
        @return the output of the command (in fact nothing)
        '''
        return self._manageIpDisturbance(operation='ADD',
                                      latencyValue=latency)


    def setIpDisturbanceLatencyJitter(self, latency=DEFAULT_LATENCY,
                                             jitter=DEFAULT_JITTER):
        '''
        set an IP disturbance  on a lab with latency+jitter
        @return the output of the command (in fact nothing)
        '''
        return self._manageIpDisturbance(operation='ADD',
                                      latencyValue=latency,
                                       jitterValue=jitter)


    def setIpDisturbancePacketLoss(self, packetLoss=DEFAULT_PACKET_LOSS):
        '''
        set an IP disturbance  on a lab with Packet loss only.
        It is not possible to call this method after having set the latency with
        another call. You must use the appropriate call.
        @return the output of the command (in fact nothing)
        '''
        return self._manageIpDisturbance(operation='ADD',
                                   packetLossValue=packetLoss)


    def setIpDisturbanceLatencyPacketLoss(self, latency=DEFAULT_LATENCY,
                                             packetLoss=DEFAULT_PACKET_LOSS):
        '''
        set an IP disturbance  on a lab with Latency (no jitter) and packet loss
        @return the output of the command (in fact nothing)
        '''
        return self._manageIpDisturbance(operation='ADD',
                                      latencyValue=latency,
                                   packetLossValue=packetLoss)


    def setIpDisturbanceLatencyJitterPacketLoss(self, latency=DEFAULT_LATENCY,
                                                       jitter=DEFAULT_JITTER,
                                                   packetLoss=DEFAULT_PACKET_LOSS):
        '''
        set an IP disturbance  on a lab with Latency+jitter and Packet loss
        @return the output of the command (in fact nothing)
        '''
        return self._manageIpDisturbance(operation='ADD',
                                      latencyValue=latency,
                                       jitterValue=jitter,
                                   packetLossValue=packetLoss)




def alphanum_key(_str):
    ''' ----- allow natural sort of a list : img1,img3,img10  instead of img1,img10,img3
        ----- syntax :  sorted(list,key=alphanum_key). Ref: http://nedbatchelder.com/blog/200712/human_sorting.html
    @param s : the key to be "naturally" sorted
    @return list : the list sorted according to the numerical part
    ---------------------------- '''
    return [int(c) if c.isdigit() else c for c in re.split('([0-9]+)', _str)]



