'''
Created on May 5, 2015
@author: FrankZh

This module is used by the automation Framework to call SU jobs
'''

import os
from time import sleep
import threading

from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from lib.database.ddm.database_state_manager import DatabaseStateManager, DatabaseStateManagerError
from lib.database.ddm.database_topology_manager import DatabaseTopologyManager
from lib.database.ddm.database_manager import DatabaseManager, DatabaseManagerError
from framework.testenv.backend import Backend
from framework.testenv.frontend import Frontend
from framework.testenv.provfrontend import ProvFrontend
from lib.platform.mcas.subshl.subshl_manager import SubshlManager
from lib.platform.mcas.mcas_application_manager import McasApplicationManager, McasApplicationManagerError
from lib.platform.linux_process_manager import LinuxProcessManager
from lib.common.multi_tasks_manager import MultiTasksManager

from lib.softwareupdate.sdm_su_job_handler import SdmSuJobHandler
from lib.softwareupdate.sdm_su_constants import SdmSuConst
from lib.softwareupdate.sdm_su_common_func import SdmSuUtils
from lib.softwareupdate.sdm_su_prerequisite import SdmSuPrerequisite
import lib.exceptions_messages as msgs

LOGGER = Logger.getLogger(__name__)

class SdmSuManagerError(BaseException):
    """If error, raise it."""
    pass


class SdmSuManager(object):
    """
    SU management class
    """

    def __init__(self, sshManager=None):
        """
        Constructor
        """
        self._sshManager = sshManager

        if not sshManager:
            self._sshManager = SshManager()
        else:
            self._sshManager = sshManager

        self.databaseTopologyManager = DatabaseTopologyManager(self._sshManager)
        self.dbStateMngr = DatabaseStateManager(self._sshManager, self.databaseTopologyManager)
        self.dbManager = DatabaseManager(self._sshManager, self.dbStateMngr, None)
        self.args = None
        self.testEnv = None
        self.dictSuReport = dict()
        self.reportMutex = threading.Lock()
        self.crystelBeFile = None
        self.crystelBeList = list()

    def _checkSuModes(self, suModes):
        '''
        check the SU mode validation
        @param suModes: download, apply, commit or backout
        return True or False
        '''
        ret = True
        if len(suModes) > 1:
            if SdmSuConst.DOWNLOAD in suModes \
                and SdmSuConst.COMMIT in suModes \
                and SdmSuConst.APPLY not in suModes:
                LOGGER.error("download and commit exist but apply not")
                ret = False

        elif len(suModes) < 1:
            ret = False

        return ret

    def _workaroundForDownload(self, labIp):
        '''
        this function is to add workaround for download for intra-release SU
        @param labIp: the ip address of the sdm lab
        return boolean
        '''
        ret = True
        # if intra-release SU, touch /etc/SU/.MCAS_skip_version_check
        strCMD = "touch /etc/SU/.MCAS_skip_version_check"
        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, 'root')
        if lRst[0] != 0:
            LOGGER.error("failed to touch /etc/SU/.MCAS_skip_version_check on lab[%s]. \
                Please check. exit", labIp)
            ret = False

        return ret

    def _getOamScriptsVersion(self, labIp):
        '''
        get OamScript version on the SDM lab
        @param labIp: the ip address of the SDM lab
        return string: if oamScript is installed already, return its version; if not, return ''
        '''
        oamScriptsVer = ''
        strCMD = "cat /PLATsoftware/OAM/ISSUE"
        [status, output] = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, SdmSuConst.SU_USER)
        if status != 0:
            LOGGER.info("retrieving OAMScripts version failed on lab[%s]. ", labIp)
        else:
            ver = output.strip()
            oamScriptsVer = ver if ver[-1] != os.linesep else ver[:-1]

        return oamScriptsVer


    def installOamScripts(self, labIp, loadSvrIp, loadSvrLogin, oamScriptsLoc):
        '''
        get oamScripts and install it
        @param labIp: the SDM lab ip address
        @param loadSvrIp: the software server ip address
        @param loadSvrLogin: the login of the software server
        @param oamScripsLoc: the directory of storing OAMScripts package
        return: string: the oamscripts version. if failed, return ''
        '''
        oamScriptsVer = ''
        if oamScriptsLoc[-1] == '/':
            oamScriptsLoc = oamScriptsLoc[:-1]

        strCMD = "rm -f /etc/SU/OAMscripts_MCAS*; scp %s@%s:%s/OAMscripts_MCAS_* /etc/SU" \
        % (loadSvrLogin, loadSvrIp, oamScriptsLoc)
        LOGGER.debug("command: [%s]", strCMD)
        [status, _] = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, SdmSuConst.SU_USER)
        if status != 0:
            LOGGER.error("scp OAMScripts version failed from load server[%s]", loadSvrIp)
        else:
            LOGGER.debug("try to install OAMScripts on lab[%s]", labIp)
            strCMD = "cd /PLATsoftware; tar xzfo /etc/SU/OAMscripts_MCAS*.tar.gz;" + \
            "/PLATsoftware/OAM/bin/OAMinstall.sh"
            LOGGER.debug("command: [%s]", strCMD)
            lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, 'root')
            if lRst[0] == 0:
                oamScriptsVer = self._getOamScriptsVersion(labIp)
                LOGGER.info("install OAMScripts[%s] succeeded on lab[%s]", oamScriptsVer, labIp)
            else:
                LOGGER.error("failed to install OAMScripts on lab[%s]", labIp)

        return oamScriptsVer

    def _checkSdmUpgradeTool(self, labIp):
        '''
        check if SDM upgrade tools is installed on lab
        @param labIp: the SDM lab ip address
        return boolean
        '''
        ret = False
        strCMD = "ls /PLATsoftware/SU/patches/State/SUcheck_CHECK:Start/"
        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, 'root')
        if lRst[0] == 0:
            if 'SUcheck_CHECK' in lRst[1]: #SUcheck_CHECK-start.sh
                LOGGER.debug("SDM Upgrade tools is installed on lab[%s] already", labIp)
                ret = True

        return ret

    def _emptyEtcSU(self, labIp, user):
        """
        remove files in /etc/SU before install agent/download
        @param labIp: the SDM lab ip address
        @param user: the SDM lab login
        return boolean
        """
        ret = False
        strCMD = "rm -f /etc/SU/*"
        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, user)
        if lRst[0] <= 1:
            LOGGER.debug("remove files in /etc/SU on lab[%s]", labIp)
            ret = True

        return ret

    def _copyDdmIni2Deliv(self, labIp, user):
        '''
        copy ddm configuration files to /DELIV
        @param labIp: the SDM lab ip address
        @param user: the SDM lab login
        return boolean
        '''
        ret = False
        strCMD = "cp /etc/SU/*.ini /DELIV"
        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, user)
        if lRst[0] == 0:
            LOGGER.debug("move DDM configuration files to /DELIV on lab[%s]", labIp)
            ret = True

        return ret

    def _execSuadmPrecheck(self, labIp, user):
        '''
        execute SUadm precheck before SU
        @param labIp: the SDM lab ip address
        @param user: the SDM lab login
        return boolean
        '''
        ret = False
        strCMD = "/PLATsoftware/OAM/bin/SUadm precheck"
        LOGGER.debug("command is: %s", strCMD)
        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, user)
        if lRst[0] == 0:
            LOGGER.debug("successfully run SUadm precheck on lab[%s] before SU", labIp)
            ret = True
        else:
            LOGGER.error("failed to run /PLATsoftware/OAM/bin/SUadm precheck on lab[%s], " + \
                "please run it manually to check what happened", labIp)

        return ret

    def getLabIdByLabIp(self, labIp):
        '''
        get lab ID(hostname in general) by lab IP in testenv
        @param labIp: the SDM lab ip address
        return string
        '''
        labId = ''
        for lab in self.testEnv.testBed.labs.values():
            if lab.oamIpAddress == labIp:
                labId = lab.id
                break

        return labId

    def getMatedpair(self, beLabId):
        '''
        find the mated pair BE in one NRG
        '''
        lab = self.testEnv.testBed.labs[beLabId]

        peerBeList = []
        if isinstance(lab.productRole, Backend):
            peerBeList = self.testEnv.testBed.getLabsInNRG(lab.productRole.networkReplicatedGroup)
            peerBeList.remove(lab)

        return peerBeList

    def getAllNrgs(self):
        """
        get all NRGs in the testEnv and put them in a dictionay
        return dictionary
        """
        dicBeNrgs = {}
        nrgNo = 0

        while True:
            lstBe = []
            lstBe = self.testEnv.testBed.getLabsInNRG(str(nrgNo + 1))
            if lstBe:
                dicBeNrgs[nrgNo + 1] = [each.id for each in lstBe]
                nrgNo += 1
            else:
                break

        return [nrgNo, dicBeNrgs]

    def masterToSlave(self, lab, dbManager, dbStateMngr):
        '''
        if BE is master, switchover to the slave one. when it is no way to get the OAM IP address
        of the mated pair BE, this function can get the replication ip addresses of other BEs in
        the same NRG and get the slave one. then ssh to the slave BE to do switchover
        if this lab is not master or is master but no mated pair BE, will return True
        @param lab: the lab to be upgraded or in SU
        @return bool
        '''
        ret = True
        try:
            if dbStateMngr.getState(lab, 'Operator Status') == 'MASTER':
                LOGGER.debug('BE[%s] is master now', lab.id)

                if self.getMatedpair(lab.id):
                    glbStatus = dbStateMngr.getState(lab, 'Global Status')
                    if 'disconnected' in glbStatus or 'not secured' in glbStatus:
                        LOGGER.debug('BE[%s] is not mated pair now, not to do switchover', lab.id)
                    else:
                        labList = self.testEnv.testBed.getLabsInNRG(lab.productRole.networkReplicatedGroup)
                        LOGGER.debug('BE[%s]:begin to do BE switchover', lab.id)
                        dbManager.matedPairSwo(labList, True, 60)
        except (AssertionError, DatabaseManagerError), ex:
            LOGGER.error('failed to try do BE switchover. reason: %s', ex)
            ret = False

        return ret

    def rmvDelSdmSpa(self, targetLab, spaType, mcasApplicationManager):
        '''
        remove/delete OAMBE/OAM/SDM SPA
        @param targetLab: the SDM lab
        @param spaType: OAMBE, OAM or SDM
        @param mcasApplicationManager:
        return boolean
        '''
        labId = targetLab.id
        spaType = spaType.strip()
        spaVer = mcasApplicationManager.getSPAVersion(targetLab, spaType)
        spaVer = spaType + spaVer.strip()
        LOGGER.debug('SPA is %s on lab[%s]', spaVer, labId)
        ret = True

        try:
            spaStatus = mcasApplicationManager.getSPAStatus(targetLab, spaVer)
            LOGGER.debug('SPA[%s] status is %s on lab[%s]', spaVer, spaStatus['SPA STATE'], labId)
            if SdmSuConst.SPASTATUS['IN_SERVICE'] == spaStatus['SPA STATE']:
                LOGGER.debug("try to remove/delete SPA[%s]", spaVer)

                mcasApplicationManager.removeSPA(targetLab, spaVer, 600, True)
                mcasApplicationManager.deleteSPA(targetLab, spaVer, 600)

            elif spaStatus['SPA STATE'] in (SdmSuConst.SPASTATUS['MOOS'], \
                SdmSuConst.SPASTATUS['OUT_OF_SERVICE']):
                LOGGER.debug("try to remove SPA[%s]", spaVer)

                mcasApplicationManager.deleteSPA(targetLab, spaVer, 600)

        except McasApplicationManagerError:
            LOGGER.info('failed to remove/delete SPA failed on lab[%s]', labId)
            ret = False

        return ret

    def installRestoreSpa(self, targetLab, spaType, mcasApplicationManager):
        '''
        install and restore SMD SPA
        @param targetLab: the SDM lab
        @param spaType: OAMBE, OAM or SDM
        @param mcasApplicationManager:
        return boolean
        '''
        labId = targetLab.id
        ret = True
        try:
            spaType = spaType.strip()
            spaVer = mcasApplicationManager.getSPAVersion(targetLab, spaType)
            spaVer = spaType + spaVer.strip()
            LOGGER.debug('SPA is %s on lab[%s]', spaVer, labId)
            spaStatus = mcasApplicationManager.getSPAStatus(targetLab, spaVer)
            LOGGER.debug('SPA[%s] status is %s on lab[%s] after SU', \
                spaVer, spaStatus['SPA STATE'], labId)
            if SdmSuConst.SPASTATUS['EQUIP'] == spaStatus['SPA STATE']:
                LOGGER.info("try to install&restore SPA[%s]", spaVer)

                mcasApplicationManager.installSPA(targetLab, spaVer, 60, 600, 10, True)
                mcasApplicationManager.restoreSPA(targetLab, spaVer, 300, 10, True)
            elif SdmSuConst.SPASTATUS['MOOS'] == spaStatus['SPA STATE']:
                LOGGER.info("try to restore SPA[%s]", spaVer)
                mcasApplicationManager.restoreSPA(targetLab, spaVer, 300, 10, True)

        except McasApplicationManagerError:
            LOGGER.info('install/restore SPA failed on lab[%s]', labId)
            ret = False

        return ret

    def stopBeOperSta(self, targetLab, dbStateMngr, dbManager):
        '''
        make BE operator status to MATED_PAIR_STOP
        @param targetLab: the SDM lab
        @param dbStateMngr:
        @param dbManager:
        return boolean
        '''
        labId = targetLab.id
        ret = True
        try:
            dbStatus = dbStateMngr.getState(targetLab, 'Operator Status')
            LOGGER.debug('BE[%s] status is [%s]', labId, dbStatus)
            if dbStatus == 'MATED_PAIR_STOP':
                LOGGER.debug('BE[%s] is MATED_PAIR_STOP already', labId)
            else:
                dbManager.setState(targetLab, 'STOP_KOM', 360, 'MATED_PAIR_STOP')
                LOGGER.info('set BE[%s] to stop_kom', labId)
        except BaseException:
            LOGGER.error('failed to change DB to stop_kom on lab[%s]', labId)
            ret = False

        return ret

    def _checkTranslogEnabled(self, labIp):
        '''
        check if translog is enabled on BE
        @param labIp: the SDM lab ip address
        return boolean
        '''
        cmd = "/usr/dhafw/bin/ddmadm -f br -c isPIFE"
        LOGGER.debug("command is: %s", cmd)
        ret = False

        [status, output] = SdmSuUtils.safeSshRun(self._sshManager, labIp, cmd)
        if status:
            errorMsg = "failed to run command[%s] on lab[%s}" % (cmd, labIp)
            LOGGER.error(errorMsg)
            raise SdmSuManagerError, errorMsg
        else:
            if 'yes' in output:
                ret = True
                LOGGER.debug("translog is enabled on BE[%s]", labIp)
            else:
                LOGGER.debug("translog is disabled on BE[%s]", labIp)

        return ret

    def _creatOrRmvTranslogFlag(self, labIp, create=True):
        """
        create or remove translog flag file. in the case that translog was disabled before apply SU,
        but apply SU failed in the middle and no way enable it for platform is not up, then backout will not
        get the correct original translog status. So if translog is enabled before SU, creating a flag file
        in /u/ainet/.translog_enabled. if applying SU succeeds and the translog status is recoverd, will remove it
        @param labIp: the SDM lab ip address
        @param create: boolean, if it is True, then create the flag file, or else, to remove it
        no return, will raise error if failed
        """
        if create:
            strCMD = "touch /u/ainet/.translog_enabled"
        else:
            strCMD = "rm -f /u/ainet/.translog_enabled"

        LOGGER.debug('run command: %s', strCMD)

        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, 'root')
        if lRst[0] != 0:
            LOGGER.error("command[%s] failed on lab[%s]", strCMD, labIp)
            raise SdmSuManagerError, 'create/remove translog flag file failed'
        else:
            LOGGER.debug("command[%s] succeeds on lab[%s]", strCMD, labIp)

    def _checkTranslogFlagOnRemoteLab(self, labIp):
        """
        check if the translog flag file /u/ainet/.translog_enabled exists
        @param labIp: the SDM lab ip address
        return boolean
        """
        ret = False
        strCMD = "ls /u/ainet/.translog_enabled"
        LOGGER.debug('run command: %s', strCMD)

        lRst = SdmSuUtils.safeSshRun(self._sshManager, labIp, strCMD, SdmSuConst.SU_USER)
        if lRst[0] == 0:
            LOGGER.debug("translog was enabled before applying SU")
            ret = True

        return ret

    def _disableTranslog(self, labIp):
        '''
        disable translog on BE
        @param labIp: the SDM lab ip address
        no return. if fail, raise error
        '''
        cmd = "/usr/dhafw/bin/ddmadm -f br -c dbl"
        if not self._checkTranslogEnabled(labIp):
            LOGGER.debug("translog is already disabled on BE[%s]", labIp)
        else:
            LOGGER.debug("command is: %s", cmd)
            [status, _] = SdmSuUtils.safeSshRun(self._sshManager, labIp, cmd)
            if status:
                errorMsg = "failed to run command[%s] on lab[%s}" % (cmd, labIp)
                LOGGER.error(errorMsg)
                raise SdmSuManagerError, errorMsg
            else:
                LOGGER.debug("complete to disable translog on BE[%s]", labIp)

    def enableTranslog(self, labIp):
        '''
        enable translog on BE
        @param labIp: the SDM lab ip address
        no return. if fail, raise error
        '''
        cmd = "/usr/dhafw/bin/ddmadm -f br -c ebl"
        if self._checkTranslogEnabled(labIp):
            LOGGER.debug("translog is already enabled on BE[%s]", labIp)
        else:
            LOGGER.debug("command is: %s", cmd)

            [status, _] = SdmSuUtils.safeSshRun(self._sshManager, labIp, cmd)
            if status:
                errorMsg = "failed to run command[%s] on lab[%s}" % (cmd, labIp)
                LOGGER.error(errorMsg)
                raise SdmSuManagerError, errorMsg
            else:
                LOGGER.debug("complete to enable translog on BE[%s]", labIp)

    def execWaBeforeSuOrBktForBE(self, targetLab, dbManager, dbStateMngr, mcasApplicationManager, \
         translogEnabled, firstRun=True):
        '''
        apply the workarounds for BE before apply SU or backout SU
        @param targetLab: the SDM lab
        @param translogEnabled: bool, translog enabled or disabled
        @param firstAction: bool, this action is first to run, not failed before
        no return. if fail, raise error
        '''
        # do BE switchover if this BE is master and mated pair BE exists
        if firstRun:
            if not self.masterToSlave(targetLab, dbManager, dbStateMngr):
                return False

        if self.args.platformonlysu and firstRun:
            # delete OAMBE SPA
            if not self.rmvDelSdmSpa(targetLab, 'OAMBE', mcasApplicationManager):
                return False
            else:
                LOGGER.info('SPA is deleted')
            # change BE to STOP_KOM locally
            if not self.stopBeOperSta(targetLab, dbStateMngr, dbManager):
                return False
            else:
                LOGGER.info('set BE to STOP_KOM')
                # sleep 180s to wait for DbSup restart
                LOGGER.info('sleep 180s to wait for DbSup restart')
                sleep(180)
            # disable translog on BE
            try:
                if translogEnabled:
                    self._disableTranslog(targetLab.oamIpAddress)
                    LOGGER.info('translog is disabled')
            except SdmSuManagerError:
                LOGGER.error('failed to deal with translog on lab[%s]', targetLab.id)
                return False

        return True

    def _execWaAfterSuOrBktForBe(self, targetLab, dbManager, mcasApplicationManager, translogEnabled):
        '''
        apply the workarounds for BE after apply SU or backout SU
        @param targetLab: the SDM lab
        @param translogEnabled: bool, translog enabled or disabled
        no return. if fail, raise error
        '''
        # after apply SU or backout SU, make it salve. it will take a long time for db replication
        ret = True
        try:
            matedBEs = self.getMatedpair(targetLab.id)
        except BaseException:
            LOGGER.error('Failed to get mated pair for lab[%s]', targetLab.id)
            return False
        try:
            if matedBEs:
                LOGGER.info('if it is STOP_KOM. try to make BE[%s] slave,' + \
                'it will spend a long time for db replication', targetLab.id)
                dbManager.setState(targetLab, 'SLAVE', 5400, None, True, 60)
            else:
                dbManager.setState(targetLab, 'MASTER', 360, None)
        except BaseException:
            LOGGER.error('failed to change DB state on lab[%s]', targetLab.id)
            return False
        # SPA can't be installed after SU is treated as normal, not return failure
        if not self.installRestoreSpa(targetLab, 'OAMBE', mcasApplicationManager):
            LOGGER.warning('fail to install and restore SPA on lab[%s]', targetLab.id)
        else:
            LOGGER.info('complete to install and restore SPA on lab[%s]', targetLab.id)

        if matedBEs:  # BE has mated pair
            try:
                LOGGER.info('do BE switchover on lab[%s]', targetLab.id)
                matedBEs.append(targetLab)
                masterBE = self.dbStateMngr.getMasterBE(matedBEs)            # returns a list
                # in case of three-way, we don't keep the 2nd slave
                listBEForSwo = [masterBE[0], targetLab]
                dbManager.matedPairSwo(listBEForSwo, True, 120)
                LOGGER.info('BE switchover is completed')
            except BaseException, ex:
                LOGGER.exception("exception: %s", ex)
                LOGGER.error('do BE switchover failed on lab[%s]', targetLab.id)
                ret = False

        # enable translog on BE if it was enabled before
        try:
            if translogEnabled:
                self.enableTranslog(targetLab.oamIpAddress)
                LOGGER.info('translog is enabled')
                self._creatOrRmvTranslogFlag(targetLab.oamIpAddress, False)
        except SdmSuManagerError:
            LOGGER.error('failed to deal with translog on lab[%s]', targetLab.id)
            ret = False

        return ret

    def _recordResult(self, strLabId, bResult):
        '''
        record SU action result
        '''
        self.reportMutex.acquire()
        self.dictSuReport.update({strLabId: bResult})
        self.reportMutex.release()

    def _getTotalResult(self, labIdList):
        '''
        check if the results of all labs are successful. one of them is not successful, reture failure
        '''
        ret = True
        if not labIdList:
            ret = False
        else:
            self.reportMutex.acquire()
            for each in labIdList:
                if each in self.dictSuReport.keys():
                    if self.dictSuReport[each] != SdmSuConst.RST_SUCCESS:
                        ret = False
                        break
                else:
                    LOGGER.error("no result entry for %s", each)
                    ret = False
                    break
            self.reportMutex.release()

        return ret

    def _clearSuResult(self):
        """
        clear dictSuReport
        """
        self.reportMutex.acquire()
        self.dictSuReport.clear()
        self.reportMutex.release()

    def _initialSuResult(self):
        """
        clear dictSuReport
        """
        self.reportMutex.acquire()
        self.dictSuReport.clear()
        listLabId = self.args.testlabs if self.args.testlabs else self.testEnv.testBed.labs.keys()
        for eachLabId in listLabId:
            self.dictSuReport.update({eachLabId: SdmSuConst.RST_ACTION_NOT_STARTED})
        self.reportMutex.release()

    def _displayResult(self, strModeName):
        '''
        record SU action result
        '''
        LOGGER.info("%s summary:", strModeName)
        self.reportMutex.acquire()
        for eachKey in self.dictSuReport:
            if self.dictSuReport[eachKey] == SdmSuConst.RST_SUCCESS:
                LOGGER.info("%s : %s", eachKey, 'Success')
            elif self.dictSuReport[eachKey] == SdmSuConst.RST_POST_SU_FAILURE:
                LOGGER.error("%s : %s", eachKey, 'SU completed, but do post works failed')
            elif self.dictSuReport[eachKey] == SdmSuConst.RST_SU_NOT_PROCEED:
                LOGGER.error("%s : %s", eachKey, 'SU not proceeded due to lab configuratin issue')
            elif self.dictSuReport[eachKey] == SdmSuConst.RST_SU_DOWNLOAD_NOT_DONE:
                LOGGER.error("%s : %s", eachKey, 'download not completed, but try to do %s' % strModeName)
            elif self.dictSuReport[eachKey] == SdmSuConst.RST_SU_DONE_BEFORE:
                LOGGER.info("%s : %s", eachKey, 'DONE already, not procceeded')
            elif self.dictSuReport[eachKey] == SdmSuConst.RST_ACTION_NOT_STARTED:
                LOGGER.info("%s : %s", eachKey, 'not started or exit due to exceptions')
            else:
                LOGGER.error("%s : %s", eachKey, 'Failure')

        self.reportMutex.release()

    def _downloadSoftwareAction(self, labId):
        """
        download SU software on one lab. this function will be used as a thread
        """
        targetLab = self.testEnv.testBed.labs[labId]
        targetLabIp = targetLab.oamIpAddress
        suLoadDir = ''

        LOGGER.info("install_agent/download on lab[%s]", labId)

        ret = SdmSuConst.RST_SUCCESS
        oamScriptsVer = self._getOamScriptsVersion(targetLabIp)
        if oamScriptsVer:
            LOGGER.debug("the installed OAMScripts version is %s", oamScriptsVer)

            strValidActions = SdmSuUtils.getValidAction(self._sshManager, targetLabIp)
            if not strValidActions:
                LOGGER.error('valid actions is null on lab[%s], please check', labId)
                ret = SdmSuConst.RST_FAILURE
            elif 'DOWNLOAD' not in strValidActions:
                LOGGER.info('download is already completed on lab[%s] ', labId)
                LOGGER.info('on lab[%s] valid actions are %s now', labId, strValidActions)
                ret = SdmSuConst.RST_SU_DONE_BEFORE
            elif self.args.oamscripts_dir:
                actionList = ['INSTALL_AGENT', 'DOWNLOAD']
            else:
                actionList = ['DOWNLOAD']
        else:
            LOGGER.info("no OAMScripts exists on lab: %s. install it firstly.", labId)
            if self.installOamScripts(targetLabIp, self.args.load_server, \
                                self.args.load_server_login, self.args.oamscripts_dir):
                actionList = ['DOWNLOAD']
            else:
                LOGGER.error("installing OAMScripts failed on lab[%s], please check it.", labId)
                ret = SdmSuConst.RST_FAILURE

        if ret != SdmSuConst.RST_SUCCESS:
            return ret

        if isinstance(targetLab.productRole, ProvFrontend):
            suLoadDir = self.args.pfe_load_dir
        elif isinstance(targetLab.productRole, Frontend):
            suLoadDir = self.args.fe_load_dir
        elif isinstance(targetLab.productRole, Backend):
            suLoadDir = self.args.be_load_dir
        else:
            LOGGER.error("error: unknown lab type on lab %s.", labId)
            return SdmSuConst.RST_FAILURE

        pilotAFixIp = SdmSuUtils.getPilotFixedIpByVip(self._sshManager, targetLabIp)[0]
        if self.args.platformonlysu:
            # actually, this WA is only for intra-release SU; for inter-release SU, it doesn't impact badly too.
            if not self._workaroundForDownload(pilotAFixIp):
                return SdmSuConst.RST_FAILURE
        # remove files in /etc/SU except dir
        self._emptyEtcSU(pilotAFixIp, 'root')

        suJobHandler = SdmSuJobHandler()
        suJobHandler.setAttr(self._sshManager, targetLabIp, labId, actionList, self.args.load_server, \
             suLoadDir, self.args.load_server_login, self.args.oamscripts_dir)
        ret = suJobHandler.execJobs()
        if ret != SdmSuConst.RST_SUCCESS:
            LOGGER.error("install_agent/download fail on lab: %s. Please check.", labId)
        else:
            LOGGER.info("install_agent/download succeeded on lab[%s]", labId)

        return ret

    def _downloadSoftwareThread(self, labId):
        '''
        the thhread for downloading software on a lb
        '''
        result = self._downloadSoftwareAction(labId)

        self._recordResult(labId, result)

    def performSuPrerequisite(self):
        """
        perform SU -- prerequisite including HELPME platform, BE state, ssh key creation to load server
        return: RST_FAILURE or RST_SUCCESS
        """
        sdmSuPrerequisite = SdmSuPrerequisite(self._sshManager)
        multiTasks = MultiTasksManager()
        labs = self.testEnv.testBed.labs.values()

        for lab in labs:
            threadName = multiTasks.register(sdmSuPrerequisite.checkHelpme, lab)
            LOGGER.debug("Check HELPME platform on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        if not multiTasks.runMultiTasks():
            LOGGER.error(msgs.HELPME_FAILURE)
            return False

        for lab in labs:
            threadName = multiTasks.register(sdmSuPrerequisite.checkBEState, lab)
            LOGGER.debug("Check BE state on Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        if not multiTasks.runMultiTasks():
            LOGGER.error(msgs.BE_STATE_FAILURE)
            return False

        for lab in labs:
            threadName = multiTasks.register(sdmSuPrerequisite.installSshkeyBetweenLabAndServer,
                                             lab=lab,
                                             loadServerIP=self.args.load_server,
                                             serverUser=self.args.load_server_login,
                                             serverPassword=self.args.load_server_password,
                                             labUser=SdmSuConst.SU_USER,
                                             labPassword=SdmSuConst.SU_USER_PASSWD)
            LOGGER.debug("Install SSH key for Lab '%s' in progress -> thread ID '%s'", lab.id, threadName)
        if not multiTasks.runMultiTasks():
            LOGGER.error(msgs.SSH_KEY_FAILURE)
            return False

        return True

    def performSuDownload(self):
        """
        perform SU -- install agent or download
        return: RST_FAILURE or RST_SUCCESS
        """
        downloadThreads = []
        listLabIds = self.args.testlabs if self.args.testlabs else self.testEnv.testBed.labs.keys()

        # initial SU result
        self._initialSuResult()

        for labId in listLabIds:
            # start download threads for each lab
            dt = threading.Thread(target=self._downloadSoftwareThread, args=(labId,))
            downloadThreads.append(dt)

        for eachThr in downloadThreads:  # start threads
            eachThr.start()

        for eachThr in downloadThreads:
            eachThr.join()  # wait download threads end

        # download report for all labs
        self._displayResult('download')

        # if failed on some one lab, then reture failure
        ret = SdmSuConst.RST_SUCCESS

        for eachKey in self.dictSuReport:
            if self.dictSuReport[eachKey] not in (SdmSuConst.RST_SUCCESS, SdmSuConst.RST_SU_DONE_BEFORE):
                ret = SdmSuConst.RST_FAILURE

        return ret

    def _verifySdmSuTools(self, labId):
        '''
        check if the SDM SU tool is installed and determine if the input parameter platformonlysu is right
        '''
        targetLabIp = self.testEnv.testBed.labs[labId].oamIpAddress
        sdmSuToolInstalled = self._checkSdmUpgradeTool(targetLabIp)

        ret = SdmSuConst.RST_SUCCESS
        if not sdmSuToolInstalled:
            LOGGER.debug("SDM Upgrade tools is not installed on lab[%s]", labId)

        if self.args.platformonlysu == sdmSuToolInstalled:
            if self.args.platformonlysu:
                LOGGER.error("platformonlysu is selected but SDM Upgrade tools is also installed on lab[%s]", labId)
            else:
                LOGGER.error("SDM Upgrade tools is not installed on lab[%s] for whole SDM SU", labId)

            ret = SdmSuConst.RST_FAILURE

        return ret, sdmSuToolInstalled

    def _preSuHandler(self, mode, labId, dbManager, dbStateMngr, mcasApplicationManager, firstRun):
        """
        this function is used to do post works after apply or backout SU
        @labId: the lad identity
        @param translogEnabled: bool, translog enabled or disabled
        """
        targetLab = self.testEnv.testBed.labs[labId]
        targetLabIp = targetLab.oamIpAddress
        bTranslogEnabled = False
        bMatedpair = True

        ret, sdmSuToolInstalled = self._verifySdmSuTools(labId)
        if ret == SdmSuConst.RST_FAILURE:
            LOGGER.error('failed to check SDM SU tools on lab[%s]', labId)
        elif isinstance(targetLab.productRole, Backend):
            LOGGER.debug('%s is BE', labId)

            if not self.getMatedpair(labId):
                bMatedpair = False

            if sdmSuToolInstalled and not bMatedpair:
                LOGGER.error("on standalone BE[%s], SDM SU tools is installed " + \
                "which will cause SU failed. Please check the parameters and lab", labId)
                ret = SdmSuConst.RST_FAILURE

            elif self.args.platformonlysu and firstRun:
                try:
                    bTranslogEnabled = self._checkTranslogEnabled(targetLabIp)
                    if bTranslogEnabled:
                        self._creatOrRmvTranslogFlag(targetLabIp, True)

                    if not bTranslogEnabled and mode == SdmSuConst.BACKOUT:
                        bTranslogEnabled = self._checkTranslogFlagOnRemoteLab(targetLabIp)
                except SdmSuManagerError:
                    LOGGER.error('failed to deal with translog on lab[%s]', labId)
                    ret = SdmSuConst.RST_FAILURE

            if ret == SdmSuConst.RST_SUCCESS:
                if not self.execWaBeforeSuOrBktForBE(targetLab, dbManager, dbStateMngr, mcasApplicationManager, \
                                         bTranslogEnabled, firstRun):
                    ret = SdmSuConst.RST_FAILURE

        elif isinstance(targetLab.productRole, Frontend):
            LOGGER.debug('%s is FE', labId)
            if self.args.platformonlysu:
                # remove and delete OAM SPA
                if not self.rmvDelSdmSpa(targetLab, 'OAM', mcasApplicationManager):
                    ret = SdmSuConst.RST_FAILURE
                # remove and delete SDM SPA
                elif not self.rmvDelSdmSpa(targetLab, 'SDM', mcasApplicationManager):
                    ret = SdmSuConst.RST_FAILURE
                else:
                    LOGGER.info('SDM and OAM SPA are deleted on FE %s', labId)
        elif isinstance(targetLab.productRole, ProvFrontend):
            LOGGER.debug('this lab is Proxy-FE')
            if self.args.platformonlysu and firstRun:
                # remove and delete PROXY SPA
                if not self.rmvDelSdmSpa(targetLab, 'PROXY', mcasApplicationManager):
                    ret = SdmSuConst.RST_FAILURE
                else:
                    LOGGER.info('PROXY SPA is deleted on PFE %s', labId)

        return ret, bTranslogEnabled

    def _postSuHandler(self, labId, dbManager, mcasApplicationManager, translogEnabled):
        """
        this function is used to do post works after apply or backout SU
        @labId: the lad identity
        @param translogEnabled: bool, translog enabled or disabled
        """
        targetLab = self.testEnv.testBed.labs[labId]
        targetLabIp = targetLab.oamIpAddress

        ret = SdmSuConst.RST_SUCCESS
        if self.args.platformonlysu:
            if isinstance(targetLab.productRole, Backend):
                # run workarounds
                if not translogEnabled:
                    translogEnabled = self._checkTranslogFlagOnRemoteLab(targetLabIp)
                if not self._execWaAfterSuOrBktForBe(targetLab, dbManager, \
                                                    mcasApplicationManager, translogEnabled):
                    ret = SdmSuConst.RST_POST_SU_FAILURE
                else:
                    LOGGER.info('completed post works on BE %s', labId)
            # SPA can't be installed after SU is treated as normal, not return failure
            elif isinstance(targetLab.productRole, Frontend):
                if self.args.platformonlysu:
                    # install and restore OAM SPA
                    if not self.installRestoreSpa(targetLab, 'OAM', mcasApplicationManager):
                        LOGGER.warning('failed to install OAM SPA on FE %s', labId)
                    #install and restore SDM SPA
                    elif not self.installRestoreSpa(targetLab, 'SDM', mcasApplicationManager):
                        LOGGER.warning('install OAM SPA successfully, but failed to install SDM SPA on FE %s', labId)
                        #ret = SdmSuConst.RST_POST_SU_FAILURE
                    else:
                        LOGGER.info('OAM&SDM SPA are restored on FE %s', labId)
            elif isinstance(targetLab.productRole, ProvFrontend):
                if self.args.platformonlysu:
                    # install and restore PROXY SPA
                    if not self.installRestoreSpa(targetLab, 'PROXY', mcasApplicationManager):
                        LOGGER.warning('failed to install proxy SPA on FE %s', labId)
                    else:
                        LOGGER.info('proxy SPA is installed on PFE %s', labId)

        return ret

    def _applySuOnSingleLab(self, labId):
        """
        apply SU on one lab
        @param labId: the lab identity. it is host name in general
        return: RST_FAILURE or RST_SUCCESS
        """
        linuxProcessManager = LinuxProcessManager(self._sshManager)
        subshlManager = SubshlManager(self._sshManager)
        mcasApplicationManager = McasApplicationManager(self._sshManager, subshlManager, linuxProcessManager)

        targetLab = self.testEnv.testBed.labs[labId]
        targetLabIp = targetLab.oamIpAddress
        bFirstRun = True
        ret = SdmSuConst.RST_FAILURE

        LOGGER.info("apply SU on lab[%s]", labId)

        strValidActions = SdmSuUtils.getValidAction(self._sshManager, targetLabIp)
        if not strValidActions:
            LOGGER.error('valid actions is null on lab[%s], please check', labId)
            return ret

        if 'VERIFY' not in strValidActions and 'BACKOUT' not in strValidActions \
            and 'RESUME2' not in strValidActions:
            LOGGER.error('lab[%s] has not entered into SU apply phase yet', labId)
            return SdmSuConst.RST_SU_DOWNLOAD_NOT_DONE
        elif 'COMMIT' in strValidActions and 'SOAK' not in strValidActions \
            and 'AFX_APPLY' not in strValidActions:
            LOGGER.info('SU apply is completed on lab %s already', labId)
            return SdmSuConst.RST_SUCCESS

        if 'DOWNLOAD' not in strValidActions:
            LOGGER.debug("apply SU ever failed on lab[%s] before", labId)
            bFirstRun = False

        # get pilot-A fix ip
        pilotAFixIp = SdmSuUtils.getPilotFixedIpByVip(self._sshManager, targetLabIp)[0]

        # execute SUadm precheck before SU
        if bFirstRun:
            LOGGER.info("execute SUadm precheck before SU on lab[%s]", labId)
            if not self._execSuadmPrecheck(pilotAFixIp, 'root'):
                return ret
        # do pre-works
        ret, translogEnabled = self._preSuHandler(SdmSuConst.APPLY, labId, \
            self.dbManager, self.dbStateMngr, mcasApplicationManager, bFirstRun)
        if ret != SdmSuConst.RST_SUCCESS:
            LOGGER.error('failed to do pre-works on lab[%s]', labId)
            return ret
        # copy ddm ini files to /DELIV if they are updated
        if self.args.platformonlysu:
            self._copyDdmIni2Deliv(pilotAFixIp, 'root')

        bEfxApplySwitch = False
        if self.args.efx_apply_patch_dir is not None:
            if self.args.efx_apply_ne_type is None:
                bEfxApplySwitch = True
            else:
                for eachRole in self.args.efx_apply_ne_type:
                    eachRole = eachRole.strip().upper()
                    if isinstance(self.testEnv.testBed.labs[labId].productRole, SdmSuConst.LABROLE[eachRole]):
                        bEfxApplySwitch = True
                        break

        suJobHandler = SdmSuJobHandler()
        suJobHandler.setAttr(self._sshManager, targetLabIp, labId, efxApplySwitch=bEfxApplySwitch, \
                             efxPatchesPath=self.args.efx_apply_patch_dir)
        ret = suJobHandler.applySU()
        if ret != SdmSuConst.RST_SUCCESS:
            LOGGER.error('failed to apply SU on lab[%s]', labId)
            return ret
        else:
            LOGGER.info('apply SU on lab[%s] succeeds. will do post SU works', labId)
            ret = self._postSuHandler(labId, self.dbManager, mcasApplicationManager, translogEnabled)
            if ret != SdmSuConst.RST_SUCCESS:
                LOGGER.error('failed to do post-works on lab[%s]', labId)

        return ret

    def _commitSuOnSingleLab(self, labId):
        """
        commit SU
        return: RST_FAILURE or RST_SUCCESS
        """
        targetLab = self.testEnv.testBed.labs[labId]
        targetLabIp = targetLab.oamIpAddress

        LOGGER.info("commit SU on lab[%s]", labId)

        ret = SdmSuConst.RST_SUCCESS

        strValidActions = SdmSuUtils.getValidAction(self._sshManager, targetLabIp)
        if not strValidActions:
            LOGGER.error('valid actions is null on lab[%s], please check', labId)
            ret = SdmSuConst.RST_FAILURE
            return ret

        curActState = SdmSuUtils.getLastActAndStatus(self._sshManager, targetLabIp).strip().split('-')
        if 'COMMIT' not in strValidActions:
            if curActState[0].strip() == 'COMMIT' and curActState[1].strip() == 'SUCCESS':
                LOGGER.info('COMMIT has been completed already on lab[%s]', labId)
                return SdmSuConst.RST_SUCCESS
            else:
                LOGGER.info('lab[%s] has not entered into soaking stage yet, commit is not allowed.' + \
                'valid actions is %s now', labId, strValidActions)
                return SdmSuConst.RST_SU_NOT_PROCEED

        elif curActState[0].strip() == 'COMMIT':
            LOGGER.debug("COMMIT SU ever failed on lab[%s] before", labId)
        # if this lab is Backend, check if it is slave. if not, do be switchover
        if isinstance(targetLab.productRole, Backend):

            # do BE switchover if this BE is master and mated pair BE exists
            if not self.masterToSlave(targetLab, self.dbManager, self.dbStateMngr):
                ret = SdmSuConst.RST_FAILURE
                return ret

        actionList = ['COMMIT']

        suJobHandler = SdmSuJobHandler()
        suJobHandler.setAttr(self._sshManager, targetLabIp, labId, actionList)

        ret = suJobHandler.execJobs()
        if ret != SdmSuConst.RST_SUCCESS and self.args.platformonlysu:
            LOGGER.warning("commit SU fail on lab: %s. retry", labId)
            ret = suJobHandler.execJobs() # retry if commit failure

        if ret == SdmSuConst.RST_SUCCESS:
            suJobHandler.clearAttr()
            LOGGER.info("commit SU succeeded on lab[%s]", labId)
        else:
            ret = SdmSuConst.RST_FAILURE
            LOGGER.error("commit SU fail on lab: %s. Please check. exit", labId)

        return ret

    def _backoutSuOnSingleLab(self, labId):
        """
        roll back SU
        return: RST_FAILURE or RST_SUCCESS
        """
        linuxProcessManager = LinuxProcessManager(self._sshManager)
        subshlManager = SubshlManager(self._sshManager)
        mcasApplicationManager = McasApplicationManager(self._sshManager, subshlManager, linuxProcessManager)
        targetLab = self.testEnv.testBed.labs[labId]
        targetLabIp = targetLab.oamIpAddress
        bFirstRun = True

        LOGGER.info("backout SU on lab[%s]", labId)

        ret = SdmSuConst.RST_SUCCESS

        strValidActions = SdmSuUtils.getValidAction(self._sshManager, targetLabIp)
        if not strValidActions:
            LOGGER.error('valid actions is null on lab[%s], please check', labId)
            ret = SdmSuConst.RST_FAILURE
            return ret

        curActState = SdmSuUtils.getLastActAndStatus(self._sshManager, targetLabIp).strip().split('-')
        # BACKOUT or BACKOUT_SOAK or RESUME2 is not in valid action list
        if 'BACKOUT' not in strValidActions and 'RESUME2' not in strValidActions:
            LOGGER.info('BACKOUT is not allowed on lab[%s] ', labId)
            LOGGER.info('valid actions is %s now on lab[%s]', strValidActions, labId)
            if curActState[0].strip() == 'BACKOUT' or curActState[0].strip() == 'RESUME2':
                LOGGER.info('backout was done on lab[%s] before', labId)
                ret = SdmSuConst.RST_SUCCESS
            elif curActState[0].strip() == 'COMMIT':
                LOGGER.info('commit was done on lab[%s] before, backout will be ignored', labId)
                ret = SdmSuConst.RST_SU_COMMIT_DONE
            else:
                LOGGER.error('lab[%s] is not upgraded yet, backout can not be proceeded', labId)
                ret = SdmSuConst.RST_SU_NOT_PROCEED

            return ret

        elif 'BACKOUT' in curActState[0].strip() or 'RESUME2' == curActState[0].strip():
            LOGGER.debug("BACKOUT failed on lab[%s] before", labId)
            bFirstRun = False

        # do pre-works
        ret, translogEnabled = self._preSuHandler(SdmSuConst.APPLY, labId, \
            self.dbManager, self.dbStateMngr, mcasApplicationManager, bFirstRun)
        if ret != SdmSuConst.RST_SUCCESS:
            LOGGER.error('failed to do pre-works on lab[%s]', labId)
            return ret

        if 'BACKOUT_SOAK' in strValidActions:
            actionList = ['BACKOUT_SOAK', 'RESUME2']
        elif 'RESUME2' in strValidActions:
            actionList = ['RESUME2']
        else:
            actionList = ['BACKOUT']

        suJobHandler = SdmSuJobHandler()
        suJobHandler.setAttr(self._sshManager, targetLabIp, labId, actionList)
        ret = suJobHandler.execJobs()
        if ret != SdmSuConst.RST_SUCCESS:
            LOGGER.error("BACKOUT fail on lab: %s. Please check. exit", labId)
            ret = SdmSuConst.RST_FAILURE
        else:
            LOGGER.info('backout SU on lab[%s] succeeds! will do post backout works', labId)
            ret = self._postSuHandler(labId, self.dbManager, mcasApplicationManager, translogEnabled)
            if ret != SdmSuConst.RST_SUCCESS:
                LOGGER.error('failed to do post-works on lab[%s]', labId)

        return ret

    def _performSuThread(self, labId, mode):
        '''
        the thread for calling _applySuOnSingleLab/_commitSuOnSingleLab/_backoutSuOnSingleLab.
        and record the result on each lab
        @param labId: the lab identity. it is host name in general
        @param mode: one of apply, commit and backout
        '''
        if mode == SdmSuConst.APPLY:
            result = self._applySuOnSingleLab(labId)
        elif mode == SdmSuConst.COMMIT:
            result = self._commitSuOnSingleLab(labId)
        elif mode == SdmSuConst.BACKOUT:
            result = self._backoutSuOnSingleLab(labId)
        #for efx_backout, the logic is not clear, so the handler for efx_backout will be added late
        #elif mode == SdmSuConst.EFX_BACKOUT:
        #    result = self._backoutSuOnSingleLab(labId)


        self._recordResult(labId, result)

    def _performSuOnBEsInOneNrg(self, labIdList, mode):
        """
        apply/commit/backout SU
        @param labIdList: the lab identity in the same NRG
        @param mode: apply, commit or backout
        return: None
        """
        ret = SdmSuConst.RST_SUCCESS
        lstLabs = [self.testEnv.testBed.labs[eachId] for eachId in labIdList]
        nrg = int(lstLabs[0].productRole.networkReplicatedGroup)

        LOGGER.info('begin to perform SU on NRG[%d]', nrg)

        try:
            lstMasterBe = self.dbStateMngr.getMasterBE(lstLabs)
        except DatabaseStateManagerError:
            LOGGER.info("master be is not availble in NRG[%d]", nrg)
            lstMasterBe = []

        lstSlaveOrStopBe = lstLabs
        if lstMasterBe:
            lstSlaveOrStopBe.remove(lstMasterBe[0])

        if len(labIdList) > 3:
            LOGGER.error('wrong lab configuration, there are more than three BE in NRG[%d]', nrg)
            ret = SdmSuConst.RST_SU_NOT_PROCEED
        elif lstMasterBe and len(lstMasterBe) > 1:
            LOGGER.error('wrong lab status, there are more than one master BE in NRG[%d]', nrg)
            ret = SdmSuConst.RST_SU_NOT_PROCEED
        elif lstSlaveOrStopBe and len(lstSlaveOrStopBe) > 2:
            LOGGER.error('wrong lab status, there are more than one master BE in NRG[%d]', nrg)
            ret = SdmSuConst.RST_SU_NOT_PROCEED

        if ret == SdmSuConst.RST_SU_NOT_PROCEED:
            for each in labIdList:
                self._recordResult(each, ret)
            return

        nonMasterSuFail = False
        if lstSlaveOrStopBe:
            if len(lstSlaveOrStopBe) > 1:
                if self.args.platformonlysu:
                    # in paraller to upgrade non-mastart BE(3-way or Crystel)
                    self._suThreadsWrapper([each.id for each in lstSlaveOrStopBe], mode)
                else:
                    # upgrade non-master BE one by one. for Crystel BE,
                    # it should be upgrade after all master/slave BE and
                    # FE have been completed applying SU.
                    for each in lstSlaveOrStopBe:
                        if each.id not in self.crystelBeList:
                            self._performSuThread(each.id, mode)
            else:  # only one slave BE
                self._performSuThread(lstSlaveOrStopBe[0].id, mode)

            # check the SU result on the slave/stop BE
            if not self._getTotalResult([each.id for each in lstSlaveOrStopBe]):
                LOGGER.info("on NRG[%d], SU is not completed on non-master BE.", nrg)
                nonMasterSuFail = True


        if not nonMasterSuFail and lstMasterBe:
            # upgrade the original master BE.
            self._performSuThread(lstMasterBe[0].id, mode)

        LOGGER.info("%s on NRG[%d] is finished, please check the result", mode, nrg)

    def _suThreadsWrapper(self, labIdList, mode):
        """
        start and wait perform SU threads
        @param labIdList: the lab id list
        @param mode:
        """
        suThreads = []
        if labIdList:
            # if self.args.platformonlysu:
            # in paraller to upgrade NE
            for each in labIdList:
                at = threading.Thread(target=self._performSuThread, args=(each, mode))
                suThreads.append(at)

            for eachThread in suThreads:
                eachThread.start()

            for eachThread in suThreads:
                eachThread.join()  # wait SU threads end

    def _commitSuOnAllLabInParallel(self):
        """
        commit SU on all labs in parallel
        return: RST_FAILURE or RST_SUCCESS
        """
        ret = SdmSuConst.RST_FAILURE
        labIdList = self.args.testlabs if self.args.testlabs else self.testEnv.testBed.labs.keys()
        if not labIdList:
            LOGGER.info("there is no lab")
            return SdmSuConst.RST_SUCCESS

        # initial SU result
        self._initialSuResult()

        self._suThreadsWrapper(labIdList, SdmSuConst.COMMIT)

        LOGGER.info("commit SU is finished on all labs, please check the result")

        if self._getTotalResult(labIdList):
            ret = SdmSuConst.RST_SUCCESS

        return ret

    def _performAllFeAndPfeSu(self, mode):
        """
        apply/commit/backout SU on all FE and PFE
        @param mode: one of apply, commit and backout
        return: RST_FAILURE or RST_SUCCESS
        """
        ret = SdmSuConst.RST_FAILURE
        feLabIdList = self.pickOutFe()
        pfeLabIdList = self.pickOutPfe()

        if not (feLabIdList + pfeLabIdList):
            LOGGER.info("there is no FE/PFE")
            return SdmSuConst.RST_SUCCESS

        if self.args.platformonlysu:
            labIdList = feLabIdList + pfeLabIdList
        else:
            if mode in (SdmSuConst.APPLY, SdmSuConst.COMMIT):
                labIdList = feLabIdList
            elif mode == SdmSuConst.BACKOUT or mode == SdmSuConst.EFX_BACKOUT:
                labIdList = pfeLabIdList

        if labIdList:
            self._suThreadsWrapper(labIdList, mode)

        if not self.args.platformonlysu:
            if not labIdList or self._getTotalResult(labIdList):
                if mode in (SdmSuConst.APPLY, SdmSuConst.COMMIT):
                    labIdList = pfeLabIdList
                elif mode == SdmSuConst.BACKOUT  or mode == SdmSuConst.EFX_BACKOUT:
                    labIdList = feLabIdList

                if labIdList:
                    self._suThreadsWrapper(labIdList, mode)

            else:
                LOGGER.error("action %s is not completed on all FEs/PFEs, please check the result")
                return SdmSuConst.RST_FAILURE

        LOGGER.info("action is done on all FEs, please check the result")

        if self._getTotalResult(feLabIdList + pfeLabIdList):
            ret = SdmSuConst.RST_SUCCESS

        return ret

    def _performSuOnAllNrg(self, mode):
        '''
        apply/commit/backout SU on all NRG
        @param mode: one of apply, commit and backout
        return: RST_FAILURE or RST_SUCCESS
        '''
        ret = SdmSuConst.RST_FAILURE
        nrgThreads = []


        dictNrg = self.groupBeByNrg()
        nrgList = dictNrg.keys()
        nrgList.sort()
        bMainNrgFail = False
        needBackoutMainNrg = False

        if dictNrg:
            if not self.args.platformonlysu:
                if 1 in nrgList:  # do special handing for main nrg if whole SDM SU
                    if mode in (SdmSuConst.APPLY, SdmSuConst.COMMIT):
                        labIdList = dictNrg[1]
                        self._performSuOnBEsInOneNrg(labIdList, mode)
                        # check the SU result on the slave/stop BE
                        if not self._getTotalResult(labIdList):
                            LOGGER.info("action[%s] is not completed on main nrg.", mode)
                            bMainNrgFail = True
                        else:
                            nrgList.remove(1)
                    elif mode == SdmSuConst.BACKOUT or mode == SdmSuConst.EFX_BACKOUT:
                        nrgList.remove(1)
                        needBackoutMainNrg = True

            if not bMainNrgFail:  # if self.args.platformonlysu=True, apply/commit/backout all NRG
                for nrg in nrgList:
                    labIdList = dictNrg[nrg]
                    th = threading.Thread(target=self._performSuOnBEsInOneNrg, args=(labIdList, mode))
                    nrgThreads.append(th)

                for eachThread in nrgThreads:
                    eachThread.start()

                for eachThread in nrgThreads:
                    eachThread.join()  # wait SU threads end

            if needBackoutMainNrg:  # roll backout MainNrg if needed
                labIdList = dictNrg[1]
                self._performSuOnBEsInOneNrg(labIdList, mode)

            listAllBe = []
            for each in dictNrg.keys():
                listAllBe += dictNrg[each]

            if self._getTotalResult(listAllBe):
                ret = SdmSuConst.RST_SUCCESS
        else:
            ret = SdmSuConst.RST_SUCCESS

        return ret

    def _performSuOnAllLabs(self, mode):
        """
        apply/commit/backout SU on all labs
        @param mode: one of apply, commit and backout
        return: RST_FAILURE or RST_SUCCESS
        """
        ret = SdmSuConst.RST_SUCCESS
        self._initialSuResult()

        if mode in (SdmSuConst.APPLY, SdmSuConst.COMMIT):
            # first do on NRG
            if self.args.platformonlysu and mode == SdmSuConst.COMMIT:
                # commit all labs including BE,FE and PFE in parallel
                ret = self._commitSuOnAllLabInParallel()
            else:
                ret = self._performSuOnAllNrg(mode)
                if ret == SdmSuConst.RST_FAILURE:
                    LOGGER.error("action %s on BE labs failed", mode)
                else:
                    ret = self._performAllFeAndPfeSu(mode)
                    if ret == SdmSuConst.RST_FAILURE:
                        LOGGER.error("action %s on FE/PFE labs failed", mode)

        elif mode == SdmSuConst.BACKOUT:
            ret = self._performAllFeAndPfeSu(mode)
            if ret == SdmSuConst.RST_FAILURE:
                LOGGER.error("action %s on FE/PFE labs failed", mode)
            else:
                ret = self._performSuOnAllNrg(mode)
                if ret == SdmSuConst.RST_FAILURE:
                    LOGGER.error("action %s on BE labs failed", mode)

        elif mode == SdmSuConst.EFX_BACKOUT:
            ret = self._performAllFeAndPfeSu(mode)
            if ret == SdmSuConst.RST_FAILURE:
                LOGGER.error("action %s on FE/PFE labs failed", mode)
            else:
                ret = self._performSuOnAllNrg(mode)
                if ret == SdmSuConst.RST_FAILURE:
                    LOGGER.error("action %s on BE labs failed", mode)

        self._displayResult(mode)

        return ret

    def _recordCrystelBe(self):
        '''
        recording the crystel BE at the first time of running SU on this lab conf
        '''
        if not os.path.isdir(SdmSuConst.SU_CACHE_DIR):
            LOGGER.info(SdmSuConst.SU_CACHE_DIR + " directory doesn't exist, creating it")
            os.makedirs(SdmSuConst.SU_CACHE_DIR)

        _, dictNrg = self.getAllNrgs()
        try:
            if not os.path.isfile(self.crystelBeFile):
                # record crystel BE in file
                fdCrystel = open(self.crystelBeFile, 'a+')
                if dictNrg:
                    for eachKey in dictNrg.keys():
                        if len(dictNrg[eachKey]) == 3:
                            for eachLabId in dictNrg[eachKey]:
                                # DB access OK_NOTRAF; Operator Status MATED_PAIR_STOP
                                lab = self.testEnv.testBed.labs[eachLabId]
                                if self.dbStateMngr.getState(lab, 'Operator Status') == 'MATED_PAIR_STOP' \
                                    and self.dbStateMngr.getState(lab, 'DB access') == 'OK_NOTRAF':
                                    fdCrystel.write("%s" % eachLabId + os.linesep)
                                    self.crystelBeList.append(eachLabId)
                                    break
            else:
                # load crystel BE
                fdCrystel = open(self.crystelBeFile)
                for eachLine in fdCrystel:
                    eachLine = eachLine.strip()
                    strCrytelBe = eachLine if eachLine[-1] != os.linesep else eachLine[:-1]
                    self.crystelBeList.append(strCrytelBe)
        except IOError:
            fdCrystel.close()
            errorMsg = "fail to write/read file[%s]" % self.crystelBeFile
            LOGGER.error(errorMsg)
            raise SdmSuManagerError, errorMsg
        except DatabaseStateManagerError:
            fdCrystel.close()
            errorMsg = "fail to load crystel BE"
            LOGGER.error(errorMsg)
            raise SdmSuManagerError, errorMsg

        strCrystelBes = ''
        if self.crystelBeList:
            for each in self.crystelBeList:
                strCrystelBes = strCrystelBes + ' ' + each
            LOGGER.info('crystel BE: %s', strCrystelBes)

        fdCrystel.close()

    def groupBeByNrg(self):
        """
        group all BEs by nrg for the SU in parallel
        """
        dictBeGroup = {}
        _, dictNrg = self.getAllNrgs()

        for key in dictNrg.keys():
            LOGGER.debug("nrg[%d], BE list %s", key, str(dictNrg[key]))

        if self.args.testlabs:
            # if specific labs to be taken actions
            for labId in self.args.testlabs:
                if isinstance(self.testEnv.testBed.labs[labId].productRole, Backend):
                    nrgId = int(self.testEnv.testBed.labs[labId].productRole.networkReplicatedGroup)
                    if not dictBeGroup.has_key(nrgId):
                        dictBeGroup[nrgId] = []

                    dictBeGroup[nrgId].append(labId)
        else:
            dictBeGroup = dictNrg

        return dictBeGroup

    def pickOutFe(self):
        """
        pick out all FE lsbs
        return labId list
        """
        listFe = []
        if self.args.testlabs:
            for labId in self.args.testlabs:
                if isinstance(self.testEnv.testBed.labs[labId].productRole, Frontend):
                    listFe.append(labId)
        else:
            dictAllFe = self.testEnv.testBed.getFrontends()
            listFe = dictAllFe.keys()

        if  listFe:
            LOGGER.debug("all FE in testEnv are %s", str(listFe))

        return listFe

    def pickOutPfe(self):
        """
        pick out all Proxy-FE lsbs
        return labId list
        """
        listPfe = []
        if self.args.testlabs:
            for labId in self.args.testlabs:
                if isinstance(self.testEnv.testBed.labs[labId].productRole, ProvFrontend):
                    listPfe.append(labId)
        else:
            dictAllPfe = self.testEnv.testBed.getProvFrontends()
            listPfe = dictAllPfe.keys()

        if  listPfe:
            LOGGER.debug("all PFE in testEnv are %s", str(listPfe))

        return listPfe

    def performSu(self, args, testEnv):
        """
        perform SU on one SDM lab. in this function
        @param args: the user input via perform_su_jenkins
        @param testEnv: the detail information of all labs
        return: RST_FAILURE or RST_SUCCESS
        """
        self.args = args
        self.testEnv = testEnv
        self.crystelBeFile = SdmSuConst.SU_CACHE_DIR + 'crystel_' + self.args.testenv
        self._recordCrystelBe()

        suModes = self.args.testmode
        ret = SdmSuConst.RST_SUCCESS

        lstSuModes = [mode.strip().lower() for mode in suModes]
        # validate suModes
        if not self._checkSuModes(lstSuModes):
            return SdmSuConst.RST_FAILURE

        if SdmSuConst.PREREQUISITE in lstSuModes:
            LOGGER.info("begin prerequisite")
            if not self.args.load_server or not self.args.load_server_login or not self.args.load_server_password:
                LOGGER.error("software server is not set for prerequisite")
                return SdmSuConst.RST_FAILURE

            ret = self.performSuPrerequisite()
            if ret != SdmSuConst.RST_SUCCESS:
                return ret

        if SdmSuConst.DOWNLOAD in lstSuModes:
            LOGGER.info("begin install_agent/download")
            if not self.args.load_server or not self.args.load_server_login:
                LOGGER.error("software server is not set for download")
                return SdmSuConst.RST_FAILURE

            ret = self.performSuDownload()
            if ret != SdmSuConst.RST_SUCCESS:
                return ret

        if SdmSuConst.APPLY in lstSuModes:
            # apply SU on each lab
            LOGGER.info("begin apply SU")
            ret = self._performSuOnAllLabs(SdmSuConst.APPLY)
            if ret != SdmSuConst.RST_SUCCESS:
                return ret

        if SdmSuConst.COMMIT in lstSuModes:
            LOGGER.info("begin commit")
            ret = self._performSuOnAllLabs(SdmSuConst.COMMIT)
            if ret == SdmSuConst.RST_SUCCESS:
                if os.path.isfile(self.crystelBeFile):
                    os.remove(self.crystelBeFile)

        if SdmSuConst.BACKOUT in lstSuModes:
            LOGGER.info("begin backout")
            ret = self._performSuOnAllLabs(SdmSuConst.BACKOUT)
            if ret == SdmSuConst.RST_SUCCESS:
                if os.path.isfile(self.crystelBeFile):
                    os.remove(self.crystelBeFile)

        if SdmSuConst.EFX_BACKOUT in lstSuModes:
            LOGGER.info("begin backout")
            ret = self._performSuOnAllLabs(SdmSuConst.EFX_BACKOUT)
            if ret != SdmSuConst.RST_SUCCESS:
                return ret

        return ret


    def startSu(self, hostIp, suActions):
        """
        start SU job. this will be called by each test case externally
        @param hostIp: IP address of the SDM lab
        @param suActions: su action list
        return: RST_FAILURE or RST_SUCCESS
        """
        suJobHandler = SdmSuJobHandler()
        suJobHandler.sshMngr = self._sshManager
        suJobHandler.oamIpAddress = hostIp.strip()
        suJobHandler.actionList = suActions.strip().split(',')

        if ('INSTALL_AGENT' in suJobHandler.actionList) or ('DOWNLOAD' in suJobHandler.actionList):
            dictSwSvr = SdmSuUtils.getSoftwareSvrData()
            if not (dictSwSvr['SwSvrIp'] and dictSwSvr['SwLoc'] and dictSwSvr['SwSvrLogin']):
                LOGGER.error("software server information is not enough, SwSvrIp: %s, SwLoc: %s, SwSvrLogin: %s", \
                     dictSwSvr['SwSvrIp'], dictSwSvr['SwLoc'], dictSwSvr['SwSvrLogin'])
                return SdmSuConst.RST_FAILURE
            else:
                suJobHandler.softwareServerIp = dictSwSvr['SwSvrIp']
                suJobHandler.releaseFilePath = dictSwSvr['SwLoc']
                suJobHandler.sftpLogin = dictSwSvr['SwSvrLogin']

            LOGGER.debug("SwSvrIp: %s, SwLoc: %s, SwSvrLogin: %s", \
                suJobHandler.softwareServerIp, suJobHandler.releaseFilePath, suJobHandler.sftpLogin)

        return suJobHandler.execJobs()
