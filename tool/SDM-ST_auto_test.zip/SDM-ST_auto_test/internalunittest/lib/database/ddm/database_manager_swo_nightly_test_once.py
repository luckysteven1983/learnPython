"""
@file database_manager_swo_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-05-12
@brief BE switchover cases
"""

import unittest
import time
import lib.exceptions_messages as eMsgs
from framework.sdm_test_case import SDMTestCase
from lib.database.ddm.database_manager import DatabaseManagerError
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class database_manager_swo_nightly_test_once(SDMTestCase):
    """Unit test for HealthCheck class.
    """
    def setUp(self):
        LOGGER.info("TestDBswitchover Test Once")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        # Suppose there are two BEs at least in NRG 1, or some cases will fail
        self.bes = self.testEnv.testBed.getNRG()

    def test_01_Unsupported_DB_state(self):
        """Unsupported DB state
        """
        LOGGER.info('[Test case 01] Unsupported DB state')
        self.assertRaisesRegexp(DatabaseManagerError, eMsgs.UNSUPPORTED_BE_STATE,
                                self.sdmManager.databaseManager.setState, self.bes[0], 'abcdef')

    def test_02_DDM_Command_NOK(self):
        """DDM Command NOK
        """
        LOGGER.info('[Test case 02] DDM Command NOK')
        self.assertRaisesRegexp(DatabaseManagerError, eMsgs.DDM_CMD_NOK,
                                self.sdmManager.databaseManager.setState, self.fe, 'slave')

        self.assertRaisesRegexp(DatabaseManagerError, eMsgs.DDM_CMD_NOK,
                                self.sdmManager.databaseManager.setState, self.fe, 'slave', None)

    def test_03_Mated_Pair_switchover_On_Slave(self):
        """Mated pair switchover on slave
        """
        LOGGER.info('[Test case 03] Mated pair switchover on slave')
        self.sdmManager.databaseManager.matedPairSwo(self.bes)

    def test_04_Mated_Pair_switchover_On_Master(self):
        """Mated pair switchover on master
        """
        LOGGER.info('[Test case 04] Mated pair switchover on master')
        try:
            self.sdmManager.databaseManager.matedPairSwo(self.bes, False)
        except DatabaseManagerError as errorMsg:
            # in some release, BE switchover command can't be executed on master BE
            if str(errorMsg).find(eMsgs.DDM_CMD_NOK) != -1:
                LOGGER.debug('Can not do switchover on master')
            else:
                raise DatabaseManagerError, errorMsg

    def test_05_Mated_Pair_switchover_On_Slave_NOK(self):
        """Mated pair switchover on slave nok
        """
        LOGGER.info('[Test case 05] Mated pair switchover on slave nok')
        self.assertRaisesRegexp(AssertionError, eMsgs.DDM_OPERATOR_STATUS_NOK,
                                self.sdmManager.databaseManager.matedPairSwo,
                                self.bes, duration=0.05)

    def test_06_Mated_Pair_switchover_NO_Check(self):
        """Mated pair switchover without check
        """
        LOGGER.info('[Test case 06] Mated pair switchover without check')
        try:
            self.sdmManager.databaseManager.matedPairSwo(self.bes, duration=None)
        except DatabaseManagerError as errorMsg:
            # in some release, BE switchover command can't be executed on master BE
            beState = self.sdmManager.databaseStateManager.getState(self.bes).lower()
            if beState == 'master' and str(errorMsg).find(eMsgs.DDM_CMD_NOK) != -1:
                LOGGER.debug('Can not do switchover on master')
            else:
                raise DatabaseManagerError, errorMsg

    def tearDown(self):
        """Wait a while before next case"""
        LOGGER.debug('Wait a while for BE state change before next test case')
        time.sleep(30)

if __name__ == "__main__":
    unittest.main()

