echo "-----------/sn/sps/OAM*/bin/showversion --------" > be_version_info.result
/sn/sps/OAM*/bin/showversion >> be_version_info.result
echo "----------fw usage------------------------------" >> be_version_info.result
/usr/dhafw/tools/fw usage >> be_version_info.result
echo "----------fw lsndb------------------------------" >> be_version_info.result
/usr/dhafw/tools/fw lsndb >> be_version_info.result
echo "----------fw lsta------------------------------" >> be_version_info.result
/usr/dhafw/tools/fw lsta >> be_version_info.result
echo "----------mpread------------------------------" >> be_version_info.result
/usr/dhafw/bin/mpread >> be_version_info.result


