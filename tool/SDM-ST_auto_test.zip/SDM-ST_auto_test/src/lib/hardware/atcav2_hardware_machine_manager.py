'''
Created on Jun 8, 2015

@author: Serge Beaufils

This library manages hardware.useful for specific function (SHMC for ATCAV2 or OA for HP)

'''
import os
import re
from lib.hardware.hardware_machine_manager import StateHW , HardwareMachineManager, \
    SLOT_PREFIX, HardwareMachineManagerError
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager


LOGGER = Logger.getLogger(__name__)

# ---- init CONSTANTS
ROOT_USER = 'root@'
SHMC_SUFX = 'SHMC'
# --- ATCA V2  prompt could be '[root@ShMC2 root]#' (spa202oam) or simply '#' (spa79oam)
# if needed we could use dedicated promt using someting like export PS1='\u @@ \h 524245262## '
SHMC_PROMPT = '#'
CLIA_PROMPT = 'CLI>'
SHMC_PW = 'alatcav2'
SHELF_RUNNING = 'SHELFMAN RUNNING IN ACTIVE MODE'
BOARDRESET_MSG = 'Board %s reset, status returned 0'  # must substitute N before use
LOGIN_MSG = 'continue connecting'
PW_MSG = 'assword:'
MCAS_USER = 'ainet'
MCAS_PW = 'ainet1'
BOARDSTATUS_REGEX = r'(Hot Swap State:)(\s)(M\d)'
BOARDSTATUS_CMD = 'clia fru '

class AtcaV2IPMCMapping:
    '''
    Class used as to have ATCAv2 mapping for board
    '''
    def __init__(self):
        """
        class constructor
        """
    IPMCdic = { 1 : '9a', 2:'96', 3:'92', 4:'8e', 5:'8a', 6:'86' \
                    , 7:'82', 8:'84', 9:'88', 10:'8c', 11:'90', 12:'94', 13:'98', 14:'9c' }

class AtcaV2HardwareMachineManager(HardwareMachineManager):

    '''
    for ATCA V2  prompt could be '[root @ ShMC2 root]#' (spa202oam) or simply '#' (spa79oam)
    '''
    BOARDRESET_CMD = 'clia boardreset '
    # for debug : BOARDRESET_CMD = 'clia board '

    def __init__(self, sshMngr):
        super(AtcaV2HardwareMachineManager, self).__init__(sshMngr)


    def _runSHMCCommand(self, lab, cmd):
        '''
        login to SHMC and run a command.  Possible messages :
            spa82-0-0-1:/root-# ssh -q root@spa82-0-0-SHMC
              The authenticity of host 'spa82-0-0-shmc (169.254.194.4)' can't be established.
              RSA key fingerprint is 64:de:0d:5f:82:9c:94:73:52:b2:df:e3:c5:8b:43:ba.
              Are you sure you want to continue connecting (yes/no)? yes
              Warning: the RSA host key for 'spa82-0-0-shmc' differs from the key for the IP address '169.254.194.4'
              Offending key for IP in /root/.ssh/known_hosts:9
              Are you sure you want to continue connecting (yes/no)? yes
            root@spa82-0-0-shmc's password:

            SHELFMAN RUNNING IN ACTIVE MODE ...
        @param lab : instance of framework.testenv.Lab
        '''

        hostSHMC = '-'.join([lab.id, SLOT_PREFIX, SHMC_SUFX])
        _localPrompt = SHMC_PROMPT

        client = self.sshmngr.getClient(lab.oamIpAddress)
        shl = client.invoke_shell()

        # first connect to SHMC
        loginStr = self.ROOT_CMD + ROOT_USER + hostSHMC
        expStr = [LOGIN_MSG, PW_MSG, SHELF_RUNNING]
        _out, _err = SshManager.sendStringRoutine(shl, loginStr, expectString=expStr)
        for _ in xrange(1, 3):  # three questions max (cf comments)
            if re.search(LOGIN_MSG, _out):
                _out, _err = SshManager.sendStringRoutine(shl, 'yes', expectString=expStr)
            elif re.search(PW_MSG, _out):
                _out, _err = SshManager.sendStringRoutine(shl, SHMC_PW, expectString=expStr)
            elif re.search(SHELF_RUNNING, _out):
                break
            else:
                break

        # now execute cmd, hoping that output arrives before the prompt.
        _out, _err = SshManager.sendStringRoutine(shl, cmd, expectString=_localPrompt)
        errFound = (re.search('Invalid slot number:', _out) is not None)
        if errFound:
            return False, _out + os.linesep + _err
        else:
            return True, _out



##############################   PUBLIC  METHODS   #################################"


    def restartBoard(self, lab, physicalSlot):
        '''
        run the command to reset board. Then check if we got the board reset msg
        @param lab : instance of framework.testenv.Lab
        @param physicalSlot : the number of the slot to restart, must be an int
        for ex : restartBoard(lab,2)
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        self.localResetMsg = BOARDRESET_MSG % slot
        # If we are restarting active pilot, the current connection will be broken
        # Suppose the ssh connection is established to active pilot.
        activePilot = self.sshmngr.run(lab.oamIpAddress, 'hostname')[1].split('-').pop() == slot
        _, _out = self._runSHMCCommand(lab, self.BOARDRESET_CMD + slot)
        if not activePilot: # return the command
            return _out
        else: # restart active pilot, the ssh connection will be broken
            if self.sshmngr.isDead(lab.oamIpAddress, heartbeat=5, timeout=300):
                return _out
            errorMsg = "Lab %s: Restart active pilot board failure (connection still alive)" %lab.id
            LOGGER.error(errorMsg)
            raise HardwareMachineManagerError, errorMsg

    def  getHardwareState(self, lab, physicalSlot):
        '''
        Get the state of a board .
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to check
        '''
        out = self.getHardwareStateRAW(lab, physicalSlot)
        result = re.search(BOARDSTATUS_REGEX, out)
        if result.group(3) == 'M4':
            return StateHW.BOARD_POWERED_ON
        elif result.group(3) == 'M1' :
            return StateHW.BOARD_POWERED_OFF
        else :
            return StateHW.OTHER


    def  getHardwareStateRAW(self, lab, physicalSlot):
        '''
        Get the state of a board in a RAW mode.
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to check
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        cmd = BOARDSTATUS_CMD + AtcaV2IPMCMapping.IPMCdic[int(slot)] + ' 0'
        _returncode, out = self._runSHMCCommandTunnel(lab, cmd)
        if _returncode == 0 :
            return out
        else :
            LOGGER.error("Command " + cmd + " fails on " + lab.oamIpAddress)
            return out

    def _runSHMCCommandTunnel(self, lab, cmd):
        '''
        Used to run an SMHC command using the spa as gateway
        '''
        hostSHMC = '-'.join([lab.id, SLOT_PREFIX, SHMC_SUFX])
        self.sshmngr.gateway = lab.oamIpAddress
        self.sshmngr.gatewayUser = MCAS_USER
        self.sshmngr.gatewayPassword = MCAS_PW
        self.sshmngr.getClient(hostSHMC, user="root", pw=SHMC_PW)
        _out, _msg = self.sshmngr.run(hostSHMC, cmd)
        return(_out, _msg)
