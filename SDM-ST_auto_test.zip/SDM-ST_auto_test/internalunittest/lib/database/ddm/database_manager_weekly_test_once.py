'''
Created on Mar 26, 2015

@author: test
'''
import unittest
import random
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from framework.asserts.common_asserts import CommonAssert
logger = Logger.getLogger(__name__)

class database_manager_weekly_test_once(SDMTestCase):
    '''
    classdocs
    '''

    def setUp(self):
        logger.info("DataBase Manager Weekly Test")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.client = self.testEnv.testBed.getBackends().popitem()
        self.DM = self.sdmManager.databaseManager
        self.DSM = self.sdmManager.databaseStateManager
        self.MCASAppli = self.sdmManager.mcasMachineManager

    def tearDown(self):
        pass

    def test_1_StationfwRestartNonPilot(self):
        '''
        This test is used to check if Restart of NP is OK
        '''
        logger.info("Station 0-0-10 will be restarted")
        self.MCASAppli.stationfwRestartNonPilot(self.client, '0-0-10')
        CommonAssert.timedAssert(3600 * 3, 10, self.DSM.assertNdbState, \
                                        self.client, 'started', '0-0-10', 'debug')
        logger.info("Station 0-0-10 is restarted")

    def test_2_set_half_cluster(self):
        '''
        This test is used to check if Restart of Half of NP is OK
        Parity is randomly choosen
        '''
        randParity = random.randint (0, 1)
        logger.info("Half of non cluster boards will be restarted")
        self.DM.setHalfClusterBE(self.client, randParity)
        CommonAssert.timedAssert(28800, 60, self.DSM.assertNdbState, \
                                        self.client, 'started', logLevel='debug')
        logger.info("All nodes are restarted")

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.test_1_restartProcess_pilot_success']
    unittest.main()
