"""
This package contains all framework sub-packages and classes.
"""
