"""
Created on Sept 30, 2015
@author: Claude Le Du
"""

from framework.testenv.router import Router
from lib.logging.logger import Logger

logger = Logger.getLogger(__name__)

class OmniswitchRouter(Router):
    """
    @details This class implements Router interface for Omniswitch routers (6850, 6900)
    """
    OMNISWITCH_TYPES = ["6850", "6900"]

    def __init__(self, sshManager, routerId, routerIp, routerType, account, prompt):
        super(OmniswitchRouter, self).__init__(routerId, routerIp, routerType, account, prompt)
        self.sshManager = sshManager
        self.channel = None


    def _sendCmd(self, cmd):
        """ Run <cmd> command on router
        @parameter cmd command to execute
        @return stdout, stderr standard and error outputs from the command """

        # fist attempt with an empty command because sometimes the first character is lost
        self.sshManager.sendStringRoutine(self.channel, "", self.prompt)
        (stdout, stderr) = self.sshManager.sendStringRoutine(self.channel, cmd, self.prompt)
        return stdout, stderr


    def clearARPTables(self):
        """ Run "clear arp-cache" command on router
        "clear arp-cache" returns nothing.
        @return stdout, stderr standard and error outputs from the command """

        cmd = "clear arp-cache"
        return self._sendCmd(cmd)


    def showVlan(self, port=False):
        """ Run "show vlan [port]" command on router
        "show vlan" returns:
                                             stree                       mble   src
        vlan  type  admin   oper   1x1   flat   auth   ip   ipx   tag   lrn   name
        -----+------+------+------+------+------+----+-----+-----+-----+-----+----------
          1    std   on    off     on    on     off    on   NA   off     on   vlan1
         11    std   on     on    off   off     off    on   NA   off     on   NODE1_LANIO1
         12    std   on     on    off   off     off    on   NA   off     on   NODE1_LANIO2a
        ...
        100    std   on     on     on    on     off   off   NA   off     on   EdgeRouter1
        117    std   on     on     on    on     off    on   NA   off     on   vlan_SIG
        118    std   on     on     on    on     off    on   NA   off     on   vlan_OAM
        119    std   on     on     on    on     off    on   NA   off     on   vlan_GDMP
        120    std   on     on     on    on     off    on   NA   off     on   vlan_HSS

        "show vlan port" returns:
        vlan   port     type      status
        ------+-------+---------+-------------
        1    1/9    default     inactive
        1    1/10   default     inactive
        1    1/11   default     inactive
        ...

        @parameter port port option
        @return stdout, stderr standard and error outputs from the command """

        cmd = "show vlan port" if port else "show vlan"
        return self._sendCmd(cmd)


    def showInterfaces(self):
        """ Run "show interfaces port" command on router
        "show interfaces port" returns:
        Slot/    Admin     Link    Violations                 Alias
        Port     Status   Status
        -----+----------+---------+----------+-----------------------------------------
         1/1    enable      up        none    ""
         1/2    enable      up        none    ""
         1/3    enable      up        none    ""
         1/4    enable      up        none    ""
         ...

        @return stdout, stderr standard and error outputs from the command """

        cmd = "show interfaces port"
        return self._sendCmd(cmd)


    def interfaceUp(self, interface):
        """ Set given interface up on router
        "interfaces 1/<interface> admin up" returns nothing.
        @parameter interface name of interface to set up
        @return stdout, stderr standard and error outputs from the command """

        cmd = "interfaces 1/" + str(interface) + " admin up"
        return self._sendCmd(cmd)


    def interfaceDown(self, interface):
        """ Set given interface down on router
        "interfaces 1/<interface> admin down" returns nothing.
        @parameter interface name of interface to set down
        @return stdout, stderr standard and error outputs from the command """

        cmd = "interfaces 1/" + str(interface) + " admin down"
        return self._sendCmd(cmd)


    def enableVlan(self, vlan):
        """ Enable given vlan on router
        "vlan <vlan> enable" returns nothing.
        @parameter vlan name of vlan to enable
        @return stdout, stderr standard and error outputs from the command """

        cmd = "vlan " + str(vlan) + " enable"
        return self._sendCmd(cmd)


    def disableVlan(self, vlan):
        """ Disable given vlan on router
        "vlan <vlan> disable" returns nothing.
        @parameter vlan name of vlan to disable
        @return stdout, stderr standard and error outputs from the command """

        cmd = "vlan " + str(vlan) + " disable"
        return self._sendCmd(cmd)
