for ip in `/usr/dhafw/bin/mppread |grep Address|awk '{ print $NF }'`
do
   if echo $ip | grep ':'
   then
      hostip=`ifconfig |grep c0a8|awk '{print $3}'|awk -F'/' '{print $1}'`
      ping6 -c 5 $ip -I $hostip>> check_delay_lost.result
   else
      ping -c 5 $ip >> check_delay_lost.result
   fi
done
