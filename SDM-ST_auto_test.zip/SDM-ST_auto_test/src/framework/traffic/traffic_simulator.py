'''
High level traffic simulator class.

@author: yohannm
'''
from framework.testenv.external_tool import ExternalTool

class TrafficSimulator(ExternalTool):
    '''
    classdocs
    '''


    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        super(TrafficSimulator,self).__init__(sshManager)
