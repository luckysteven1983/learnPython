'''
Created on Aug 21, 2015

@author: xzhao015
'''
import re
import time
import os
from datetime import datetime
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

MALBAN_ROOT = 'root'
MALBAN_PW = 'alatcav2'
MALBAN_SUFX = 'SWITCH'
MALBAN_PROMPT = '#'
LOGIN_MSG = 'continue connecting'
PW_MSG = 'assword:'

class MalbanManager(object):
    """Run command on malban and return its response."""

    def __init__(self, sshManager):
        """Init SubshlManager instance with sshManager.

        Keyword arguments:
        sshManager -- an SSH or other protocol instance used for remote command
                    execution.
        """
        self._sshManager = sshManager

    def sendStringRoutineForMalban(self, shl, strToSend, timeout=60):
        '''
            Public method
            run a string or command and expect a string to terminate the function.
            The string to wait can be located at end of flow (like a prompt)
            and in the middle of the flow (useful with subshl).

            Trailing spaces are removed to get an easier comparison.
            @param shl: paramiko Channel (interactive shell)
            @param strToSend: (String) the command to execute
            @param timeout (int) in seconds. interrupt the function if timeout reached.
                   useful if expectString never found
            @return returnCode,stdout,stderr : the return code of the command,
                    the stdout of the command ,
                    the stderr as 2 unique string (including EOL)
        '''
        patt = re.compile(r'resultCode: (\d+)')

        self._sshManager._voidBuffers(shl)  #  pylint: disable= W0212
        # delete multiple trailing EOL if any. And add trailing \n if needed :
        strToSend = strToSend.rstrip() + "; echo 'resultCode: '$?" + os.linesep

        shl.send(strToSend)  # send the string
        time.sleep(0.1)
        time0 = int(datetime.now().strftime('%s')) + timeout
        deltaTim = 0
        # --- while loop : depending on stringAtEnd test comparison is not the same.
        # we loop while :
        #       - time is lower than timeout
        #  AND  - we dont have the expected String

        buff, buffErr = self._sshManager.readBuffers(shl)  # first, init buffer
        while deltaTim <= time0 and not re.search(patt, buff):
            buffAdd, buffErrAdd = self._sshManager.readBuffers(shl)
            buff += buffAdd
            buffErr += buffErrAdd
            deltaTim = int(datetime.now().strftime('%s'))
        # --- if timeout has been reached : better to empty the buffers
        if deltaTim > time0:
            self._sshManager._voidBuffers(shl) #  pylint: disable= W0212
            buffErr = 'timeout ' + str(timeout) + ' reached'
        resultCode = None
        for line in buff.split(os.linesep):
            if re.search('resultCode: ', line):
                resultCode = line.split(":")[-1].strip()
        return [int(resultCode), buff, buffErr]

    def getClientMalban(self, host, slot):
        '''
            get client of malban ROUZIC
            @param host (String) the host where execute the cmd
            @param slot: (String) the slot number of the malban, value should be ['0-0-7', '0-0-8']

            @return client.invoke_shell object
        '''

        client = self._sshManager.getClient(host)
        if not client.get_transport().is_alive():
            return None, None
        shl = client.invoke_shell(width=120)
        time.sleep(0.1)

        hostMalban = '-'.join([slot, MALBAN_SUFX])
        loginStr = 'ssh -q -o StrictHostKeyChecking=no '+ hostMalban
        expStr = [LOGIN_MSG, PW_MSG, MALBAN_PROMPT]
        _out, _ = self._sshManager.sendStringRoutine(shl, loginStr, expStr, 5)
        for _ in xrange(1, 3):
            if re.search(LOGIN_MSG, _out):
                _out, _ = self._sshManager.sendStringRoutine(shl, 'yes', expStr, 5)
            elif re.search(PW_MSG, _out):
                _out, _ = self._sshManager.sendStringRoutine(shl, MALBAN_PW, expStr, 5)
            elif re.search(MALBAN_PROMPT, _out):
                break
            else:
                break
        return shl

    def runOnMalban(self, host, slot, command, timeout=1200):
        '''
            run a command on malban of ROUZIC Lab
            @param host (String) the host where execute the cmd
            @param slot: (String) the slot number of the malban, value should be ['0-0-7', '0-0-8']
            @param command (String) the command to execute
            @param timeout (int) in seconds. interrupt the function if timeout reached.

            @return returnCode,stdout,stderr : the return code of the command,
                    the stdout of the command , the stderr as 2 unique string (including EOL)
               Ex:    .runOnMalban('spa20oam','whoami')
        '''
        shl = self.getClientMalban(host, slot)
        _res = self.sendStringRoutineForMalban(shl, command, timeout)
        return _res
