"""
@file
Created on July 3, 2015
@ingroup SDMSQA Automation
@author Zhao Junming
@brief Defines Spectra sigtran Traffic Class
# prerequisite:
    1. All ctr(workspace file) should be put in C:\\AutomationTestExport_DoNotDelete
    2. workspace in configuration.xml should contain workspace and datamodel, hp25_cp104.ctr and ALU-PureHLR
    3. spectra2 server should enable ftp, and ftp root directory should be set to C:\\AutomationTestExport_DoNotDelete
    4. No space in workspace directory name
    5. Note, GUI should be closed for same workspace.
"""

from __future__ import division
import time
import os
import re
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
import pexpect
from framework.common import Utils
from threading import Timer
import ftplib
from framework.traffic.traffic import Traffic, BadQosException

logger = Logger.getLogger(__name__)

# workspace location on PC lab
AUTO_DIR = "AutomationTestExport_DoNotDelete"
WS_BASE_DIR = "C:\\" + AUTO_DIR
TIMER_SPECTRA_2SEC = 2
TIMER_SPECTRA_10SEC = 10
TIMER_SPECTRA_STOP_GRACEFULLY = 20
TIMER_SPECTRA_20SEC = 20
TIMER_SPECTRA_30SEC = 30
TIMER_SPECTRA_CMD = 60


class SpectraSigtranTraffic(Traffic):
    """
    @details This class offers the commands to control a spectra simulator.
    """
    def __init__(self, spectraTrafficProfile, spectraSIGTRANTrafficSimulator, testBed):
        """ SpectraSigtranTrafficSimulator class constructor """

        super(SpectraSigtranTraffic, self).__init__()
        self.workspace = ""
        self.myFEPrefix = ""
        self.be = []
        self.trafficType = "SIGTRAN"
        self.cnx = ""
        self.pcCnx = ""
        self.pcftp = ""
        self.ftpCnx = ""
        self.qos = ""
        self.previousQos = ""
        self.errors = 0
        self.previousErrors = 0
        self.nbRequestsStart = 0
        self.nbRequestsEnd = 0
        self.nbErrorsStart = 0
        self.nbErrorsEnd = 0
        self.failed = 0
        self.requests = 0
        self.account = spectraSIGTRANTrafficSimulator.account
        self.ftpAccount = spectraSIGTRANTrafficSimulator.ftpAccount
        self.toolIpAddress = spectraSIGTRANTrafficSimulator.toolIpAddress
        self.workspace = spectraSIGTRANTrafficSimulator.workspace
        self.spectraTrafficProfile = spectraTrafficProfile
        self.trafficModel = spectraTrafficProfile.model
        self.tps = spectraTrafficProfile.tps
        self.testBed = testBed
        self.timerInterval = 60
        self.timerCnx = None
        self.trafficInfo = "Spectra " + str(self.trafficType) + " traffic on " + self.toolIpAddress + \
                            " workspace: " + str(self.workspace) + " model: " + self.trafficModel
        self.running = "N"

    def _timerRun(self):
        """ watchdog """
        self.cnx.sendline("Generator Status")
        rc = self.cnx.expect(["is running"], timeout=TIMER_SPECTRA_CMD)
        if rc != 0:
            logger.error(msgs.SPECTRA_NOT_RUNNING)
            self.cnx.sendline('Stop')
            self.cnx.expect('0000:Ok', timeout=TIMER_SPECTRA_CMD)
            self.cnx.sendline('Close')
            self.cnx.expect('0000:Ok', timeout=TIMER_SPECTRA_CMD)
            raise Exception(msgs.SPECTRA_NOT_RUNNING)
        logger.debug("Generator is running, Spectra sigtran traffic is ok")
        self.running = "Y"
        self.timerCnx = Timer(self.timerInterval, self._timerRun)
        self.timerCnx.start()

    def _exportEventLog(self):
        """ Private method to export Spectra Event log file to get info, error, warning messages """
        cacheDir = Utils.findDir("cache", "CACHE_DIR")
        _localDir = cacheDir + os.sep + self.toolIpAddress
        if not os.path.isdir(_localDir):
            os.mkdir(_localDir)
        eventLogFile = self.workspace.replace(".ctr", "_eventLog") + ".csv"
        cmd = "EventLog Export " + WS_BASE_DIR + "\\" + eventLogFile
        logger.debug(cmd)
        self.cnx.sendline(cmd)
        self.cnx.expect("0000:Ok", timeout=TIMER_SPECTRA_CMD)
        time.sleep(TIMER_SPECTRA_10SEC)
        # direct ftp from spectra2.
        logger.debug("ftp: get " + eventLogFile + " in " + _localDir)
        try:
            self.ftpCnx = ftplib.FTP()
            self.ftpCnx.connect(self.toolIpAddress, 21, 30)
            self.ftpCnx.login(self.ftpAccount.login, self.ftpAccount.password)
            self.ftpCnx.cwd(AUTO_DIR)
            self.ftpCnx.retrbinary("RETR " + eventLogFile, open(_localDir + "/" + eventLogFile, 'wb').write)
        except ftplib.error_perm:
            self.ftpCnx.quit()
            logger.error(msgs.SPECTRA_EVENTLOG_NOK)
            raise Exception(msgs.SPECTRA_EVENTLOG_NOK)
        self.ftpCnx.quit()
        cmd = "dos2unix -q " + _localDir + "/" + eventLogFile
        logger.debug(cmd)
        os.system(cmd)
        logger.debug("Copy " + _localDir + "/" + eventLogFile + " in debug file")
        for line in open(_localDir + "/" + eventLogFile):
            logger.debug(line)


    def _sendSpectraCommand(self, cmd):
        """ Private method to send a command to Spectra and wait for the return
        @param cmd: command to send """
        logger.debug(cmd)
        self.cnx.sendline(cmd)
        rc = self.cnx.expect(["0000:Ok", pexpect.TIMEOUT], timeout=TIMER_SPECTRA_CMD)
        if rc != 0:
            self._expectDebug(rc)
            logger.error(msgs.SPECTRA_COMMAND_FAILED + ": " + cmd)
            raise Exception(msgs.SPECTRA_COMMAND_FAILED + ": " + cmd)


    def _expectDebug(self, rc):
        """ Private method """
        logger.debug("rc=" + str(rc) + " - before=" + self.cnx.before + " - after=" + str(self.cnx.after))


    def start(self, killIfExists=False):
        """ Start a spectra traffic
        @param killIfExists the traffics must be killed and restarted if already exist, note: \
        this parameter can not be used in spectra
        @exception Exception if Open spectra2 connection failed
        @exception Exception if Run spectra2 failed
        @exception Exception if Run spectra traffic model failed
        @exception Exception if Generator status is NOT running"""

        if self.running == "Y" and killIfExists == False:
            return
        if self.running == "Y" and killIfExists == True:
            self.stop()
        logger.info(self.trafficInfo)

        cmd = "telnet " + self.toolIpAddress + " 10001"
        logger.debug(cmd)
        self.cnx = pexpect.spawn(cmd, timeout=TIMER_SPECTRA_CMD)
        workspaceFile = WS_BASE_DIR + "\\" + self.workspace
        self._sendSpectraCommand("Prompt on")
        cmd = "Open " + self.account.login + " " + self.account.password + " " + workspaceFile
        self._sendSpectraCommand("Open " + self.account.login + " " + self.account.password + " " + workspaceFile)
        logger.info("open spectra2 connection done")
        self._sendSpectraCommand("Run")
        logger.info("Run workspace done")
        time.sleep(TIMER_SPECTRA_30SEC)
        waitLinkStart = time.time()
        retry = 0
        retryFlag = "N"
        while True:
            waitLinkNow = time.time()

            if retry < 3 and retryFlag == "Y":
                logger.info("retry connect spectra")
                cmd = "telnet " + self.toolIpAddress + " 10001"
                logger.debug(cmd)
                self.cnx = pexpect.spawn(cmd, timeout=TIMER_SPECTRA_CMD)
                self._sendSpectraCommand("Prompt on")
                self._sendSpectraCommand("Open " + self.account.login + " " + self.account.password +
                                         " " + workspaceFile)
                logger.info("open spectra2 connection done")
                self._sendSpectraCommand("Run")
                logger.info("Run workspace done")
                retry = retry + 1
            time.sleep(TIMER_SPECTRA_20SEC)
            cmd = "stats link"
            logger.debug(cmd)
            self.cnx.sendline(cmd)
            rc = self.cnx.expect([pexpect.EOF, pexpect.TIMEOUT, "0016:Up", "0001:Failed", \
                                          "Terminated Links"], timeout=TIMER_SPECTRA_CMD)
            if rc == 2:
                logger.info("links are UP")
                break
            if rc == 0 or rc == 1 or (waitLinkNow - waitLinkStart >= 60):
                self._expectDebug(rc)
                if retry == 3:
                    logger.warning(msgs.SPECTRA_ALL_LINKS_NOK)
                    break
                cmd = "Stop"
                logger.debug(cmd)
                self.cnx.sendline(cmd)
                time.sleep(TIMER_SPECTRA_2SEC)
                cmd = "Close"
                logger.debug(cmd)
                self.cnx.sendline(cmd)
                time.sleep(TIMER_SPECTRA_2SEC)
                self.cnx.close()
                logger.info("Links are NOT UP, retry")
                retryFlag = "Y"
                time.sleep(TIMER_SPECTRA_20SEC)

        time.sleep(TIMER_SPECTRA_20SEC)
        self._sendSpectraCommand("Generator Run " + self.trafficModel)
        time.sleep(TIMER_SPECTRA_30SEC)
        self.cnx.sendline("Generator Status")
        rc = self.cnx.expect(["is running", pexpect.TIMEOUT], timeout=TIMER_SPECTRA_CMD)
        if rc != 0:
            self._expectDebug(rc)
            logger.error(msgs.SPECTRA_NOT_RUNNING)
            logger.debug("Stop")
            self.cnx.sendline('Stop')
            self.cnx.expect(["0000:Ok", pexpect.TIMEOUT], timeout=TIMER_SPECTRA_CMD)
            logger.debug("Close")
            self.cnx.sendline('Close')
            # for the last command, we don't catch timeout so the exception can be raised
            self.cnx.expect('0000:Ok', timeout=TIMER_SPECTRA_CMD)
            # self._exportEventLog()
            raise Exception(msgs.SPECTRA_NOT_RUNNING)
        # self._exportEventLog()
        self.running = "Y"
        logger.info("Spectra traffic launched: " + self.trafficInfo)
#         self.timerCnx = Timer(self.timerInterval, self._timerRun)
#         self.timerCnx.start()

    def checkGlobalQoS(self):
        """ Check the traffic QoS from the beginning"""

        self.previousErrors = self.errors
        self.previousQos = self.qos
        self.requests, self.errors = self._searchNbRequestsAndErrorsInLog()
        if self.requests == 0:
            self.qos = 1
        else:
            self.qos = float(self.errors) / float(self.requests)
        if self.qos not in [0, 1]:
            self.qos = "{:1.8f}".format(self.qos)
        # elif self.qos == 1:
            # all requests fail => display event log to see if any issue occurred
            # self._exportEventLog()
        logger.debug(self.trafficInfo)
        logger.debug("Requests: " + str(self.requests))
        logger.debug("Previous errors (max(aborted, timeout)): " + str(self.previousErrors) + \
                     " Current errors: " + str(self.errors))
        logger.debug("Previous QoS:" + str(self.previousQos) + " Current QoS: " + str(self.qos))
        if float(self.qos) > 0.000001:
            msg = msgs.TRAFFIC_BAD_QOS + " (" + str(self.qos) + ") for " + self.trafficInfo
            logger.error(msg)
            raise BadQosException(msg)

    def getRequestsAndErrors(self):
        """ Checks the number of requests and errors, for instance
            to set a starting point from which to calculate the QoS """
        # nbRequestsStart and nbErrorsStart store values from last but one checkQoSInit
        self.nbRequestsStart = self.nbRequestsEnd
        # nbErrorsStart/1 = total ko + total timeout
        self.nbErrorsStart = self.nbErrorsEnd
        # nbRequestsEnd and nbErrorsEnd store values from last checkQoSInit
        self.nbRequestsEnd, self.nbErrorsEnd = self._searchNbRequestsAndErrorsInLog()


    def _searchNbRequestsAndErrorsInLog(self):
        """ Check the traffic QoS
        @exception Exception if Generate report failed """

        cacheDir = Utils.findDir("cache", "CACHE_DIR")
        _localDir = cacheDir + os.sep + self.toolIpAddress
        if not os.path.isdir(_localDir):
            os.mkdir(_localDir)
        self._sendSpectraCommand("Generator Export " + WS_BASE_DIR + "\\" + self.workspace.replace(".ctr", "_sum"))
        time.sleep(TIMER_SPECTRA_10SEC)
        ftpHost = "LINCASEPC"
        # ftp issue when VM. if VM, ftp through one lincase PC
        if ftpHost == "VM":
            # ftp issue on VM, so through lincasePC 135.252.181.14:/local/jzhao/R422

            self.pcCnx = pexpect.spawn("ssh jzhao@135.252.181.14", timeout=TIMER_SPECTRA_CMD)

            ret = self.pcCnx.expect(["continue connecting", "assword:"], timeout=TIMER_SPECTRA_CMD)
            if ret == 0:
                self.pcCnx.sendline("yes")
                self.pcCnx.expect("assword:", timeout=TIMER_SPECTRA_CMD)
                self.pcCnx.sendline("jzhao")
            if ret == 1:
                self.pcCnx.sendline("jzhao")
            self.pcCnx.expect("jzhao", timeout=TIMER_SPECTRA_CMD)
            self.pcCnx.sendline("cd /local/jzhao/R422")
            self.pcCnx.sendline("ftp " + self.toolIpAddress)
            self.pcCnx.expect("Name", timeout=TIMER_SPECTRA_CMD)
            self.pcCnx.sendline(self.ftpAccount.login)
            self.pcCnx.expect("assword:", timeout=TIMER_SPECTRA_CMD)
            self.pcCnx.sendline(self.ftpAccount.password)
            self.pcCnx.expect("ftp>", timeout=TIMER_SPECTRA_CMD)
            self.pcCnx.sendline("cd" + self.workspace.replace(".ctr", "_sum"))
            self.pcCnx.sendline("get \"Transaction Processing.csv\"")
            self.pcCnx.expect("ftp>", timeout=TIMER_SPECTRA_CMD)
            self.pcCnx.sendline("bye")
            self.pcCnx.expect("jzhao", timeout=TIMER_SPECTRA_CMD)
            self.pcCnx.sendline("mv \"Transaction Processing.csv\" Transaction_Processing.csv")
            self.pcCnx.sendline("exit")
            time.sleep(TIMER_SPECTRA_2SEC)

            self.pcftp = pexpect.spawn("sftp jzhao@135.252.181.14", timeout=TIMER_SPECTRA_CMD)
            self.pcftp.expect("assword", timeout=TIMER_SPECTRA_CMD)
            self.pcftp.sendline("jzhao")
            self.pcftp.expect("sftp>", timeout=TIMER_SPECTRA_CMD)
            self.pcftp.sendline("cd /local/jzhao/R422")
            self.pcftp.expect("sftp>", timeout=TIMER_SPECTRA_CMD)
            self.pcftp.sendline("lcd " + _localDir)
            self.pcftp.expect("sftp>", timeout=TIMER_SPECTRA_CMD)
            self.pcftp.sendline("get \"Transaction_Processing.csv\"")
            self.pcftp.expect("sftp>", timeout=TIMER_SPECTRA_CMD)
            self.pcftp.sendline("bye")
            time.sleep(TIMER_SPECTRA_2SEC)

            self.pcCnx.close()
            self.pcftp.close()
        else:

            # direct ftp from spectra2.
            try:
                self.ftpCnx = ftplib.FTP()
                logger.debug("ftp connection to " + self.toolIpAddress)
                self.ftpCnx.connect(self.toolIpAddress, 21, 30)
                logger.debug("ftp login with " + self.ftpAccount.login)
                self.ftpCnx.login(self.ftpAccount.login, self.ftpAccount.password)
                cmd = AUTO_DIR + "/" + self.workspace.replace(".ctr", "_sum")
                logger.debug("CWD " + cmd)
                self.ftpCnx.cwd(cmd)
                cmd = "RETR Transaction Processing.csv"
                logger.debug(cmd)
                self.ftpCnx.retrbinary(cmd, open(_localDir + "/Transaction_Processing.csv", 'wb').write)
            except ftplib.error_perm:
                self.ftpCnx.quit()
                logger.error(msgs.SPECTRA_REPORT_FAILED)
                raise Exception(msgs.SPECTRA_REPORT_FAILED)
            self.ftpCnx.quit()

        os.system("dos2unix -q " + _localDir + "/" + "Transaction_Processing.csv")
        for line in open(_localDir + "/" + "Transaction_Processing.csv"):
            if len(re.findall(",", line)) < 3:
                break
            listLine = line.split(",")
            typeRet = listLine[0]
            totalnumber = listLine[2]
            if typeRet == "Transaction Attempt Failures":
                failedTrans = totalnumber
            if typeRet == "Transactions Aborted":
                failedAbort = totalnumber
            if typeRet == "Transaction Timeout Failures":
                failedTimeout = totalnumber
            if typeRet == "Transactions Ended":
                successEnd = totalnumber

        errors = max(int(failedAbort), int(failedTimeout))
        success = int(successEnd)
        requests = success + errors
        logger.debug("Success (Transactions Ended): " + str(successEnd) + " Errors: " + str(errors) +
                     " Attempts failure: " + failedTrans +
                     " Abort failure: " + failedAbort + " Timeout failure: " + failedTimeout)
        return requests, errors

    def getErrorStatus(self):
        """ Returns true if #errors increased between two checkGlobalQoS """

        if self.errors > self.previousErrors:
            return True
        else:
            return False

    def getCountersString(self):
        """ Returns a string made of traffic counters """

        successes = self.requests - self.errors
        text = "QoS=" + str(self.qos) + "  Requests=" + str(self.requests) + "  Successes=" + str(successes) + \
                "  Errors (max(aborted+Timeout))=" + str(self.errors)
        return text

    def stop(self):
        """ Stop a SPECTRA traffic """

#         self.timerCnx.cancel()
        cmd = "Generator StopGracefully " + self.trafficModel
        logger.debug(cmd)
        self.cnx.sendline(cmd)
        time.sleep(TIMER_SPECTRA_STOP_GRACEFULLY)
        rc = self.cnx.expect([pexpect.EOF, pexpect.TIMEOUT, "0000:Ok"], timeout=TIMER_SPECTRA_CMD)
        if rc != 2:
            self._expectDebug(rc)
            self.cnx.close()
            raise Exception(msgs.SPECTRA_STOP_FAILED)
        cmd = "Stop"
        logger.debug(cmd)
        self.cnx.sendline(cmd)
        rc = self.cnx.expect([pexpect.EOF, pexpect.TIMEOUT, "0000:Ok"], timeout=TIMER_SPECTRA_CMD)
        if rc != 2:
            self._expectDebug(rc)
            self.cnx.close()
            raise Exception(msgs.SPECTRA_STOP_FAILED)
        cmd = "Close"
        logger.debug(cmd)
        self.cnx.sendline(cmd)
        rc = self.cnx.expect([pexpect.EOF, pexpect.TIMEOUT, "0000:Ok"], timeout=TIMER_SPECTRA_CMD)
        if rc != 2:
            self._expectDebug(rc)
            self.cnx.close()
            raise Exception(msgs.SPECTRA_STOP_FAILED)
        self.cnx.close()
        logger.info("Spectra sigtran traffic is stopped")

class SpectraTrafficException(BaseException):
    """If error, raise it."""
    pass
