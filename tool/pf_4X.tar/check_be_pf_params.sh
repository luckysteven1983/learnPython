#!/bin/bash

#Format
#PARAMETER_NMAE=HPG6_Value,HPG8_Value,BONO24_Value,BONO48_Value,Rouzic_Value
SI_DDM_SWITCHOVER_LOW_LEVEL=7000000,7000000,6000000,6000000,1000000
SI_DDM_SWITCHOVER_LOW_LEVEL_AUTOMATIC=19000000,21000000,16000000,16000000,3000000
SI_DDM_SWITCHOVER_HIGH_LEVEL=32000000,32000000,26000000,26000000,5000000
SI_DDM_SWITCHOVER_DATA_LOST_LEVEL=19000000,21000000,16000000,16000000,3000000
SI_DDM_NOT_SECURED_LEVEL=34000000,34000000,27000000,27000000,5400000
SI_DDM_QUICK_SWITCHOVER=yes,yes,yes,yes,yes
SI_DDM_PILOT_BACKUP_PART_SIZE=30G,90G,30G,90G,10G
SI_DDM_PILOT_REPL_PART_SIZE=120G,120G,80G,120G,10G
SI_DDM_NDBD_MEMORY_PARTITION_SIZE=168G,242G,168G,168G,37G
SI_DDM_NDBD_DISK_PARTITION_SIZE=10G,1G,10G,1G,1G
#Removed SI_DDM_PILOT_DB_PART_SIZE since R4.3
#Removed SI_DDM_NON_PILOT_DB_PART_SIZE since R4.3
#Removed SI_DDM_SPDATA_SIZE
SI_DDM_PILOT_LOG_SPACE=6G,50G,6G,4G,6G
#Removed SI_DDM_NON_PILOT_LOG_SPACE
#Removed SI_DDM_SUBTREE_SIZE
SI_DDM_MAX_GCI_TO_PURGE=57600,57600,57600,57600,57600
SI_DDM_MAX_DELTA_TO_PURGE_BINLOG=60000000,60000000,54000000,63000000,8000000
SI_DDM_DATABASE_NODES=10,10,10,10,10

echo "/opt/config/installinfo/DDM/ddm_ini_info" > be_performance_param.xls
for param in `cat DDM_params|awk '{print $1}'` 
do   
  if [ `grep $param /opt/config/installinfo/DDM/ddm_siteinfo |wc -l` -eq 0 ]; then
     echo -e "$param\t Not Exists" >> be_performance_param.xls 
  else
     grep -w $param /opt/config/installinfo/DDM/ddm_siteinfo|awk -F"=" '{ print "'"$param"'" "\t" $2}' >> be_performance_param.xls 
  fi
done
rm DDM_params
echo SI_MYSQL_DATA_MEMORY  >> MYSQL_params 
echo SI_MYSQL_INDEX_MEMORY   >> MYSQL_params
echo SI_MYSQL_FRAGMENT_LOG_FILE_SIZE  >> MYSQL_params
echo SI_MYSQL_NO_FRAGMENT_LOGFILES     >> MYSQL_params
echo SI_MYSQL_MaxNoOfSubscriptions      >> MYSQL_params
echo SI_MYSQL_MaxNoOfSubscribers       >> MYSQL_params
echo SI_MYSQL_MAX_NO_OF_TABLES      >> MYSQL_params
echo SI_MYSQL_MaxNoOfAttributes     >> MYSQL_params
echo SI_MYSQL_MaxNoOfOrderedIndexes    >> MYSQL_params
echo SI_MYSQL_MaxNoOfUniqueHashIndexes   >> MYSQL_params
echo SI_MYSQL_MaxNoOfTriggers         >> MYSQL_params
echo SI_MYSQL_TRANSACTION_DEADLOCK_DETECTION_TIMEOUT    >> MYSQL_params
echo SI_MYSQL_SEND_BUFFER_MEMORY      >> MYSQL_params
echo SI_MYSQL_SECURITY_TO_ACTIVATE       >> MYSQL_params
echo SI_MYSQL_BuildIndexThreads         >> MYSQL_params
echo SI_MYSQL_MAX_NO_OF_CONCURRENT_OPERATIONS    >> MYSQL_params
echo SI_MYSQL_MaxNoOfConcurrentScans        >> MYSQL_params
echo SI_MYSQL_MaxNoOfConcurrentTransactions    >> MYSQL_params
echo SI_MYSQL_LockExecuteThreadToCPU     >> MYSQL_params

echo "/opt/config/installinfo/MYSQL/mysql_siteinfo" >> be_performance_param.xls
for param in `cat MYSQL_params|awk '{print $1}'` 
do   
  if [ `grep $param /opt/config/installinfo/MYSQL/mysql_siteinfo |wc -l` -eq 0 ]; then
     echo -e "$param\t Not Exists" >> be_performance_param.xls 
  else
     grep -w $param /opt/config/installinfo/MYSQL/mysql_siteinfo|awk -F"=" '{ print "'"$param"'" "\t" $2}' >> be_performance_param.xls 
  fi
done
rm MYSQL_params

echo "/DDM_SUBTREE/etc/nectar/conf/conf.ini" >> be_performance_param.xls
for param in TIMER_FOR_RESTORE MANAGE_STALE_STATUS USE_MULTI_THREADED_NDBD SLAVE_REP_OVERLOAD_L1 SLAVE_REP_OVERLOAD_L2
do
  if [ `grep $param /DDM_SUBTREE/etc/nectar/conf/conf.ini |wc -l` -eq 0 ]; then
     echo -e "$param\t Not Exists" >> be_performance_param.xls 
  else
     grep -w $param /DDM_SUBTREE/etc/nectar/conf/conf.ini | grep -v "#" |awk -F"=" '{ print "'"$param"'" "\t" $2}' >> be_performance_param.xls 
  fi 
done

echo "/DDM_SUBTREE/usr/dhafw/data/GdmpServerpf_generic.cfg" >> be_performance_param.xls
if [ `grep ClonePoolMaxSize /DDM_SUBTREE/usr/dhafw/data/GdmpServerpf_generic.cfg|wc -l` -eq 0 ]; then
     echo -e "ClonePoolMaxSize\t Not Exists" >> be_performance_param.xls 
else
     grep -w ClonePoolMaxSize /DDM_SUBTREE/usr/dhafw/data/GdmpServerpf_generic.cfg|awk -F"=" '{ print "ClonePoolMaxSize" "\t" $2}' |grep -v "#" >> be_performance_param.xls 
fi 

echo GDMP_RES_SIZE_LIM >> GDMP_params
echo NDB_POLL_NB >> GDMP_params
echo GdmiNdbMaxUse >> GDMP_params
echo NbClusterConnections >> GDMP_params
echo MaxMemoryForEntries >> GDMP_params
echo MaxReplyThreadsNumber >> GDMP_params
echo MaxSimultaneousSearch >> GDMP_params
echo MinReplyThreads >> GDMP_params
echo NbReplyThreads >> GDMP_params
echo MaxNdbObjects >> GDMP_params
echo MAX_ALLOWED_CPU >> GDMP_params   
echo ActivateOverloadManagement >> GDMP_params

echo "/DDM_SUBTREE/etc/nectar/conf/gdmp.ini" >> be_performance_param.xls
for param in `cat GDMP_params|awk '{print $1}'` 
do   
  if [ `grep $param /DDM_SUBTREE/etc/nectar/conf/gdmp.ini |wc -l` -eq 0 ]; then
     echo -e "$param\t Not Exists" >> be_performance_param.xls 
  else
     grep -w $param /DDM_SUBTREE/etc/nectar/conf/gdmp.ini|awk -F"=" '{ print "'"$param"'" "\t" $2}'|grep -v "#"|head -1 >> be_performance_param.xls 
  fi
done  
rm GDMP_params

echo "/DDM_SUBTREE/usr/dhafw/data/GdmpServerpf_site.cfg" >> be_performance_param.xls
for param in NdbObjectsLoadThresholds EntriesCacheLoadThresholds ReplyThreadsLoadThresholds                  
do                                                    
  if [ `grep $param /DDM_SUBTREE/usr/dhafw/data/GdmpServerpf_site.cfg |wc -l` -eq 0 ]; then                 
     echo -e "$param\t Not Exists" >> be_performance_param.xls 
  else                                                                                                                
     grep -w $param /DDM_SUBTREE/usr/dhafw/data/GdmpServerpf_site.cfg|awk -F"=" '{ print "'"$param"'" "\t" $2}'|grep -v "#" >> be_performance_param.xls
  fi                                                                                                                  
done       

echo "/DDM_SUBTREE/usr/dhafw/data/gdmpServerOverloadpf_generic.cfg" >> be_performance_param.xls 
if [ `grep MEM_OVERLOAD_INHIBITED /DDM_SUBTREE/usr/dhafw/data/gdmpServerOverloadpf_generic.cfg |wc -l` -eq 0 ]; then
     echo -e "MEM_OVERLOAD_INHIBITED\t Not Exists" >> be_performance_param.xls                 
else                                                                                                                
     grep -w MEM_OVERLOAD_INHIBITED /DDM_SUBTREE/usr/dhafw/data/gdmpServerOverloadpf_generic.cfg|awk -F"=" '{ print "'"$param"'" "\t" $2}'|grep -v "#" >> be_performance_param.xls
fi


echo "TCP parameters" >> be_performance_param.xls
for sta in 1 2 3 4 5 6 7 8 10 11 12 13 14 15 16
do
   ssh 0-0-$sta 'sysctl -a | grep net | grep mem | grep core | grep -v opt'
   echo "=====0-0-$sta====="
done >> be_performance_param.xls

