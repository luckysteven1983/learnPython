#!/bin/sh

while [ 1 ]
do  
   echo `date`
   netstat -nap|grep  32002 
   sleep $1
done
