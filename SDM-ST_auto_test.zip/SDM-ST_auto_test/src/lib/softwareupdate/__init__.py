"""
this dir includes softwareupdate libraries
"""
