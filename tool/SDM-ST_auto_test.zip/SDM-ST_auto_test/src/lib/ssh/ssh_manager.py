'''
Created on Aug 7, 2014
Modified onMarch 9th 2015 by Serge Beaufils

@author: yohann

This library manages the SSH connections

There is two distincts cases :
1-  SSH connection to a lab  (connection with user ainet and root)
2-  SSH connection to any computer "not-lab" with a specified user and pw.


1- connection to lab : this is the easiest case because users and pw are known.
   Even if the first connection is with two users (ainet - root) it is transparent for the tester.
   Once the instance is created you can call immediatly the public methods :
      getClient() , run() , sendStringAndExpect() , scpGet() , scpPut()
   The first call to one of those methods will ssh-connect ,, install the ssh keys if needed
   and store the connection. The subsequent calls will just fetch the ssh connection already stored.

   Typical usage :
     sshManager = SshManager()           # creates the instance
     localPath = sshManager.scpGet(LAB,filename)  # get a file on remote lab. SSH connection is created and
                                              # stored in the instance of SshManager
                                              # it is not necessary to store the returned (paramiko) SSH connection

     sshManager.run(LAB, 'whoami')      # run() could also be called immediatly after instance creation

     SshManager().run(LAB, 'pwd')    # a "one-shot" call is possible without storing the instance

     sshManager.getClient(LAB)             # can be used to explicitely creates the connection without doing more.
     sshCn = sshManager.getClient(LAB)     # The same as previous one but we store the paramiko SSH client


2- Connection to a non-lab. There is 2 differences
   *** The very first call (to create the SSH connection) must be done with a user and pw via getClient()
   *** The user must be specified in the public methods

   Typical usage :
     sshManager = SshManager()                      # creates the instance
     sshconn = sshManager.scpGet(LAB, user='nx', filename)   # NOT POSSIBLE now because not yet ssh-connected
     sshManager.run(LAB, 'whoami', user='nx')                # idem : NOT POSSIBLE now because not yet ssh-connected
     sshManager.getClient(LAB,user='nx', pw='anything')      # OK: creates the connection which is stored into instance

     sshManager.run(LAB, user='nx', cmd='whoami')            # connection already created, we can run a command

'''

# ===== fix  Pylint bug. See http://stackoverflow.com/questions/20553551/how-do-i-get-pylint-to-recognize-numpy-members
# pylint: disable=no-name-in-module
from collections import namedtuple
from datetime import datetime
from operator import xor
import os
import re
import time
import socket
from subprocess import Popen, PIPE
from subprocess import call
import sys
import threading

import paramiko
from paramiko.ssh_exception import SSHException, AuthenticationException
from scp import SCPClient

from framework.common import Utils
import lib.exceptions_messages as msgExc
from lib.logging.logger import Logger
import traceback
from lib.exceptions_messages import CONNECTION_DOWN, LOST_CONNECTION, \
    CONNECTION_NOT_FOUND


# pylint: enable=no-name-in-module
class SshManagerError(BaseException):
    """If error, raise it."""
    pass


# very verbose mode of paramiko :
# paramiko.common.logging.basicConfig(level=paramiko.common.DEBUG)
LOGGER = Logger.getLogger(__name__)

# ---- init CONSTANTS
BUFF_SIZE = 8192
MCAS = 'mCAS'
TOMIX = 'TOMIX'
MCAS_USER = 'ainet'
MCAS_PW = 'ainet1'
ALCSSH = 'AlcatelSSH'
ALCSSH_PW = 'alcatel0921'
MCAS_ROOT = 'root'
MCAS_ROOT_PW = 'r00t'
ROOT_PW_TOMIX = 'ascp01'
ROOT_DIR = '/root'
ROOT_PRPT = 'root-#'
PW_PRPT = 'Password:'
CMD_KEYGEN = 'ssh-keygen'
CMD_KEYSCAN = 'ssh-keyscan'
CMD_SU = 'su -'
CMD_WHO = 'whoami'
CMD_SUBSHL = '/cs/sn/cep/subshl'
WHO_RESP = os.linesep + 'root' + os.linesep
PRIV_KEY_FILE = '/id_rsa'
SSH_DIR = '.ssh/'
AUTHK_FIL = 'authorized_keys'
MAX_CONNECTION_ATTEMPTS = 15
CONNECTION_ATTEMPTS_INTERVAL = 60  # seconds
SSH_DEFAULT_PORT = 22



class SshManager(object):
    '''
    Manage all the SSH connections with any user. Install SSH key if needed.
    There is 2 cases to address a connection : a lab or not
    1- 'hostname' : connecting to a lab in 2 steps : login 'ainet' then 'root'. pw are known.
    2- 'user @ hostname' : connecting directly to hostname in 1 step  using the user 'user'.
       The user can be root.  pw MUST be specified as argument for the first call to getClient
    See functions 'getClient' or 'run'
    '''

    confDir = Utils.findDir("conf", "CONF_DIR")  #
    cacheDir = Utils.findDir("cache", "CACHE_DIR")  #
    privateKey = confDir + PRIV_KEY_FILE  #
    publicKey = privateKey + ".pub"  #

    tunnel = namedtuple("tunnel", ["process", "port"])
    clientAndTunnel = namedtuple("clientAndTunnel", ["client", "tunnel"])
    defaultHeartbeat = 120

    # creates conf dir if needed
    if not os.path.isdir(confDir):
        LOGGER.debug(confDir + " directory doesn't exist, creating it")
        os.makedirs(confDir)

    # if only One of the Two key file exist , delete the other one (to avoid question during ssh-keygen)
    if xor(os.path.isfile(privateKey), os.path.isfile(publicKey)):
        if os.path.exists(privateKey):
            os.remove(privateKey)
        if os.path.exists(publicKey):
            os.remove(publicKey)

    if not os.path.isfile(privateKey):
        LOGGER.debug(privateKey + " doesn't exist, creating it")
        cmd = [CMD_KEYGEN, '-f', privateKey, "-t", "rsa", "-C", "", "-N", ""]
        res = call(cmd)
        if res != 0:
            LOGGER.trace("command: " + str(cmd) + " returned " + str(res))
            sys.exit(res)
    if not os.path.isfile(publicKey):
        LOGGER.trace(publicKey + " doesn't exist, delete " + privateKey + " and retry")
        sys.exit(1)
    pubKeyFile = open(publicKey, "r")
    publicKeyStr = pubKeyFile.read().rstrip()
    pubKeyFile.close()



    def __init__(self, gateway=None, gw_user=None, gw_pw=None):
        '''
        Constructor
        '''
        self.gateway = gateway  # store gateway information
        self.gatewayUser = gw_user
        self.gatewayPassword = gw_pw
        self.tunnelLocalPort = -1
        self.tunnelProcess = None
        self._connections = {}  # empty dictionary
        if gateway is not None:
            if gw_user is None or gw_pw is None:
                LOGGER.error(msgExc.GATEWAY_MISSING_USERPW)
                raise SshManagerError, msgExc.GATEWAY_MISSING_USERPW

        self.clientLock = threading.Lock()

    def _checkAccessAndGrantIfNecessaryIn2Steps(self, host, primaryUser, primaryPassword, finalPw, port=SSH_DEFAULT_PORT):
        '''
        Check if we have already SSH access. And copy SSH key if necessary
        twoStep=True
        @param host : hostname
        @param primaryUser : primary user to login
        @param primaryPassword : pw of primaryUser
        @param finalPw : pw of final user (= root)
        @param twoStep (boolean) : are we in a 2-step process to copy key via ainet then root ?
        '''
        cli = self._checkAccessUsingPw(host, primaryUser, primaryPassword, port)
        if cli is not None:
            SshManager._copyPublicKeyRootIn2Steps(cli, finalPw)  # copy key to root via ainet login
            return cli
        else:
            return None



    def _checkAccessAndGrantIfNecessary(self, host, user, password, port=SSH_DEFAULT_PORT):
        '''
        Check if we have already SSH access. And copy SSH key if necessary
        twoStep=True
        @param host : hostname
        @param user : primary user to login
        @param twoStep (boolean) : are we in a 2-step process to copy key via ainet then root ?
        '''
        cli = self._checkAccessUsingPw(host, user, password, port)
        if cli is not None:
            exceptionMessage = ' , '.join([host, user, password])
            SshManager._copyPublicKey(cli, exceptionMessage)  # copy key directly
            return cli
        else:
            return None

    def _checkAccessUsingKey(self, host, user, port=SSH_DEFAULT_PORT):
        '''
        check if we have SSH access via user by using SSH keys ?
        Having an AuthenticatioException is one of the standard ways.
        @param host : hostname
        @param user : user to login
        @return None if no connection.  Returns instance of SSH connection if OK
        '''
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            #  to ignore user .ssh homedir keys : use those options  allow_agent=False, look_for_keys=False)
            # CAUTION with those option : exception is SSHException (instead of AuthenticationException)
            client.connect(host, port, user, key_filename=self.privateKey)
            client.get_transport().set_keepalive(self.__class__.defaultHeartbeat)
            return client
        except AuthenticationException:
            LOGGER.trace(' No access, no SSH key already installed on ' + host + ' with user ' + user)
        client.close()
        return None


    def _checkAccessUsingPw(self, host, user, password, port=SSH_DEFAULT_PORT):
        '''
        check if we have SSH access via user by using SSH keys ?
        Having an AuthenticatioException is one of the standard ways.
        @param host : hostname
        @param user : user to login
        @return None if no connection. Returns instance of SSH connection if OK
        '''
        client = paramiko.SSHClient()
        # client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect(host, port, user, password)
            client.get_transport().set_keepalive(self.__class__.defaultHeartbeat)
            return client
        except AuthenticationException:
            LOGGER.debug(' No access via password for ' + host + ' with user ' + user)
        client.close()
        return None



    def _openTunnel(self, host):
        '''
        open a Tunnel if using a gateway
        @param host : hostname
        @return the tunnel property
        '''
        # trick to find free port number
        _sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _sock.bind(("", 0))
        self.tunnelLocalPort = _sock.getsockname()[1]
        _sock.close()
        tunnelArgs = ["ssh", "-oStrictHostKeyChecking=no",
                      "-oUserKnownHostsFile=/dev/null", "-i",
                      SshManager.privateKey, "-L",
                      str(self.tunnelLocalPort) + ":" + host + ":" + str(SSH_DEFAULT_PORT),
                      self.gatewayUser + "@" + self.gateway]
        process = Popen(tunnelArgs, stdout=PIPE)
        # trick: read first line of output from ssh command so that python
        # waits long enough before it tries to connect to tunnel input
        # logger.debug("popen answer first line: " + self.tunnelProcess.stdout.readline())
        process.stdout.readline()
        return SshManager.tunnel(process, self.tunnelLocalPort)


    def _runCommand(self, host, userSsh, command, client, ignoreStdStreams=False, txtToAdd=""):
        # log msg before command executed
        LOGGER.trace(' -- '.join([' ----- Run command', host, userSsh, command, txtToAdd]))

        _, stdOut, stdErr = client.exec_command(command)
        exitStatus = stdOut.channel.recv_exit_status()

        if not ignoreStdStreams:

            out = stdOut.read().rstrip()
            err = stdErr.read().rstrip()

            # log msg after command executed
            txtHead = ' -- '.join([' ----- Run stdout ', host, userSsh, command, 'rc=' + str(exitStatus), ''])
            txtLogList = [txtHead, ' ----- stdout : ']
            if out != '':
                txtLogList.append(out)
            if err != '':
                txtLogList += [' ----- stderr : ', err]
            LOGGER.trace(os.linesep.join(txtLogList))
            returnTxt = out + os.linesep + err

        else:
            returnTxt = ''

        return exitStatus, returnTxt.rstrip()


    def scpGet(self, host, source, user=None):
        '''
        get a remote file and copy in cache Dir . similar as 'scp  user @ remote:file  localfile'
        @param host : hostname
        @param source : the local file which should be in cache Dir
        @param user : the user to login on remote. default is 'root'
        @return the path of the local file
        NB : At least one getClient() must have been executed before calling this proc
             i.e. connection is already stored in self._connections
        '''
        userSsh = 'root' if user is None else user
        client = self.getClient(host, user=userSsh)
        scpClient = SCPClient(client.get_transport(), socket_timeout=float(self.__class__.defaultHeartbeat))
        _localDir = SshManager.cacheDir + os.sep + host
        if not os.path.isdir(_localDir):
            os.mkdir(_localDir)
        _localPath = _localDir + os.sep + os.path.basename(source)
        LOGGER.trace("scpClient.get(%s, %s)", source, _localPath)
        scpClient.get(source, _localPath)
        return _localPath

    def scpGetAll(self, host, source, user=None):
        '''
        get remote files and copy in cache Dir . similar as 'scp  user @ remote:file  localfile'
        @param host : hostname
        @param source : the local files which should be in cache Dir, eg: /snlog/snmplog*
        @param user : the user to login on remote. default is 'root'
        @return the local file list with full path
        NB : At least one getClient() must have been executed before calling this proc
             i.e. connection is already stored in self._connections
        '''
        userSsh = 'root' if user is None else user
        client = self.getClient(host, user=userSsh)
        command = "ls " + source
        _, stdOut, _ = client.exec_command(command)
        fileList = stdOut.read().rstrip().split()
        scpClient = SCPClient(client.get_transport())
        _localDir = SshManager.cacheDir + os.sep + host
        _localFielList = []
        if not os.path.isdir(_localDir):
            os.mkdir(_localDir)
        for fileName in fileList:
            _localPath = _localDir + os.sep + os.path.basename(fileName)
            scpClient.get(fileName, _localPath)
            _localFielList.append(_localPath)
        return _localFielList

    def scpPut(self, localFile, host, remoteFile, user=None):
        '''
        copy a file to remote host . similar as 'scp  localfile  host:remotefile'
        @param localFile : path of local File. absolute or relative (depending where you are)
        @param host : the remote host where to copy
        @param remoteFile : path of remote file (absolute) or in homedir if relative
        @param user: login.  user=None means 'root'
        @return (boolean) : False if localFile does not exist
            Ex:           sshMngr.scpPut('/tmp/tototo', LX4SI3, '/tmp/tototo', user='jenkins')
        NB : At least one getClient() must have been executed before calling this proc
             i.e. connection is already stored in self._connections
        '''
        userSsh = 'root' if user is None else user
        client = self.getClient(host, user=userSsh)
        scpClient = SCPClient(client.get_transport())
        scpClient.socket_timeout = 1000.0
        if os.path.isfile(localFile):
            scpClient.put(localFile, remoteFile)
            return True
        else:
            return False

    def getClient(self, host, user=None, pw=None, useKey=True,
                  labCustomUser=MCAS_USER, labCustomPw=MCAS_PW, labRootPw=MCAS_ROOT_PW):
        '''
        return the paramiko SSH client instance.  Creates and install SSH keys if needed. Default user is root.
        There are 3 cases depending on host syntax, mixing root or ot root user, 1-step or 2-steps process
        @param host : the hostname used when creating the instance
        @param user login .  "user=None" (no parameter) means it is a lab => 2 steps login
        @param pw password
        @param useKey boolean, use public / private key to connect to this host or simple user
               password method. Default value: true (use public / private key).
          The following prameters (labCustomxxx) are useful only for lab (2-steps login) :
        @param labCustomUser : to connect to a lab (in 2 steps) without the default user (not ainet)
                               Default is 'ainet'
        @param labCustomPw : the pw associated to labCustomUser
                             Default is the ainet pw
        @param labCustomRootPw : the root pw to log in on a lab
                             Default is the "standard" root pw
        @return the paramiko SSHclient instance
        @verbatim the different cases are :
           ** standard lab with login in 2 steps ainet/ainxxx then root/rxxx  : no user to specify 
                # getClient(host)
           ** standard lab with login in 2 steps with the "post-R44" new pw for ainet and root.
              "user=None" because 2 steps login. Must only specify the new pw
                # getClient(host, labCustomPw='ainetR4.4pw...', labRootPw='rootR4.4pw...') )
           ** standard lab with login in 2 steps via a different user (nxuser), no change for root
                # getClient(host, labCustomUser='nxuser', labCustomPw='nxuser_pw')
           ** a lab with a "not-standard" login in 2 steps : user1/xxxx then root/yyyy
                # getClient(host, labCustomUser='user1', labCustomPw='xxxx', labRootPw='yyyy')
           ** a miscellanous station (not lab) with direct root login
                # getClient(host, user='root', pw='xxxx')
           ** It is possible to log in on a standard lab by specifying the users (unuseful) :
                # getClient(host, labCustomUser='ainet', labCustomPw='ainet1', labRootPw='r00t')
        '''

        # --- first set the key to check if connection already stored
        if user is None:  # is it a lab ? (a lab is a 2-steps login)
            finalUser = MCAS_ROOT
        else:
            finalUser = user
        key = finalUser + '@' + host
        self.clientLock.acquire()
        # --- if user@host already established , returns it
        if key in self._connections:
            self.clientLock.release()
            return self._connections[key].client

        # --- connection was not stored, we can set the values for user and pw
        if user is None:  # is it a lab ?
            twoStep = True  # yes : => 2 steps with use MCAS_USER and ROOT_USER
            primaryUser = labCustomUser
            primaryPw = labCustomPw
            finalPw = labRootPw
        else:
            twoStep = False
            finalPw = pw

        destPort = SSH_DEFAULT_PORT
        try:
            # --- test gateway
            tunnel = None
            if self.gateway is not None:
                self._checkAccessAndGrantIfNecessary(self.gateway,
                                                     self.gatewayUser,
                                                     self.gatewayPassword)
                tunnel = self._openTunnel(host)
                host = "localhost"
                destPort = tunnel.port

            client = None

            if useKey:
                # test if finalUser has already grant access.  Have an exception means only
                # that we dont have access, this is a normal way
                try:
                    client = self._checkAccessUsingKey(host, finalUser, destPort)
                except SSHException as ex:
                    LOGGER.error("cannot connect to %s as %s", host, finalUser)
                    LOGGER.exception(ex)
                    raise ex

            if client is None:  # no access for finalUser via SSH key

                # if 2-step login (lab) : login to ainet
                try:
                    if twoStep:
                        #  ----  in 2 steps , finalUser is always root
                        self._checkAccessAndGrantIfNecessaryIn2Steps(host, primaryUser, primaryPw, finalPw, destPort)
                    else:
                        if useKey:
                            self._checkAccessAndGrantIfNecessary(host, finalUser, finalPw, destPort)
                        else:
                            client = self._checkAccessUsingPw(host, finalUser, finalPw)
                except SSHException as ex:
                    LOGGER.error("cannot connect to %s as %s", host, primaryUser if twoStep else finalUser)
                    LOGGER.exception(ex)
                    raise ex

                if useKey:
                    # --- now we have access, keys are installed . Create the final client to store it
                    client = self._checkAccessUsingKey(host, finalUser, destPort)

            # --- now finalUser has access to host . We can store the connection
            clientAndTunnel = SshManager.clientAndTunnel(client, tunnel)
            self._connections[key] = clientAndTunnel
        finally:
            self.clientLock.release()

        return client



    def closeClient(self, host, user='root'):
        '''
        closeClient : close connection to a host or a list of host
        @param host : a hostname (string)
        @param user: login
        '''
        if user is None:
            user = 'root'
        key = user + '@' + host
        self.clientLock.acquire()
        if key in self._connections:
            sshClient = self._connections[key]
            sshClient.client.close()
            if self.gateway is not None:
                SshManager._closeTunnel(sshClient.tunnel)
            del self._connections[key]
        self.clientLock.release()



    def closeAllClients(self):
        '''
            close all Clients of this instance
        '''
        for key in self._connections.keys():
            wkey = key.split('@')
            self.closeClient(wkey[1], wkey[0])


    def _reconnect(self, client, host, userSsh):
        l_client = client
        timeout = CONNECTION_ATTEMPTS_INTERVAL * MAX_CONNECTION_ATTEMPTS
        LOGGER.warning(CONNECTION_DOWN + host + ", " + str(timeout))
        count = 0
        while count < MAX_CONNECTION_ATTEMPTS and \
                ((l_client is None) or (not l_client.get_transport().is_alive())):
            self.closeClient(host, userSsh)
            time.sleep(CONNECTION_ATTEMPTS_INTERVAL)
            try:
                l_client = self.getClient(host, user=userSsh)
            except BaseException:
                LOGGER.debug("ssh reconnection attempt #" + str(count) + " failed: "
                             + traceback.format_exc())
            count = count + 1
        if count == MAX_CONNECTION_ATTEMPTS:
            self.closeClient(host, userSsh)
            msg = LOST_CONNECTION + host + ", " + str(MAX_CONNECTION_ATTEMPTS)
            LOGGER.error(msg)
            raise BaseException(msg)
        LOGGER.info("ssh connection back after " + str(count) + " attempts: " + host)
        return l_client

    def run(self, host, cmd, user=None, station=None, ignoreStdStreams=False):
        '''
            Executes a command via paramiko exec_command and return the full stdout of the command.
            An empty string could be returned in some cases, a command in background for example.

            >>> CAUTION >>> Dont rely on trailing chars of the flow (EOL as \r or \n , space).
                            Dont suppose that there is a trailing EOL or no trailing EOL.
                            The caller must filter the full output to find the right line.
            >>> CAUTION >>> At least one getClient() must have been executed before calling this proc
                             i.e. connection is already stored in self._connections

            If connection is dead, we try to reconnect every minute for 15 minutes. If it's still
            impossible to open a new connection after 15 minutes, an exception is raised.

            @param host : the target lab
            @param cmd the (string) the command to execute
            @param user login
            @param station : the blade target if any, if None target is pilot active
            @param ignoreStdStreams : ignore stdout and stderr. Dont read them after executing command.
                   But get an exit status. Useful for nohup command, background process, etc
            @return the tuple (exit_status, stdout) stdout is a unique string with all EOL except trailing EOL
            @usage
               sshManager.run('hp31oam',cmd)                 : executes cmd on pilot active
               sshManager.run('hp31oam',station='C',cmd)     : executes cmd on station C
               sshManager.run(lab, 'nohup launch_traffic &', ignoreStdStreams=True)
                            : launch traffic in background. Don't wait the output of the command
        '''
        userSsh = 'root' if user is None else user
        client = self.getClient(host, user=userSsh)
        if not client.get_transport().is_alive():
            client = self._reconnect(client, host, userSsh)

        if station:
            # probably needs to be improved...
            command = cmd.replace("\"", "\\\"").replace("$", "\\$")
            command = "ssh STATION_" + station + " \"" + command + "\""
        else:
            command = cmd

        txtToAdd = '[ignore stdout stderr]' if ignoreStdStreams else ''

        return self._runCommand(host, userSsh, command, client, ignoreStdStreams, txtToAdd)


    def sendStringAndExpect(self, host, strToSend, expectString, user=None, timeout=1200):
        '''
            run a string or command and expect a string to terminate the function. The string to wait can be
            located at end of flow (like a prompt) and in the middle of the flow (useful with subshl).
            Trailing spaces are removed to get an easier comparison.
            @param host (String) the host where execute the cmd
            @param strToSend (String) the command to execute
            @param expectString (String or list) the string to detect in stdout to quit the function. Case sensistive
                   >>> MUST NOT BE EMPTY
                   You can use multiple string in a list
            @param user: default is 'root'
            @param timeout (int) in seconds. interrupt the function if timeout reached.
                useful if expectString never found
            @return stdout,stderr : the stdout of the command , the stderr as 2 unique string (including EOL)
               Ex:    sshManager.sendStringAndExpect('spa20oam','subshl','<')
                      sshManager.sendStringAndExpect('spa20oam','OP:STATUS,SPA=ALL','END OF REPORT #')
        '''
        userSsh = 'root' if user is None else user
        client = self.getClient(host, user=userSsh)
        if not client.get_transport().is_alive():
            return None, None
        shl = client.invoke_shell(width=120)
        time.sleep(0.1)
        shl.settimeout(timeout)
        _res = SshManager.sendStringRoutine(shl, strToSend, expectString, timeout)
        return _res

    def checkConnections(self, testenv):
        for lab in testenv.testBed.labs.values():
            client = self.getClient(lab.oamIpAddress)
            if client is None or not client.get_transport().is_alive():
                raise BaseException(CONNECTION_NOT_FOUND + lab.oamIpAddress)

    def isAlive(self, host, user=None):
        '''
        check if connection still alive.
        @param host : the remote host
        @param user : the user
        @return boolean depending of the connection status
        Ex:   sshManager.isALive ('lalx03si3',user='jenkins')
        '''
        user = 'root' if user is None else user
        return self.getClient(host, user=user).get_transport().is_alive()

    def isDead(self, host, user=None, pw=None, heartbeat=None, timeout=120, interval=5):
        """Check the ssh connection down within timeout

        @param host      the remote host
        @param user      the user
        @param heartbeat ssh connection keepalive value
        @param timeout   timeout to wait the connection down
        @param interval  sleep interval before next check
        """
        dead = True
        if heartbeat:
            self.getClient(host, user, pw).get_transport().set_keepalive(heartbeat)
        while timeout > 0:
            time.sleep(interval)
            timeout -= interval
            if self.isAlive(host, user):
                LOGGER.debug("Host %s: connection alive (%d)", host, timeout)
                continue
            LOGGER.debug("Host %s: connection down (%d)", host, timeout)
            # Close the connection, so ssh lib will create it again.
            self.closeClient(host, user)
            break
        else:
            LOGGER.debug("Host %s: connection still alive (%d)", host, timeout)
            dead = False
            if heartbeat:
                self.getClient(host, user, pw).get_transport().set_keepalive(self.__class__.defaultHeartbeat)
        return dead

    @staticmethod
    def readBuffers(shl):
        ''' read stdout and atderr buffer
        '''
        buff = shl.recv(BUFF_SIZE) if shl.recv_ready() else ''
        buffErr = shl.recv_stderr(BUFF_SIZE)if shl.recv_stderr_ready() else ''
        return buff, buffErr


    @staticmethod
    def sendStringRoutine(channel, strToSend, expectString, timeout=60):
        '''
            Public method
            run a string or command and expect a string to terminate the function. The string to wait can be
            located at end of flow (like a prompt) and in the middle of the flow (useful with subshl).
            Trailing spaces are removed to get an easier comparison.
            @param channel: paramiko Channel (interactive shell)
            @param strToSend: (String) the command to execute
            @param expectString (String or list) the string to detect in  stdout to quit the function. Case sensistive
                   >>> MUST NOT BE EMPTY
                   You can use multiple string in a list
            @param timeout (int) in seconds. interrupt the function if timeout reached.
                   useful if expectString never found
            @return stdout,stderr : the stdout of the command , the stderr as 2 unique string (including EOL)
        '''

        # exepectString could be a string or a list of string
        # if type(expectString)  == str:
        #    expectString = [expectString]                               # list of one elt
        if type(expectString) == list:
            expectString = [exStr.rstrip() for exStr in expectString]  # remove trailing spaces and other
            expectString = '|'.join(expectString)
        else:
            expectString = expectString.rstrip()
        patt = re.compile(expectString)

        SshManager._voidBuffers(channel)  # empty the stdout and stderr buffers
        # delete multiple trailing EOL if any. And add trailing \n if needed :
        strToSend = strToSend.rstrip() + os.linesep

        LOGGER.trace("send string on terminal: " + strToSend)
        channel.send(strToSend)  # send the string
        time.sleep(0.1)
        time0 = int(datetime.now().strftime('%s')) + timeout
        deltaTim = 0
        # --- while loop : depending on stringAtEnd test comparison is not the same.
        # we loop while :
        #       - time is lower than timeout
        #  AND  - we dont have the expected String

        buff, buffErr = SshManager.readBuffers(channel)  # first, init buffer
        while deltaTim <= time0 and not re.search(patt, buff):
            buffAdd, buffErrAdd = SshManager.readBuffers(channel)
            buff += buffAdd
            buffErr += buffErrAdd
            deltaTim = int(datetime.now().strftime('%s'))
        # --- if timeout has been reached : better to empty the buffers
        if deltaTim > time0:
            SshManager._voidBuffers(channel)
            msg = "timeout " + str(timeout) + " reached for command: " + strToSend
            LOGGER.debug(msg)
            # TODO raise exception and update calling methods
            # raise BaseException(msg)
        LOGGER.trace("sent string on terminal: " + strToSend
                     + ", received:\nstdout: " + buff + "\nstderr: " + buffErr)
        return [buff, buffErr]

    @staticmethod
    def _closeTunnel(tunnel):
        '''
        Private method
        close the current tunnel
        '''
        tunnel.process.terminate()
        # del tunnel.process
        # del tunnel.port



    @staticmethod
    def _copyPublicKeyRootIn2Steps(client, finalPw):
        '''
        Private method
        to copy public key for root to remote host. we need to login first as ainet
        @param host : the remote host
        @param finalPw : pw of final User in 2 steps login (= root)
        '''
        channel = client.invoke_shell()

        SshManager.sendStringRoutine(channel, CMD_SU, PW_PRPT)
        SshManager.sendStringRoutine(channel, finalPw, ROOT_PRPT)
        SshManager.sendStringRoutine(channel, 'echo ' + SshManager.publicKeyStr + ' >> '
                                   + SSH_DIR + AUTHK_FIL, ROOT_PRPT)
        SshManager.sendStringRoutine(channel, 'chmod 600 ' + SSH_DIR + AUTHK_FIL, ROOT_PRPT)

        client.close()



    @staticmethod
    def _copyPublicKey(client, exceptionMsg):
        '''
        Private method
        to copy public key for specified user to remote host.
        @param host : the remote host
        @param port : the ssh port
        @param user : the user
        Ex:  ._copyPublicKey('spa02oam','ainet','ainet1')
        '''
        LOGGER.debug("_copyPublicKey " + str(client) + ", " + SshManager.publicKeyStr)

        cmd = 'mkdir ' + SSH_DIR + ' 2>/dev/null'
        LOGGER.trace(cmd)
        client.exec_command(cmd)

        cmd = "echo " + SshManager.publicKeyStr + ' >> ' + SSH_DIR + AUTHK_FIL
        LOGGER.trace(cmd)
        _, stdout, stdErr = client.exec_command(cmd)
        err = stdErr.read().rstrip()
        rc = stdout.channel.recv_exit_status()
        cmd = 'chmod 600 ' + SSH_DIR + AUTHK_FIL  # if file has been created by previous command , chmod is 644
        LOGGER.trace(cmd)
        _, stdout, _ = client.exec_command(cmd)

        client.close()
        if rc != 0:
            LOGGER.error(msgExc.PUBLIC_KEY_COPY_ERROR + str(rc) + " " + err + " ( " + exceptionMsg + " )")
            raise Exception(msgExc.PUBLIC_KEY_COPY_ERROR + str(rc) + " " + err + " ( " + exceptionMsg + " )")


    @staticmethod
    def _voidBuffers(chann):
        '''
        Private method
        void the buffers : stdout and stderr. Useful  just before a loop with a new command
        '''
        while chann.recv_stderr_ready():
            chann.recv_stderr(BUFF_SIZE)
        while chann.recv_ready():
            chann.recv(BUFF_SIZE)


