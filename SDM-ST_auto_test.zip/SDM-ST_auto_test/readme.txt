SDM automated system tests

This python project contains classes for system test cases execution
(framework), libraries and the actual test cases.

Documentation available here:
https://atlassianwave.web.alcatel-lucent.com/confluence/display/SDM8650/Architecture

To install all dependencies, you should make sure all native dependencies of
libraries in requirements.txt are installed. The native packages required are:

 - python-dev
 - lxml: libxml2-dev, libxslt-dev, python-dev

Those package names are debian package names. The corresponding redhat package
names are:

 - python-devel
 - lxml: libxml2-devel, libxslt-devel, python-devel

Once those native dependencies are installed, you can create a pip configuration
file ~/.config/pip/pip.conf:

[global]
proxy = global.proxy.alcatel-lucent.com:8000

with your own proxy.

It's also advised to use virtualenv to create a virtual python environment with
your own user 3rd party packages.
To create a new virtualenv, just run:
  virtual myenv
It will create a local directory with a duplicate of your system python
executable and libraries.
To activate this new environment, run:
  source myenv/bin/activate

Before you can use classes provided by this project, you should run the
following command line to install the 3rd party python packages (once your 
virtual environment activated):

  pip install -r requirements.txt

if you created the pip config file, otherwise:

  pip install -r requirements.txt --proxy="global.proxy.alcatel-lucent.com:8000" 

To start test cases, use module framework.jenkins_worker in src directory:

(with your virtualenv active)

How to run test case ?

in any case, run those command lines from project root directory (SDM-ST_auto_test)

1) run internalunittest once

PYTHONPATH=src python src/framework/jenkins_worker.py --testenv LN-V8650-G8-1--nohealthcheck --internalunittest_pattern *nightly_test_once.py

2) run ST test cases (src/testcases)

i) Given the full pathname
PYTHONPATH=src python src/framework/jenkins_worker.py --testenv LN-ROUZIC-2 --testitems src/testcases/groups/example/casegroup1 src/testcases/groups/example/casegroup2

PYTHONPATH=src python src/framework/jenkins_worker.py --testenv LN-ROUZIC-2
--testitems src/testcases/suites/example/case_suite1

ii) Given the shorten file name
PYTHONPATH=src python src/framework/jenkins_worker.py --testenv LN-ROUZIC-2 --testitems casegroup1 casegroup2
PYTHONPATH=src python src/framework/jenkins_worker.py --testenv LN-ROUZIC-2 --testitems case_suite1

or

PYTHONPATH=src\
  python src/framework/jenkins_worker.py\
    --testenv LN-ROUZIC-2\
    --testitems case_suite1

project structure:
  src/               contains python source code for framework, libs and test cases
  internalunittest/  contains internal unittest test cases written in python
  cache/             contains files temporary files copied from remote target labs
  conf/              contains configuration files for framework
  doc/               contains dynamically generated documentation
  log/               contains log files from test cases execution
  Doxyfile           doxygen configuration file
  project-config.ini defines link to alcatel-lucent jira server for a server hook
  pylint.rc          pylint configuration file
  PythonCodingRules.txt pylint rules as plain text for human readers
  readme.txt         this file
  readme-windows.txt how to execute framework on windows (not officially supported)
  requirements.txt   pip dependency file (python package management tool)
  setup.py           not used yet

To generate documentation, just run doxygen in root directory (you need to
install doxypy package first).
To evaluate source code, you can install and run pylint with the following
command line:
  pylint --rcfile=pylint.rc src/*
The pylint.rc config file only contains values not similar to default values.
To get default values for all pylint features, run pylint --generate-rcfile

To run the internal unit tests use the following command line once virtualenv
activated:
To get XML output :
PYTHONPATH=src:internalunittest/ python -m test_runner

To get text output (old)
  PYTHONPATH=src:internalunittest python -m unittest discover -s internalunittest/ -p "*_test.py" -t .

To run internal test finishing with _test_once.py :
PYTHONPATH=src python src/framework/jenkins_worker.py --testenv LN-ROUZIC-2 --internaltests_once --nohealthcheck
These tests rely on the availability of a full test environment (ssh, traffic pc, etc)
Run them to ensure there is no regression on the framework

UML Diagrams

to generate uml diagrams, you need to install graphviz:
 - linux (debian): apt-get install graphviz
 - windows: windows installer from graphviz website
     (add dot.exe from graphviz to your path)
then, use the following command line to generate uml diagrams:
  pyreverse -o <output_format> -p <package_name> <package_name>
this command must be executed in src directory.
<output_format> can be svg or png or any output format supported by graphviz.
<package_name> is python root package name.

For example:
  pyreverse -o png -p lib lib

