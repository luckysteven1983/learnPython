'''
Created on Jun 8, 2015

@author: Serge Beaufils

This library manages hardware.useful for specific function (SHMC for ATCAV2 or OA for HP)

'''

import re
from lib.hardware.hardware_machine_manager import StateHW , HardwareMachineManager, \
    SLOT_PREFIX
from lib.logging.logger import Logger

logger = Logger.getLogger(__name__)

# ---- init CONSTANTS
ROOT_USER = 'Administrator@'
OASSH_CMD = '/usr/psp/sbin/oassh '

BOARDRESET_MSG = 'Rebooting Blade %s'
BOARDRESET_CMD = 'REBOOT SERVER '
BOARDSTATUS_CMD = 'SHOW SERVER STATUS '
BOARDSTATUS_REGEX = r'(Power:)(\s)(.*)'
OA_PROMPT = '#'



class HpHardwareMachineManager(HardwareMachineManager):

    '''
    for HP  prompt could be 'hostname-0-0-OA1'  or '...-OA2' depending on active OA
    '''


    def __init__(self, sshMngr):
        super(HpHardwareMachineManager, self).__init__(sshMngr)



    def _runOACommand(self, lab, cmd):
        '''
        to execute directly an OA command :
        /usr/psp/sbin/oassh <rack> command .    Rack is generally '0-0'
        output is : NOTICE: Sending to Active OA 0-0-1.
                    HP BladeSystem Onboard Administrator
                    hp33-0-0-OA1 [SCRIPT MODE]> REBOOT SERVER 5
                    Rebooting Blade 5
                    hp33-0-0-OA1 [SCRIPT MODE]>
                    REBOOT SERVER 5
        @param lab : instance of framework.testenv.Lab
        '''
        sshOACmd = ' '.join([OASSH_CMD, SLOT_PREFIX, cmd])
        _rc, _out = self.sshmngr.run(lab.oamIpAddress , sshOACmd)

        if _rc == 0:
            return True, _out
        else:
            return False, _out



##############################   PUBLIC  METHODS   #################################


    def restartBoard(self, lab, physicalSlot):
        '''
        run the command to reset board. Then check if we got the board reset msg
        @param lab : instance of framework.testenv.Lab
        @param the number of the slot to restart, must be an int
        for ex : restartBoard(lab,2)
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        self.localResetMsg = BOARDRESET_MSG % slot
        _, _out = self._runOACommand(lab, BOARDRESET_CMD + slot)
        # now check if restarted
        return self._checkBoardRestart(_out)

    def  getHardwareState(self, lab, physicalSlot):
        '''
        Get the state of a board .
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to check
        '''
        out = self.getHardwareStateRAW(lab, physicalSlot)
        result = re.search(BOARDSTATUS_REGEX, out)
        if result.group(3) == 'On':
            return StateHW.BOARD_POWERED_ON
        elif result.group(3) == 'Off' :
            return StateHW.BOARD_POWERED_OFF
        else :
            return StateHW.OTHER

    def  getHardwareStateRAW(self, lab, physicalSlot):
        '''
        Get the state of a board .
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to check
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        cmd = BOARDSTATUS_CMD + slot
        _returncode, out = self._runOACommand(lab, cmd)
        if _returncode :
            return out
        else :
            logger.error("Command " + cmd + " fails on " + lab.oamIpAddress)
            return out

