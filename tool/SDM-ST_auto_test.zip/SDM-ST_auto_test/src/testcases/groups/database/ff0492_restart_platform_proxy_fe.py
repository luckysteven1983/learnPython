'''
Created on Oct 20, 2015

@author: Yohann Martineau
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0492_restart_platform_proxy_fe(SDMTestCase):
    '''test restart platform proxy on frontend'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.databaseManager = self.sdmManager.databaseManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.linuxProcessManager = self.sdmManager.linuxProcessManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []

    def test_restart_Platform_Proxy_master(self):
        '''test restart Platform Proxy on frontend'''

        process = "PlatformProxy"
        processRestart = "DDM_PlatProxy"
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.info("start to restart Platform Proxy on frontend")
        _, frontend = self.testEnv.testBed.getFrontends().popitem()
        
        activePilotPre = self.mcasMachineManager.getActivePilot(frontend)
        LOGGER.debug("%s: active pilot is %s", frontend.id, activePilotPre)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, frontend)
        LOGGER.debug("Start to restart Platform Proxy on frontend at: " + startTime)

        LOGGER.debug("check the Platform Proxy on all stations is alive")
        self.platformAsserts.assertProcessAlive(frontend, process)

        LOGGER.debug("restart Platform Proxy on active pilot")
        self.databaseManager.restartProcess(frontend, processRestart)

        LOGGER.debug("check the Platform Proxy process can be recovered on frontend")
        self.platformAsserts.assertProcessAlive(frontend, process)

        LOGGER.debug("check alarms")
        # Compares alarms from snmp log file to expected and accepted lists
        # but doesn't check all raised alarms are cleared
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(frontend, myAlarmsConfig,
                                                               logFile=LOGFILE[1])

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        LOGGER.debug("restart platform proxy on frontend success!\n")
