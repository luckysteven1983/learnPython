"""
@file alarms_checker.py
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines the AlarmsChecker class
"""

import os.path
from lib.alarm.alarm import Alarm
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.logparser.mcas_log import MCASLog

LOGGER = Logger.getLogger(__name__)

class AlarmsCheckerError(BaseException):
    """If error, raise it."""
    pass

class AlarmsChecker(object):
    """ @details This class searches a list of alarms in snmplog file(s) between two dates. """

    # If one alarm raised during test case can't be found in expected and accepted alarm
    # lists, error happens
    NORMAL = 0
    # If one excepted alarm can't be found in alarms raised during test case, error happens
    EXPECTED_NOT_FOUND = 1
    # If one excepted alarm can't be found in alarms raised during test case or alarm listed in
    # "MustNotHave table" are present, error happens
    EXPECTED_AND_MUST_NOT_HAVE = 2

    def __init__(self, sshManager, acceptedAlarms):
        """ AlarmsChecker class constructor
        @param sshManager: ssh manager
        @param acceptedAlarms: list of common accepted alarms.
        """
        self._alarmsFound = list()
        self.sshManager = sshManager
        self.acceptedAlarms = acceptedAlarms

    @classmethod
    def printList(cls, message, level):
        """ Private method to print a list of alarms with a message

        @param message    text to print in console and debug log
        @param level      log level to print in console log
        """
        if level == 'error':
            LOGGER.error(message)
        elif level == 'warning':
            LOGGER.warning(message)
        else:
            LOGGER.debug(message)

    def _getAlarmsList(self, myAlarmsConfig):
        """Return alarms list"""
        expectedFound = list()
        acceptedFound = list()
        unexpectedFound = list()
        # for all alarms found in snmplog files, check if it is expected or accepted
        for alarm in self._alarmsFound:
            # check if the alarm is expected
            if alarm in myAlarmsConfig.expectedAlarms:
                expectedFound.append(alarm)
                continue
            # it is not expected, check if the alarm is accepted
            if alarm in myAlarmsConfig.acceptedAlarms + self.acceptedAlarms:
                acceptedFound.append(alarm)
                continue
            # not expected nor accepted: add the alarm to the list of unexpected ones
            unexpectedFound.append(alarm)
        # check if all expected alarms were found
        expectedNotFound = [al for al in myAlarmsConfig.expectedAlarms if al not in expectedFound]
        return (expectedFound, unexpectedFound, expectedNotFound)

    def _checkAlarms(self, myAlarmsConfig, lab, logFile, failureMode):
        """ Method to check if all found alarms were expected, accepted or unexpected ones.
        Also check if all awaited alarms were found.
        Expected, accepted, unexpected or must-have-not alarms are read from self.myAlarmsConfig.
        @exception Exception according to the failureMode.
        """
        (expectedFound, unexpectedFound, expectedNotFound) = self._getAlarmsList(myAlarmsConfig)
        if logFile and lab:
            # Here we need to save all alarms to csv file for analyses later
            LOGGER.debug("save alarms to csv file on node: " + lab.id)
            Alarm.writeAlarms2CSV(lab, self._alarmsFound, logFile)
        labMsg = lab.id + ": " if lab else str()
        # Original alarm implementation
        if failureMode == self.__class__.NORMAL and unexpectedFound:
            errorMsg = "%s%d unexpected alarm(s) found.\n%s\nSee csv file for more details."\
                        %(labMsg, len(unexpectedFound), Alarm.display(unexpectedFound))
            self.__class__.printList(errorMsg, 'error')
            raise AlarmsCheckerError, "%s - %s" %(msgs.ALARM_UNEXPECTED_ALARM, errorMsg)
        # Raise exception whatever the failureMode is if expected alarms not found
        if expectedNotFound:
            errorMsg = "%s%d expected alarm(s) not found.\n%s\nSee csv file for more details."\
                        %(labMsg, len(expectedNotFound), Alarm.display(expectedNotFound))
            self.__class__.printList(errorMsg, 'error')
            raise AlarmsCheckerError, "%s - %s" %(msgs.ALARM_EXPECTED_ALARM_NOT_FOUND, errorMsg)
        # New behavior, only print warning if alarms found is not in expected alarm list
        if failureMode in (self.__class__.EXPECTED_NOT_FOUND,
                           self.__class__.EXPECTED_AND_MUST_NOT_HAVE):
            allowedFound = [al for al in self._alarmsFound if al not in expectedFound]
            if allowedFound:
                errorMsg = "%s%d unexpected alarm(s) found. See csv file for more details."\
                            %(labMsg, len(allowedFound))
                self.__class__.printList(errorMsg, 'warning')
        # New behavior, raise exception if some raised alarms is in MUST NOT HAVE list
        if failureMode == self.__class__.EXPECTED_AND_MUST_NOT_HAVE and myAlarmsConfig.mustNotHaveAlarms:
            mustNotList = [al for al in self._alarmsFound if al in myAlarmsConfig.mustNotHaveAlarms]
            if mustNotList:
                errorMsg = "%s%d must not have alarms found.\n%s\nSee csv file for more details."\
                            %(labMsg, len(mustNotList), Alarm.display(mustNotList))
                self.__class__.printList(errorMsg, 'error')
                raise AlarmsCheckerError, "%s - %s" %(msgs.ALARM_MUST_NOT_HAVE_FOUND, errorMsg)

    def parseSnmpLogFiles(self, lab=None, myAlarmsConfig=None, mySnmpLogFiles=None, logFile=None, failureMode=None):
        """Method to parse a set of snmplog files and check the alarms.

        @param lab  one lab from which get snmplogs
        @param mySnmpLogFiles  snmplog files to be parsered if lab is not given
        @param myAlarmsConfig   one AlarmSConfig object to be checked.
        @param failureMode   one flag to indicate how to parse the given alarms

        @exception msg Error: file not found if at least one snmplog file does not exist
        @exception msg Error: startingDate > endingDate
        @exception msg Unexpected alarms occurred or expected alarms not found

        The failureMode can be assigned with the following vlaues.

        1) AlarmsChecker.NORMAL
           If one alarm raised during test case can't be found in expected and accepted alarm lists,
           error happens and raise exception.

        2) AlarmsChecker.EXPECTED_NOT_FOUND
           If one excepted alarm can't be found in alarms raised during test case, error happens and
           raise exception.

        3) AlarmsChecker.EXPECTED_AND_MUST_NOT_HAVE
           If one excepted alarm can't be found in alarms raised during test case or alarm listed in
           "MustNotHave table" are present, error happens and raise exception.
        """
        if failureMode is None:
            failureMode = self.__class__.EXPECTED_AND_MUST_NOT_HAVE
        if failureMode not in (self.__class__.NORMAL, self.__class__.EXPECTED_NOT_FOUND,
                               self.__class__.EXPECTED_AND_MUST_NOT_HAVE):
            failMsg = "%s - %s" %(msgs.ALARM_UNSUPPORTED_FAILURE_MODE, str(failureMode))
            LOGGER.error(failMsg)
            raise AlarmsCheckerError, failMsg
        self._alarmsFound = list()
        if lab:
            mySnmpLogFiles = self.sshManager.scpGetAll(lab.oamIpAddress, "/snlog/snmplog*")
        # check if all snmplog files exist
        for myFile in mySnmpLogFiles:
            if not os.path.isfile(myFile):
                LOGGER.error(msgs.ALARM_FILE_NOT_FOUND + myFile)
                raise AlarmsCheckerError, msgs.ALARM_FILE_NOT_FOUND + myFile
        if myAlarmsConfig.endingDate and myAlarmsConfig.startingDate > myAlarmsConfig.endingDate:
            LOGGER.error(msgs.ALARM_STARTING_DATE_AFTER_ENDING_DATE)
            raise AlarmsCheckerError, msgs.ALARM_STARTING_DATE_AFTER_ENDING_DATE
        LOGGER.debug("time: %s ~ %s", myAlarmsConfig.startingDate, myAlarmsConfig.endingDate)
        alms = iter(MCASLog(mySnmpLogFiles, myAlarmsConfig.startingDate, myAlarmsConfig.endingDate))
        self._alarmsFound = [Alarm.getAlarmByString(alm[1]) for alm in alms if alm[0]]
        self._checkAlarms(myAlarmsConfig, lab, logFile, failureMode)
