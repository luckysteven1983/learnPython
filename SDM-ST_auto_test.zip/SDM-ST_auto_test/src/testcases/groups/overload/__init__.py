"""
This package contains all overload related test cases, checking
the expected behavior of SDM product when thresholds are crossed.
"""
