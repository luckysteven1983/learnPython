#!/bin/sh
# start log on station

# resolve links - $0 may be a soft-link
PRG="$0"

# special deal with STATION_A~L
STATION_ID=`echo $1|tr a-z A-Z`
STATION_ID=`expr $STATION_ID : "STATION_\(.*\)"`

#otherwise use the input parameter directly
STATION_ID=${STATION_ID:-$1}

VIEW_DIR=$2
TYPE=$3
ACTIVEPILOT=`echo $4|tr a-z A-Z`

while [ -h "$PRG" ] ; do
    ls=`ls -ld "$PRG"`
    link=`expr "$ls" : '.*-> \(.*\)$'`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=`dirname "$PRG"`/"$link"
    fi
done

TOOL_DIR=`dirname "$PRG"`

LOG_INI="log.ini"
LOG_DIR=/var/local/nectar/log
OUT_DIR=/var/local/nectar/out
NDBLOG_DIR=/user/database/log

CONF="$TOOL_DIR/$LOG_INI"
PILOT_ID="A B"
COMPACT_DB_BLADE="C D E F"
COMPACT_RT_BLADE="G H I J K L"


help () {
	 echo "$0 station_id view_dir type [activepilot]"
	 echo "		station_id: STATION_A-L"
	 echo "		view: the view for logs"
	 echo "		type: FPAE|BE|COMCT"
	 echo "		activepilot: yes|no| : default=no"
	 echo "Sample:" 
	 echo "		$0 STATION_D /MDS COMPACT"
	 echo "		$0 STATION_E /MDS/pt FE yes"
}

if [  "$#" -lt 3 ]; then
   help
   exit 1
fi



echo "The config file for $script is: $CONF"
echo "The current view is: $VIEW_DIR"
echo "STATION_ID: ${STATION_ID} ${STATION_ID2}"
echo "ActivePilot: $ACTIVEPILOT"


script=`basename $0`
if ps -ef |grep $script |grep -v grep |grep -v $$ > /dev/null ;then
        echo "$0 already exists"
        exit 3
fi

STATION_ID2=`hostname|sed -e 's:^.*-\([0-9]*\)$:\1:'` 

#LOG_LOCK="$TOOL_DIR/STATION_${STATION_ID2}.LOCK"

# RT/DB/STATION_X/PILOT/NPILOT/ALL/FE_PILOT/FE_NPILOT/BE_PILOT/BE_NPILOT/ACTIVEPILOT/ACTIVEFEPILOT/NACTIVEPILOT/NACTIVEFEPILOT
FILTER="ALL|STATION_$STATION_ID|$STATION_ID2"

bPilot=false
bActivePilot=false

# active pilot
if   [ y"$ACTIVEPILOT" = "yYES" -o y"$ACTIVEPILOT" = "yY" ]; then
	bActivePilot=true
fi

#pilot ?
for x in $PILOT_ID; do
	if [ "$STATION_ID" = "$x" ]; then
	   bPilot=true
	   break;
	fi 
done

# RT/DB/STATION_X/PILOT/NPILOT/ALL/FE_PILOT/FE_NPILOT/BE_PILOT/BE_NPILOT/ACTIVEPILOT/ACTIVEFEPILOT/NACTIVEPILOT/NACTIVEFEPILOT
# RT or DB blad?
case $TYPE in
	 F?|f?)
	 	   if  $bPilot; then
			  FILTER="$FILTER|FE_PILOT|PILOT"
			  if $bActivePilot; then
		   	  	 FILTER="$FILTER|ACTIVEPILOT|ACTIVEFEPILOT"
			  else
			  	 FILTER="$FILTER|NACTIVEPILOT|NACTIVEFEPILOT" 
			  fi
	 	   else
	 	   	  FILTER="$FILTER|FE_NPILOT|RT|NPILOT" 	     
	 	   fi	  
	 	   ;;
     B?|b?)
	 	   if  $bPilot; then
			  FILTER="$FILTER|BE_PILOT|PILOT"
			  if $bActivePilot; then
		   	  	 FILTER="$FILTER|ACTIVEPILOT|ACTIVEBEPILOT"
			  else
			  	 FILTER="$FILTER|NACTIVEPILOT|NACTIVEBEPILOT" 
			  fi
	 	   else
	 	   	  FILTER="$FILTER|BE_NPILOT|DB|NPILOT"     
	 	   fi	  
	 	   ;;
     C*|c*)
     	   if  $bPilot; then
			  FILTER="$FILTER|BE_PILOT|FE_PILOT|PILOT"
			  if $bActivePilot; then
		   	  	 FILTER="$FILTER|ACTIVEPILOT|ACTIVEBEPILOT|ACTIVEFEPILOT"
			  else
			  	 FILTER="$FILTER|NACTIVEPILOT|NACTIVEBEPILOT|NACTIVEFEPILOT" 
			  fi     	   	   
     	   else
	     	   for x in $COMPACT_RT_BLADE; do
				   	if [ "$STATION_ID" = "$x" ]; then
				   	   FILTER="$FILTER|FE_NPILOT|RT|NPILOT"
				   	   break
					fi    
			   done	
	     	   for x in $COMPACT_DB_BLADE; do
				   	if [ "$STATION_ID" = "$x" ]; then
				   	   FILTER="$FILTER|BE_NPILOT|DB|NPILOT"
				   	   break
					fi    
			   done	
     	   fi 		   	   
     	   ;;
     *)
       ;;
esac
	        
echo "Filter: $FILTER"

# Create VIEW_DIR
if ! mkdir -p $VIEW_DIR> /dev/null; then
   echo "Can't create $VIEW_DIR"
   exit 4
fi

# set the trap to clear all sub process
g_process_id=$$
_clearup () {
#         rm -rf $LOG_LOCK
	 ps h --ppid $g_process_id |grep -v ppid|awk '{ print $1}' | xargs -n 1  kill -9 > /dev/null
	 
}


trap _clearup INT TERM

#touch $LOG_LOCK

COMMANDS=`cat $CONF|egrep "^($FILTER)[ \t]*" | sed "s:[^ \t]*[ \t]*::" `
COMMANDS=`echo "$COMMANDS"|sed -e "s:\\\${OUT_DIR}:${OUT_DIR}:g" \
			 -e "s:\\\${LOG_DIR}:${LOG_DIR}:g" \
			 -e "s:\\\${TOOL_DIR}:${TOOL_DIR}:g" \
			 -e "s:\\\${VIEW_DIR}:${VIEW_DIR}:g" \
			-e "s:\\\${STATION_ID}:${STATION_ID}:g" \
                        |sed "s:[ \t]*$:#:"`
			
#COMMANDS=`cat $CONF|egrep "^($FILTER)[ \t]*" `
IFS_save=$IFS
IFS="#"
for cmd in $COMMANDS
do
	#echo "COMMAND: $command"
	if [ -z "$cmd" ]; then
		continue;
	fi
	cmd=`echo "$cmd"|sed -e "s:\\\${OUT_DIR}:${OUT_DIR}:g" \
			 -e "s:\\\${LOG_DIR}:${LOG_DIR}:g" \
			 -e "s:\\\${TOOL_DIR}:${TOOL_DIR}:g" \
			 -e "s:\\\${VIEW_DIR}:${VIEW_DIR}:g" \
			-e "s:\\\${STATION_ID}:${STATION_ID}:g"`	
	cmd="$cmd &"
	echo "$cmd"
        eval "$cmd" 
#        eval "${command} &"
done
IFS=$IFS_SAVE

#ps h --ppid $$
wait
