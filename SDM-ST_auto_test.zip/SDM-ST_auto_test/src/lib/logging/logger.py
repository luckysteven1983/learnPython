'''
Logger
Changed on October 22, 2015 to add TRACE level
@author: yohannm
'''
import datetime
import logging.config
import os
import sys
import time
from logging import FileHandler
from framework import arch


TRACE_LEVEL = 5

class Logger(logging.Logger):
    """Custom logger for python framework

    This class can be used the same way as the standard library logging.logger:

    import lib.logging.logger

    logger = Logger.getLogger(__name__)

    ...
        logger.debug("my debug message")
    ...

    of course you can use all debug functions provided by python logging
    standard lib (debug, info, warning, error, etc.).

    All messages are displayed on both standard output and in a common file.
    This common log file is in log directory and its name starts with date.
    Its name contains jenkins job id and build id if the corresponding
    environment variables are available.

    For messages sent from a test case file, a subdirectory is created in
    log directory with the test case name (zz0000_hello_world). A file
    is created which name contains the date, the test case name, and
    jenkins job and build id if available. This log file contains only
    test case messages. It can be used to debug the test case itself.

    As soon as there is an issue in the framework or in a library, the
    common log file must be used to investigate.

    All messages from test cases automatically reach the common file thanks
    to the "propagate" property of python standard logging library.
    """

    logging.addLevelName(TRACE_LEVEL, "TRACE")
    jenkins_job_name = "JOB_NAME"
    jenkins_build_number = "BUILD_NUMBER"
    jenkins_joburl = "JOB_URL"
    jenkinsJob = os.environ.get(jenkins_job_name)
    jenkinsBuild = os.environ.get(jenkins_build_number)
    jenkinsJobURL = os.environ.get(jenkins_joburl)
    date = datetime.datetime.now().strftime("%Y%m%d-"\
        + time.tzname[1] + "-%H%M%S.%f")
    log_dir_name = "log"
    filename = log_dir_name + os.sep + date
    if jenkinsJob:
        filename += "_job_" + jenkinsJob
    if jenkinsBuild:
        filename += "_build_" + jenkinsBuild
    if jenkinsJobURL is None:
        jenkinsJobURL = ""
    filename += ".log"
    loggerConfig = {
        "version": 1,
        "loggers": {
            "": {
                "handlers": ["console", "defaultFile"],
                "level": "TRACE"
            },
            "paramiko": {
                "level": "CRITICAL"
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "level": "INFO",
                "stream": sys.stdout,
                "formatter": "colored"
            },
            "defaultFile": {
                "class": "logging.FileHandler",
                "formatter": "defaultFormatter",
                "level": "TRACE",
                "filename": filename
            }
        },
        "formatters": {
            "defaultFormatter": {
                "format": "%(asctime)s - %(name)s - %(filename)s - %(lineno)d - %(levelname)s - %(threadName)s - %(message)s"
            },
            "colored": {
                '()': 'colorlog.ColoredFormatter',
                "format" : "%(bold)s%(asctime)s %(reset)s - %(name)s - %(filename)s - %(lineno)d - "
                           "%(log_color)s%(levelname)s %(reset)s - %(threadName)s - %(message)s"
            }
        }
    }
    logging.config.dictConfig(loggerConfig)
    if jenkinsJobURL:
        logging.getLogger().info("workspace directory: " + jenkinsJobURL + "ws/")
    if jenkinsBuild:
        filename = jenkinsBuild + "/artifact/" + filename
    logging.getLogger().info("Global PostBuild Log file is : \n" + jenkinsJobURL + "/" + filename)

    @staticmethod
    def getLogger(name):
        """
        Logger configuration
        Goal of this is to customize logger, to have different logging level for console and file
        """
        loggerName = name
        if arch.CASEDIR in name:
            logging.getLogger().info("\n\n\n\n\n\n\n++++++++++++++++++++++++++++" + name + "++++++++++++++++++++++++++++++++++++")
            shortName = name.split(".")[-1]
            handler = name + "FileHandler"
            Logger.loggerConfig["loggers"][name] = {
                "handlers": [handler],
                "level": "TRACE"
            }
            Logger.loggerConfig["handlers"][handler] = Logger.loggerConfig["handlers"]["defaultFile"].copy()
            logDir = Logger.log_dir_name + os.sep + shortName
            if not os.path.exists(logDir):
                os.makedirs(logDir)
            filename = logDir + os.sep + Logger.date + "_" + shortName
            if Logger.jenkinsJob:
                filename += "_job_" + Logger.jenkinsJob
            else:
                filename += "_job_"
            if Logger.jenkinsBuild:
                filename += "_build_" + Logger.jenkinsBuild
            else:
                filename += "_build_"
            filename += "_TC_skeleton.log"
            Logger.loggerConfig["handlers"][handler]["filename"] = filename
            if Logger.jenkinsBuild:
                filename = Logger.jenkinsBuild + "/artifact/" + filename
            Logger.postBuildTestLogFile = ("Test PostBuild Log file is : \n" + Logger.jenkinsJobURL + "/" + filename)
        else:
            loggerName = None
        logging.config.dictConfig(Logger.loggerConfig)
        return logging.getLogger(loggerName)

    @staticmethod
    def getAlarmLogFileNames(name):
        """Return the log file name into which the alarms will be written.

        Three file names are returned with a touple used to save the begining, duration, and end
        alarms
        """
        logFile = Logger.loggerConfig["handlers"][name + "FileHandler"]["filename"]
        dirName = os.path.dirname(logFile)
        fileName = os.path.basename(logFile).rstrip(".log").replace("TC_skeleton","")
        endAlarm = dirName + os.sep + "end_active_alarms_" + fileName + ".csv"
        beginingAlarm = dirName + os.sep + "begining_active_alarms_" + fileName + ".csv"
        duringAlarm = dirName + os.sep + "during_case_alarms_" + fileName + ".csv"
        return (beginingAlarm, duringAlarm, endAlarm)

    @staticmethod
    def getMeasCSVLogFileNames(name, tablename):
        """Return the log file name into which the measurement data will be written.

        Three file names are returned
        """
        logFile = Logger.loggerConfig["handlers"][name + "FileHandler"]["filename"]
        dirName = os.path.dirname(logFile)
        fileName = os.path.basename(logFile).rstrip(".log").replace("TC_skeleton","")
        csvFileName = dirName + os.sep + fileName + tablename + ".csv"
        return csvFileName

    def trace(self, message, *args, **kws):
        """
        Add a new logger level below DEBUG
        Can be used like other levels :
        LOGGER.trace("Low level message")
        """
        if self.isEnabledFor(TRACE_LEVEL):
            self._log(TRACE_LEVEL, message, args, **kws)
    logging.Logger.trace = trace

    @staticmethod
    def switchToTcLog(LOGGER,tcName,loop=None):
        """ remove the main handler from the logger.
        create and add the TC handler to the logger
        return the main handler, the TC handler and the link to the TC log file"""
        # copy "DefaultFile handler"
        oldHandler = LOGGER.handlers[1]
        # create filename
        jenkins_job_name = "JOB_NAME"
        jenkins_build_number = "BUILD_NUMBER"
        jenkins_joburl = "JOB_URL"
        jenkinsJob = os.environ.get(jenkins_job_name)
        jenkinsBuild = os.environ.get(jenkins_build_number)
        jenkinsJobURL = os.environ.get(jenkins_joburl)
        date = Logger.date
        log_dir_name = "log/"+tcName
        TcFilename = log_dir_name + os.sep + date
        if jenkinsJob:
            TcFilename += "_job_" + jenkinsJob
        if jenkinsBuild:
            TcFilename += "_build_" + jenkinsBuild
        if jenkinsJobURL is None:
            jenkinsJobURL = ""
        if loop == None:
            TcFilename = TcFilename+"_"+tcName+".log"
        else:
            TcFilename = TcFilename+"_"+tcName+"_"+str(loop)+".log"
        # copy the oldHandler formatter
        formatter = oldHandler.__getattribute__("formatter")
        # create the new handler to replace "DefaultFile" handler
        newHandler = FileHandler(TcFilename)
        newHandler.setLevel(TRACE_LEVEL)
        newHandler.setFormatter(formatter)
        # change main handler
        LOGGER.removeHandler(oldHandler)
        LOGGER.addHandler(newHandler)
        # create url logFile
        filename = TcFilename
        if jenkinsBuild:
            filename = jenkinsBuild + "/artifact/" + TcFilename
        message = jenkinsJobURL + "/" + filename
        return oldHandler, message

    @staticmethod
    def switchToMainLog(LOGGER, mainLog):
        """
        remove the tcLog handler from the logger
        add the mainLog handler to the logger
        """
        # remove TC handler
        LOGGER.removeHandler(LOGGER.handlers[1])
        # add old handler
        LOGGER.addHandler(mainLog)
