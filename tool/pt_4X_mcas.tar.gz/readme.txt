Version: 4.0..1.2012.03.07
2012-03-07	licanhua
	change log.ini for 4.0.1
2011-12-13	licanhua
	add simpWatch from pre4.0
2011-11-24	licanhua
	replease "scp" with "scp -p" to keep the time info
2011-11-22	licanhua
	add meminfo script for swap memory
2011-11-4	licanhua
	liqing raised the issue ssh 0-0-shmc doesn't need password
2011-10-8	licanhua
	measure is not collected in log.ini. use /snlog/meas
2011-9-30	licanhua
	fix some gmetric_cpu.sh can't be killed when stoplog
2011-9-22	licanhua
	modify the install.sh and only create .local_xxx in pilot
2011-9-07	licanhua
	modify iostat to iostat -x in log.ini
	correct the error of can't kill getroute when pt stoplog
2011-9-01	licanhua
	add /gmetric_cpu.sh mpread mppread into log.ini
	add /var/local/nectar/crash into pt core list
2011-8-30	licanhua
	modify max top task display to 30
	add iostat
	add check bandwidth
	add pt cores
2011-8-26	licanhua
	add .local_profile into install.sh
Version:  4.0.2011.8.10
2011-8-10	licanhua
	4.0.2011.8.10	add pt "lsta/llsta/ or subshl command" into pt
			modify fw for lsta
			add mpread|mppread|mpchg|mpros|mpswo into pt
			add ndb*|mysql* to pt
2011-6-28	licanhua
	modify gmetric_cpu to multi core other than only 2
2011-6-3	licanhua
    4.0		first release
2011-5-30 licanhua
	draft 	init the PT tool 
