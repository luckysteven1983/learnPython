'''
Created on May 5, 2015
@author: FrankZh

the base class to build and start jobs
'''

import os
from time import sleep

from lib.common.multi_tasks_manager import MultiTasksManager
from framework.testenv.lab import Lab
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MCASMachineManager
from lib.platform.mcas.subshl.subshl_manager import SubshlManager
from lib.softwareupdate.sdm_su_common_func import SdmSuUtils
from lib.softwareupdate.sdm_su_constants import SdmSuConst
from lib.softwareupdate.sdm_su_runner import SdmSuRunner
from lib.ssh.ssh_manager import SshManager


# import sys
LOGGER = Logger.getLogger(__name__)

class SdmSuJobHandler(object):
    """
    the base class to build and start jobs
    """

    def __init__(self):
        self.oamIpAddress = ''
        self._ipPilotA = ''
        self._ipPilotB = ''
        self.actionList = []
        self.releaseFilePath = ''
        self.softwareServerIp = ''
        self.efxPatchesPath = ''
        self.efxApplySwitch = False
        self.sftpLogin = ''
        self.oamScriptsDir = ''
        self.sshMngr = None
        self._suRunner = None
        self._labId = ''

    def setAttr(self, sshMngr, oamIpAddress, labId='', actionlist='', \
        swServerIp='', swPath='', swLogin='', oamScriptsDir='', \
        efxApplySwitch=False, efxPatchesPath=''):
        '''
        set parameter values by the external call
        '''
        self.oamIpAddress = oamIpAddress.strip()
        self.actionList = actionlist
        self.releaseFilePath = swPath
        self.softwareServerIp = swServerIp
        self.sftpLogin = swLogin
        self.sshMngr = sshMngr
        self.oamScriptsDir = oamScriptsDir
        self._labId = labId
        if self._labId == '':
            self._labId = self.oamIpAddress
        self.efxApplySwitch = efxApplySwitch
        self.efxPatchesPath = efxPatchesPath

    def clearAttr(self):
        '''
        set attributes to default
        '''
        self.oamIpAddress = ''
        self.actionList = []
        self.releaseFilePath = ''
        self.softwareServerIp = ''
        self.oamScriptsDir = ''
        self.sftpLogin = ''
        self._ipPilotA = ''
        self._ipPilotB = ''
        self._labId = ''

    def initSuRunner(self, suJob):
        """
        create SdmSuRunner instance and initialize it
        """
        targetIp = ''
        suJob = suJob.strip()

        if suJob == 'ACTIVATE':
            targetIp = self._ipPilotB
        elif 'BACKOUT' in suJob:  # BACKOUT or BACKOUT_SOAK
            if 'EFX_BACKOUT' in suJob:
                targetIp = self._ipPilotA
            else:
                curActState = SdmSuUtils.getLastActAndStatus(self.sshMngr, self.oamIpAddress).strip().split('-')

                if curActState[0] in ['ACTIVATE', 'VERIFY']:
                    targetIp = self._ipPilotA
                elif 'BACKOUT' in curActState[0]:
                    # if backout failed ever, to get the last two actions before backout like VERIFY_DONE, VERIFY_SUCCESS
                    lstLastTwoMarkedActions = SdmSuUtils.getLastTwoMarkedActions(self.sshMngr, \
                        self.oamIpAddress, 'root')

                    if not lstLastTwoMarkedActions or len(lstLastTwoMarkedActions) < 2:
                        LOGGER.error('failer to get SU Marker')
                        return SdmSuConst.RST_FAILURE

                    if lstLastTwoMarkedActions[1] in ['ACTIVATE', 'VERIFY']:
                        # backout failed before after activate/verify
                        targetIp = self._ipPilotA
                    else:
                        targetIp = self._ipPilotB
                else:
                    targetIp = self._ipPilotB
        else:
            # suJob may be 'INSTALL_AGENT', 'DOWNLOAD', 'VERIFY', 'APPLY1', 'RESUME1',
            # 'APPLY2', 'SOAK', 'COMMIT' or 'RESUME2'
            targetIp = self._ipPilotA

        LOGGER.debug('target lab ip address is %s', targetIp)

        self._suRunner = SdmSuRunner(targetIp, suJob, self.sshMngr)

        strValidAct = SdmSuUtils.getValidAction(self.sshMngr, targetIp)
        if suJob not in strValidAct:
            LOGGER.info("SU Action [%s] is not in valid list [%s], ignore it", suJob, strValidAct)
            return SdmSuConst.RST_ACTNOTALLOWED

        if suJob == 'INSTALL_AGENT':
            self._suRunner.releaseFilePath = self.oamScriptsDir
            self._suRunner.softwareServerIp = self.softwareServerIp
            self._suRunner.sftpLogin = self.sftpLogin

        if suJob == 'DOWNLOAD':
            self._suRunner.releaseFilePath = self.releaseFilePath
            self._suRunner.softwareServerIp = self.softwareServerIp
            self._suRunner.sftpLogin = self.sftpLogin

        if suJob == 'EFX_APPLY':
            self._suRunner.releaseFilePath = self.efxPatchesPath
            self._suRunner.softwareServerIp = self.softwareServerIp
            self._suRunner.sftpLogin = self.sftpLogin

        return SdmSuConst.RST_SUCCESS

    def setActionList(self, suActions):
        """
        set action list by the external caller
        """
        self.actionList = suActions.strip().split(',')

    def closeClientAfterEachSuAction(self):
        """
        close all client of the SU lab after each SU action
        """
        for host in (self.oamIpAddress, self._ipPilotA, self._ipPilotB):
            for user in (SdmSuConst.ROOT_USER, SdmSuConst.AINET_USER, SdmSuConst.SU_USER):
                self.sshMngr.closeClient(host, user)

    def execSingleJob(self, strJob, bFirstJob='False'):
        '''
        execute one job self.oamIpAddress
        '''
        ret = self.initSuRunner(strJob)
        if ret == SdmSuConst.RST_SUCCESS:
            if not bFirstJob:
                self._suRunner.lAgentXmlAbsent = False

            if self._suRunner.suActionStart() == SdmSuConst.RST_SUCCESS:
                LOGGER.debug("action %s DONE", strJob)
            else:
                LOGGER.debug("action %s FAILED", strJob)
                # self.sshMngr.closeAllClients()
                ret = SdmSuConst.RST_FAILURE
        elif ret == SdmSuConst.RST_FAILURE:
            LOGGER.error("failed to init SuRunner for %s", strJob)
        elif ret == SdmSuConst.RST_ACTNOTALLOWED:
            if strJob == "ACTIVATE":
                LOGGER.error("nothing to do for %s", strJob)
                ret = SdmSuConst.RST_SUCCESS
            else:
                LOGGER.error("action %s in not in valid list, exit", strJob)
                # self.sshMngr.closeAllClients()
                ret = SdmSuConst.RST_FAILURE

        self.closeClientAfterEachSuAction()

        return ret

    def execJobs(self):
        """
        start SU jobs. this function is used for sdm_apply_su
        """
        if not self.oamIpAddress.strip():
            LOGGER.error("lab ip is null, exit!")
            return SdmSuConst.RST_FAILURE
        # connection lab
        self._connectLab()
        # get fix ip of pilot blades
        self.getFixIp()

        suRst = SdmSuConst.RST_SUCCESS

        for i, eachAction in enumerate(self.actionList):
            eachAction = eachAction.strip()

            bFirstAction = False if i > 0 and eachAction != 'DOWNLOAD' else True
            ret = self.execSingleJob(eachAction, bFirstAction)
            if ret != SdmSuConst.RST_SUCCESS:
                suRst = SdmSuConst.RST_FAILURE
                break

            if eachAction == 'ACTIVATE':
                LOGGER.info('waiting Pilot-A is up far enough to INTERVL')
                if not self.waitPilotAUp():
                    suRst = SdmSuConst.RST_FAILURE
                    break

            self._suRunner = None
            # wait 60 seconds until the next job starts
            if (i + 1) < len(self.actionList):
                sleep(60)
                LOGGER.info(os.linesep)

        return suRst

    def waitPilotAUp(self):
        """
        wait pilot-A to turn into 'COMPL' or 'INTERVAL' status after reboot
        """
        lab = Lab()
        lab.oamIpAddress = self.oamIpAddress
        lab.id = self._labId
        multiTasksManager = MultiTasksManager()
        subshlManager = SubshlManager(self.sshMngr)
        mCASMachineManager = MCASMachineManager(self.sshMngr, subshlManager, multiTasksManager)

        ret = False
        loop = 0
        while loop < 100:
            try:
                mCASMachineManager.checkMachineStatus(lab, 1, 'INTERVL')
                LOGGER.debug('Pilot-A is up on lab [%s]', self._labId)
                ret = True
                break
            except AssertionError, ex:
                LOGGER.debug('%s', ex)
                sleep(6)
                loop += 1

        if loop == 100:
            LOGGER.error('Pilot-A has not init up in 10 minutes on lab[%s]', self._labId)

        return ret

    def _connectLab(self):
        '''
        connect to lab with login 'rmtadm' and 'root' for the future use
        '''
        # create client for ssh
        if not self.sshMngr:
            self.sshMngr = SshManager()
        self.sshMngr.getClient(self.oamIpAddress, SdmSuConst.SU_USER, SdmSuConst.SU_USER_PASSWD)
        self.sshMngr.getClient(self.oamIpAddress)

        LOGGER.debug("complete to connect lab[%s] as rmtadm and root", self.oamIpAddress)

    def getFixIp(self):
        '''
        get pilot fix ip addresses. if ssh client is not created, firstly create it.
        '''
        lstPilot = SdmSuUtils.getPilotFixedIpByVip(self.sshMngr, self.oamIpAddress)
        self._ipPilotA = lstPilot[0]
        self._ipPilotB = lstPilot[1]

        LOGGER.debug("pilotA is [%s], pilotB is [%s]", self._ipPilotA, self._ipPilotB)

    def applySU(self):
        """
        perform SU
        """
        if not self.oamIpAddress.strip():
            LOGGER.error("lab ip is null, exit!")
            return SdmSuConst.RST_FAILURE
        # get the fixed ip address of pilot-A and Pilot-B
        self.getFixIp()

        bFirstAction = True
        suRst = SdmSuConst.RST_SUCCESS
        while True:
            strValidActions = SdmSuUtils.getValidAction(self.sshMngr, self.oamIpAddress)
            if not strValidActions:
                LOGGER.error('valid actions is null on lab[%s]', self._labId)
                suRst = SdmSuConst.RST_FAILURE
                break

            LOGGER.info('valid actions are [%s] on lab[%s]', strValidActions, self._labId)

            listValidActions = [action.strip() for action in strValidActions.strip().split(',')]
            if 'VERIFY' in listValidActions:
                nextAction = 'VERIFY'
            elif 'BACKOUT' not in strValidActions:
                LOGGER.error('lab[%s] has not entered into SU phase yet', self._labId)
                suRst = SdmSuConst.RST_FAILURE
                break
            else:
                if 'BACKOUT_SOAK' in listValidActions:
                    listValidActions.remove('BACKOUT_SOAK')
                elif 'BACKOUT' in listValidActions:
                    listValidActions.remove('BACKOUT')

                if 'EFX_BACKOUT' in listValidActions:
                    listValidActions.remove('EFX_BACKOUT')

                if 'COMMIT' in listValidActions:
                    if len(listValidActions) == 1:
                        LOGGER.info('apply is completed on lab %s already', self._labId)
                        suRst = SdmSuConst.RST_SUCCESS
                        break
                    else:
                        listValidActions.remove('COMMIT')

                if len(listValidActions) > 1:
                    LOGGER.error('more than one apply action are availble on lab %s, please check', \
                    self._labId)
                    break

                nextAction = listValidActions[0]

            if nextAction == 'EFX_APPLY':
                if self.efxApplySwitch:
                    LOGGER.info('next SU action is %s on lab %s', listValidActions[0], self._labId)
                else:
                    LOGGER.info('efx_apply is displayed but there is no efx patch to be applied on lab %s', self._labId)
                    LOGGER.info('apply is completed on lab %s', self._labId)
                    break


            ret = self.execSingleJob(nextAction, bFirstAction)
            if ret != SdmSuConst.RST_SUCCESS:
                suRst = SdmSuConst.RST_FAILURE
                break

            if nextAction != 'INSTALL_AGENT':
                bFirstAction = False

            self._suRunner = None

            if nextAction == 'ACTIVATE':
                LOGGER.info('waiting Pilot-A is up far enough to INTERVL')
                if not self.waitPilotAUp():
                    suRst = SdmSuConst.RST_FAILURE
                    break

            # wait 60 seconds until the next job starts
            sleep(60)

        return suRst
