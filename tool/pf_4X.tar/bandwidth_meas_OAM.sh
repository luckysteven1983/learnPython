#!/bin/bash
function bwFilter { 
gawk '
$0 ~ /Incoming    Outgoing      Ierr/  { flag=1; }
($0 !~ /END OF REPORT/) && (flag==1) { print $0; }
$0 ~ /END OF REPORT/ {  flag=0; }
'
}

# including switches configuration file
currentpath=$(cd "$(dirname "$0")"; pwd)
echo $currentpath
. $currentpath/bandwidth_meas.conf

file=`ls -lrt meas*|tail -1|awk '{print $9}'`
cat $file | bwFilter > bandwidth.txt
HW=`grep 'name="HARDWARE"' /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `
if [[ "$HW" =~ "HP" ]];then
    ## HPblade case
    HW="HP"
elif [[ "$HW" =~ "BONO" ]];then
        ##  case
        HW="BONO"
else
        ## ROUZIC case
        HW="ROUZIC"  
fi

if [ "$HW" = "BONO" ] ; then
         No007=`cat bandwidth.txt | grep ${TSWITCHFEBONO["OAM"]} | grep 0-0-7-|wc -l`
         No008=`cat bandwidth.txt | grep ${TSWITCHFEBONO["OAM"]} | grep 0-0-8-|wc -l`
         if [ $No007 -gt 0 ] && [ $No008 -gt 0 ]; then   
            cat bandwidth.txt | grep ${TSWITCHFEBONO["OAM"]} | grep 0-0-7- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > OAM.1
            cat bandwidth.txt | grep ${TSWITCHFEBONO["OAM"]} | grep 0-0-8- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > OAM.2
            paste OAM.1 OAM.2 > OAM.tmp
            cat OAM.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM" , $2+$7,$3+$8,$4+$9,$5+$10}' > OAM.txt
            rm OAM.1 OAM.2 OAM.tmp
          elif [ $No007 -gt 0 ]; then
            cat bandwidth.txt | grep ${TSWITCHFEBONO["OAM"]} | grep 0-0-7- | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM", $3, $4, $5, $6 }' > OAM.txt
          else [ $No008 -gt 0 ]
            cat bandwidth.txt | grep ${TSWITCHFEBONO["OAM"]} | grep 0-0-8- | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM", $3, $4, $5, $6 }' > OAM.txt
          fi
     	 echo -e "Type\tAvg(In)\tMax(In)\tAvg(Out)\tMAX(Out)" > bandwidth.result
         awk 'BEGIN { maxIn=0; maxOut=0;} { if ($2 > maxIn) maxIn=$2; if  ($3 > maxOut) maxOut=$3; sumIn+=$2; sumOut+=$3; num++; next; } END { printf "%s\t%.2f\t%.2f\t%.2f\t%.2f\n", "OAM", sumIn/num/1024, maxIn/1024,sumOut/num/1024,maxOut/1024}' OAM.txt >> bandwidth.result
         rm OAM.txt
elif [ "$HW" = "ROUZIC" ]; then
         No007=`cat bandwidth.txt | grep ${TSWITCHFEROUZIC["OAM"]} | grep 0-0-7-|wc -l`
         No008=`cat bandwidth.txt | grep ${TSWITCHFEROUZIC["OAM"]} | grep 0-0-8-|wc -l`
         if [ $No007 -gt 0 ] && [ $No008 -gt 0 ]; then   
            cat bandwidth.txt | grep ${TSWITCHFEROUZIC["OAM"]} | grep 0-0-7- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > OAM.1
            cat bandwidth.txt | grep ${TSWITCHFEROUZIC["OAM"]} | grep 0-0-8- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > OAM.2
            paste OAM.1 OAM.2 > OAM.tmp
            cat OAM.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM" , $2+$7,$3+$8,$4+$9,$5+$10}' > OAM.txt
            rm OAM.1 OAM.2 OAM.tmp
          elif [ $No007 -gt 0 ]; then
            cat bandwidth.txt | grep ${TSWITCHFEROUZIC["OAM"]} | grep 0-0-7- | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM", $3, $4, $5, $6 }' > OAM.txt
          else [ $No008 -gt 0 ]
            cat bandwidth.txt | grep ${TSWITCHFEROUZIC["OAM"]} | grep 0-0-8- | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM", $3, $4, $5, $6 }' > OAM.txt
          fi
     	 echo -e "Type\tAvg(In)\tMax(In)\tAvg(Out)\tMAX(Out)" > bandwidth.result
         awk 'BEGIN { maxIn=0; maxOut=0;} { if ($2 > maxIn) maxIn=$2; if  ($3 > maxOut) maxOut=$3; sumIn+=$2; sumOut+=$3; num++; next; } END { printf "%s\t%.2f\t%.2f\t%.2f\t%.2f\n", "OAM", sumIn/num/1024, maxIn/1024,sumOut/num/1024,maxOut/1024}' OAM.txt >> bandwidth.result
         rm OAM.txt
elif [ "$HW" = "HP" ]; then
         No001=`cat bandwidth.txt | grep ${TSWITCHFEHP["OAM"]} | grep 0-0-1-|wc -l`
         No002=`cat bandwidth.txt | grep ${TSWITCHFEHP["OAM"]} | grep 0-0-2-|wc -l`
         if [ $No001 -gt 0 ] && [ $No002 -gt 0 ]; then   
            cat bandwidth.txt | grep ${TSWITCHFEHP["OAM"]} | grep 0-0-1- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > OAM.1
            cat bandwidth.txt | grep ${TSWITCHFEHP["OAM"]} | grep 0-0-2- | awk '{ print $2 "\t" $3 "\t" $4 "\t" $5 "\t" $6}' > OAM.2
            paste OAM.1 OAM.2 > OAM.tmp
            cat OAM.tmp | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM" , $2+$7,$3+$8,$4+$9,$5+$10}' > OAM.txt
            rm OAM.1 OAM.2 OAM.tmp
          elif [ $No001 -gt 0 ]; then
            cat bandwidth.txt | grep ${TSWITCHFEHP["OAM"]} | grep 0-0-1- | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM", $3, $4, $5, $6 }' > OAM.txt
          else [ $No002 -gt 0 ]
            cat bandwidth.txt | grep ${TSWITCHFEHP["OAM"]} | grep 0-0-2- | awk '{ printf "%s\t%d\t%d\t%d\t%d\n", "OAM", $3, $4, $5, $6 }' > OAM.txt
          fi
         echo -e "Type\tAvg(In)\tMax(In)\tAvg(Out)\tMAX(Out)" > bandwidth.result
         awk 'BEGIN { maxIn=0; maxOut=0;} { if ($2 > maxIn) maxIn=$2; if  ($3 > maxOut) maxOut=$3; sumIn+=$2; sumOut+=$3; num++; next; } END { printf "%s\t%.2f\t%.2f\t%.2f\t%.2f\n", "OAM", sumIn/num/1024, maxIn/1024,sumOut/num/1024,maxOut/1024}' OAM.txt >> bandwidth.result
         rm OAM.txt
fi
rm bandwidth.txt
