'''
Created on Aug 27, 2015

@author: Claude Le Du
'''


from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
import lib.exceptions_messages as msgs
from framework.asserts.common_asserts import CommonAssert


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fg7904_restart_lb_board_active(SDMTestCase):
    """ Restart Load Balancer active board on FE """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.success = True
        self.exceptMsg = ""


    def test_restart_lb_board_active(self):
        """ Restart Load Balancer active board on FE """

        LOGGER.debug("Check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("Start to choose one FE to test this case")
        fes = self.testEnv.testBed.getFrontends()
        feID, fe = fes.popitem()  # will return one over all FEs (no order in a dictionary)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.debug("Restart Load Balancer active board on FE " + str(feID) + " at: " + startTime)

        # creates the instance of HardwareManager
        hardwareManager = self.sdmManager.hardwareManagerFactory.createHardwareManager(fe)

        # creates the instance of LoadBalancerManager
        if fe.hardware in ['ROUZIC']:
            loadbalancerManager = self.sdmManager.seloadbalancerManager
        elif fe.hardware in ['HPG6', 'HPG8', 'BONO24', 'BONO48', 'VMMHI']:
            loadbalancerManager = self.sdmManager.asrloadbalancerManager
        else:
            exceptMsg = msgs.LB_UNSUPPORTED_HARDWARE + ": " + fe.hardware
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)

        LOGGER.debug("Get active load balancer board")
        activeLB = loadbalancerManager.getActiveLB(fe)

        LOGGER.info("Restart active load balancer board: " + activeLB + " on " + str(feID))
        hardwareManager.restartBoard(fe, activeLB.split('-')[2])

        # Need to wait for board being up again
        LOGGER.info("Waiting board to be online")
        myAssert = self.sdmManager.testEnvAsserts.assertStationOK
        CommonAssert.timedAssert(3600, 30, myAssert, fe, activeLB, logLevel="debug")

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", str(feID))

        LOGGER.debug("Check the alarms")
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(fe, myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.error("%s: alarm check fail", str(feID))

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("fg7904_restart_lb_board_active success!\n")
        else:
            LOGGER.error("fg7904_restart_lb_board_active failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)
