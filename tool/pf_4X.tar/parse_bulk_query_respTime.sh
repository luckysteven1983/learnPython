#!/bin/bash
#
#cat Result_OamPT_CreSub_0.xml|grep dateTime|grep activity|awk '{ print $2}'|awk -F"\"" '{ print $2}'
#2014-04-28T10:37:18.998002
#activity dateTime="2014-04-28T10:37:19.385645" type="validate"
if [ ! $# -eq 1 ];  then
        echo "Usage: parse_time.sh bulk_result_xml"
        return 1;
fi

#arg1=start, arg2=end, format: %s.%N  
function getTiming() {  
    start=`echo $1|sed -n -e 's/T/ /p'`  
    end=`echo $2|sed -n -e 's/T/ /p'`

    start_s=`date -d "$start" +%s.%N`
    end_s=`date -d "$end" +%s.%N`
  
    awk -v end=$end_s -v sta=$start_s 'BEGIN { printf "%5.6f", end-sta }'
}

function sumv {
  awk -v v1=$1 -v v2=$2 'BEGIN { printf "%.6f", v1+v2 }'
}

function avgv {
  awk -v v1=$1 -v v2=$2 'BEGIN { printf "%.3f\n", v1/v2*1000 }'
}

data=(`cat $1|grep "activitiy dateTime"|awk '{ print $2}'|awk -F"\"" '{ print $2}'`)
length=`expr ${#data[@]} - 1`
#getTiming ${data[0]} ${data[1]}
#echo "sumvTest=`sumv 0.23456 0.123455`"
st=${data[0]}
#  echo "START=$st"
end=${data[$length]}
#  echo "END=$end"
result=`getTiming $st $end`
#  echo "RESULT=$result"
avgv $result $length
