'''
Created on Nov 16, 2015

@author: Cassandra Lajeunie
'''
import ConfigParser
from lib.logging.logger import Logger
from lxml import etree
import lib.exceptions_messages as msgs

LOGGER = Logger.getLogger(__name__)
REMOTE_PATH_SDM_GENERAL_DATA = "/cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml"
REMOTE_PATH_CONFIG = "/etc/nectar/conf/conf.ini"

class ConfigManager(object):
    '''
    classdocs
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def getSdmGeralDataParameter(self, lab, module, function, option):
        """
        find in the SDMS-General-Data.xml file the value of the specified option
        @param lab: a lab object
        @param module: module name in the SDM_General_Data.xml
        @param function: function name in the module
        @param option: option name in the function
        @return string, the value of the option. It can be "" if not found, raise exception
        @verbatim
        getSdmGeralDataParameter(pathToTheFile, "General", "Common", "CONFIGURATION")
        @endverbatim
        """
        xmlOption = '/applicationConfiguration/module[@name="%s"]/function[@name="%s"]/option[@name="%s"]/@value'
        sdmGeneralDataPath = self.sshManager.scpGet(lab.oamIpAddress, REMOTE_PATH_SDM_GENERAL_DATA)
        tree = etree.parse(sdmGeneralDataPath)  # pylint: disable=no-member
        result = tree.xpath(xmlOption % (module, function, option))
        if len(result) == 0:
            errMsg = msgs.SDM_GENERAL_DATA_PARAMETER_NOT_FOUND + ' : MODULE = ' + module + ' FUNCTION = ' + function + ' OPTION = ' + option + ' on the lab ' + str(lab.oamIpAddress)
            raise Exception, errMsg
        else:
            return result[0]

    def getConfigParser(self, lab, filePath):
        """
        create a ConfigParser object base on given parameters
        @param lab: a lab object
        @param filePath: the remote path to the file
        @return ConfigParser object
        @verbatim
        self.getConfigParser(lab, REMOTE_PATH_CONFIG)
        @endverbatim
        """
        config = ConfigParser.ConfigParser()
        fileToRead = self.sshManager.scpGet(lab.oamIpAddress, filePath)
        config.read(fileToRead)
        return config

    def getIniFileParameter(self, lab, filePath, section, option):
        """
        find the value of the given section-option parameter in the given .ini file of the lab
        @param lab: a lab object
        @param filePath: the remote path to the file
        @param section: the section name in the config.ini file
        @param option: the option name in the section
        @return string the value of the option. If the option does not exist, raise an error
        @verbatim
        self.getConfIniParameter(lab, REMOTE_PATH_CONFIG, "NODE", "CONFIGURATION")
        @endverbatim
        """
        config = self.getConfigParser(lab, filePath)
        return config.get(section, option)