"""
@file mcas_machine_manager_weekly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-10
@brief unit test for mcas machine manager
"""

import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class mcas_machine_manager_weekly_test_once(SDMTestCase):
    """Unit test for MCASMachineManager class.
    """
    def setUp(self):
        LOGGER.info("TestMCASMachineManager Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()

    def xtest_01_remove_restore_non_vhost(self):
        """test method remove_restore_Machine
        """
        LOGGER.info('[Test case 01] test method remove_restore_Machine for non vhost')
        self.assertTrue(self.sdmManager.mcasMachineManager.removeMachine(self.fe, 4))
        self.assertTrue(self.sdmManager.mcasMachineManager.restoreMachine(self.fe, 4))

    def xtest_02_remove_restore_active_vhost(self):
        """test method remove_restore_Machine
        """
        LOGGER.info('[Test case 02] test method remove_restore_Machine for active vhost')

        lab = self.fe
        vhostList = self.sdmManager.mcasMachineManager.getVhostsList(lab)
        LOGGER.debug('vhost list: %s', str(vhostList))
        if vhostList:
            actVhost = self.sdmManager.mcasMachineManager.getActiveVhost(lab, vhostList[0])
            LOGGER.debug('target active vhost: %s', actVhost)
            # Can not remove active vhost
            self.assertFalse(self.sdmManager.mcasMachineManager.removeMachine(lab, actVhost))
            # Switchover if remove the active vhost
            self.assertTrue(self.sdmManager.mcasMachineManager.removeMachine(lab, actVhost, True))

    def xtest_03_powerOff_powerOn_Machine(self):
        """test method powerOff_powerOn_Machine
        """
        LOGGER.info('[Test case 03] test method powerOff_powerOn_Machine')

        lab = self.fe
        self.assertTrue(self.sdmManager.mcasMachineManager.removeMachine(lab, 4))
        self.assertTrue(self.sdmManager.mcasMachineManager.powerOffMachine(lab, 4))
        self.assertTrue(self.sdmManager.mcasMachineManager.powerOnMachine(lab, 4))

    def xtest_04_pilotSwitchover(self):
        """test method pilotSwitchover
        """
        LOGGER.info('[Test case 04] test method pilotSwitchover success')

        self.assertTrue(self.sdmManager.mcasMachineManager.pilotSwitchover(self.fe))

    def xtest_05_pilotSwitchover(self):
        """test method pilotSwitchover
        """
        LOGGER.info('[Test case 05] test method pilotSwitchover failure')

        self.assertFalse(self.sdmManager.mcasMachineManager.pilotSwitchover(self.fe, 180))

    def test_06_pilotSwitchover(self):
        """test method pilotSwitchover
        """
        LOGGER.info('[Test case 06] test method pilotSwitchover sucess without checkpoint')

        self.assertTrue(self.sdmManager.mcasMachineManager.pilotSwitchover(self.fe, None))

    def test_07_StationfwRestartNonPilot(self):
        '''
        This test is used to check if Restart of NP is OK
        '''
        LOGGER.info("Station 0-0-10 will be restarted")
        self.sdmManager.mcasMachineManager.stationfwRestartNonPilot(self.fe, '0-0-10')
        CommonAssert.timedAssert(3600, 30, self.sdmManager.testEnvAsserts.assertStationOK, \
                                        self.fe, '0-0-10', logLevel='debug')

        LOGGER.info("Station 0-0-10 is restarted")

    def tearDown(self):
        """Lab Recovery"""
        # recover lab in case of the lab is broken by test case.
        LOGGER.info('Recover lab if necessary')
        self.sdmManager.labRecover.machineRecover(self.fe)

if __name__ == "__main__":
    unittest.main()

