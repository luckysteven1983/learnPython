'''
Created on Aug 6, 2015

@author: Qinqin FAN
'''
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import SPA_TIMEOUT_SMALL


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)
OAMGSUITE_PROCESS_NAME = "OamGSUITE"

class ei9255_restart_oam_process_fe(SDMTestCase):
    '''test kill all oam processes on one FE of the test-bed '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self._mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.success = True
        self.exceptMsg = ""

    def test_restart_oam_process_fe(self):
        '''test kill oam process'''

        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("Start to choose one FE to test this case")
        fes = self.testEnv.testBed.getFrontends()
        feID, fe = fes.popitem()  # will return one over all FEs (no order in a dictionary)
        LOGGER.info("Kill all oam processes on FE: " + str(feID))

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.debug("Kill all oam processes on FE at: " + startTime)

        LOGGER.debug("Start kill all oam processes on FE :" + str(feID))
        activePilot = self.mcasMachineManager.getActivePilot(fe)
        try:
            self._mcasApplicationManager.killOamAndWaitRecover(fe, activePilot, OAMGSUITE_PROCESS_NAME,
                                                                SPA_TIMEOUT_SMALL)
        except BaseException, msg:
            self.exceptMsg += str(msg)
            self.success = False
            LOGGER.error("kill all oam processes on FE :" + str(feID) + " fail")
        else:
            LOGGER.debug("kill all oam processes on FE :" + str(feID) + " successful")

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", feID)

        LOGGER.debug("Check the alarms")
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared (done in assertEndState)
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(fe, myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.error("%s: alarm check fail", feID)

        LOGGER.debug("Check the end status of the test env")
        try:
            # Regarding alarms, assertEndState checks if all raised alarms are cleared
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: end state of test env check fail", feID)

        if self.success:
            LOGGER.debug("ei9255 restart oam processes successfull!\n")
        else:
            LOGGER.error("ei9255 restart oam processes failed!\n")
            LOGGER.error(self.exceptMsg)
            # spa recover done in jenkins worker
            raise Exception(self.exceptMsg)
