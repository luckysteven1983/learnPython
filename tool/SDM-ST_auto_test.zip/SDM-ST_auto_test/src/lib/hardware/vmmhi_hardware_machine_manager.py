'''
Created on Jul 22, 2015

@author: Tangi Lavanant

This library manages hardware.useful for specific function (VMMHI for v8650)

'''
import os
import re
from lib.hardware.hardware_machine_manager import HardwareMachineManager, HardwareMachineManagerError, StateHW
from lib.logging.logger import Logger
import lib.exceptions_messages as msgs

LOGGER = Logger.getLogger(__name__)

# ---- init CONSTANTS
FTVMMHI_CMD = '/sn/ft/FTvmmhi '
FTVMMHI_LIST = 'list '
FTVMMHI_RESET = 'reset '
FTVMMHI_POWEROFF = 'poweroff '
FTVMMHI_POWERON = 'poweron '
FTVHHMI_STATUS = 'list --csv '
BOARDRESET_MSG = ''

class VmmhiHardwareMachineManager(HardwareMachineManager):

    '''
    User to send command to host from guest on VMMHI Hardware
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        # self.sshManager = sshManager
        super(VmmhiHardwareMachineManager, self).__init__(sshManager)

##############################   PUBLIC  METHODS   #################################

    def vmmhiStatus(self, lab):
        '''
        run the command to get board status.
        @param lab : instance of framework.testenv.Lab
        '''
        cmd = FTVMMHI_CMD + FTVMMHI_LIST
        _returncode, out = self.sshmngr.run(lab.oamIpAddress , cmd)
        if _returncode :
            LOGGER.error("Command " + cmd + " fails on " + lab.oamIpAddress)
            return out
        else :
            return out

    def  getHardwareState(self, lab, physicalSlot):
        '''
        Get the state of a board .
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to restart
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        regex = '(0-0-' + slot + ',0-0-' + slot + ',)(.*)'
        out = self.getHardwareStateRAW(lab, physicalSlot)
        result = re.search(regex, out)
        if result.group(2) == 'ACTIVE':
            return StateHW.BOARD_POWERED_ON
        elif result.group(2) == 'INACTIVE' :
            return StateHW.BOARD_POWERED_OFF
        else :
            return StateHW.OTHER

    def  getHardwareStateRAW(self, lab, physicalSlot):
        '''
        Get the state of a board .
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to restart
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        cmd = FTVMMHI_CMD + FTVHHMI_STATUS
        regex = '(0-0-' + slot + ',0-0-' + slot + ',)(.*)'
        _returncode, out = self.sshmngr.run(lab.oamIpAddress , cmd)
        if _returncode :
            LOGGER.error(msgs.VMMHI_GET_STATUS_ERROR + " from " + lab.oamIpAddress)
            raise BaseException(msgs.VMMHI_GET_STATUS_ERROR + " from " + lab.oamIpAddress)
        else :
            result = re.search(regex, out)
            return result.group(0)

    def restartBoard(self, lab, physicalSlot):
        '''
        run the command to reset board. Then check if we got the board reset msg
        @param lab : instance of framework.testenv.Lab
        @param physicalSlot : the number of the slot to restart, must be an int
        for ex : restartBoard(lab,2)
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        self.localResetMsg = BOARDRESET_MSG
        cmd = FTVMMHI_CMD + FTVMMHI_RESET + '0-0-' + slot
        _returncode, _out = self.sshmngr.run(lab.oamIpAddress , cmd)
        if _returncode :
            LOGGER.error("Command " + cmd + " fails on " + lab.oamIpAddress)
            raise HardwareMachineManagerError('Restart board failed :' + os.linesep + _out)
        else :
            return _out

    def powerOffBoard(self, lab, physicalSlot):
        '''
        run the command to power off board.
        @param lab : instance of framework.testenv.Lab
        @param physicalSlot : the number of the slot to restart
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        self.localResetMsg = BOARDRESET_MSG
        cmd = FTVMMHI_CMD + FTVMMHI_POWEROFF + '0-0-' + slot
        _returncode, _out = self.sshmngr.run(lab.oamIpAddress , cmd)
        if _returncode :
            LOGGER.error("Command " + cmd + " fails on " + lab.oamIpAddress)
            raise HardwareMachineManagerError('Restart board failed :' + os.linesep + _out)
        else :
            return _out

    def powerOnBoard(self, lab, physicalSlot):
        '''
        run the command to power on board.
        @param lab : instance of framework.testenv.Lab
        @param physicalSlot : the number of the slot to restart
        '''
        slot = str(physicalSlot) if type(physicalSlot) == int else physicalSlot
        self.localResetMsg = BOARDRESET_MSG
        cmd = FTVMMHI_CMD + FTVMMHI_POWERON + '0-0-' + slot
        _returncode, _out = self.sshmngr.run(lab.oamIpAddress , cmd)
        if _returncode :
            LOGGER.error("Command " + cmd + " fails on " + lab.oamIpAddress)
            raise HardwareMachineManagerError('Restart board failed :' + os.linesep + _out)
        else :
            return _out
