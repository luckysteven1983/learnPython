'''
Created on July 23, 2015

@author: Qinqin FAN
'''

# Test items to be run
TEST_ITEMS = ["src/testcases/groups/example/casegroup1",
              "src/testcases/groups/example/casegroup2",
              "src/testcases/groups/example/casegrouptestfail",
              "src/testcases/groups/example/casegroup3"]
