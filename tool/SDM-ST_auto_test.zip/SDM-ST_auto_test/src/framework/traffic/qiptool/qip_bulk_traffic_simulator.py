"""
@file
Created on Mar 10, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines QiptoolBulkTrafficSimulator class
"""

from framework.traffic.bulk_traffic_simulator import BulkTrafficSimulator

class QiptoolBulkTrafficSimulator(BulkTrafficSimulator):
    """
    @details This class describes a Qiptool traffic as defined in configuration.xml.
    """

    def __init__(self):
        """
        QiptoolBulkTrafficSimulator class constructor
        """
        super(QiptoolBulkTrafficSimulator,self).__init__()
        self.trafficProfileId = ""
