'''
Created on Apr 20, 2015

@author: Xia Zhao
'''

import os
import time

from framework.asserts.common_asserts import CommonAssert
from lib.alarm.alarm import Alarm
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_PILOT


LOGGER = Logger.getLogger(__name__)

class TestEnvAssertsError(BaseException):
    """If error, raise it."""
    pass

class TestEnvAsserts(object):
    """Test env assert at the begining/end of each test case.
    """

    def __init__(self, sshManager, currentAlarmManager, coreCheckManager, mcasMachineManager,
                 mcasApplicationManager, databaseManager, databaseStateManager, trafficManager,
                 healthCheckManager, databaseTopologyManager):
        """ Constructor
        """
        self.sshManager = sshManager
        self.currentAlarmManager = currentAlarmManager
        self.coreCheckManager = coreCheckManager
        self.mcasMachineManager = mcasMachineManager
        self.mcasApplicationManager = mcasApplicationManager
        self.databaseStateManager = databaseStateManager
        self.trafficManager = trafficManager
        self.healthCheckManager = healthCheckManager
        self.databaseManager = databaseManager
        self.databaseTopologyManager  = databaseTopologyManager

    def assertInitialState(self, testEnv, logFile, checkQoS=True):
        """
        get the initial state of the testEnv
        assert applications status
        assert node status
        assert status of machines of all lab
        @param testEnv: the testEnv of the conf
        @param checkQoS: execute the QoS check (False for ex. in stability_traffics testcase)
        TODO assert applications (spa) status
        TODO assert node status
        TODO assert machine status
        """
        if checkQoS:
            # sets a starting point from which to calculate the QoS after the test
            # in case no traffic disturbance is done
            # If a traffic disturbance is awaited, need to call this method in the test case before
            # assertEndState.
            # checkQoSFinalPointAllTraffics is called in assertEndState
            try:
                self.trafficManager.setQoSStartingPointAllTraffics()
            except BaseException as arg:
                LOGGER.error(arg.message)
        # Here we only save the alarm to csv file

        Alarm.writeAlarmsOnAllLabs2CSV(testEnv.testBed, self.currentAlarmManager, logFile)
        self.databaseTopologyManager.checkTopology(testEnv.testBed)


    def assertEndState(self, testEnv, startTime, logFile, checkQoS=True):
        """
        check the status of the testEnv at the end of TC
        assert no core
        assert node status is ok
        assert stations status is ok
        @param testEnv: the testEnv of the conf
        @param startTime: case start time, used to assert no new alarm
        @param checkQoS: execute the QoS check (False for ex. in stability_traffics testcase)
        @param targetQos: it is Qos threshold. If larger than it when End, it will be failed.
        TODO assert applications (spa) status
        TODO assert node status
        TODO assert machine status
        """
        success = True
        exceptMsg = ""

        LOGGER.debug("---- Check Final status on all labs ----")
        Alarm.writeAlarmsOnAllLabs2CSV(testEnv.testBed, self.currentAlarmManager, logFile)
        # Check core on all labs in parallel
        if not self.coreCheckManager.runCheckCoreOnAllTestBed(testEnv.testBed, startTime):
            LOGGER.error("Check core files failure")
            exceptMsg += "Check core files failure\n"
            success = False

        if checkQoS:
            if len(self.trafficManager.startedTraffics) > 0:
                time.sleep(60)
                # checks the QoS from starting point (set earlier by trafficManager.setQoSStartingPointAllTraffics)
                try:
                    LOGGER.debug("Call checkQoSFinalPointAllTraffics...")
                    self.trafficManager.checkQoSFinalPointAllTraffics()
                except BaseException as arg:
                    # A bad QoS does not set the test case result to "failed".
                    # To do so, an exception would need to be raised here
                    LOGGER.error(arg.message)
                    exceptMsg += str(arg.message) + os.linesep

        # Check all labs state at the end of the test case
        if not self.healthCheckManager.runCheckAllOnTestBed(testEnv.testBed):
            LOGGER.error("Check lab status failure")
            exceptMsg += "Check lab status failure\n"
            success = False
        # Check Topology state at the end of the test case
        try:
            self.databaseTopologyManager.checkTopology(testEnv.testBed)
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
            success = False

        if success:
            LOGGER.debug("assertEndState success!\n")
        else:
            LOGGER.error("assertEndState fail!\n")
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)

    def assertStationOK(self, lab, station, status='COMPL', logLevel='error'):
        """
        check the station is OK or not
        define station OK:
        if FE: mCAS platform is OK, spa is OK
        if BE: mCAS platform is OK, ndb is OK
        @param lab: Lab type
        @param station: the rcs-hostname of the station
        @param status: expected machine status (default 'COMPL'), if None, do not check it
        @param logLevel: if error, the errorMsg will be output to console, otherwise, just put into log file
        """

        LOGGER.debug("%s: %s: assert mCAS_state is Online", lab.id, station)
        nodeInfo = self.databaseManager.loadNodes(lab, station)
        errorMsg = lab.id + ": " + station +": mCAS_status is not Online"
        CommonAssert.assertRegexpMatches(nodeInfo['mCAS_state'], 'Online', errorMsg, logLevel)

        if status:
            LOGGER.debug("%s: %s: assert station statue is %s", lab.id, station, status)
            try:
                self.mcasMachineManager.checkMachineStatus(lab, station, logLevel=logLevel)
            except BaseException as _e:
                raise TestEnvAssertsError, "%s: %s is not in %s status" %(lab.id, station, status) + _e.msg

        if 'DB' in lab.stations[station].productRole:
            LOGGER.debug("%s: %s: assert ndb state is started", lab.id, station)
            errorMsg = lab.id + ": " + station +": NDB state is not started"
            CommonAssert.assertEqual(self.databaseStateManager.getNDBState(lab, station), 'started', errorMsg, logLevel)
            LOGGER.debug("%s: %s: assert DDM_state is active", lab.id, station)
            errorMsg = lab.id + ": " + station +": DDM_state is not active"
            CommonAssert.assertEqual(nodeInfo['DDM_state'], 'active', errorMsg, logLevel)

        if 'RT' in lab.stations[station].productRole:
            LOGGER.debug("%s: %s: assert spa is IS", lab.id, station)
            spaState = self.mcasApplicationManager.getSPAStatus(lab, 'SDM')
            errorMsg = lab.id + ": " + station +": spa state is not IS"
            CommonAssert.assertEqual(spaState[station], 'IS', errorMsg, logLevel)
            LOGGER.debug("%s: %s: assert DDM_state is active", lab.id, station)
            errorMsg = lab.id + ": " + station +": DDM_state is not active"
            CommonAssert.assertEqual(nodeInfo['DDM_state'], 'active', errorMsg, logLevel)

        if lab.stations[station].middlewareRole == MIDDLEWARE_ROLE_PILOT:
            LOGGER.debug("%s: %s: assert DDM_state is active or standby", lab.id, station)
            errorMsg = lab.id + ": " + station +": DDM_state is not active and not standby "
            CommonAssert.assertIn(nodeInfo['DDM_state'], ['active', 'standby'], errorMsg, logLevel)
