#!/bin/bash

#######################################################
#       usage: $0  <output dir> 
#######################################################  

currentpath=$(cd "$(dirname "$0")"; pwd)

if [ ! -d $1 ]
then
  echo "directory no exist! create it"
  mkdir -p $1
fi


########################################################
# Collect Version Information
#######################################################
#echo "Collect BE version information ......."
#$currentpath/check_be_version.sh
#mv be_version_info.result $1
#echo "Cellect BE version information done."


########################################################
# Collect BE lab status Information
#######################################################
#echo "Collect BE lab status  information ......."
#$currentpath/check_lab_status.exp BE
#mv lab_status.result $1
#echo "Cellect BE lab status information done."

########################################################
# Collect Backdoor Parameters Information
#######################################################
echo "Collect BE backdoor parameters ......."
$currentpath/check_backdoor.exp 30111
mv 30111.result $1
echo "Collect BE backdoor parameters done."


########################################################
# Collect BE Parameter Files 
#######################################################
echo "Collect BE configure file ......."
$currentpath/check_config.sh BE_CONFIG $1
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'`
do
  scp STATION_$sta:/usr/dhafw/data/st_site.cfg $1/st_site.cfg.$sta
  scp STATION_$sta:/usr/dhafw/data/GdmpServerpf_generic.cfg $1/GdmpServerpf_generic.cfg.$sta
  scp STATION_$sta:/usr/dhafw/data/GdmpServerst_site.cfg $1/GdmpServerst_site.cfg.$sta
  scp STATION_$sta:/usr/dhafw/data/gdmpServerOverloadpf_site.cfg $1/gdmpServerOverloadpf_site.cfg.$sta
  scp STATION_$sta:/usr/dhafw/data/gdmpServerOverloadpf_generic.cfg $1/gdmpServerOverloadpf_generic.cfg.$sta
done
echo "Collect BE configure file done."
