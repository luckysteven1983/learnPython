'''
Created on Aug 19, 2015
@file
@ingroup loadbalancer
@author Xia Zhao
'''


class LoadBalancerManager(object):
    '''
    module for load balancer
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager
