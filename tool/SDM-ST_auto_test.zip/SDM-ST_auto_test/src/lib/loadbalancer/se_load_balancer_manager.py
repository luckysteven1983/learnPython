'''
@file
@ingroup loadbalancer
@author Xia Zhao
@brief some functions about SE load balancer manager
This LB exist on malban
'''
import re
import os
import lib.exceptions_messages as msgs
from lib.loadbalancer.load_balancer_manager import LoadBalancerManager
from framework.asserts.common_asserts import CommonAssert
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class SELoadBalancerManagerError(BaseException):
    """If error, raise it."""
    pass

class SELoadBalancerManager(LoadBalancerManager):
    '''
    module for SE load balancer which exist on malban
    '''

    def __init__(self, sshManager, malbanProcessManager):
        '''
        Constructor
        '''
        super(SELoadBalancerManager, self).__init__(sshManager)
        self.sshManager = sshManager
        self.malbanProcessManager = malbanProcessManager

    def getCurlOutput(self, lab, command):
        '''
        this function is to get the output of the curl command

        @author: Xia Zhao
        @param lab: the Lab object
        @param command: string, the curl command

        @verbatim
        output = getCurlOutput(lab, command)
        return: string
        @endverbatim
        '''
        exceptionMsg = lab.id + ": " + command + ": " + msgs.GET_CURL_OUTPUT_FAIL
        [cmdStatus, stateOutput] = self.sshManager.run(lab.oamIpAddress, command)
        if not cmdStatus:
            LOGGER.debug("%s: command %s success", lab.id, command)
            LOGGER.debug("%s: %s output is \n%s", lab.id, command, stateOutput)
        else:
            LOGGER.error(exceptionMsg)
            raise SELoadBalancerManagerError, exceptionMsg
        return stateOutput

    def getActiveLB(self, lab):
        '''
        this function is to get the malban with the active LB
        use command curl 0-0-7-SWITCH:5000/se/lb/list to get the LB information
        Only support ROUZIC lab.

        @author: Xia Zhao
        @param lab: the Lab object

        @verbatim
        activeMalban = getActiveLB(lab)
        return: station rcs-hostname, 0-0-7 or 0-0-8
        @endverbatim
        '''

        if lab.hardware != "ROUZIC":
            exceptionMsg = lab.id + ": hardware is " + lab.hardware + ": not supported"
            LOGGER.error(exceptionMsg)
            raise SELoadBalancerManagerError, exceptionMsg
        LOGGER.debug("%s: try to get the active malban", lab.id)

        command = "curl 0-0-7-SWITCH:5000/se/lb/list"
        malbanInfo = self.getCurlOutput(lab, command)
        activeMalbanInfo = [line for line in malbanInfo.split(os.linesep)
                            if re.search("node name", line)]
        activeMalban = re.search(r"(\d{1,2}-\d{1,2}-\d{1,2})", activeMalbanInfo[0]).group(1)
        if not activeMalban:
            exceptionMsg = lab.id + ": " + msgs.GET_ACTIVE_LOADBALANCER_FAIL
            LOGGER.error(exceptionMsg)
            raise SELoadBalancerManagerError, exceptionMsg
        LOGGER.debug("%s: active malban is %s", lab.id, activeMalban)
        return activeMalban


    def getStandbyLB(self, lab):
        """
        Returns the standby load balancer blade.
        se_load_balancer_manager lib supports Rouzic labs
        asr_load_balancer lib is for BONO, HP and VMMHI (v8650) labs.
        @param lab: a Lab object
        @return standbyLB: (string) blade hosting the standby load balancer
        @verbatim
        standbyLB = getStandbyLB(lab)
        return: station rcs-hostname, 0-0-7 or 0-0-8
        @endverbatim
        """

        lbBlades = lab.getStationListbyProductRole('iLB').keys()
        activeLB = self.getActiveLB(lab)
        lbBlades.remove(activeLB)
        standbyLB = lbBlades[0]
        return standbyLB

    def restartLBProcess(self, lab, blade=None, processName=None):
        '''
        this function is to kill diameter process on given blade

        @author: Xia Zhao
        @param lab: the Lab object
        @param blade: the rcs-hostname of the blade, 0-0-7 or 0-0-8
                default is None, if none, will restart LB process on active LB blade
        @param processName: the name of the process will restart
                default is None, if none, will restart diameter related process

        @verbatim
        restartLBProcess(lab, '0-0-8')
        @endverbatim
        '''
        if not blade:
            blade = self.getActiveLB(lab)
        else:
            lbBlade = lab.getStationListbyProductRole('iLB').keys()
            CommonAssert.assertIn(blade, lbBlade, lab.id + ': ' + blade + ': Not an iLB blade')
        if not processName:
            processName = 'diameter'

        exceptionMsg = lab.id + ": " + blade + ": " + msgs.RESTART_LB_PROCESS_FAIL
        if lab.hardware != "ROUZIC":
            exceptionMsg = lab.id + ": hardware is " + lab.hardware + ": do not support"
            LOGGER.error(exceptionMsg)
            raise SELoadBalancerManagerError, exceptionMsg

        LOGGER.debug("%s: get LB process pid on %s", lab.id, blade)

        pidListPre = self.malbanProcessManager.getPidbyPSOnMalban(lab, blade, processName)
        LOGGER.debug("%s: %s: get LB process pid list is %s", lab.id, blade, str(pidListPre))

        LOGGER.debug("%s: kill LB process on %s", lab.id, blade)
        self.malbanProcessManager.killProcessbyPidOnMalban(lab, blade, pidListPre)

        LOGGER.debug("%s: wait LB process restart on %s", lab.id, blade)
        CommonAssert.timedAssert(60, 3,
                                 self.assertLBProcessStart,
                                 lab, blade, processName, pidListPre, 'debug')

        LOGGER.debug("%s: restart LB process on %s success", lab.id, blade)

    def assertLBProcessStart(self, lab, blade=None,
                             processName=None, oldPidList=None, logLevel='error'):
        '''
        this function is to assert diameter process start up on given blade

        @author: Xia Zhao
        @param lab: the Lab object
        @param blade: the rcs-hostname of the blade, 0-0-7 or 0-0-8
                default is None, if none, will restart LB process on active LB blade
        @param processName: the name of the process will restart
                default is None, if none, will restart diameter related process
        @param oldPidList: the old pid of the process, which is usefull for LB process restart
                default is None, if not None, will compare the old pids and the new pids.
                If same, will raise exception
         @param logLevel if "error" display as error logger message, else debug level

        @verbatim
        assertLBProcessStart(lab, '0-0-8', 'diameter', ['123','234'])
        @endverbatim
        '''
        exceptionMsg = lab.id + ": " + blade + ": " + msgs.ASSERT_LB_PROCESS_START_FAIL
        if not blade:
            blade = self.getActiveLB(lab)
        if not processName:
            processName = 'diameter'
        pidList = self.malbanProcessManager.getPidbyPSOnMalban(lab, blade, processName, logLevel)
        if oldPidList:
            CommonAssert.assertEqual(len(oldPidList), len(pidList), exceptionMsg, logLevel)
            for pid in pidList:
                CommonAssert.assertNotIn(pid, oldPidList, exceptionMsg, logLevel)

