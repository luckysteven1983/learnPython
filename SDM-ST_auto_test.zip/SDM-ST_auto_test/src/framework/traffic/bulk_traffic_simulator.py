'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.traffic.provisioning_traffic_simulator import ProvisioningTrafficSimulator

class BulkTrafficSimulator(ProvisioningTrafficSimulator):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        super(BulkTrafficSimulator,self).__init__()
