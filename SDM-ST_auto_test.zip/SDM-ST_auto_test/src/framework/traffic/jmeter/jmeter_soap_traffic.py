"""
@file
Created on July 10, 2015
@ingroup SDMSQA Automation
@author Junming Zhao
@brief Defines JmeterSOAPTraffic Class
"""

import re
import time
import os
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger

logger = Logger.getLogger(__name__)

BUILD_TAG = os.getenv("BUILD_TAG", "build tag default")
BUILD_ID = os.getenv("BUILD_ID", "12345")
JOB_NAME = os.getenv("JOB_NAME", "job_name")
NODE_NAME = os.getenv("NODE_NAME", "jenkins_slave")
DIR_LOG_LOCAL = "log"
DIR_JOB_WORKSPACE="/home/jenkins/workspace"

class JmeterSOAPTraffic(object):
    """
    @details This class offers the commands to control a jmeter simulator.
    """

    def __init__(self, jmeterTrafficProfile, jmeterSOAPTrafficSimulator, testBed):
        """ JmeterSOAPTrafficSimulator class constructor """
        super(JmeterSOAPTraffic, self).__init__()
        self.jmeterTrafficProfile = jmeterTrafficProfile
        self.scenario = jmeterTrafficProfile.workspace
        self.testBed = testBed
        self.jmeterDir = jmeterTrafficProfile.jmeterDir
        self.myFEPrefix = ""
        self.be = []
        self.trafficType = ""
        self.sshManager = jmeterSOAPTrafficSimulator.sshManager
        self.sshCnx = ""
        self.qos = ""
        self.previousQos = ""
        self.errors = 0
        self.previousErrors = 0
        self.nbRequestsStart = 0
        self.nbRequestsEnd = 0
        self.nbErrorsStart = 0
        self.nbErrorsEnd = 0
        self.failed = 0
        self.previousFailed = 0
        self.requests = 0
        self.account = jmeterSOAPTrafficSimulator.account
        self.toolIpAddress = jmeterSOAPTrafficSimulator.toolIpAddress
        self.trafficInfo = ""
        self.jmeterPort = ""

    def _load(self, jmeterTrafficProfile):
        """ Private method that loads data into the class attributes
        @exception Exception if scenario file do not exists on PC lab """

        self.trafficType = "SOAP"
        for lab in self.testBed.getFrontends().values():
            if lab.productRole.FE_Key == jmeterTrafficProfile.FE_Key:
                self.myFEPrefix = lab.id
                break
            if lab.productRole.FE_Key == "":
                self.myFEPrefix = lab.id
                break
        self.trafficInfo = "Jmeter " + self.trafficType + " traffic on " + self.toolIpAddress + \
                            " - FE: " + str(self.myFEPrefix) + " scenario: " + str(self.scenario) 
        # Checking if scenario exists
        cmd = "bash -c 'ls " + self.jmeterDir + "/bin/scripts/" + self.scenario + "'"
        rc, _ = self.sshManager.run(self.toolIpAddress, cmd, self.account.login)
        if rc != 0:
            logger.error(msgs.JMETER_SCENARIO_NOT_FOUND + " for " + self.trafficInfo)
            raise JmeterTrafficException(msgs.JMETER_SCENARIO_NOT_FOUND)

    def _getPid(self):
        """ Check if a given jmeter traffic is running
        @return pid the pid of jmeter process """

        cmd = "bash -c 'ps -ef | grep -i jmeter | grep -v grep | grep " + self.scenario + " | tr -s \" \" | cut -d \" \" -f2'"
        _ , stdout = self.sshManager.run(self.toolIpAddress, cmd, self.account.login)
        pid = stdout
        return pid
    
    def _getJmeterPort(self, logfile):
        """ Get the Jmeter port
        @param jmeter's summary file
        @return Port number of jmeter process """

        cmd = "bash -c 'grep " + "\"Waiting for possible shutdown message on port\" " + self.jmeterDir + "/bin/" + logfile + "'"
        _ , stdout = self.sshManager.run(self.toolIpAddress, cmd, self.account.login)
        match = re.search("[0-9]+", stdout)
        port = match.group(0)
        return port

    def start(self, killIfExists=False):
        """ Start a jmeter traffic
        @param killIfExists the traffics must be killed and restarted if already exist
        @exception Exception if this scenario is already running
        @exception Exception if traffic can not be started """

        self._load(self.jmeterTrafficProfile)
        pid = self._getPid()
        if pid and not killIfExists:
            logger.debug(msgs.JMETER_SCENARIO_ALREADY_IN_USE + self.trafficInfo)
        else:
            if pid and killIfExists:
                logger.info(msgs.JMETER_SCENARIO_ALREADY_IN_USE + ": " + self.trafficInfo + \
                            " => this traffic will be restarted")
                lim=" "
                pid_list=lim.join(pid.splitlines())
                cmd = "bash -c 'kill -9 " + pid_list + "'"
                logger.debug("execute command on %s: %s", self.toolIpAddress, cmd)
                self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)

            logger.info("Try to start " + self.trafficInfo)

            # Launch the traffic with jmeter
            cmd = "bash -c 'cd " + self.jmeterDir + "/bin; ./jmeter -n -t ./scripts/" + self.scenario + " >" + self.scenario + ".sum &'"
            logger.debug("execute command on %s: %s", self.toolIpAddress, cmd)
            self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
            logger.debug("Waiting 20s before checking " + self.trafficType + " traffic...")
            time.sleep(20)
            self.jmeterPort = self._getJmeterPort(self.scenario + ".sum")
            pid = self._getPid()
            lim=" "
            pid_list=lim.join(pid.splitlines())
            if not pid:
                logger.error(msgs.JMETER_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
                raise JmeterTrafficException(msgs.JMETER_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
            logger.info(self.trafficType + " traffic launched (pid=" + pid_list + ")...")

    def _searchNbRequestsAndErrorsInLog(self):
        """ Get the end of jmeter log and search numbers of requests and errors
        @exception Exception if this scenario is not running """

        pid = self._getPid()
        if not pid:
            logger.error(msgs.JMETER_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
            raise JmeterTrafficException(msgs.JMETER_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
        cmd = "bash -c 'ls " + self.jmeterDir + "/bin/" + self.scenario + ".sum" + "'"
        _, stdout = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        logger.debug("remote traffic log file on " + self.toolIpAddress + ": " + stdout)
        pathToLogFile = self.sshManager.scpGet(self.toolIpAddress, stdout, user=self.account.login)
        logfile = pathToLogFile + "_" + BUILD_ID + "_" + BUILD_TAG.replace(" ", "_")
        os.rename(pathToLogFile, logfile)
        with open(logfile, "r") as myFile:
            for line in reversed(myFile.readlines()):
                # grep last success number in log file
                match = re.search("summary =", line)
                if match:
                    match = re.search("([0-9]+) in", line)
                    total = int(match.group(1))
                    match = re.search(r"Err: \s*([0-9]+)", line)
                    if match:
                        errors = int(match.group(1))
                        match = re.search(r"in \s*([0-9]+)\.[0-9]+s", line)
                        if match:
                            duration = int(match.group(1))
                            break

        failed = 0
        success = total - errors

        logger.debug("Success: " + str(success) + " Error: " + str(errors) + " Failed: " + str(failed) + " on the duration: " + str(duration))
        return total, errors, failed


    def getRequestsAndErrors(self):
        """ Checks the number of requests and errors, for instance to set a starting point from which to calculate the QoS """
        # nbRequestsStart and nbErrorsStart store values from last but one checkQoSInit
        self.nbRequestsStart = self.nbRequestsEnd
        # nbErrorsStart/1 = total ko + total timeout
        self.nbErrorsStart = self.nbErrorsEnd
        # nbRequestsEnd and nbErrorsEnd store values from last checkQoSInit
        self.nbRequestsEnd, self.nbErrorsEnd, _ = self._searchNbRequestsAndErrorsInLog()


    def checkGlobalQoS(self):
        """ Check the traffic QoS from the beginning"""

        self.previousErrors = self.errors
        self.previousQos = self.qos
        self.previousFailed = self.failed
        self.requests, self.errors, self.failed = self._searchNbRequestsAndErrorsInLog()
        # requests can be 0 because we only take into account failed3004 and 5012 but not others ("failed" counter)
        if self.requests == 0:
            self.qos = 1
        else:
            self.qos = float(self.errors) / float(self.requests)
        if self.qos not in [0, 1]:
            self.qos = "{:1.8f}".format(self.qos)
        calls = self.requests + self.failed
        logger.debug(self.trafficInfo)
        logger.debug("Requests: " + str(self.requests) + "  Calls (requests+failed): " + str(calls))
        logger.debug("Previous errors: " + str(self.previousErrors) + \
                     " Current errors: " + str(self.errors))
        logger.debug("Previous failed (other errors): " + str(self.previousFailed) + \
                     " Current failed: " + str(self.failed))
        logger.debug("Previous QoS:" + str(self.previousQos) + " Current QoS: " + str(self.qos))
        if float(self.qos) > 0.000001:
            msg = msgs.TRAFFIC_BAD_QOS + " (" + str(self.qos) + ") for " + self.trafficInfo
            logger.error(msg)
            raise JmeterTrafficException(msg)


    def getErrorStatus(self):
        """ Returns true if number of errors or failed increased between two checkGlobalQoS """

        if self.errors > self.previousErrors or (self.failed > self.previousFailed):
            return True
        else:
            return False


    def getCountersString(self):
        """ Returns a string made of traffic counters """

        calls = self.requests + self.failed
        successes = self.requests - self.errors
        text = "QoS=" + str(self.qos) + "  Calls=" + str(calls) + "  Successes=" + str(successes) + \
                "  Errors=" + str(self.errors) + "  Failed=" + str(self.failed)
        return text



    def stop(self):
        """ Stop a jmeter traffic
        @exception Exception if this scenario is not running """

        logger.info("Try to stop " + self.trafficInfo)
        pid = self._getPid()
        if not pid:
            logger.error(msgs.JMETER_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
            raise JmeterTrafficException(msgs.JMETER_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
        cmd = "bash -c 'cd " + self.jmeterDir + "/bin; ./shutdown.sh " + self.jmeterPort + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        logger.info(self.trafficType + " traffic stopped...")
        tarLog = "jmeter" + "_" + self.scenario + ".tar.gz"
        cmd = "bash -c 'cd " + self.jmeterDir + "/bin; tar zcvf " + tarLog + " " + self.scenario + ".sum" + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        pathToTarlog = self.sshManager.scpGet(self.toolIpAddress, self.jmeterDir + "/bin/" + tarLog, user=self.account.login)
        ltarLog = DIR_LOG_LOCAL + "/" + tarLog
        os.rename(pathToTarlog, ltarLog)
        logger.debug("local traffic log file on " + NODE_NAME + ": " + DIR_JOB_WORKSPACE + "/" + \
                     JOB_NAME.replace(" ", "_") + "/" + ltarLog)
        logger.debug("Use 'tar xvf <filename>' to uncompress archive")
        cmd = "bash -c 'cd " + self.jmeterDir + "/bin; rm -rf *.sum'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)



class JmeterTrafficException(BaseException):
    """If error, raise it."""
    pass
