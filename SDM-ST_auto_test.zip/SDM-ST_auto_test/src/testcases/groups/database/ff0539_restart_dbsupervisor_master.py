"""
Created on October 29, 2015

@author: Cassandra Lajeunie

# no test sheet found
"""
import os
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils
from lib.database.ddm.database_manager import PROCESS_DBSUPERVISOR, SCRIPT_DBSUPERVISOR

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0539_restart_dbsupervisor_master(SDMTestCase):
    "Test restart dbsupervisor on master Be"

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.success = True
        self.exceptMsg = ""
        self.expectedAlarmsSpecific = []
        self.acceptedAlarmsSpecific = []
        self.expectedAlarms4BE = []
        self.acceptedAlarms4BE = []
        self.platformAsserts = self.sdmManager.platformAsserts
        self.databaseManager = self.sdmManager.databaseManager
        self.linuxProcessManager = self.sdmManager.linuxProcessManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getLabsInNRG("1")

    def test_restart_dbsupervisor_master(self):
        """
        ' Test restart dbsupervisor on master BE '
        What it does : restart the db supervisor on the master BE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case ...")

        # Get master Be of 1st NRG
        masterBE = self.databaseStateManager.getMasterBE(self.allBEs)[0]
        LOGGER.debug("Master BE is: %s", masterBE.id)
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)

        LOGGER.debug("%s: check DbSupervisor process is alive", masterBE.id)
        self.linuxProcessManager.isAlive(masterBE, processName=PROCESS_DBSUPERVISOR)

        LOGGER.debug("%s: restart db supervisor", masterBE.id)
        self.databaseManager.runScriptOperation(masterBE, SCRIPT_DBSUPERVISOR, ddmOperation='restart')

        LOGGER.debug("%s: check DbSupervisor process restarted", masterBE.id)
        self.platformAsserts.assertProcessAlive(masterBE, PROCESS_DBSUPERVISOR)

        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case postcheck"""
        LOGGER.debug("test case post check")
        LOGGER.debug("check the alarm")
        exceptMsg = str()
        myAlarmsConfig4BE = AlarmsConfig(self.expectedAlarms4BE, self.acceptedAlarms4BE, startTime)
        for labIndex in self.allBEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
