#!/bin/bash

tool_dir=$(cd "$(dirname "$0")"; pwd)

file=`ls -lrt meas*|tail -1|awk '{print $9}'`
for alarm in `cat ${tool_dir}/conf/BE_ALARM|awk '{print $1}'`
do
    col=`grep ${alarm} ${tool_dir}/conf/BE_ALARM|awk '{print $2}'`
    echo ${alarm} > ${alarm}.txt
    grep -A 2 -w ${alarm} $file|grep -v "\-"|awk '{print $"'"${col}"'"}'|grep -v "^[A-Za-z]" >> ${alarm}.txt
    awk 'BEGIN{ max=0; } NR == 1 {next} {if ($1 > max) max=$1; next} END { if (max > 0) { printf "%s\t%d\n", "'"$alarm"'", max;} } ' ${alarm}.txt >> alarm.result 
    #rm ${alarm}.txt
done

