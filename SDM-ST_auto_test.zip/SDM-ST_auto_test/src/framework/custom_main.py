"""
@author: yohannm

The goal of this module is to show how to write a simple main function
to perform any action on labs using libraries provided by framework
and testenv objects but without all initial deep checks.
"""

import argparse
import os

from framework.configuration import Configuration
from framework.env_checker import EnvChecker
from framework.version_manager import VersionManager
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from lib.common.multi_tasks_manager import MultiTasksManager

LOGGER = Logger.getLogger(__name__)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="simple demo main")
    parser.add_argument("--testenv",
                        help="name of test environment from configuration.xml (required)",
                        required=True)
    args = parser.parse_args()
    testEnvParam = args.testenv
    LOGGER.info("test environment: " + testEnvParam)

    sshGateway = os.getenv("SSH_GATEWAY")
    sshUser = os.getenv("SSH_GATEWAY_USER")
    sshPassword = os.getenv("SSH_GATEWAY_PASSWORD")
    sshManager = SshManager(sshGateway, sshUser, sshPassword)

    configuration = Configuration()
    configuration.load(sshManager)
    try:
        testEnv = configuration.testEnvs[testEnvParam]
    except KeyError:
        raise Exception("testenv " + testEnvParam + " not found in config file")

    for lab in testEnv.testBed.labs.values():
        LOGGER.debug("testEnv " + testEnv.id + " lab: " + lab.id)
        sshManager.getClient(lab.oamIpAddress)

    versionManager = VersionManager(sshManager)
    multiTasksManager = MultiTasksManager()

    envChecker = EnvChecker(sshManager, versionManager, multiTasksManager)
    # actually, here we don't check anything, we just load information
    # from target lab, e.g. using sdm_general_data.xml.
    envChecker.checkInitialState(testEnv)

    # custom code starts here
    feId, fe = testEnv.testBed.getFrontends().popitem()
    sshClient = sshManager.getClient(fe.oamIpAddress)
    stdin, stdout, stderr = sshClient.exec_command("whoami")
    LOGGER.info("fe " + fe.id + " " + stdout.read())
    # custom code ends here

    sshManager.closeAllClients()
