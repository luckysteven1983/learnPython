package=pt_4.1.0.`date "+%Y.%m.%d"`_mcas.tar.gz 
rm -rf *.gz
rm -rf $package


for x in `ls *`; do
	dos2unix $x > /dev/null 2>&1
done
chmod a+x *.sh pt lg

rm -rf common.ini

echo "do unit test"
if sh runtest; then
   tar czf $package *
   echo "$package created"
	ls -ltr $package
	cp $package /home/canhuali/bin/package
	ls -ltr /home/canhuali/bin/package/$package
else
	echo ""
   echo "unittest failed"
fi

