'''
@file
@ingroup loadbalancer
@author Xia Zhao
Amended on Sept 1, 2015 by Tangi Lavanant (VMMHI support)
@brief some functions about ASR load balancer manager
This LB exist on BONO,HP and VMMHI (v8650) labs
'''

import lib.exceptions_messages as msgs
from lib.loadbalancer.load_balancer_manager import LoadBalancerManager
from framework.asserts.common_asserts import CommonAssert
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class ASRLoadBalancerManagerError(BaseException):
    """If error, raise it."""
    pass

class ASRLoadBalancerManager(LoadBalancerManager):
    '''
    module for asr load balancer which exist on BONO and HP labs and VMMHI (v8650)
    '''

    def __init__(self, sshManager, linuxProcessManager, mcasMachineManager):
        '''
        Constructor
        '''
        super(ASRLoadBalancerManager, self).__init__(sshManager)
        self.sshManager = sshManager
        self.linuxProcessManager = linuxProcessManager
        self.mcasMachineManager = mcasMachineManager

    def getActiveLB(self, lab):
        '''
        this function is to get blade with the active LB
        Only support BONO,HP and VMMHI (v8650) lab.

        @author: Xia Zhao
        @param lab: the Lab object

        @verbatim
        activeLBboard = getActiveLB(lab)
        return: station rcs-hostname, 0-0-3 or 0-0-1 (0-0-10 or 0-0-2 for v8650)
        @endverbatim
        '''

        if lab.hardware not in ['HPG6', 'HPG8', 'BONO24', 'BONO48', 'VMMHI']:
            exceptionMsg = lab.id + ": hardware is " + lab.hardware + ": not supported by this lib"
            LOGGER.error(exceptionMsg)
            raise ASRLoadBalancerManagerError, exceptionMsg
        LOGGER.debug("%s: try to get the active board running Load Balancer", lab.id)

        lbBlades = lab.getStationListbyProductRole('iLB').keys()
        activeBlade = self.mcasMachineManager.getActiveVhost(lab, lbBlades[0])
        if not activeBlade:
            exceptionMsg = lab.id + ": " + msgs.GET_ACTIVE_LOADBALANCER_FAIL
            LOGGER.error(exceptionMsg)
            raise ASRLoadBalancerManagerError, exceptionMsg
        LOGGER.debug("%s: active board running Load Balancer is %s", lab.id, activeBlade)
        return activeBlade


    def getStandbyLB(self, lab):
        """
        Returns the standby load balancer blade.
        asr_load_balancer lib supports BONO, HP and VMMHI (v8650) labs.
        se_load_balancer_manager lib is for Rouzic labs.
        @param lab: a Lab object
        @return standbyBlade: (string) blade hosting the standby load balancer
        @verbatim
        standbyLB = getStandbyLB(lab)
        return: station rcs-hostname, 0-0-3 or 0-0-11 (0-0-2 or 0-0-10 for v8650)
        @endverbatim
        """

        lbBlades = lab.getStationListbyProductRole('iLB').keys()
        activeLB = self.getActiveLB(lab)
        lbBlades.remove(activeLB)
        standbyLB = lbBlades[0]
        return standbyLB


    def restartLBProcess(self, lab, blade=None, processName=None):
        '''
        this function is to kill diameter process on given blade

        @author: Xia Zhao
        @param lab: the Lab object
        @param blade: the rcs-hostname of the blade, 0-0-11 or 0-0-3 (0-0-10 or 0-0-2 for v8650)
                default is None, if none, will restart LB process on active LB blade
        @param processName: the name of the process will restart
                default is None, if none, will restart DiamLB related process

        @verbatim
        restartLBProcess(lab, '0-0-8')
        @endverbatim
        '''
        if not blade:
            blade = self.getActiveLB(lab)
        else:
            lbBlade = lab.getStationListbyProductRole('iLB').keys()
            CommonAssert.assertIn(blade, lbBlade, lab.id + ': ' + blade + ': Not an iLB blade')
        if not processName:
            processName = 'DiamLB'

        exceptionMsg = lab.id + ": " + blade + ": " + msgs.RESTART_LB_PROCESS_FAIL
        if lab.hardware not in ['HPG6', 'HPG8', 'BONO24', 'BONO48', 'VMMHI']:
            exceptionMsg = lab.id + ": hardware is " + lab.hardware + ": not supported"
            LOGGER.error(exceptionMsg)
            raise ASRLoadBalancerManagerError, exceptionMsg

        LOGGER.debug("%s: get LB process pid on %s", lab.id, blade)

        pidListPre = self.linuxProcessManager.getPidbyPS(lab, processName, blade)
        LOGGER.debug("%s: %s: get LB process pid list is %s", lab.id, blade, str(pidListPre))

        LOGGER.debug("%s: kill LB process on %s", lab.id, blade)
        self.linuxProcessManager.killProcessbyPid(lab, pidListPre, blade)

        LOGGER.debug("%s: wait LB process restart on %s", lab.id, blade)
        CommonAssert.timedAssert(900, 30,
                                 self.assertLBProcessStart,
                                 lab, blade, processName, pidListPre, 'debug')

        LOGGER.debug("%s: restart LB process on %s success", lab.id, blade)

    def assertLBProcessStart(self, lab, blade=None, processName=None, oldPidList=None, \
                             logLevel='error'):
        '''
        this function is to assert diameter process start up on given blade

        @author: Xia Zhao
        @param lab: the Lab object
        @param blade: the rcs-hostname of the blade, 0-0-3 or 0-0-11 (0-0-10 or 0-0-2 for v8650)
                default is None, if none, will restart LB process on active LB blade
        @param processName: the name of the process will restart
                default is None, if none, will restart DiamLB related process
        @param oldPidList: the old pid of the process, which is usefull for LB process restart
                default is None, if not None, will compare the old pids and the new pids.
                If same, will raise exception
         @param logLevel if "error" display as error logger message, else debug level

        @verbatim
        assertLBProcessStart(lab, '0-0-3', 'diameter', ['123','234'])
        @endverbatim
        '''
        exceptionMsg = lab.id + ": " + blade + ": " + msgs.ASSERT_LB_PROCESS_START_FAIL
        if not blade:
            blade = self.getActiveLB(lab)
        if not processName:
            processName = 'DiamLB'
        LOGGER.debug("%s: check LB process start on %s", lab.id, blade)
        pidList = self.linuxProcessManager.getPidbyPS(lab, processName, blade, logLevel)
        if oldPidList:
            CommonAssert.assertEqual(len(oldPidList), len(pidList), exceptionMsg, logLevel)
            for pid in pidList:
                CommonAssert.assertNotIn(pid, oldPidList, exceptionMsg, logLevel)

