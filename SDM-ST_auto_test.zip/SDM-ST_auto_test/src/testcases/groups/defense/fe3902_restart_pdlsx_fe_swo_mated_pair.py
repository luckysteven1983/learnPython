"""
Created on Aug 25, 2015

@author: Claude LE DU
"""

import os

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fe3902_restart_pdlsx_fe_swo_mated_pair(SDMTestCase):
    """Blade SW fault: restart PDLSU/I/L on RT blade and swo manual Mated pair on SLAVE"""

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.multiTasksManager = self.sdmManager.multiTasksManager

    def test_restart_pdlsx_fe_swo_mated_pair(self):
        """ Kill PDLSU/I/L on the FE and meanwhile do BE switchover on slave BE.
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _restartPdlsx(self, feObj):
        ''' kill pdls '''

        LOGGER.info("Kill all pdls on FE: " + feObj.id)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, feObj)
        LOGGER.debug("Kill all pdls on FE at: " + startTime)

        LOGGER.debug("Call LinuxProcessManager.advancedKillProcess")

        # Kill one PDLS
        pdlsList = ["PDLSU1", "PDLSI1", "PDLSL1", "PDLSM1"]
        foundProcess = None
        for plds in pdlsList:
            processOnblades = self.sdmManager.linuxProcessManager.getProcessPids(feObj, plds)
            if processOnblades:
                LOGGER.debug("Found process %s", plds)
                foundProcess = plds
                break
        else:
            raise BaseException, "No PDLS available"

        self.sdmManager.linuxProcessManager.advancedKillWaitProcess(feObj, foundProcess, processOnblades.keys(),
                                                                    logLevel='debug')

        LOGGER.debug("Call mcasApplicationManager.assertSPAState to check spa status on all blades")
        CommonAssert.timedAssert(1800, 10, self.sdmManager.mcasApplicationManager.assertSPAStateOnStations,
                                 feObj, "SDM", "IS", feObj.getStationListbyProductRole('RT').values(), 'debug')
        LOGGER.debug("Call mcasMachineManager.checkMachineStatus to check op:status,machine=all is COMPL")
        CommonAssert.timedAssert(1800, 30, self.sdmManager.mcasMachineManager.checkMachineStatus, feObj,
                                 logLevel='debug')


    def _runTestCase(self):
        """Execute test case"""
        # Get BE list
        LOGGER.debug("run test case ...")
        # Try BE switch-over on NRG 1
        beObjs = self.testEnv.testBed.getLabsInNRG()
        beStates = dict((beObj.id, self.databaseStateManager.getState(beObj)) for beObj in beObjs)
        LOGGER.debug("BE states before: %s", str(beStates))
        # Get a FE
        feObj = self.allFEs[0]
        LOGGER.debug("FE name: %s", feObj.id)

        # Run multiple tasks: restart pdls and BE switch-over
        LOGGER.info("Restart pdlsx and BE switch-over in progress")
        threadName = self.multiTasksManager.register(self._restartPdlsx, feObj)
        LOGGER.info("Restart PDLSx process on Lab '%s' in progress -> thread ID '%s'", feObj.id, threadName)
        threadName = self.multiTasksManager.register(self.databaseManager.matedPairSwo, beObjs)
        LOGGER.info("BE switch-over on Lab '%s' in progress -> thread ID '%s'", [be.id for be in beObjs], threadName)

        # Get a time from any lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, beObjs[0])
        LOGGER.info("Restarting pdlsx on %s and BE switch-over on %s", feObj.id, str(beStates.keys()))

        if not self.multiTasksManager.runMultiTasks():
            raise Exception("Restart pdlsx or BE switch-over failure")

        # Here we need to make sure the other BE status haven't changed
        newStates = dict((beObj.id, self.databaseStateManager.getState(beObj)) for beObj in beObjs)
        LOGGER.debug("BE states after: %s", str(newStates))
        self.assertEqual(beStates.values().sort(), newStates.values().sort(), "Other BE states have changed!")
        LOGGER.info("Restart traffics if needed")
        # If the traffic can't recover, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("Test case post-check")

        expectedAlarmsSpecific = []
        acceptedAlarmsSpecific = []
        expectedAlarmsBE = []
        acceptedAlarmsBE = []
        expectedAlarmsFE = []
        acceptedAlarmsFE = []
        exceptMsg = str()
        myAlarmsConfigFE = AlarmsConfig(expectedAlarmsFE, acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        masterBE = self.databaseStateManager.getMasterBE(self.allBEs)
        for labIndex in self.allBEs:
            if labIndex in masterBE:
                myAlarmsConfigBE = AlarmsConfig(expectedAlarmsSpecific, acceptedAlarmsSpecific, startTime)
            else:
                myAlarmsConfigBE = AlarmsConfig(expectedAlarmsBE, acceptedAlarmsBE, startTime)
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep


        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
