'''
Created on Jun 8, 2015

@author: Serge Beaufils

Amended on Jul 22, 2015
by Tangi Lavanant to add CLOUD (v8650)

Amended on August 19, 2015
by Tangi Lavanant to add getHardwareState

This library manages hardware. Useful for specific function (SHMC for ATCAV2 or OA for HP)

This parent class is only useful for INTERFACE. This is the only class seen by the user to
know accessible methods.
Child classes contains implementation of specific function to access SHMC or OA or VMMHI:
     AtcaV2HardwareMachineManager
     HpHardwareMachineManager
     VmmhiHardwareMachineManager

Typical usage (reset a board) :
   ( Note that it is not possible to manage ATCA V2 and HP hardw in the same time.
     A configuration is always the same hardware)

    lab = 'spa82oam'
    sshmngr = SshManager()
         # --- we creates the adequate HardwareMachineManager :
    hwTyp = HardwareMachineManager._getHardwareType(sshmngr, lab)
    if hwTyp == 'ATCA':
        hardwareManager = AtcaV2HardwareMachineManager(sshmngr)
    elif hwTyp == 'HP':
        hardwareManager = HpHardwareMachineManager(sshmngr)
    elif hwTyp == 'VMMHI':
        hardwareManager = VmmhiMachineManager(sshmngr)
         # --- now reset the board 6 on lab :
    hardwareManager.restartBoard(lab, 6)

'''

import os
import re
from lib.logging.logger import Logger

class HardwareMachineManagerError(BaseException):
    """If error, raise it."""
    pass

logger = Logger.getLogger(__name__)

# ---- init CONSTANTS
BUFF_SIZE = 8192
HARDW_CMD = '/opt/config/lib/get_configdb_attr hardware'
PREFIX_CMD = '/usr/psp/customize/list_servers_having_mod pilot'
SYSNAME_CMD = '/opt/config/lib/get_system_name'
HW_V8650 = 'VMMHI' 
SLOT_PREFIX = '0-0'

class StateHW:
    '''
    Class used as enum to have hardware state
    '''
    def __init__(self):
        """
        class constructor
        """
    BOARD_POWERED_ON, BOARD_POWERED_OFF, OTHER = range(3)

class HardwareMachineManager(object):

    ''' those constants must be in class to be accessed by child
    '''
    ROOT_CMD = 'ssh -q -o StrictHostKeyChecking=no '

    def __init__(self, sshMngr):
        '''
        constructor
        @param sshMngr : the paramiko sshmngr client to the remote lab
        '''
        self.sshmngr = sshMngr
        self.localResetMsg = ''
        self.localPrompt = ''

    def _checkBoardRestart(self, cmdOutput):
        '''
        check if an ATCA board has actually restarted.
        msg after cmd is for example "Rebooting Blade 3" (HP)
        localResetMsg is set in subclass
        '''
        if re.search(self.localResetMsg, cmdOutput, re.IGNORECASE):
            return cmdOutput
        else:
            raise HardwareMachineManagerError('Restart board failed :' + os.linesep + cmdOutput)

    ############################  PUBLIC  METHODS  #######################

    ######  all operations made via SHMC / OA are  declared  here    #####
    ######  but implemented  in the appropriate child  class         #####

    def restartBoard(self, lab, physicalSlot):
        '''
        restart a board .  INTERFACE only . see dedicated class for implementation (Atcav2... or Hp...)
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to restart
        '''
        raise NotImplementedError("You can't use parent class HardwareMachineManager. Use only subclass")

    def  getHardwareState(self, lab, physicalSlot):
        '''
        Get the state of a board to know if it is power on or off.
        INTERFACE only . see dedicated class for implementation (Atcav2... or Hp...)
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to restart
        '''
        raise NotImplementedError("You can't use parent class HardwareMachineManager. Use only subclass")

    def  getHardwareStateRAW(self, lab, physicalSlot):
        '''
        Get the state of a board, in a raw mode, i.e depending on Hardware.
        INTERFACE only . see dedicated class for implementation (Atcav2... or Hp...)
        @param lab : instance of framework.testenv.Lab
        @physicalSlot : the number of the slot to restart
        '''
        raise NotImplementedError("You can't use parent class HardwareMachineManager. Use only subclass")
