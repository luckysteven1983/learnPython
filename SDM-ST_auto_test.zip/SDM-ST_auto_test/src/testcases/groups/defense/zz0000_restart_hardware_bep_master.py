"""
Created on September 18, 2015

@author: Cassandra Lajeunie

# no test sheet found
"""
import os
import random

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_state_manager import DDM_DB_SYNCHRO_TIMEOUT, \
    DDM_DB_INTERVAL_CHECK
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class zz0000_restart_hardware_bep_master(SDMTestCase):
    "Test restart non pilot board on BE master using SHMC / OA depending on the hardware"

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results

        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()

    def test_restart_hardware_bep_master(self):
        """
        "Test restart non pilot board on BE master using SHMC / OA depending on the hardware"
        What it does : detect the type of hardware and run the appropriate command to restart board via hardware manager
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case ...")
        # Define Timeout
        TIMEOUT_5_MINUTES = 300

        # Get master BE
        master_be = self.databaseStateManager.getMasterBE(self.allBEs)[0]

        # Find a non pilot blade
        # --- list all non pilot blades
        list_non_pilot = self.mcasMachineManager.getMachinesNonPilot(master_be)
        # --- choose a random blade in the list of non pilot
        non_pilot_board = list_non_pilot[random.randint(0, len(list_non_pilot) - 1)]
        non_pilot_board_short = non_pilot_board.split('-')[2]

        # create the appropriate HardwareMachineManager object
        hardwareManager = self.sdmManager.hardwareManagerFactory.createHardwareManager(master_be)

        # take a random non-pilot blade
        LOGGER.info("restart board %s on BE %s " , non_pilot_board, master_be.id)
        hardwareManager.restartBoard(master_be, non_pilot_board_short)

        # wait the node to be different from 'started'. What means the node is restarting
        CommonAssert.timedAssert(TIMEOUT_5_MINUTES, 5, self.sdmManager.databaseStateManager.assertNdbNotState,
                                 master_be, 'started', non_pilot_board, logLevel='debug')

        # wait the board station to be ok again
        LOGGER.info("Wait for the station to be ok")
        # Waiting for requirement from SAE
        # LOGGER.debug("Time out for the assertStationOk is based on the FFRD-183269-532 (document id in compas : 183269) ")
        CommonAssert.timedAssert(DDM_DB_SYNCHRO_TIMEOUT, DDM_DB_INTERVAL_CHECK,
                                  self.testEnvAsserts.assertStationOK,
                                 master_be, non_pilot_board, logLevel='debug')

        # Get a time from the master BE
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, master_be)

        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case postcheck"""
        LOGGER.debug("test case post check")

        expectedAlarmsSpecific = []
        acceptedAlarmsSpecific = []
        expectedAlarms4BE = []
        acceptedAlarms4BE = []
        exceptMsg = str()

        masterBE = self.databaseStateManager.getMasterBE(self.allBEs)
        for labIndex in self.allBEs:
            if labIndex in masterBE:
                myAlarmsConfig4BE = AlarmsConfig(expectedAlarmsSpecific, acceptedAlarmsSpecific, startTime)
            else:
                myAlarmsConfig4BE = AlarmsConfig(expectedAlarms4BE, acceptedAlarms4BE, startTime)
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
