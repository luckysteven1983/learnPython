#!/bin/sh

# 6-03-2011 draft by canhua
# auto do the sanity test on lab

TOOL_DIR=`pwd`
package=$1

if [ -n "$package" ] && ! [ -f "$package" ]; then
   echo "package $package unknown."
   echo "sh install.sh [packagename]"
   exit 1
else
	if [ `ls pt*.gz 2>/dev/null|wc -l` -ne 1 ]; then
	   echo "package not found or there is more than 1 .gz files"
	else
		package=`ls pt*.gz` 
	fi   
fi



sh install.sh `ls pt*.gz`
echo "STEP 1"
pt lsview

echo "STEP 2"
pt setview $TOOL_DIR/testdir

echo "STEP 3"
pt lsview

echo "STEP 4"
pt cdtool <<EOF

EOF

echo "STEP 5"
pt lstool

echo "STEP 6"
pt cd <<EOF

EOF

echo "STEP 7"
pt lslog

echo "STEP 8"
pt startlog

echo "STEP 9"
pt done

echo "STEP 10"
pt cddone <<EOF

EOF

echo "STEP 11"
pt lsdone

echo "STEP 12"
pt stoplog A 

echo "STEP 12"
pt stoplog


echo "STEP 13"
pt rexec all "rm -rf $TOOL_DIR/testdir"