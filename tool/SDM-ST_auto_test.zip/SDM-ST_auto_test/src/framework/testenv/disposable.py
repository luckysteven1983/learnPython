'''
Created on Jan 30, 2015

@author: yohannm
'''

class Disposable(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        