'''
Created on Jan 30, 2015

@author: yohannm
'''

class Lab(object):
    '''
    classdocs
    '''

    def __init__(self):
        """ SYSTEM_PREFIX field in SDM_general_data.xml """
        self.id = None
        self.stations = dict()
        """ ROUZIC,BONO24, BONO48, HPG6, HPG8, DL380G8, DL380G6, ML350G6 or VM or VMMHI (v8650)"""
        self.hardware = None
        """ OAM IP address """
        self.oamIpAddress = None
        """ front-end, back-end, provisioning front-end, sdm-expert, etc. """
        self.productRole = None
        self.zoneId = None
        """ variable set to true as soon as first execution of health -h is ok on target lab """
        self.healthCheckAvailable = False
        """ List of Connection occurrences with Routers """
        self.connections = list()
        """ Account to login as root in 2 steps . primaryAccount is generally ainet """
        self.primaryAccount = None
        self.rootAccount = None


    def getStationListbyProductRole(self, role):
        '''
        get blade list according to the product role
        @param role: string, [iLB ss7 RT DB]
        @return: directory
        @author: Xia Zhao
        '''
        stationDict = dict()
        for station in self.stations.values():
            if role in station.productRole:
                stationDict[station.rcsHostname] = station
        return stationDict

    def getBladeListbymiddlewareRole(self, role):
        '''
        get blade list accoding to the middleware role
        @param role: string, [pilot non-pilot]
        @return: directory
        @author: Xia Zhao
        '''
        bladeDict = dict()
        for station in self.stations.values():
            if station.middlewareRole == role:
                bladeDict[station.rcsHostname] = station
        return bladeDict

    def getAllBlade(self):
        '''
        get all blades
        @return: directory
        @author: Xia Zhao
        '''
        bladeDict = dict()
        for station in self.stations.values():
            if station.middlewareRole:
                bladeDict[station.rcsHostname] = station
        return bladeDict


    def getStationsFromString(self, blades):
        '''
        get Stations object from a list of blades (String)
        @param blades : a list of blades (list of string)
        @return: list of Station objects
        @author: Serge Beaufils
        '''
        lStation = []
        for station in self.stations.values():
            if station.rcsHostname in blades:
                lStation.append(station)
                if len(lStation) == len(blades):  # dont go further if already full list
                    break
        return lStation
