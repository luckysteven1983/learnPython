'''
Created on Aug 8, 2014
@author: yohann
'''

from lib.ssh.ssh_manager import SshManager
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from random import randint
from framework.traffic.ptool.ptool_diameter_traffic_simulator import PtoolDiameterTrafficSimulator
from framework.traffic.tgen.tgen_ldap_traffic_simulator import TgenLDAPTrafficSimulator

logger = Logger.getLogger(__name__)


EMPTY_STR = ''
EMPTY_ERR_MSG = 'UNEXPECTED EMPTY OUTPUT'
NOT_EMPTY_ERR_MSG = 'UNEXPECTED OUTPUT : SHOULD BE EMPTY'



class ssh_manager_nightly_test_once(SDMTestCase):

    '''
        initiate and store the SSH connections to labs, PC , etc
        General info for parameters during first call :
        ** only hostname =>  this is a lab with 2-steps login (ainet then root). User of connection is root
        ** hostname, user, password => this is a standard direct login.
        In the following calls, if not provided the default user is 'root'

        Examples of first connection to remote station :
           .getClient('spa87oam')
                   => lab connection via ainet then root. pw are known
           .getClient('spa202oam.fr.alcatel-lucent.com')
                   => lab connection via ainet then root. pw are known
           .getClient('lalx04si3.fr.alcatel-lucent.com', user='jenkins', pw='jenkins')
                   => direct connection to jenkins server with user jenkins and pw
           .getClient('135.252.181.16',user='bic_guest', pw='bic_guest')
                   => direct connection to china portal with user bic_guest and pw
           .getClient('spa204oam',user='ainet', pw='ainet1')
                   => lab connection with ainet. It is a direct connection, not a lab connection as first case
           .getClient('hp30oam',user='root', pw='r00t')
                   => direct lab connection with root. 1-step connection (not lab connect)

        Once connection are initialized , you can call w/o pw and w/o user depending on the case :
            .run('spa87oam', cmd)                                         : root is default user
            .run('spa202oam.fr.alcatel-lucent.com', cmd)                  : root is default user
            .run('lalx04si3.fr.alcatel-lucent.com', cmd, user='jenkins')
            .run('135.252.181.16', cmd, user='bic_guest')
            .run('spa204oam', cmd, user='ainet')
            .run('hp30oam', cmd)                                          : root is default user
    '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results

        beList = self.testEnv.testBed.getBackends()
        self.be1 = beList.popitem()[1]
        self.be1Ip = self.be1.oamIpAddress
        feList = self.testEnv.testBed.getFrontends()
        self.fe1 = feList.popitem()[1]
        self.fe1Ip = self.fe1.oamIpAddress

        self.pcTraffic = None
        self.pcAccount = None
        for myTrafficSimulator in self.testEnv.trafficSimulators:
            if isinstance(myTrafficSimulator, PtoolDiameterTrafficSimulator) \
                     or isinstance(myTrafficSimulator, TgenLDAPTrafficSimulator):
                self.pcTraffic = myTrafficSimulator.toolIpAddress
                self.pcAccount = myTrafficSimulator.account
                break
        if not self.pcTraffic:
            logger.warning("No ptool or tgen simulator found: will not execute some unit tests.")
        if self.testEnv.id.startswith("BJ"):
            self.chinaConf = True
        else:
            self.chinaConf = False
        # generate a non-existent filename
        self.randomFilename = 'dummy_filename_' + str(randint(0, 99999))

        self._sshManager = self.sdmManager.sshManager



    def test_01_std_out_err(self):
        '''
         test with any command with output on 1) stdout 2) stderr 3) stdout+stderr
        '''
        logger.debug("\n")
        logger.debug(" ################  test_01_std_out_err ########################")
        sshMngr = SshManager()

        cmdOk = 'ls -ld /etc'
        cmdKo = 'ls ' + str(self.randomFilename)
        cmdOkKo = 'ls -ld /etc ' + str(self.randomFilename)

        logger.info(' >> ' + self.fe1.id + ' >> Command with stderr only : ' + cmdKo)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdKo)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertNotEqual(_out, EMPTY_STR, EMPTY_ERR_MSG)

        logger.info(' >> ' + self.fe1.id + ' >> Command with stdout only : ' + cmdOk)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdOk)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertNotEqual(_out, EMPTY_STR, EMPTY_ERR_MSG)

        logger.info(' >> ' + self.fe1.id + ' >> Command with stdout AND stderr : ' + cmdOkKo)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdOkKo)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertNotEqual(_out, EMPTY_STR, EMPTY_ERR_MSG)



    def test_02_run_background_command_no_std(self):
        '''
         test with any command with output on 1) stdout 2) stderr 3) stdout+stderr
        '''
        logger.debug("\n")
        logger.debug(" ################  test_02_run_background_command_no_std ########################")
        sshMngr = SshManager()

        cmdFind = 'find . -name ' + self.randomFilename  # should be1 return an empty stdout
        cmdBkg2 = 'nohup sleep 10 '
        cmdBkg3 = 'sleep 10 &'
        cmdBkg4 = 'nohup sleep 10 &'
        cmdBkg5 = 'nohup sleep 10 > /dev/null &'

        logger.info(' >> ' + self.fe1.id + ' >> Command find : ' + cmdFind)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdFind, ignoreStdStreams=True)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertEqual(_out, EMPTY_STR, EMPTY_ERR_MSG)

        logger.info(' >> ' + self.fe1.id + ' >> Command sleep (2) : ' + cmdBkg2)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdBkg2, ignoreStdStreams=True)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertEqual(_out, EMPTY_STR, NOT_EMPTY_ERR_MSG)

        logger.info(' >> ' + self.fe1.id + ' >> Command sleep (3) : ' + cmdBkg3)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdBkg3, ignoreStdStreams=True)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertEqual(_out, EMPTY_STR, NOT_EMPTY_ERR_MSG)

        logger.info(' >> ' + self.fe1.id + ' >> Command sleep (4) : ' + cmdBkg4)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdBkg4, ignoreStdStreams=True)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertEqual(_out, EMPTY_STR, NOT_EMPTY_ERR_MSG)

        logger.info(' >> ' + self.fe1.id + ' >> Command sleep (5) : ' + cmdBkg5)
        _rc, _out = sshMngr.run(self.fe1Ip, cmdBkg5, ignoreStdStreams=True)
        logger.info (' >>> rc=' + str(_rc) + ' >> stdout= ' + _out)
        self.assertEqual(_out, EMPTY_STR, NOT_EMPTY_ERR_MSG)



    def test_05_BasicUse(self):
        '''
            Docstring
        '''
        logger.debug("\n")
        logger.debug(" ################  test_05_BasicUse  ########################")
        sshMngr = SshManager()

        # --- ssh connection to a lab : 2 - step process with ainet then root.

        # --- ssh connection to test server with jenkins user
        if self.pcTraffic:
            sshMngr.getClient(self.pcTraffic, self.pcAccount.login, self.pcAccount.password)

        sshMngr.getClient(self.fe1Ip)

        #--- ssh connection to china portal with bic_guest user
        # _ = sshMngr.getClient(self.pcChina, user='bic_guest', pw='bic_guest')
        # --- lab connection with ainet user (not root)
        sshMngr.getClient(self.be1Ip, user='ainet', pw='ainet1')


        if self.chinaConf:
            cmd = "whoami; hostname; pwd"  # no ls for china stations because of special chars
        else:
            cmd = "whoami; hostname; pwd; ls -al"

        if self.pcTraffic:
            _, _out = sshMngr.run(self.pcTraffic, cmd, self.pcAccount.login)
            logger.debug('\n  >> ' + self.pcTraffic + ' >> ' + _out + "\n")

        # _, _out = sshMngr.run(self.pcChina, cmdCh, user='bic_guest')
        # logger.debug('\n  >> ' + self.pcChina + ' >> ' + _out + "\n")

        _, _out = sshMngr.run(self.fe1Ip, cmd)
        logger.debug('\n  >> ' + self.fe1.id + ' >> ' + _out + "\n")

        _, _out = sshMngr.run(self.be1Ip, cmd, user='ainet')
        logger.debug('\n  >> ' + self.be1.id + ' >> ' + _out + "\n")

        if self.pcTraffic:
            logger.debug(' >>>>> scpput')
            logger.debug("copy " + str(sshMngr.scpPut('/tmp/tototo', self.pcTraffic, '/tmp/tototo', self.pcAccount.login)))
            _, _out = sshMngr.run(self.pcTraffic, 'sleep 5 &', self.pcAccount.login)
            logger.debug("\n >>>>  command in background (sleep n) >>>>" + _out + "\n")

        # logger.debug("\n close connection " + self.pcChina)
        # sshMngr.closeClient(self.pcChina, user='bic_guest')
        logger.debug("\n close all connections")
        sshMngr.closeAllClients()



    def test_07_Close(self):
        '''
            Docstring
        '''
        logger.debug("\n ################  test_07_Close ########################")
        sshMngr = SshManager()
        if self.pcTraffic:
            sshMngr.getClient(self.pcTraffic, self.pcAccount.login, self.pcAccount.password)
        sshMngr.getClient(self.be1Ip, user='ainet', pw='ainet1')

        cmd = "whoami; hostname"
        if self.pcTraffic:
            _, _out = sshMngr.run(self.pcTraffic, cmd, self.pcAccount.login)
            logger.debug('\n  >> ' + self.pcTraffic + ' >> ' + _out + "\n")

        _, _out = sshMngr.run(self.be1Ip, cmd)
        logger.debug('\n  >> ' + self.be1.id + ' >> ' + _out + "\n")

        _, _out = sshMngr.run(self.fe1Ip, cmd)
        logger.debug('\n  >> ' + self.fe1.id + ' >> ' + _out + "\n")

        _, _out = sshMngr.run(self.be1Ip, cmd, user='ainet')
        logger.debug('\n  >> ' + self.be1.id + ' >> ' + _out + "\n")

        logger.debug("close connections")
        if self.pcTraffic:
            sshMngr.closeClient(self.pcTraffic, self.pcAccount.login)
        sshMngr.closeClient(self.be1Ip)
        sshMngr.closeClient(self.fe1Ip)
        sshMngr.closeClient(self.be1Ip, user='ainet')



    def test_09_RunStation(self):
        '''
            Docstring
        '''
        logger.debug("\n ################  test_09_RunStation ########################")

        sshMngr = SshManager()
        host = self.be1Ip
        cmd = "whoami; hostname"

        logger.debug("\n .................... host = " + host)
        # choose a few stations to execute command
        for sta in ['B', 'C', 'E', 'F']:
            _, _out = sshMngr.run(host, cmd, station=sta)
            logger.debug(sta + ' > > > ' + _out + "\n")

        logger.debug("close connections")
        sshMngr.closeAllClients()



    def test_11_Expect(self):
        '''
            Docstring
        '''
        logger.debug("\n ################  test_11_Expect ########################")
        sshMngr = SshManager()

        host = self.be1Ip

        logger.debug("\n \n host: " + host)

        linux = 'Linux'
        cmd = 'uname -a'
        _out, _ = sshMngr.sendStringAndExpect(host, cmd, linux , timeout=5)
        self.assertIn(linux, _out, cmd + " did not return " + linux)
        logger.debug('\n >>>>>  Linux OS ? ' + str(linux in _out))
        logger.debug("close connections")
        sshMngr.closeAllClients()


    def test_12_getClientDontUseKey(self):
        logger.debug("################ test_12_getClientNoKey ########################")
        if not self.pcTraffic:
            logger.debug("no traffic pc, test not executed")
            return
        sshManager = SshManager()
        expected = "hello"
        client = sshManager.getClient(self.pcTraffic, self.pcAccount.login, self.pcAccount.password, False)
        channel = client.invoke_shell()
        (stdout, _) = sshManager.sendStringRoutine(channel, "echo " + expected, expected)
        self.assertRegexpMatches(stdout, ".*" + expected + ".*", "expected message not found")


    def test_20_noStandardConnection(self):
        logger.debug("################ test_20_noStandardConnection ########################")

        # standard login :
        _ = self._sshManager.getClient(self.fe1Ip)
        self._sshManager.closeClient(self.fe1Ip)

        # login again to root via the same primaryUser (ainet , nxuser, ... :
        _ = self._sshManager.getClient(self.fe1Ip, labRootPw='r00t')
        self._sshManager.closeClient(self.fe1Ip)

        # same login again but by specifying the default primary User
        _ = self._sshManager.getClient(self.fe1Ip, labCustomUser='ainet', labCustomPw='ainet1', labRootPw='r00t')
        self._sshManager.closeClient(self.fe1Ip)

        # same login again but by specifying a different primary User
        _ = self._sshManager.getClient(self.fe1Ip, labCustomUser='nxuser', labCustomPw='nxuser', labRootPw='r00t')
        self._sshManager.closeClient(self.fe1Ip)

        pass


