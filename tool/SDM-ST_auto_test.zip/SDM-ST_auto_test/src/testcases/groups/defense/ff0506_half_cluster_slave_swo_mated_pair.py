'''
Created on Aug 31, 2015

@author: Serge Beaufils

@jenkins http://lalx04si3.fr.alcatel-lucent.com:8080/view/Dev_Jobs/job/Dev-All-FV2-beaufil2/34/console
'''

import random
import time

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarm import Alarm
from lib.logging.logger import Logger

TIMEOUT_4H = 4 * 3600  # timeout 4 h in seconds

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)


class ff0506_half_cluster_slave_swo_mated_pair(SDMTestCase):
    '''Blade SW fault: restart one cluster on BE SLAVE and swo manual Mated pair on SLAVE'''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.databaseManager = self.sdmManager.databaseManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.multiTasksManager = self.sdmManager.multiTasksManager

        self.expectedAlarmsSpecific = []
        self.acceptedAlarmsSpecific = [Alarm(alarmCode=404, severity="Major"),
                                       Alarm(alarmCode=404, severity="Minor")]
        self.expectedAlarms4BE = []
        self.acceptedAlarms4BE = []
        self.expectedAlarms4FE = []
        self.acceptedAlarms4FE = []
        self.success = True
        self.exceptMsg = ""

        _, self.be = self.testEnv.testBed.getBackends().popitem()

        # --- get the list of stations of one cluster (randomly choosen)
        nodeInfo = self.databaseManager.loadNodes(self.be)
        nCluster = str(random.randint(1, 2))  # choose randomly cluster #1 or #2
        self.clustStations = [nod for nod, nodDict in nodeInfo.iteritems() if nodDict['boot_group'] == nCluster]



    def test_kill_cluster_slave_swo_mated_pair(self):
        """ kill cluster on BE and swo pilot on MASTER and SLAVE.
        Procedure:
        1. restart kill cluster and meanwhile do pilot switch-over on all BE of NRG.
        2. restart SDM SPA on the FE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check and return current active alarm list"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post check")
        time.sleep(10)

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])


    def _runTestCase(self):
        """Execute test case"""

        LOGGER.debug("run test case %s", self.__class__.__name__)

        LOGGER.debug("Get BEs of NRG 1")
        belist = self.testEnv.testBed.getNRG()
        beOperStatus = ''
        for be in belist:
            beOperStatus += self.databaseStateManager.getState(be, key='Global Status')
        if not 'master is secured' in beOperStatus or not 'slave is secured' in beOperStatus:
            # not a mated pair  or mated pair not OK => Raises Exception
            raise Exception('Mated Pair not OK : ' + beOperStatus)

        masterBE = self.databaseStateManager.getMasterBE(belist)[0]
        slaveBE = self.databaseStateManager.getSlaveBE(belist)[0]
        if masterBE is None or slaveBE is None:
            txt = "Unable to find Master and Slave in Mated Pair : %s %s"
            LOGGER.error(txt, belist[0].id, belist[1].id)
            raise Exception(txt, belist[0].id, belist[1].id)

        LOGGER.debug("Master BE is " + masterBE.id)
        LOGGER.debug("Slave BE is " + slaveBE.id)


        # Run multiple tasks: kill 1 cluster and swo mated pair.
        LOGGER.info("Kill Cluster and BE switchover in progress")
        multiTasksManager = self.sdmManager.multiTasksManager
        threadName = multiTasksManager.register(self.databaseManager.setHalfClusterBE, slaveBE)

        LOGGER.info("Kill Cluster on Lab '%s' in progress -> thread ID '%s'", slaveBE.id, threadName)
        threadName = multiTasksManager.register(self.databaseManager.matedPairSwo, belist)
        LOGGER.info("BE switch-over on Lab '%s' in progress -> thread ID '%s'", [be.id for be in belist], threadName)

        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.info("Kill Cluster on '%s' and BE swithover on '%s'", slaveBE.id, [be.id for be in belist])

        if not multiTasksManager.runMultiTasks():
            raise Exception("Killing Cluster or BE swithover failure")

        # --- now wait that all nodes restarted, every 3 min, 4h max. 2h is not enough is some cases !
        CommonAssert.timedAssert(TIMEOUT_4H, 180, self.databaseStateManager.assertNdbState,
                                 slaveBE, 'started', logLevel='debug')
        LOGGER.info("All nodes now 'started' on BE %s ", slaveBE.id)

        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

