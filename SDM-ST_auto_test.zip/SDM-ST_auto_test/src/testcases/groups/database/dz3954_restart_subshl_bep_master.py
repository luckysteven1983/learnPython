'''
Created on Sept 9, 2015

@author: Claude Le Du
'''

import os
import random

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_state_manager import DDM_DB_SYNCHRO_TIMEOUT, \
    DDM_DB_INTERVAL_CHECK
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class dz3954_restart_subshl_bep_master(SDMTestCase):
    """ Restart a board on a master BE """


    def setUp(self):
        self.logLinksPrint()   # Used to get the log links in Junit XML results
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsBE = []
        self.acceptedAlarmsBE = []
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.success = True
        self.exceptMsg = ""


    def test_restart_subshl_bep_master(self):
        """ Restart a board on a master BE """

        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)


    def _precheck(self):
        """Test case pre-check and return current active alarm list """

        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        """ Restart a board on a master BE """

        LOGGER.debug("Get a master BE")
        beList = self.testEnv.testBed.getLabsInNRG("1")
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(beList)[0]
        LOGGER.debug("Master BE is " + masterBE.id)

        LOGGER.debug("%s: Choose a non-pilot station", masterBE.id)
        nonPilotStation = random.choice(self.mcasMachineManager.getMachinesNotVHost(masterBE))
        LOGGER.debug("%s: non-pilot station %s has been chosen", masterBE.id, nonPilotStation)

        LOGGER.debug("%s: check non-pilot station %s is in good status", masterBE.id, nonPilotStation)
        self.testEnvAsserts.assertStationOK(masterBE, nonPilotStation)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.info("Restart board " + nonPilotStation + " on master BE " + masterBE.id + " at: " + startTime)

        self.assertTrue(self.mcasMachineManager.removeMachine(masterBE, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.powerOffMachine(masterBE, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.powerOnMachine(masterBE, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.restoreMachine(masterBE, nonPilotStation))

        CommonAssert.timedAssert(DDM_DB_SYNCHRO_TIMEOUT, DDM_DB_INTERVAL_CHECK,
                                  self.testEnvAsserts.assertStationOK, masterBE, nonPilotStation,
                                 'COMPL', 'debug')

        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()

        return startTime


    def _postcheck(self, startTime):

        """ Test case post-check"""
        LOGGER.debug("Test case post-check")
        LOGGER.debug("Check the alarms")
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(self.expectedAlarmsBE, self.acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("dz3954_restart_subshl_bep_master success!\n")
        else:
            LOGGER.error("dz3954_restart_subshl_bep_master failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)

