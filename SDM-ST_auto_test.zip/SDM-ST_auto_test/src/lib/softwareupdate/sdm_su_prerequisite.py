"""
@file sdm_su_prerequisite.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-11-03
@brief SU prerequisite

"""
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_platform_manager import McasPlatformManager
from lib.platform.mcas.subshl.subshl_manager import SubshlManager
from lib.platform.mcas.mcas_machine_manager import MCASMachineManager
from lib.platform.linux_process_manager import LinuxProcessManager
from lib.database.ddm.database_state_manager import DatabaseStateManager
from lib.database.ddm.database_topology_manager import DatabaseTopologyManager
from lib.platform.mcas.mcas_user_manager import MCASUserManager
from lib.platform.mcas.mcas_user_manager import Account
from lib.common.multi_tasks_manager import MultiTasksManager

LOGGER = Logger.getLogger(__name__)

class SdmSuPrerequisite(object):
    """SDM SU precheck """

    def __init__(self, sshManager):
        """Init SdmSuPrerequisite instance with sshManager. """
        self._sshManager = sshManager
        self._subshlManager = SubshlManager(sshManager)
        self._linuxProcessManager = LinuxProcessManager(sshManager)
        self._multiTasksManager = MultiTasksManager()
        self._mcasMachineManager = MCASMachineManager(sshManager, self._subshlManager,self._multiTasksManager)
        self._databaseTopologyManager = DatabaseTopologyManager(sshManager)

    def checkHelpme(self, lab, option='platform'):
        """Run HELPME on lab with option.

        @param lab    one Lab object
        @param option    one option as string for HELPME command (default 'platform')
        """
        # Run HELPME of mCAS
        McasPlatformManager(self._sshManager,
                            self._subshlManager,
                            self._linuxProcessManager,
                            self._mcasMachineManager).runHelpme(lab, option)

    def checkBEState(self, lab):
        """Check BE state only success for master or slave state.

        @param lab    one Lab object
        """
        DatabaseStateManager(self._sshManager, self._databaseTopologyManager).checkBEState(lab)

    def installSshkeyBetweenLabAndServer(self, lab, loadServerIP, serverUser, serverPassword,
                                         labUser=Account.MCASUSER, labPassword=Account.MCASPW):
        """Create user on lab and pass its ssh key into remote server"""
        MCASUserManager(self._sshManager).sshSetup(loadServerIP, lab.oamIpAddress,
                                                   serverUser, serverPassword, labUser, labPassword)
        # create user successful, and then get ssh client used for other modes
        self._sshManager.getClient(lab.oamIpAddress, labUser, labPassword)
