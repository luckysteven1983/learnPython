#!/bin/sh
# 5-30-2011	draft by canhua
# This script is used to stop the log on station

#resolve links - $0 may be a soft-link
PRG="$0"

while [ -h "$PRG" ] ; do
    ls=`ls -ld "$PRG"`
    link=`expr "$ls" : '.*-> \(.*\)$'`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=`dirname "$PRG"`/"$link"
    fi
done

TOOL_DIR=`dirname "$PRG"`

script="_startlog.sh"
process=`ps -ef |grep "$script"|grep -v grep |awk '{ print $2}' `
for i in "$process"
do
         ps h --ppid $process |grep -v ppid|awk '{ print $1}' | xargs -n 1 kill -9
         kill -9 $process
done
        
#ps -ef |grep "$script"|grep -v grep |awk '{ print $2}' | xargs kill  > /dev/null

# Delete the lock
STATION_ID=`hostname|sed -e 's:^.*-\([0-9]*\)$:\1:'`
#LOG_LOCK="$TOOL_DIR/STATION_${STATION_ID}.LOCK"

#if [ -f "$LOG_LOCK" ]; then
#        rm -rf "$LOG_LOCK"
#fi

#recover the toprc and rhosts
APPENDIX="bak.pt"
APPENDIX_NOTHING="bak.nothing"
APPENDIX_NODO="bak.nodo"

toprc=/root/.toprc
#rhosts=/root/.rhosts

restore_file () {
	filename=$1
	if [ -f $filename.$APPENDIX_NODO ]; then
	   rm -rf $filename.$APPENDIX_NODO
	   rm -rf $filename
	   return 0
	fi
	
	if [ -f $filename ]; then
	   if [ -f $filename.$APPENDIX ] && ! [ -f $filename.$APPENDIX_NOTHING ]; then
			mv  $filename.$APPENDIX $filename			
			return 0
				  
	   fi
	   rm -rf $filename.$APPENDIX_NOTHING	   	
	fi			
}


#if [ -f $rhosts.$APPENDIX_NOTHING ]; then
#	rm -rf $rhosts $rhosts.$APPENDIX_NOTHING
#fi
restore_file $toprc




if  [ -f $toprc.$APPENDIX ] ; then
        mv $toprc.$APPENDIX $toprc
fi

#if   [ -f $rhosts.$APPENDIX ] ; then
#        mv $rhosts.$APPENDIX $rhosts
#fi


#sleep 5
#process=`ps -ef |grep "$script"|grep -v grep |awk '{ print $2}' `
#for i in "$process"
#do
#         ps h --ppid $process |grep -v ppid|awk '{ print $1}' | xargs kill -9
#         kill -9 $process
#done
