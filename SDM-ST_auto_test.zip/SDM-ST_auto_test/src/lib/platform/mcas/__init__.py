"""Inclde all operations on MCAS platform."""
