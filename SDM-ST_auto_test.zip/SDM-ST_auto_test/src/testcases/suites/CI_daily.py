"""Test cases to be run every day on release CI"""
TEST_ITEMS = [
            "src/testcases/groups/ip/fc3968_ip_fault_vlan_fe", #IP TC to be added at beginning waiting for SDMSQA-1161
            "src/testcases/groups/ip/ff0526_ip_arp_tables_clear_fe",
            "src/testcases/groups/database/ff0490_restart_gdmp_master",
            "src/testcases/groups/database/ff0491_restart_gdmp_overload_master",
            "src/testcases/groups/database/ff0487_restart_mysqld_master",
            "src/testcases/groups/database/ez4324_swo_mated_pair_nrg1",
            "src/testcases/groups/platform/ff0493_restart_spas_fe",
            "src/testcases/groups/platform/ff0494_restart_spa_master",
            "src/testcases/groups/oam/ei9255_restart_oam_process_fe",
            "src/testcases/groups/platform/ev6411_swo_pilot_master",
            "src/testcases/groups/platform/ff0509_swo_pilot_fe",
            "src/testcases/groups/defense/ev1397_half_cluster_master",
            "src/testcases/groups/defense/ez4323_kill_cluster_master",
            "src/testcases/groups/database/dz3954_restart_subshl_bep_master",
            "src/testcases/groups/database/ff0488_restart_platform_proxy_master",
            "src/testcases/groups/database/ff0492_restart_platform_proxy_fe",
            "src/testcases/groups/platform/ff0517_restart_subshl_fep",
            "src/testcases/groups/application/ei9253_restart_pdlsx_fe",
            "src/testcases/groups/defense/ff0511_kill_cluster_slave",
            "src/testcases/groups/database/ff0489_restart_ndb_master",
            "src/testcases/groups/database/ff0540_restart_topo_manager_fe",
            "src/testcases/groups/database/ff0539_restart_dbsupervisor_master",
            "src/testcases/groups/application/fg1204_restart_ldaps_fe",
            "src/testcases/groups/healthchecktool/es4793_check_CPU_usage",
            "src/testcases/groups/platform/du3934_restart_platform_pfboot_master_nrg1",
            "src/testcases/groups/ip/ff3154_ip_interface_pilot_fe"
              ]