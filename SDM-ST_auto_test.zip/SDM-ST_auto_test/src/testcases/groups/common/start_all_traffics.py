"""
Created on Apr 15, 2015

@author: Claude Le Du
"""

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

logger = Logger.getLogger(__name__)


class start_all_traffics(SDMTestCase):


    def setUp(self):
        logger.debug("setUp")
        logger.debug("testEnv id: %s", self.testEnv.id)
        self.logLinksPrint()#Used to get the log links in Junit XML results


    def tearDown(self):
        logger.debug("tearDown")


    def testStartAllTraffics(self):
        logger.debug("testStartAllTraffics")
        trafficManager = self.sdmManager.trafficManager
        try:
            trafficManager.startAllTraffics(self.trafficProfile, self.testEnv) # pylint: disable=no-member
        except BaseException as arg:
            logger.error(arg.message)
            raise BaseException(arg.message)

