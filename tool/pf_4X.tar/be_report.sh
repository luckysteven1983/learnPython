#!/bin/bash

#######################################################
#       usage: $0 <PT tool logs directory>
#       $LOG_DIR=<PT tool logs directory>
#######################################################  

currentpath=$(cd "$(dirname "$0")"; pwd)
hostname=`hostname|awk -F"-" '{print $1}'`
#HW=`hostname|awk -F"-" '{print $1}'|sed -n -e 's/[0-9]//gp'`
HW=`grep 'name="HARDWARE"' /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `
if [[ "$HW" =~ "HP" ]];then
    ## HPblade case
    HW="HP"
elif [[ "$HW" =~ "BONO" ]];then
        ##  case
        HW="BONO"
else
        ## ROUZIC case
        HW="ROUZIC"   
fi
cd $1
################################################################
# The tool will save the result under directory $LOG_DIR/Result.
################################################################
if [ -d $1/Result ]
then
  echo "directory exist! clear it"
  rm -r $1/Result;mkdir $1/Result
else
  echo "directory no exist! create it"
  mkdir -p $1/Result
fi
echo Hostname > $1/Result/be_${hostname}_report.xls
echo `hostname|awk -F"-" '{print $1}'` >> $1/Result/be_${hostname}_report.xls 
###############################################################
#BE Hottest CPU and average CPU usage statistics
###############################################################
cd $1/Done
echo "Parsing cpu data ......"
$currentpath/top_cpu.sh 
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "        BE Hottest CPU and average CPU Usage Statistics  Result                    ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat top_cpu.report >> $1/Result/report_${hostname}
paste $1/Result/be_${hostname}_report.xls  top_cpu.summary >> $1/Result/be_${hostname}_report.tmp
mv $1/Result/be_${hostname}_report.tmp $1/Result/be_${hostname}_report.xls
echo "Parsing cpu data done."


################################################################
# BE memory statistics
# Memory=used - buffer - cache
################################################################
echo "Parsing memory data ......"
$currentpath/top_memory.sh
echo "----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "        BE Memory Usage Statistics  Result                                        ">>$1/Result/report_${hostname}
echo "----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat top_mem.report >> $1/Result/report_${hostname}
paste $1/Result/be_${hostname}_report.xls oam_mem.summary > $1/Result/be_${hostname}_report.tmp
paste $1/Result/be_${hostname}_report.tmp nonpilot_mem.summary > $1/Result/be_${hostname}_report.xls
rm $1/Result/be_${hostname}_report.tmp 
mv *mem.txt $1/Result
echo "Parsing memory data done."


################################################################
# BE run queue statistics
################################################################
echo "Parsing run queue data ......"
$currentpath/nonpilot_vmstat.sh
echo "----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "        BE Run Queue Statistics  Result                                           ">>$1/Result/report_${hostname}
echo "----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat runque.xls >> $1/Result/report_${hostname}
paste $1/Result/be_${hostname}_report.xls runque.xls > $1/Result/be_${hostname}_report.tmp
mv $1/Result/be_${hostname}_report.tmp $1/Result/be_${hostname}_report.xls
rm runque.xls
echo "Parsing run queue data done."

################################################################
# BE process statistics
################################################################
echo "Parsing GdmpServer ndbmtd cpu & memory data ......"
$currentpath/top_process.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "    GdmpServer & ndbmtd Average CPU Usage Statistics  Result                       ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat top_process.report >> $1/Result/report_${hostname}
paste $1/Result/be_${hostname}_report.xls oam_process.summary > $1/Result/be_${hostname}_report.tmp
paste $1/Result/be_${hostname}_report.tmp nonpilot_process.summary > $1/Result/be_${hostname}_report.xls
rm $1/Result/be_${hostname}_report.tmp 
mv *.txt $1/Result

echo "Parsing GdmpServer ndbmtd cpu & memory data done."
##############################################################
#Transfer GdmpServer & ndbmtd cpu and memory data to Excel Chart
##############################################################
$currentpath/txt2excel_dir_chart.pl $1/Result


##############################################################
#BE bandwidth statistics
##############################################################
echo "Parsing bandwidth data ......"
$currentpath/bandwidth_meas.sh 

echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "       BE Bandwidth Statistics  Result                                             ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat bandwidth.report >> $1/Result/report_${hostname}
mv ms_ip_data_meas.txt $1/Result
paste $1/Result/be_${hostname}_report.xls bandwidth.summary > $1/Result/be_${hostname}_report.tmp
mv $1/Result/be_${hostname}_report.tmp $1/Result/be_${hostname}_report.xls
echo "Parsing bandwidth  data done."

##############################################################
#BE NbReplyThreads & NdbObject Measure statistics
##############################################################
echo "Parsing NbReplyThreads & NdbObject measurements data ......"
$currentpath/be_gdmpserver_meas.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "     BE NbReplyThreads & NdbObject Measure Statistics  Result                      ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat be_gdmpserver_meas.result >> $1/Result/report_${hostname}
cat be_gdmpserver_meas.result | awk ' BEGIN { print "ndbObject" } NR==1 { next; }  { print $2 }' > ndbObject.xls

paste $1/Result/be_${hostname}_report.xls ndbObject.xls  > $1/Result/be_${hostname}_report.tmp
mv $1/Result/be_${hostname}_report.tmp $1/Result/be_${hostname}_report.xls
rm be_gdmpserver_meas.result ndbObject.xls
echo "Parsing NbReplyThreads & NdbObject measurements data done."

##############################################################
#BE DDM_GDMPSERVER_SUM_MEAS Statistics
##############################################################
echo "Parsing DDM_GDMPSERVER_SUM_MEAS data ......" 
$currentpath/be_gdmpserver_sum_meas.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "            BE DDM_GDMPSERVER_SUM_MEAS Statistics  Result                          ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat be_gdmpserver_sum_meas.result >> $1/Result/report_${hostname}
rm be_gdmpserver_sum_meas.result
echo "Parsing DDM_GDMPSERVER_SUM_MEAS data done."


##############################################################
#BE ALARM Measure statistics
##############################################################
 echo "Parsing ALARM measurements data ......"
$currentpath/be_alarm_meas.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "          BE ALARM Measure Statistics  Result                                      ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
mv *.txt $1/Result
echo "Parsing ALARM measurements data done."

##############################################################
#BE Replication Measures statistics
##############################################################
echo "Parsing Replication measurements data ......"
$currentpath/be_replication_meas.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "          BE Replication Measures Statistics  Result                               ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat be_rep_meas.result >> $1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "          BE Replication Binlog Measures Statistics  Result                        ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat be_rep_binlog_meas.result >> $1/Result/report_${hostname}

cat be_rep_meas.result | awk 'BEGIN { print "RepLatency%<2sectRepLatency%2-3sec"; m1=0; m2=0; } NR==1 { next; } { s1=$2+$3;  s2=$4+$5; if (s1 > m1) m1=s1; if ( s2 > m2) m2=s2; next} END { printf "%dt%dn", m1, m2 } ' > latency.xls
paste $1/Result/be_${hostname}_report.xls latency.xls > $1/Result/be_${hostname}_report.tmp
mv $1/Result/be_${hostname}_report.tmp $1/Result/be_${hostname}_report.xls
rm be_rep_meas.result 
echo "Parsing Replication measurements data done."

echo "Parsing loadprof_SUM ......"
$currentpath/loadprof_meas.sh
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
echo "          BE loadprof_SUM                                                          ">>$1/Result/report_${hostname}
echo "-----------------------------------------------------------------------------------">>$1/Result/report_${hostname}
cat be_loadprof_meas.result >> $1/Result/report_${hostname}

##############################################################
#BE lab status and configuration
##############################################################

echo "###################### BE version information #######################" >> $1/Result/report_${hostname}
$currentpath/check_be_version.sh
cat be_version_info.result >> $1/Result/report_${hostname}
rm be_version_info.result
echo "Cellect BE version information done."

echo "###################### BE lab status  information ###################" >> $1/Result/report_${hostname}
$currentpath/check_lab_status.exp BE
cat lab_status.result >> $1/Result/report_${hostname} 
rm lab_status.result
echo "Cellect BE lab status information done."

echo "###################### BE Core Dump  information ###################" >> $1/Result/report_${hostname}
ls -lrt /sncore/*/* |grep sncore|grep -v ":$" >> $1/Result/report_${hostname}
echo "Collect core dump information done."

$currentpath/collect_be_paramters.sh  $1/Result/Configuration
cat  $1/Result/report_${hostname}

