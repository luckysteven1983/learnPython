"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines TgenTrafficProfile class
"""

class TgenTrafficProfile(object):
    """
    @details This class describes a Tgen traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        TgenTrafficProfile class constructor
        """

        self.scenario = ""
        self.tps = ""
        self.threads = ""
        self.application = ""
