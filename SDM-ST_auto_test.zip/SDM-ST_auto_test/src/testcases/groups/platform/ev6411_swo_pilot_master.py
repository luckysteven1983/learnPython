'''
Created on Aug 20, 2015

@author: Qinqin FAN
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ev6411_swo_pilot_master(SDMTestCase):
    '''swo control pilot on master BE'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.myDSM = self.sdmManager.databaseStateManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.success = True
        self.exceptMsg = ""

    def test_swo_pilot_master(self):
        '''swo control pilot on master BE'''

        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.info("start to swo pilot on master BE")
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getLabsInNRG("1")
        masterBE = self.myDSM.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.debug("swo pilot on master BE: " + startTime)

        LOGGER.info("%s: swo control pilot", masterBE.id)
        self.assertTrue(self.mcasMachineManager.pilotSwitchover(masterBE))

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", masterBE.id)

        LOGGER.debug("Check the alarms")
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(masterBE, myAlarmsConfig,
                                                                   logFile=LOGFILE[1])
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.error("%s: alarm check fail", masterBE.id)

        LOGGER.debug("check the end status of the test env")
        try:
            labs = [lab for lab in self.testEnv.testBed.labs.values() if lab is not masterBE]
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("ev6411_swo_pilot_master success!\n")
        else:
            LOGGER.error("ev6411_swo_pilot_master fail!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)
