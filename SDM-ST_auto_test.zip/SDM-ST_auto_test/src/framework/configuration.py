"""
Created on Feb 13, 2015
@file
@ingroup SDMSQA Automation
@author Yohann Martineau, Claude Le Du
@brief Defines the Configuration class
"""

import os
import re

from lxml import etree

from framework.common import Utils
from framework.testenv.account import Account
from framework.testenv.connection import Connection
from framework.testenv.lab import Lab
from framework.testenv.omniswitch_router import OmniswitchRouter
from framework.testenv.router import Router
from framework.testenv.test_bed import TestBed
from framework.testenv.test_env import TestEnv
from framework.traffic.disturbances import Disturbances
from framework.traffic.jmeter.jmeter_soap_traffic_simulator import JmeterSOAPTrafficSimulator
from framework.traffic.jmeter.jmeter_traffic_profile import JmeterTrafficProfile
from framework.traffic.mistral.mistral_sigtran_traffic_simulator import MistralSIGTRANTrafficSimulator
from framework.traffic.mistral.mistral_traffic_profile import MistralTrafficProfile
from framework.traffic.ptool.ptool_diameter_traffic_simulator import PtoolDiameterTrafficSimulator
from framework.traffic.ptool.ptool_traffic_profile import PtoolTrafficProfile
from framework.traffic.qiptool.qip_bulk_traffic_simulator import QiptoolBulkTrafficSimulator
from framework.traffic.qiptool.qiptool_traffic_profile import QiptoolTrafficProfile
from framework.traffic.spectra.spectra_sigtran_traffic_simulator import SpectraSIGTRANTrafficSimulator
from framework.traffic.spectra.spectra_traffic_profile import SpectraTrafficProfile
from framework.traffic.tgen.tgen_ldap_traffic_simulator import TgenLDAPTrafficSimulator
from framework.traffic.tgen.tgen_traffic_profile import TgenTrafficProfile
from framework.traffic.traffic_profile import TrafficProfile
from lib.alarm.alarm import Alarm
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)

class Configuration(object):
    """ @details Class to load all test environments and traffic profiles (trafficProfile) \
        from configuration file. """

    CONF_DIR_NAME = "conf"
    CONF_ENV_VAR = "sdm.auto.test.conf"
    DEFAULT_CONFIG_FILE = "configuration.xml"
    SCHEMA = "configuration.xsd"
    NAMESPACE = "{http://www.alcatel-lucent.com/}"


    configFile = Utils.findDir(CONF_DIR_NAME, "") + os.sep + DEFAULT_CONFIG_FILE
    if not os.path.isfile(configFile):
        configFile = os.environ.get(CONF_ENV_VAR)
        if not configFile or not os.path.isfile(configFile):
            LOGGER.error("configuration file not found")
            raise Exception("configuration file not found")

    def __init__(self, fileName=None):
        """ Configuration class constructor
        @param fileName   name of configuration file (default: configuration.xml)
        """

        self.file = Configuration.configFile
        if fileName:
            if os.path.isfile(fileName):
                self.file = fileName
            else:
                LOGGER.error("configuration file " + fileName + " not found")
                raise Exception("configuration file " + fileName + " not found")

        schemaFile = Utils.findDir(Configuration.CONF_DIR_NAME, "")\
            + os.sep + Configuration.SCHEMA

        xmlschema = etree.XMLSchema(file=schemaFile)  # pylint: disable=no-member
        xmlconfig = etree.parse(self.file)  # pylint: disable=no-member
        xmlschema.assertValid(xmlconfig)

        self.accounts = {}
        self.testEnvs = {}
        self.trafficProfiles = {}
        self.defaultTrafficProfile = None
        self.disturbances = None
        self.acceptedAlarms = []
        self.routers = {}


    def _loadAccount(self, accountEl):
        """ Private method to load an account from configuration file.
        @param accountEl object from lxml.etree containing an account section from xml configuration file
        @return account  instance of Account class """

        account = Account()
        accountType = accountEl.get("type")
        account.login = accountEl.get("user")
        account.password = accountEl.get("password")

        self.accounts[accountType] = account


    def _loadRouter(self, routerEl, sshManager):
        """ Private method to load a router from configuration file.
        @param routerEl object from lxml.etree containing a router section from xml configuration file
        @return account  instance of Router class """

        routerId = routerEl.get("id")
        routerIp = routerEl.find(Configuration.NAMESPACE + "ip").text
        routerType = routerEl.find(Configuration.NAMESPACE + "type").text


        accountType = routerEl.find(Configuration.NAMESPACE + "account").text
        account = self.accounts[accountType]
        prompt = routerEl.find(Configuration.NAMESPACE + "prompt").text
        if routerType in OmniswitchRouter.OMNISWITCH_TYPES:
            myRouter = OmniswitchRouter(sshManager, routerId, routerIp, routerType, account, prompt)
        else:
            myRouter = Router(routerId, routerIp, routerType, account, prompt)
        self.routers[myRouter.routerId] = myRouter


    def _loadTestEnv(self, testEnvEl, sshManager):
        """ Private method to load a test environment (testEnv) from configuration file.
        @param testEnvEl object from lxml.etree containing a testEnv section from xml configuration file
        @param sshManager instance of SshManager class
        @return testEnv  instance of TestEnv class """

        testEnv = TestEnv()
        testEnv.id = testEnvEl.get("id")
        testBedEl = testEnvEl.find(Configuration.NAMESPACE + "testBed")
        testBed = TestBed()
        testEnv.testBed = testBed
        for labEl in testBedEl.findall(Configuration.NAMESPACE + "lab"):
            lab = Lab()
            lab.id = labEl.get("id")

            # --- get the account for user and pw to use
            primAccountId = labEl.find(Configuration.NAMESPACE + "primaryAccount").text
            rootAccountId = labEl.find(Configuration.NAMESPACE + "rootAccount").text
            lab.primaryAccount = self.accounts[primAccountId]
            lab.rootAccount = self.accounts[rootAccountId]

            lab.oamIpAddress = labEl.find(Configuration.NAMESPACE + "host").text
            for connectionEl in labEl.findall(Configuration.NAMESPACE + "connection"):
                connection = Connection()
                routerId = connectionEl.find(Configuration.NAMESPACE + "routerId").text
                connection.router = self.routers[routerId]
                connection.flow = connectionEl.find(Configuration.NAMESPACE + "flow").text
                connection.vlan = connectionEl.find(Configuration.NAMESPACE + "vlan").text
                connection.interface = connectionEl.find(Configuration.NAMESPACE + "interface").text
                lab.connections.append(connection)
            testBed.labs[lab.id] = lab

        trafficSimulatorsEl = testEnvEl.find(Configuration.NAMESPACE + "trafficSimulators")

        provisioningEl = trafficSimulatorsEl.find(Configuration.NAMESPACE + "provisioning")
        if provisioningEl is not None:
            jmeterEl = provisioningEl.find(Configuration.NAMESPACE + "jmeter")
            if jmeterEl is not None:
                for simulatorEl in jmeterEl.findall(Configuration.NAMESPACE + "simulator"):
                    jmeter = JmeterSOAPTrafficSimulator(sshManager)
                    jmeter.toolIpAddress = simulatorEl.find(Configuration.NAMESPACE + "host").text
                    accountType = simulatorEl.find(Configuration.NAMESPACE + "account").text
                    jmeter.account = self.accounts[accountType]
                    testEnv.trafficSimulators.append(jmeter)

            qiptoolEl = provisioningEl.find(Configuration.NAMESPACE + "qiptool")
            if qiptoolEl is not None:
                for simulatorEl in qiptoolEl.findall(Configuration.NAMESPACE + "simulator"):
                    qiptool = QiptoolBulkTrafficSimulator()
                    qiptool.toolIpAddress = simulatorEl.find(Configuration.NAMESPACE + "host").text
                    accountType = simulatorEl.find(Configuration.NAMESPACE + "account").text
                    qiptool.account = self.accounts[accountType]
                    testEnv.trafficSimulators.append(qiptool)

        telecomEl = trafficSimulatorsEl.find(Configuration.NAMESPACE + "telecom")
        if telecomEl is not None:
            sigtranEl = telecomEl.find(Configuration.NAMESPACE + "sigtran")
            if sigtranEl is not None:
                mistralEl = sigtranEl.find(Configuration.NAMESPACE + "mistral")
                if mistralEl is not None:
                    for simulatorEl in mistralEl.findall(Configuration.NAMESPACE + "simulator"):
                        mistral = MistralSIGTRANTrafficSimulator()
                        mistral.toolIpAddress = simulatorEl.find(Configuration.NAMESPACE + "host").text
                        accountType = simulatorEl.find(Configuration.NAMESPACE + "account").text
                        mistral.account = self.accounts[accountType]
                        mistral.mistralIp = simulatorEl.find(Configuration.NAMESPACE + "mistralIp").text
                        testEnv.trafficSimulators.append(mistral)

                spectraEl = sigtranEl.find(Configuration.NAMESPACE + "spectra")
                if spectraEl is not None:
                    for simulatorEl in spectraEl.findall(Configuration.NAMESPACE + "simulator"):
                        spectra = SpectraSIGTRANTrafficSimulator()
                        spectra.toolIpAddress = simulatorEl.find(Configuration.NAMESPACE + "host").text
                        accountType = simulatorEl.find(Configuration.NAMESPACE + "account").text
                        spectra.account = self.accounts[accountType]
                        ftpAccountType = simulatorEl.find(Configuration.NAMESPACE + "ftpAccount").text
                        spectra.ftpAccount = self.accounts[ftpAccountType]
                        spectra.workspace = simulatorEl.find(Configuration.NAMESPACE + "workspace").text
                        testEnv.trafficSimulators.append(spectra)

            diameterEl = telecomEl.find(Configuration.NAMESPACE + "diameter")
            if diameterEl is not None:
                ptoolEl = diameterEl.find(Configuration.NAMESPACE + "ptool")
                if ptoolEl is not None:
                    for simulatorEl in ptoolEl.findall(Configuration.NAMESPACE + "simulator"):
                        ptool = PtoolDiameterTrafficSimulator(sshManager)
                        ptool.toolIpAddress = simulatorEl.find(Configuration.NAMESPACE + "host").text
                        accountType = simulatorEl.find(Configuration.NAMESPACE + "account").text
                        ptool.account = self.accounts[accountType]
                        ptool.application = simulatorEl.find(Configuration.NAMESPACE + "application").text
                        ptool.transport = simulatorEl.find(Configuration.NAMESPACE + "transport").text
                        testEnv.trafficSimulators.append(ptool)

            ldapEl = telecomEl.find(Configuration.NAMESPACE + "ldap")
            if ldapEl is not None:
                tgenEl = ldapEl.find(Configuration.NAMESPACE + "tgen")
                if tgenEl is not None:
                    for simulatorEl in tgenEl.findall(Configuration.NAMESPACE + "simulator"):
                        tgen = TgenLDAPTrafficSimulator(sshManager)
                        tgen.toolIpAddress = simulatorEl.find(Configuration.NAMESPACE + "host").text
                        accountType = simulatorEl.find(Configuration.NAMESPACE + "account").text
                        tgen.account = self.accounts[accountType]
                        tgen.application = simulatorEl.find(Configuration.NAMESPACE + "application").text
                        tgen.server = simulatorEl.find(Configuration.NAMESPACE + "server").text
                        testEnv.trafficSimulators.append(tgen)

        return testEnv

    def _loadTrafficProfile(self, trafficProfileEl):
        """ Private method to load a traffic profile (trafficProfile) from configuration file.
        @param trafficProfileEl object from lxml.etree containing a trafficProfile section from xml configuration file
        @return trafficProfile  instance of TrafficProfile class """

        trafficProfile = TrafficProfile()
        trafficProfile.id = trafficProfileEl.get("id")

        jmeterEl = trafficProfileEl.find(Configuration.NAMESPACE + "jmeter")
        if jmeterEl is not None:
            for jmeterEl in trafficProfileEl.findall(Configuration.NAMESPACE + "jmeter"):
                jmeter = JmeterTrafficProfile()
                jmeter.interface = jmeterEl.find(Configuration.NAMESPACE + "interface").text
                jmeter.workspace = jmeterEl.find(Configuration.NAMESPACE + "workspace").text
                jmeter.jmeterDir = jmeterEl.find(Configuration.NAMESPACE + "jmeter_dir").text
                jmeter.FE_Key = jmeterEl.find(Configuration.NAMESPACE + "FE_Key").text
                jmeter.tps = jmeterEl.find(Configuration.NAMESPACE + "tps").text
                trafficProfile.simulatorsTrafficProfiles.append(jmeter)

        qiptoolEl = trafficProfileEl.find(Configuration.NAMESPACE + "qiptool")
        if qiptoolEl is not None:
            for qiptoolEl in trafficProfileEl.find(Configuration.NAMESPACE + "qiptool"):
                qiptool = QiptoolTrafficProfile()
                qiptool.workspace = qiptoolEl.find(Configuration.NAMESPACE + "workspace").text
                qiptool.tps = qiptoolEl.find(Configuration.NAMESPACE + "tps").text
                trafficProfile.simulatorsTrafficProfiles.append(qiptool)

        mistralEl = trafficProfileEl.find(Configuration.NAMESPACE + "mistral")
        if mistralEl is not None:
            for mistralEl in trafficProfileEl.findall(Configuration.NAMESPACE + "mistral"):
                mistral = MistralTrafficProfile()
                mistral.gitTrafficDir = mistralEl.find(Configuration.NAMESPACE + "gitTrafficDir").text
                mistral.tps = mistralEl.find(Configuration.NAMESPACE + "tps").text
                trafficProfile.simulatorsTrafficProfiles.append(mistral)

        spectraEl = trafficProfileEl.find(Configuration.NAMESPACE + "spectra")
        if spectraEl is not None:
            for spectraEl in trafficProfileEl.findall(Configuration.NAMESPACE + "spectra"):
                spectra = SpectraTrafficProfile()
                spectra.model = spectraEl.find(Configuration.NAMESPACE + "model").text
                spectra.tps = spectraEl.find(Configuration.NAMESPACE + "tps").text
                trafficProfile.simulatorsTrafficProfiles.append(spectra)

        ptoolEl = trafficProfileEl.find(Configuration.NAMESPACE + "ptool")
        if ptoolEl is not None:
            for ptoolEl in trafficProfileEl.findall(Configuration.NAMESPACE + "ptool"):
                ptool = PtoolTrafficProfile()
                ptool.ptoolDir = ptoolEl.find(Configuration.NAMESPACE + "ptool_dir").text
                ptool.scenario = ptoolEl.find(Configuration.NAMESPACE + "scenario").text
                ptool.FE_Key = ptoolEl.find(Configuration.NAMESPACE + "FE_Key").text
                ptool.tps = ptoolEl.find(Configuration.NAMESPACE + "tps").text
                ptool.application = ptoolEl.find(Configuration.NAMESPACE + "application").text
                ptool.transport = ptoolEl.find(Configuration.NAMESPACE + "transport").text
                trafficProfile.simulatorsTrafficProfiles.append(ptool)

        tgenEl = trafficProfileEl.find(Configuration.NAMESPACE + "tgen")
        if tgenEl is not None:
            for tgenEl in trafficProfileEl.findall(Configuration.NAMESPACE + "tgen"):
                tgen = TgenTrafficProfile()
                tgen.scenario = tgenEl.find(Configuration.NAMESPACE + "scenario").text
                tgen.tps = tgenEl.find(Configuration.NAMESPACE + "tps").text
                tgen.threads = tgenEl.find(Configuration.NAMESPACE + "threads").text
                tgen.application = tgenEl.find(Configuration.NAMESPACE + "application").text
                trafficProfile.simulatorsTrafficProfiles.append(tgen)

        return trafficProfile

    def _loadDisturbanceByHardware(self, trafficType, trafficTypeEl):
        """ Private method to load all disturbances from configuration file for a given type of hardware
        @param trafficType type of traffic (provisioning, telecom)
        @param trafficTypeEl object from lxml.etree containing a section from xml configuration file """

        for disturbEl in trafficTypeEl:
            match = re.search(Configuration.NAMESPACE + "(.*)", disturbEl.tag)
            disturbName = match.group(1)
            for hardware in ["HP", "Bono", "Rouzic"]:
                disturbHardEl = disturbEl.find(Configuration.NAMESPACE + hardware)
                for releaseEl in disturbHardEl.findall(Configuration.NAMESPACE + "release"):
                    SDMRelease = releaseEl.get("id")
                    disturbTime = releaseEl.text
                    self.disturbances.setDisturbance(trafficType, disturbName, hardware, disturbTime, SDMRelease)
                    defaultEl = disturbHardEl.find(Configuration.NAMESPACE + "default")
                    defaultTime = defaultEl.text
                    self.disturbances.setDisturbance(trafficType, disturbName, hardware, defaultTime)


    def _loadTrafficDisturbances(self, disturbancesEl):
        """ Private method to load all disturbances from configuration file.
        @param disturbancesEl object from lxml.etree containing the disturbances section from xml configuration file
        @return disturbances instance of Disturbances class """

        self.disturbances = Disturbances()
        timeEl = disturbancesEl.find(Configuration.NAMESPACE + "time")
        provisioningEl = timeEl.find(Configuration.NAMESPACE + "provisioning")
        trafficType = "provisioning"
        self._loadDisturbanceByHardware(trafficType, provisioningEl)
        telecomEl = timeEl.find(Configuration.NAMESPACE + "telecom")
        trafficType = "telecom"
        self._loadDisturbanceByHardware(trafficType, telecomEl)


    def _loadAlarms(self, alarmsEl):
        """ Private method to load the list of alarms to be ignored from configuration file.
        @param alarmsEl object from lxml.etree containing the alarms section from xml configuration file """

        for alarmEl in alarmsEl.findall(Configuration.NAMESPACE + "alarm"):
            alarmId = alarmEl.get("id")
            severity = alarmEl.text
            alarm = Alarm(alarmCode=int(alarmId), severity=severity)
            self.acceptedAlarms.append(alarm)


    def load(self, sshManager):
        """ Method to load all test environments (testEnv), traffic profiles (trafficProfile)
        and disturbances from configuration file into a Configuration instance. """

        tree = etree.parse(self.file)  # pylint: disable=no-member
        root = tree.getroot()

        accountsEl = root.find(Configuration.NAMESPACE + "accounts")
        for accountEl in accountsEl.findall(Configuration.NAMESPACE + "account"):
            self._loadAccount(accountEl)

        routersEl = root.find(Configuration.NAMESPACE + "routers")
        for routerEl in routersEl.findall(Configuration.NAMESPACE + "router"):
            self._loadRouter(routerEl, sshManager)

        testEnvsEl = root.find(Configuration.NAMESPACE + "testEnvs")
        for testEnvEl in testEnvsEl.findall(Configuration.NAMESPACE + "testEnv"):
            testEnv = self._loadTestEnv(testEnvEl, sshManager)
            self.testEnvs[testEnv.id] = testEnv

        trafficProfilesEl = root.find(Configuration.NAMESPACE + "trafficProfiles")
        for trafficProfileEl in trafficProfilesEl.findall(Configuration.NAMESPACE + "trafficProfile"):
            trafficProfile = self._loadTrafficProfile(trafficProfileEl)
            self.trafficProfiles[trafficProfile.id] = trafficProfile

        self.defaultTrafficProfile = root.find(Configuration.NAMESPACE + "defaultTrafficProfile").text

        disturbancesEl = root.find(Configuration.NAMESPACE + "disturbances")
        self._loadTrafficDisturbances(disturbancesEl)

        alarmsEl = root.find(Configuration.NAMESPACE + "alarmsToIgnore")
        self._loadAlarms(alarmsEl)
