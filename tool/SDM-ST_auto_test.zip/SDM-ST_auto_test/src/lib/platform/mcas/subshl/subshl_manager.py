"""
@file subshl_manager.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-03-12
@brief Run the given subshl command and return its response

Run the given subshl command and return its response.
"""
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class SubshlManager(object):
    """Run subshl command and return its response.

    Usage:
        Let's take lab 135.251.83.201 as an example on how to get a SubshlManager
        instance.

        import SshManager, SubshlManager
        sshManager = SshManager()
        subshl = SubshlManager(sshManager)

        So then we can use instance subshl to call the methods provided by this
        class. On how to call the method, please check doc string in each
        method.
    """

    def __init__(self, sshManager):
        """Init SubshlManager instance with sshManager.

        Keyword arguments:
        sshManager -- an SSH or other protocol instance used for remote command
                    execution.
        """
        self._sshManager = sshManager

    def run(self, lab, subshlCmd):
        """Run subshl command and return its result.

        The subshl command should be a complete command. For example, in order
        to delete SPA, the complete command should be 'delete:proc,spa=OAMXXX;y'
        not 'delete:proc,spa=OAMXXX'.

        Example:
            subshlResponse = subshl.run(lab, 'op:status,machine=all')

            the subshlResponse should be a string including the subshl command
            output.

        Keyword arguments:
        subshlCmd -- subshl command to be executed.
        """
        cmd = "echo '%s' | /sn/cr/textsh -F" %subshlCmd
        return self._sshManager.run(lab.oamIpAddress, cmd)[1]
