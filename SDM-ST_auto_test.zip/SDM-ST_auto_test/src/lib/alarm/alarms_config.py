"""
@file
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines the AlarmsConfig class
"""

class AlarmsConfig(object):
    """
    @details This class describes a set of expected and acceptable alarms for a given test.
    It is made of:
    - a list of expected alarms
    - a list of accepted alarms
    - a starting date from which to start searching
    - a ending date at which to stop searching (optional) """

    STARTING_DATE = '0000-00-00 00:00:00'
    ENDING_DATE = '9999-99-99 99:99:99'

    def __init__(self, expectedAlarms=None, acceptedAlarms=None, startingDate=None,
                 endingDate=None, mustNotHaveAlarms=None):
        """
        AlarmsConfig class constructor
        @param expectedAlarms   list of expected alarms(from Alarm class)
        @param acceptedAlarms   list of accepted alarms(from Alarm class)
        @param mustNotHaveAlarms   list of MUST HAVE NOT alarms (from Alarm class)
        @param startingDate     a time string to start the search from (see snmplog time format)
        @param endingDate       a time string to stop the search from (see snmplog time format)
        """
        self.expectedAlarms = expectedAlarms if expectedAlarms else list()
        self.acceptedAlarms = acceptedAlarms if acceptedAlarms else list()
        self.mustNotHaveAlarms = mustNotHaveAlarms if mustNotHaveAlarms else list()
        self.startingDate = startingDate if startingDate else self.__class__.STARTING_DATE
        self.endingDate = endingDate if endingDate else self.__class__.ENDING_DATE
