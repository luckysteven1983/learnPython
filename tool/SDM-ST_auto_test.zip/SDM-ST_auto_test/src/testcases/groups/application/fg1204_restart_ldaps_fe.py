'''
Created on Oct. 29, 2015

@author: Tangi Lavanant
'''

import os

from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_manager import PROCESS_LDAP_SERVER, \
    SCRIPT_LDAP_SERVER
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fg1204_restart_ldaps_fe(SDMTestCase):
    """ Restart Ldap Server on blades of FE were LDAP processes are already running"""

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.myPA = self.sdmManager.platformAsserts
        self.myDM = self.sdmManager.databaseManager
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.success = True
        self.exceptMsg = ""

    def test_restart_ldap_fe(self):
        """ Restart Ldap Server on all blades of FE"""

        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check and return current active alarm list """

        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """ Restart Ldap Server on all blades of FE with LDAP service """
        stationLdap = []
        LOGGER.debug("Get a FE")
        _, fe = self.testEnv.testBed.getFrontends().popitem()
        LOGGER.debug("FE is " + fe.id)
        stations = fe.getAllBlade().keys()
        LOGGER.debug("check on which blades the LDAP process is alive")
        for blade in stations:
            try:
                self.sdmManager.linuxProcessManager.isAlive(fe, processName=PROCESS_LDAP_SERVER,
                                                             station=[blade], logLevel="debug")
                stationLdap.append(blade)
            except BaseException:
                pass

        LOGGER.debug("the station list with LDAP is: " + str(stationLdap))

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)

        LOGGER.info("Restart LDAP Server on LDAP blades of FE " + fe.id + " at: " + startTime)
        self.myDM.restartProcess(fe, SCRIPT_LDAP_SERVER, stationLdap)

        LOGGER.debug("check the LDAP process on stations can be recovered")
        self.myPA.assertProcessAliveOnStations(fe, PROCESS_LDAP_SERVER, stationLdap)

        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()

        return startTime

    def _postcheck(self, startTime):

        """ Test case post-check"""
        LOGGER.debug("Test case post-check")
        LOGGER.debug("Check the alarms")
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("fg1204_restart_ldaps_fe success!\n")
        else:
            LOGGER.error("fg1204_restart_ldaps_fe failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)

