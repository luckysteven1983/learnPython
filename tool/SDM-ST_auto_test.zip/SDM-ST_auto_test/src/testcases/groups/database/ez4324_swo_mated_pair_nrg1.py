"""
Created on Aug 20, 2015

@author: jiaxij
"""

import os
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ez4324_swo_mated_pair_nrg1(SDMTestCase):
    """Hardening: SWO mated pair on NRG1
    """

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_swo_mated_pair(self):
        """switch over mated pair
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case")
        # Get a time from any lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])

        belist = self.testEnv.testBed.getNRG("1")
        LOGGER.debug("Get master BE")
        masterBE = self.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is " + masterBE.id)

        beStates = dict((beObj.id, self.databaseStateManager.getState(beObj)) for beObj in belist)
        LOGGER.debug("BE state before: %s", str(beStates))

        LOGGER.debug("Switch over")
        self.databaseManager.matedPairSwo(belist)

        newStates = dict((beObj.id, self.databaseStateManager.getState(beObj)) for beObj in belist)
        LOGGER.debug("BE states after: %s", str(newStates))

        LOGGER.debug("Get new master BE after switch over")
        newMasterBE = self.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("new Master BE is " + newMasterBE.id)

        self.assertNotEqual(masterBE.id, newMasterBE.id, "new master BE id should not equal to original master BE id")

        self.assertEqual(beStates.values().sort(), newStates.values().sort(), "Other BE states are changed!")

        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check")

        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep
        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
