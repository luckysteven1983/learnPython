'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.traffic.telecom_traffic_simulator import TelecomTrafficSimulator

class SIGTRANTrafficSimulator(TelecomTrafficSimulator):
    '''
    classdocs: SIGTRANTrafficSimulator
    '''


    def __init__(self):
        '''
        Constructor
        '''
        super(SIGTRANTrafficSimulator,self).__init__()