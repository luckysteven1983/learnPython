'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.traffic.provisioning_traffic_simulator import ProvisioningTrafficSimulator

class SOAPTrafficSimulator(ProvisioningTrafficSimulator):
    '''
    classdocs
    '''


    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        super(SOAPTrafficSimulator,self).__init__(sshManager)

        