"""
@file ew9771_SU_CHECK_1rst_BE.py
@ingroup SU
@author Frank Zhang
@date 2015-05-12
@brief SU-CHECK on the first BE
"""
#import sys

import unittest
#import lib.exceptions_messages as eMsgs
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.softwareupdate.sdm_su_constants import SdmSuConst as ct

LOGGER = Logger.getLogger(__name__)

class ew9771_SU_CHECK_1rst_BE(SDMTestCase):
    """Unit test for SDM SU Class.
    """
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_ew9776_Verify(self):
        """
        Run Verify on the first BE
        """
        labIp = self.testEnv.testBed.labs.items()[0][1].oamIpAddress
        #labIp = self.testEnv.testBed.labs[self.labId].oamIpAddress.strip()
        lstActions = 'VERIFY'

        LOGGER.info("begin case ew9771: run VERIFY on the first BE [%s]", labIp)
        rst = self.sdmManager.sdmSuManager.startSu(labIp, lstActions)

        if rst != ct.RST_SUCCESS:
            LOGGER.error("case ew977 failed on lab [%s]", labIp)
            self.fail()

if __name__ == "__main__":
    unittest.main()
