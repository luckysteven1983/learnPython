"""Include all platform associated operations"""
