from distutils.core import setup
setup(name='sdm-auto-test',
      version='1.0',
      package_dir={'lib.ssh': 'src/lib/ssh'},
      packages=['lib.ssh'],
      )
