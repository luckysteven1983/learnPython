"""
This package contains all test suites (list of test cases by execution
frequency).
"""