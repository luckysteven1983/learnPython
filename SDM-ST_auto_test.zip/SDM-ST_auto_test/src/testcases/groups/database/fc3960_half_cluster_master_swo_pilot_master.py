'''
Created on Nov 30, 2015

@author: xzhao015
'''

import os
from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_state_manager import DDM_DB_INTERVAL_CHECK, \
    DDM_DB_SYNCHRO_TIMEOUT_HALF_CLUSTER
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fc3960_half_cluster_master_swo_pilot_master(SDMTestCase):
    """setup half cluster on BE MASTER and swo control pilot on MASTER
    capture the alarms on FE, check spa status on FE
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.multiTasksManager = self.sdmManager.multiTasksManager

    def test_half_cluster_master_swo_pilot_master(self):
        """
        setup half cluster on BE MASTER and swo control pilot on MASTER
        """
        self._precheck()
        startTime, masterBE = self._runTestCase()
        self._postcheck(startTime, masterBE)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _halfClusterMaster(self, lab, parity):
        """Half cluster reset on lab"""
        LOGGER.debug("Half cluster reset on BE %s", lab.id)
        self.sdmManager.databaseManager.setHalfClusterBE(lab, parity)
        # wait 8 hours to ndb up (worst case). this will be changed later through parsing configuration.xml
        # file
        CommonAssert.timedAssert(DDM_DB_SYNCHRO_TIMEOUT_HALF_CLUSTER, DDM_DB_INTERVAL_CHECK,
                                 self.sdmManager.databaseStateManager.assertNdbState,
                                 lab, 'started', logLevel='debug')

    def _swoPilot(self, lab):
        """swo control pilot on lab"""
        self.assertTrue(self.sdmManager.mcasMachineManager.pilotSwitchover(lab))

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case")
        #choose which half-cluster will be restarted
        parity = 0
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        # Half cluster reset on any master BE.
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(self.allBEs)[0]

        LOGGER.info("Half cluster reset on master BE '%s' in progress", masterBE.id)
        self._halfClusterMaster(masterBE, parity)

        LOGGER.info("swo control pilot on Lab '%s' in progress", masterBE.id)
        self._swoPilot(masterBE)

        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime, masterBE

    def _postcheck(self, startTime, masterBE):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        try:
            labs = [lab for lab in self.testEnv.testBed.labs.values() if lab is not masterBE]
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
