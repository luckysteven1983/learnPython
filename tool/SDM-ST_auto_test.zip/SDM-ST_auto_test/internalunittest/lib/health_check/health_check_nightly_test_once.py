"""
@file health_check_nightly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-14
@brief health check for system
"""

import unittest
import lib.exceptions_messages as eMsgs
from lib.health_check.health_check_manager import HealthCheckManagerError
from lib.health_check.health_check_manager import HealthCheckManager
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.testenv.lab import Lab

LOGGER = Logger.getLogger(__name__)

class health_check_nightly_test_once(SDMTestCase):
    """Unit test for HealthCheck class.
    """

    def setUp(self):
        self.logLinksPrint()
        LOGGER.info("TestHealthCheckManager Test Once")
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()

    def test_01_No_health_Check_Tool(self):
        """Rainy day cases.

        Health check tool is not installed on target lab.
        """
        print '\n[Test case 01] Health check tool not installed'

        myFun = HealthCheckManager(self.sdmManager.sshManager, self.sdmManager.multiTasksManager).verifyToolInstalled
        lab = Lab()
        lab.oamIpAddress = self.be.oamIpAddress
        lab.id = "fakeLabBasedOn" + self.be.id
        self.assertRaisesRegexp(HealthCheckManagerError, eMsgs.HEALTH_CHECK_TOOL_NOK, myFun, lab, "/NoSuchDir")

    def test_02_Check_All(self):
        """Check All OK
        """
        LOGGER.info('[Test case 02] Check All OK')
        self.sdmManager.healthCheckManager.runCheckAll(self.fe)
        self.sdmManager.healthCheckManager.runCheckAll(self.be)

        checkPoints = ['Spa', 'Machine', 'Station']
        self.sdmManager.healthCheckManager.runCheckAll(self.fe, checkPoints)

        checkPoints = ['SPA', 'proc']
        self.sdmManager.healthCheckManager.runCheckAll(self.be, checkPoints)

        checkPoints = ['Spa1', 'Proc']
        self.assertRaisesRegexp(HealthCheckManagerError, eMsgs.HEALTH_CHECK_POINT_NOK,
                                self.sdmManager.healthCheckManager.runCheckAll,
                                self.fe, checkPoints)

    def test_03_Check_Success(self):
        """Health Check Successful
        """
        LOGGER.info('[Test case 03] Health Check Successful')

        LOGGER.debug('healthCheckManager on SPA')
        self.sdmManager.healthCheckManager.runCheckSpa(self.fe)
        self.sdmManager.healthCheckManager.runCheckSpa(self.be)

        LOGGER.debug('healthCheckManager on Machine')
        self.sdmManager.healthCheckManager.runCheckMachine(self.fe)
        self.sdmManager.healthCheckManager.runCheckMachine(self.be)

        LOGGER.debug('healthCheckManager on Station')
        self.sdmManager.healthCheckManager.runCheckStation(self.fe)
        self.sdmManager.healthCheckManager.runCheckStation(self.be)

        LOGGER.debug('healthCheckManager on NDB')
        self.sdmManager.healthCheckManager.runCheckNdb(self.be)

        LOGGER.debug('healthCheckManager on Proc')
        self.sdmManager.healthCheckManager.runCheckProc(self.fe)
        self.sdmManager.healthCheckManager.runCheckProc(self.be)

        LOGGER.debug('healthCheckManager on Helpme')
        self.sdmManager.healthCheckManager.runCheckHelpme(self.fe, 'ip')
        self.sdmManager.healthCheckManager.runCheckHelpme(self.be, 'ip')

if __name__ == "__main__":
    unittest.main()

