"""
contains SU (global software update) tests, including data model schema update
"""
