"""
@author: jiaxij

In order to do auto hotslide we use this tool prepare a to-do list in
which paralleled and sequential job IPs
are separated by spaces and semicolons.
"""

import argparse
import os
import sys

from framework.configuration import Configuration
from framework.env_checker import EnvChecker
from framework.version_manager import VersionManager
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from lib.database.ddm.database_state_manager import DatabaseStateManager
from lib.common.multi_tasks_manager import MultiTasksManager

LOGGER = Logger.getLogger(__name__)

def printLabListToFile(lablist, filename, mode='a'):
    """print a list of labs to a specified file with format"""
    with open(filename, mode) as filehandler:
        #filehandler.write(';'.join(lablist) + '\n')
        for labItem in lablist:
            filehandler.write(labItem.oamIpAddress + ' m;')
        filehandler.write('\n')

def getToDoList(testEnv, sshManager, args):
    """get to-do list prepared for auto hotslide"""
    allBEList = testEnv.testBed.getBackends().values()
    dsm = DatabaseStateManager(sshManager)
    masterBEList = dsm.getMasterBE(allBEList)
    nonMasterBEList = list(set(allBEList) - set(masterBEList))
    allFEList = testEnv.testBed.getFrontends().values()

    printLabListToFile(nonMasterBEList, args.output, 'w')
    printLabListToFile(masterBEList, args.output, 'a')
    printLabListToFile(allFEList, args.output, 'a')

def main():
    """ main"""
    parser = argparse.ArgumentParser(description="simple demo main")
    parser.add_argument("--testenv",
                        help="name of test environment from configuration.xml (required)",
                        required=True)
    parser.add_argument("--output",
                        help="path and name of the output file(required)",
                        required=True)
    args = parser.parse_args()
    testEnvParam = args.testenv
    LOGGER.info("test environment: " + testEnvParam)

    sshGateway = os.getenv("SSH_GATEWAY")
    sshUser = os.getenv("SSH_GATEWAY_USER")
    sshPassword = os.getenv("SSH_GATEWAY_PASSWORD")
    sshManager = SshManager(sshGateway, sshUser, sshPassword)

    configuration = Configuration()
    configuration.load(sshManager)

    try:
        testEnv = configuration.testEnvs[testEnvParam]
        versionManager = VersionManager(sshManager)
        multiTasksManager = MultiTasksManager()
        envChecker = EnvChecker(sshManager, versionManager, multiTasksManager)
        envChecker.checkInitialState(testEnv)
        getToDoList(testEnv, sshManager, args)

    except BaseException:
        LOGGER.error("Failed to generate lab list with provided testenv.")
        #raise Exception("Error in generating list of labs")
        return 1

    sshManager.closeAllClients()
    LOGGER.info("Generate lab list in hotslide_list succeeded.")
    return 0

if __name__ == '__main__':
    sys.exit(main())
