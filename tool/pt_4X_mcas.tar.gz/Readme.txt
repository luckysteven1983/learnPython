1.	Install pt tool from lincase
Invoke install_pt4.3.exp to install this tool on lab /MDS/pt:
./install_pt4.3.exp FE|BE host1 [ host2 ��]
2.	Manually install pt tool on lab
 Manually Install the tool on FE and BE when blade restart or switchover:
./install.sh  (for help)
{prompt}sh install.sh FE pt_4.3.0_mcas.tar.gz  ��for FE��
{prompt}sh install.sh BE pt_4.3.0_mcas.tar.gz   (for BE)
3.	Tool Usage
o	Set view
pt setview dirname (the filename is the directory that the logs will be collected to )
pt lsview: { } : list the view you are using
o	Change to tool direcotry
pt cd   (Go to the directory where all the logs are collected )
pt cddone: { } : cd the Done subdir of logs's dir
pt lsdone: { } : ls the Done subdir of logs's dir
o	Start logs collection 
pt startlog all  (start to collect logs, do after the test begin)
pt lslog: {<sta_letter> |all|pilot|npilot|  } : list the logging on stations.
o	Stop logs collection
pt stoplog all  (stop to collect logs, do after the test end)
pt done: { } : collect logs from all stations.
o	Connect to Log Server
pt upload : help to upload test report to pt server
o	List core files
pt cores: { [0-9]*hour|[0-9]*min|[0-9]*day|[0-9]* } : list cores

