'''
Created on Jun 1, 2015

@author: Andy Sun
'''
import unittest
from lib.logging.logger import Logger
from lib.platform.linux_process_manager import LinuxProcessManagerError
import lib.exceptions_messages as msgs
from framework.sdm_test_case import SDMTestCase
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class linux_kill_process_nightly_test_once(SDMTestCase):
    """Unit test for the method killProcess2 in LinuxProcessManager"""

    def setUp(self):
        """Setup env"""
        LOGGER.info("Linux Process Manager kill process Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.advancedKillWaitProcess = self.sdmManager.linuxProcessManager.advancedKillWaitProcess
        self.processName = 'PDLSI'

    def test_01_No_Such_Process_On_blade(self):
        """No such process on given blades"""
        blade = ['0-0-1']
        LOGGER.info("Test 01: No process %s on blade %s", self.processName, str(blade))
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.GET_PID_FAIL,
                                self.advancedKillWaitProcess, self.fe, self.processName, blade)

    def test_02_No_Such_Process_On_BE(self):
        """No such process on BE"""
        LOGGER.info("Test 02: No process %s on BE", self.processName)
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.NO_PROCESS_FOUND,
                                self.advancedKillWaitProcess, self.be, self.processName)

    def test_03_Kill_Process_And_Wait(self):
        '''
        Kill process and wait process restart in given time
        chose 2 real time  board of self.fe
        before it was
        if self.lab.hardware == 'VMMHI':
            blade = ['0-0-2', '0-0-10']
        else :
           blade  = ['0-0-12', '0-0-14']
        intervalTime is used to avoid execute time to be smaller than assert time
        '''
        blade = self.fe.getStationListbyProductRole('RT').keys()[:2]

        waitTime = 1800
        intervalTime = 30
        LOGGER.info("Test 03: Kill process %s on blade %s and wait boot in %d seconds",
                    self.processName, str(blade), waitTime)
        self.advancedKillWaitProcess(self.fe, self.processName, blade, waitTime)
        LOGGER.info("Kill process %s success", self.processName)

        # Need to wait SDM SPA become IS on 0-0-12 and 0-0-14
        LOGGER.info("Wait SDM SPA IS before next test case")
        myAssert = self.sdmManager.testEnvAsserts.assertStationOK
        CommonAssert.timedAssert(waitTime, intervalTime , myAssert, self.fe, blade[0], logLevel='debug')
        CommonAssert.timedAssert(waitTime, intervalTime , myAssert, self.fe, blade[1], logLevel='debug')

if __name__ == "__main__":
    unittest.main()
