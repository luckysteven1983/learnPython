"Unit test for core check"
