"""
Created on Apr 16, 2015

@author: Claude Le Du
"""

import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
import time
import lib.exceptions_messages as msgs

logger = Logger.getLogger(__name__)


class verif_QoS_all_traffics(SDMTestCase):


    def setUp(self):
        logger.debug("setUp")
        self.logLinksPrint()#Used to get the log links in Junit XML results


    def tearDown(self):
        logger.debug("tearDown")


    def testVerifQoSAllTraffics(self):
        logger.debug("testCheckQosAllTraffics")
        trafficManager = self.sdmManager.trafficManager

#         logger.info("Waiting " + str(self.timerFirstQos) + " min...") # pylint: disable=no-member
#         timerInSec = int(self.timerFirstQos) * 60 # pylint: disable=no-member
#         time.sleep(timerInSec)
#         trafficManager.checkQoSAllTraffics()
#         logger.info("Calling trafficManager.checkErrorsAllTraffics...")
        trafficManager.setQoSStartingPointAllTraffics()
        time.sleep(20)
        logger.info("Calling trafficManager.checkQoSFinalPointAllTraffics...")
        trafficManager.checkQoSFinalPointAllTraffics()
                    

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'EmptyTest.testName']
    unittest.main()
