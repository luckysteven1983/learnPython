'''
Created on Feb 17, 2015

@author: yohannm,tangil
'''
from unittest.case import TestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class SDMTestCase(TestCase):
    '''
    This class should be used for all test.
    One of the goal is to print the links to log file in xml reports
    '''
    def __init__(self, methodName='runTest'):
        super(SDMTestCase, self).__init__(methodName)
        self.testEnv = None
        self.sdmManager = None
        self.testLabs = None
        self.testParams = None

    def logLinksPrint(self):
        '''
        Goal of this function is to print links to log files in xml test report
        This function is empty for the moment as it is called in every TC
        '''
        #print is used because it is the only way found to get infos in xml junit file
        #Logger not working in this case