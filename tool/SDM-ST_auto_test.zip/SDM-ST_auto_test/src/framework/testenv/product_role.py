'''
Created on Feb 13, 2015

@author: yohannm
'''

class ProductRole(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
