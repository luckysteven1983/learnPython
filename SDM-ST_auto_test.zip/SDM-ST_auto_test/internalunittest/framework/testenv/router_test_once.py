"""
Created on Sept 30, 2015

@author: Claude Le Du
"""
import re
import unittest

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

ROUTER_TYPE_6850 = "6850"
ROUTER_TYPE_6900 = "6900"
GDMP_FLOW = "GDMP"

class router_test_once(SDMTestCase):
    """
    This class is to test methods from router class
    """

    def setUp(self):
        LOGGER.info("Setup of router test once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.myFE = self.testEnv.testBed.getFrontends().popitem()
        for aConnection in self.myFE.connections:
            if aConnection.flow == GDMP_FLOW:
                self.myRouter = aConnection.router
                self.myConnection = aConnection
                break
        if not self.myRouter:
            self.skipTest("Requires router definition with GDMP flow for " + self.myFE.id)

    def tearDown(self):
        pass

    def test_1_show_vlan(self):
        """ Run show vlan command on router from 1st found FE """
        stdoutList, _ = self.myRouter.showVlan()
        self.assertFalse(stdoutList == [], "stdout from showVlan is empty")
        LOGGER.debug("showVlan => " + str(stdoutList))
        stdoutList, _ = self.myRouter.showVlan(port=True)
        self.assertNotEquals(len(stdoutList), 0, "stdout from showVlan(port) is empty")
        LOGGER.debug("showVlan port => " + str(stdoutList))

    def test_2_showInterfaces(self):
        """ Run show interfaces command on router from 1st found FE """
        stdoutList, _ = self.myRouter.showInterfaces()
        self.assertNotEquals(len(stdoutList), 0, "stdout from showInterface is empty")
        LOGGER.debug("showVlan => " + str(stdoutList))

    def test_3_clearARPTables(self):
        """ Run clear arp-cache command on router from 1st found FE """
        self.myRouter.clearARPTables()

    def test_4_disableEnableVlan(self):
        """ Run vlan <vlan> [admin-state] disable/enable command on router from 1st found FE """
        self.myRouter.disableVlan(vlan=self.myConnection.vlan)
        stdoutList, _ = self.myRouter.showVlan()
        for line in stdoutList:
            if line[0] == self.myConnection.vlan:
                # line[0]: #vlan, line[2]: administrative state
                if self.myRouter.type == ROUTER_TYPE_6850:
                    status = "off"
                elif self.myRouter.type == ROUTER_TYPE_6900:
                    status = "Dis"
                else:
                    self.fail("Unknown router type")
                self.assertEquals(line[2], status, "vlan " + self.myConnection.vlan + " is not disabled" )
                break

        self.myRouter.enableVlan(vlan=self.myConnection.vlan)
        stdoutList, _ = self.myRouter.showVlan()
        for line in stdoutList:
            if line[0] == self.myConnection.vlan:
                # line[0]: #vlan, line[2]: administrative state
                if self.myRouter.type == ROUTER_TYPE_6850:
                    status = "on"
                elif self.myRouter.type == ROUTER_TYPE_6900:
                    status = "Ena"
                else:
                    self.fail("Unknown router type")
                self.assertEquals(line[2], status, "vlan " + self.myConnection.vlan + " is not enabled" )
                break

    def test_6_interfaceDownUp(self):
        """ Run interfaces <interface> admin down/disable/up/enable command on router from 1st found FE """
        self.myRouter.interfaceDown(interface=self.myConnection.interface)
        stdoutList, _ = self.myRouter.showInterfaces()
        for line in stdoutList:
            if line != [] and re.match("[0-9]", line[0]):
                if line[0] == self.myConnection.interface:
                    # line[0]: #slot/port, line[1]: administrative status
                    self.assertEquals(line[1], "disable", "interface " + self.myConnection.interface +
                                      " is not disabled" )
                    break

        self.myRouter.interfaceUp(interface=self.myConnection.interface)
        stdoutList, _ = self.myRouter.showInterfaces()
        for line in stdoutList:
            if line != [] and re.match("[0-9]", line[0]):
                if line[0] == self.myConnection.interface:
                    # line[0]: #slot/port, line[1]: administrative status
                    self.assertEquals(line[1], "enable", "interface " + self.myConnection.interface +
                                      " is not enabled" )
                    break

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
