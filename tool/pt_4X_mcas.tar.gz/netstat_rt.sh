#!/bin/sh

while [ 1 ]
do  
   echo `date`
   netstat -nap|grep  LISTEN|grep PDLS 
   sleep $1
done
