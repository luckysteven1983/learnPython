'''
Created on Nov 24, 2015

@author: xzhao015
'''
from lib.hardware.atcav2_hardware_machine_manager import AtcaV2HardwareMachineManager
from lib.hardware.hp_hardware_machine_manager import HpHardwareMachineManager
from lib.hardware.vmmhi_hardware_machine_manager import VmmhiHardwareMachineManager
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
LOGGER = Logger.getLogger(__name__)

class HardwareManagerFactoryError(BaseException):
    """If error, raise it."""
    pass

class HardwareManagerFactory(object):
    '''
    module for hardware manager factory
    '''


    def __init__(self, sshManager, mcasMachineManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager
        self.mcasMachineManager = mcasMachineManager

    def createHardwareManager(self, lab):
        """
        detect the hardware type of the lab
        create the appropriate HardwareMachineManager object
        """
        hardwareManager = None
        if lab.hardware in ['ROUZIC', 'BONO24', 'BONO48']:
            hardwareManager = AtcaV2HardwareMachineManager(self.sshManager, self.mcasMachineManager)
        elif lab.hardware in ['HPG6', 'HPG8']:
            hardwareManager = HpHardwareMachineManager(self.sshManager, self.mcasMachineManager)
        elif lab.hardware in ['VMMHI']:
            hardwareManager = VmmhiHardwareMachineManager(self.sshManager, self.mcasMachineManager)
        else:
            exceptMsg = msgs.UNSUPPORTED_HARDWARE + ": " + lab.hardware
            LOGGER.error(exceptMsg)
            raise HardwareManagerFactoryError, exceptMsg
        return hardwareManager