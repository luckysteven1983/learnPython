"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines MistralTrafficProfile class
"""

class MistralTrafficProfile(object):
    """
    @details This class describes a Mistral traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        MistralTrafficProfile class constructor
        """

        self.gitTrafficDir = ""
        self.tps = ""
