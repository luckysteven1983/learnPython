'''
Created on May 7, 2015

@author: xzhao015
'''
import unittest

from framework.asserts.common_asserts import CommonAssert
from framework.testenv.lab import Lab

class common_assert_test(unittest.TestCase):

    def setUp(self):
        self.CA=CommonAssert
        self.lab = Lab()

    def test_01_assertTrue(self):
        self.CA.assertTrue(True)
        self.assertRaises(BaseException, self.CA.assertTrue,False,logLevel='debug')

    def test_02_assertFalse(self):
        self.CA.assertFalse(False)
        self.assertRaises(BaseException, self.CA.assertFalse,True,logLevel='debug')

    def test_03_assertEqual(self):
        def myadd(a, b):
            return int(a)+int(b)
        self.CA.assertEqual('1','1')
        self.CA.assertEqual(2,myadd(1,1))
        self.CA.assertEqual(myadd(0,2),myadd(1,1))
        self.assertRaises(BaseException, self.CA.assertFalse,'1','2',logLevel='debug')
        self.assertRaises(BaseException, self.CA.assertFalse,2,myadd(1,2),logLevel='debug')

    def test_04_assertNotEqual(self):
        def myadd(a, b):
            return int(a)+int(b)
        self.CA.assertNotEqual('1','2')
        self.CA.assertNotEqual(2,myadd(2,1))
        self.assertRaises(BaseException, self.CA.assertNotEqual,'1','1',logLevel='debug')
        self.assertRaises(BaseException, self.CA.assertNotEqual,2,myadd(1,1),logLevel='debug')

    def test_05_assertIn(self):
        self.CA.assertIn('1',['1','2'])
        self.assertRaises(BaseException, self.CA.assertIn,'1',['2','3'],logLevel='debug')

    def test_06_assertNotIn(self):
        self.CA.assertNotIn('1',['3','2'])
        self.assertRaises(BaseException, self.CA.assertNotIn,'1',['1','3'],logLevel='debug')

    def test_07_timedAssert(self):
        self.CA.timedAssert(2,1,self.CA.assertEqual,'1','1')
        self.assertRaises(BaseException, self.CA.timedAssert,2,1,self.CA.assertEqual,'2','1',logLevel='debug')

    def test_08_assertIsInstance(self):
        self.CA.assertIsInstance(self.lab,Lab)
        self.assertRaises(BaseException, self.CA.assertIsInstance,'1',unittest,logLevel='debug')

    def test_09_assertNotIsInstance(self):
        self.CA.assertNotIsInstance('1',CommonAssert)
        self.assertRaises(BaseException, self.CA.assertNotIsInstance,self.lab,Lab,logLevel='debug')

    def test_10_assertRaises(self):
        self.CA.assertRaises(BaseException, self.CA.assertEqual, '1', '2')
        self.assertRaises(BaseException, self.CA.assertRaises,BaseException,'debug', self.CA.assertEqual, '1', '1',logLevel='debug')

    def test_11_assertAlmostEqual(self):
        self.CA.assertAlmostEqual(1.1,1.2,0)
        self.CA.assertAlmostEqual(1.0001,1.0002,3)
        self.CA.assertAlmostEqual(1.00000001,1.00000002)
        self.assertRaises(BaseException, self.CA.assertAlmostEqual,1.1,1.2,logLevel='debug')
        self.assertRaises(BaseException, self.CA.assertAlmostEqual,1.01,1.02,2,logLevel='debug')

    def test_12_compare(self):
        self.CA.assertLess(1.1,1.2)
        self.assertRaises(BaseException, self.CA.assertLess,1.3,1.2,logLevel='debug')
        self.CA.assertLessEqual(1.1,1.1)
        self.assertRaises(BaseException, self.CA.assertLessEqual,1.2,1.1,logLevel='debug')
        self.CA.assertGreater(1.3,1.2)
        self.assertRaises(BaseException,  self.CA.assertGreater,1.1,1.2,logLevel='debug')
        self.CA.assertGreaterEqual(1.1,1.1)
        self.assertRaises(BaseException, self.CA.assertGreaterEqual,1.2,1.4,logLevel='debug')
    def test_13_assertNone(self):
        self.CA.assertIsNone(None)
        self.assertRaises(BaseException, self.CA.assertIsNone,1.3,logLevel='debug')
        self.CA.assertIsNotNone(1)
        self.assertRaises(BaseException, self.CA.assertIsNotNone,None,logLevel='debug')

    def test_14_assertListEqual(self):
        self.CA.assertListEqual([1,2],[1,2])
        self.assertRaises(BaseException, self.CA.assertListEqual,[1],[1,2],logLevel='debug')

    def test_15_assertTupleEqual(self):
        self.CA.assertTupleEqual((1,2),(1,2))
        self.assertRaises(BaseException, self.CA.assertTupleEqual,(1,2),(2,1),logLevel='debug')

    def test_16_assertDictEqual(self):
        dic1={'1':'a','2':'b'}
        dic2={'2':'b','1':'a'}
        dic3={'1':'c','2':'b'}
        self.CA.assertDictEqual(dic1,dic2)
        self.assertRaises(BaseException, self.CA.assertDictEqual,dic2,dic3,logLevel='debug')

    def test_17_assertListAlmostEqual(self):
        self.CA.assertListAlmostEqual([1,2],[2,1])
        self.assertRaises(BaseException, self.CA.assertListAlmostEqual,[1],[1,2],logLevel='debug')

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()