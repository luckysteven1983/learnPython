'''
Created on Jan 30, 2015

@author: yohannm
'''

class Station(object):
    '''
    classdocs
    '''

    def __init__(self):
        """rcs_hostname"""
        self.rcsHostname = ""
        """ddm_hostname"""
        self.ddmHostname = ""
        """pilot Non-pilot"""
        self.middlewareRole = ""
        self.toolIpAddress = None
        self.serialIp = None
        """iLB ss7 RT DB"""
        self.productRole = []
        self.mysqlNodeID = ""
