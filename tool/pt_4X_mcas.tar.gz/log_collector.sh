#This script is used to mearge OM, snmp, meas, debug logs of the test to one file.
for log in OMlog snmplog measlog debuglog
do
    echo "Now begin to process $log....."
    if [ -f ${log}* ]; then
	ls -lrt ${log}*|awk '{print $9}' > meas_files
       	key=`cat log.ini`
        #echo "Current timestamp key is $key."
	key_len=16
	flag=1
	#Use the timestamp YYYY-mm-dd HH:MM when logs begin to be collected as the key word
	#If the key word can be found in some of the logs, find out this log file and record the line number when this key word appears.
	#If the key word can\'t be found in the logs, change the key word to enlarge the search scope, until use YYYY-mm-dd timestamp to search the log file and line number
		
	while [ "$flag" -gt 0 -a "$key_len" -gt 11 ] 
	do
            num=`grep "$key" ${log}*|wc -l`
	    if [ $num -gt 0 ]; then
	        key_file=`grep -l "$key" ${log}*|head -1|awk '{print $1}'`
	       # echo "The file that log begin: $key_file."
	        key_start=`sed -n "/$key/=" $key_file|head -1`
               # echo "The begining line is $key_start."			   
	        key_end=`sed -n '$=' $key_file`
	       # echo "The ending line is $key_end."	
	        sed -n "$key_start,$key_end p"  $key_file > ${log}.tlog
	        meas_start=`sed -n "/$key_file/=" meas_files`
               # echo "meas_start=$meas_start" 
	        flag=0
	     else
                echo "Can't find the log begin time, try again."
	        let key_len--
		key=`cat log.ini|cut -c1-$key_len`
          	#echo "New searching scope timestamp key is $key."
	    fi	
        done
		
	let meas_start++
        #echo "New keyfile meas start is $meas_start"
	meas_end=`sed -n '$=' meas_files`
	if [ $meas_start -le $meas_end ]; then
           for file in `sed -n "$meas_start,$meas_end p" meas_files`
           do
	        cat $file >> ${log}.tlog
           done
	fi
      rm meas_files
    fi		
done
