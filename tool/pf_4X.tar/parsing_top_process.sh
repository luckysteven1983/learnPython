#!/bin/bash

#Function: This script is used to analysis cpu&memory data from top output.
#This script supports HP,BONO,ROUZIC 3 hardware types.
#This script also supports FE, BE performance data analysis.

#Usage: ./parsed_top_process.sh

#ProcFunction: This procedures is used to get time and resource usage of one process.
#Usage: filter_proc process_name

############################################
#### Version 0.2
#### Add BE option 
#### Nov. 4th, 2015
############################################
if [ ! -x "$1" ];then
    echo "Done data path: $1 does not exist!"
    exit 1
else
    cd $1
fi
function filter_proc {
proc=$1
gawk '
$0 ~ /top -/ {Time=$3;}
$12 == "'"$proc"'"  { printf("Time: %8s\t%s\n", Time, $0); }
' 
}

#ProcFunction: This procedures is used to get cpu usage of one process on one blade or station.
#Usage: cpu_parser_proc process_name blade_number
#       process_name: PDLSI1 PDLSL1 PDLSU1 PDLSM1 OamCOMM
#       blade_number: A B C D E F G H I J K L M N O P 
function cpu_parser_proc {
proc=$1
sta=$2
#Sometimes there are 2 pid with the same process name, find out the right one
num=`cat ${proc}_${sta}.txt |awk '{ print $3}' | sort | uniq |wc -l`
if [ $num -eq 1 ]; then
  cat ${proc}_${sta}.txt |awk '{ print $2,$11 }' > ${proc}_${sta}_cpu.tmp
else
  for pid in `cat ${proc}_${sta}.txt |awk '{ print $3}' | sort | uniq`
  do
     cat ${proc}_${sta}.txt |grep $pid |wc -l|awk '{ printf "%8s\t%10d\n", "'"$pid"'", $1 }' >> tmp
  done
  wrong_pid=`sort -n -k2 tmp|head -1|awk '{ print $1}'`
  rm tmp
  cat ${proc}_${sta}.txt|grep -v $wrong_pid|awk '{ print $2,$11 }' > ${proc}_${sta}_cpu.tmp
fi

awk '{ if(min=="") {min=max=$2}; if($2>=max) {max=$2;MaxTime=$1}; if($2<=min) {min=$2;MinTime=$1}; total+=$2; count+=1} END {printf "%-10s\t%-7s\t%5.1f\t%5.1f\t%8s\t%-5.1f\t%8s\n","'"$proc"'", "'"$sta"'",total/count,min,MinTime,max,MaxTime}' ${proc}_${sta}_cpu.tmp >> process_cpu.report
mv ${proc}_${sta}_cpu.tmp ${proc}_${sta}_cpu.txt
}

#ProcFunction: This procedures is used to get mem usage of one process on one blade or station.
#Usage: mem_parser_proc process_name blade_number
#       process_name: PDLSI1 PDLSL1 PDLSU1 PDLSM1 OamCOMM
#       blade_number: A B C D E F G H I J K L M N O P 
function mem_parser_proc {
proc=$1
sta=$2
#In case there are more than one PID have same process name, remove its data from original file; 
num=`cat ${proc}_${sta}.txt |awk '{ print $3}' | sort | uniq |wc -l`
if [ $num -gt 1 ]; then
  for pid in `cat ${proc}_${sta}.txt |awk '{ print $3}' | sort | uniq`
  do
     cat ${proc}_${sta}.txt |grep $pid |wc -l|awk '{ printf "%8s\t%10d\n", "'"$pid"'", $1 }' >> tmp
  done
  wrong_pid=`sort -n -k2 tmp|head -1|awk '{ print $1}'`
  rm tmp
  cat ${proc}_${sta}.txt|grep -v $wrong_pid > ${proc}_${sta}.tmp
  mv ${proc}_${sta}.tmp ${proc}_${sta}.txt
fi

cat ${proc}_${sta}.txt |awk '{  if ($8 ~/[0-9]$/) {printf("%8s\t%5.3f\n",$2,$8/1024/1024)} else if ($8 ~/k$/) {gsub("k",""); printf("%8s\t%5.3f\n",$2,$8/1024)} else if ($8 ~ /m$/){gsub("m","");printf("%8s\t%8d\n",$2,$8);} else if ($8 ~/g$/) {gsub("g",""); printf("%8s%8d\n",$2,$8*1024)}; }' > ${proc}_${sta}_mem.tmp
awk '{ if(min=="") {min=max=$2}; if($2>=max) {max=$2;MaxTime=$1}; if($2<=min) {min=$2;MinTime=$1}; total+=$2; count+=1} END {printf "%-10s\t%-7s\t%6d\t%6d\t%8s\t%-6d\t%8s\n","'"$proc"'", "'"$sta"'",total/count,min,MinTime,max,MaxTime}' ${proc}_${sta}_mem.tmp >> process_mem.report
mv ${proc}_${sta}_mem.tmp ${proc}_${sta}_mem.txt
}

#Hardeware TYPE
HW=`grep -w "HARDWARE" /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `
if [[ "$HW" =~ "HP" ]];then
    ## HPblade case
    HW="HP"
elif [[ "$HW" =~ "BONO" ]];then
        ##  case
        HW="BONO"
elif [[ "$HW" =~ "ROUZIC" ]]; then
        ## ROUZIC case
        HW="ROUZIC"
fi

#NetElement  FE|BE|PFE|PMGW
NE=`grep -w "CONFIGURATION" /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }' `

#If the script is reused, old result shall be deleted.
for file in parsed_top_process.report parsed_top_process.summary process_mem.report process_cpu.report oam_process.summary nonpilot_process.summary nonpilot_process_D.summary
do
 if [ -f $file ]; then
    rm $file
 fi
done

#If configuration is FE or PMGW 
if [[ "$NE" = "FE" ]] || [[ "$NE" = "PMGW" ]]; then
#Process FE or PMGW OAM part 
 for sta in A B
 do
    ls -lrt |grep parsed_top_${sta} > /dev/null
    if [ $? -eq 0 ]; then
       file=`ls -lrt|grep parsed_top_${sta} |tail -1|awk '{print $9}'`
       #FE pilot process may contain OamCOMM, OamEIR, OamMNP. PMGW pilot process is OamPMGW.
       for proc in OamCOMM OamEIR OamMNP OamPMGW
       do
           grep $proc $file > /dev/null
           if [ $? -eq 0 ]; then 
          	cat $file | filter_proc $proc > ${proc}_${sta}.txt           
           	cpu_parser_proc ${proc} ${sta}
                echo $sta > ${proc}_${sta}_cpu.raw
           	awk '{ print $2 }' ${proc}_${sta}_cpu.txt >> ${proc}_${sta}_cpu.raw
           	mem_parser_proc ${proc} ${sta}
                echo $sta > ${proc}_${sta}_mem.raw
           	awk '{ print $2 }' ${proc}_${sta}_mem.txt >> ${proc}_${sta}_mem.raw
                if [ ! -f ${sta}_dates.raw ]; then
                   echo $sta > ${sta}_dates.raw
                   awk '{ print $1 }' ${proc}_${sta}_cpu.txt >> ${sta}_dates.raw
                fi
           	rm ${proc}_${sta}.txt ${proc}_${sta}_cpu.txt ${proc}_${sta}_mem.txt
           fi
       done
    fi
 done

 date_file=`ls *_dates.raw`
 if [ $? -eq 0 ]; then
    paste ${date_file} > parsed_top_oam_dates.txt
    rm *_dates.raw
 fi

 
 for proc in OamCOMM OamEIR OamMNP OamPMGW
 do
    cpu_cmd="paste"
    mem_cmd="paste"
    for sta in A B
    do
       if [ -f ${proc}_${sta}_cpu.raw ]; then
         cpu_cmd=`echo $cpu_cmd " " ${proc}_${sta}_cpu.raw`
         mem_cmd=`echo $mem_cmd " " ${proc}_${sta}_mem.raw`
       fi
    done

    ls -lrt *_cpu.raw |grep ${proc} > /dev/null
    if [ $? -eq 0 ]; then
       exec $cpu_cmd > oam_${proc}_cpu.txt &
       sleep 1
       exec $mem_cmd > oam_${proc}_mem.txt &
       sleep 1
       echo $cpu_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
       echo $mem_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
    fi
 done

 for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
 do
   ls -lrt |grep parsed_top_${sta} > /dev/null
   if [ $? -eq 0 ]; then
       file=`ls -lrt|grep parsed_top_${sta} |tail -1|awk '{print $9}'`
       #FE nonpilot process may contain PDLSI, PDLSL, PDLSU, PDLSM , PDLSA; PMGW nonpilot process is OamCDMA.
       procs=(`cat $file | grep -E "PDLS|OamCDMA" | awk '{ print $NF }'| sort | uniq`)
       for proc in ${procs[@]}
       do
           cat $file | filter_proc $proc > ${proc}_${sta}.txt
           cpu_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_cpu.raw
           awk '{ print $2 }' ${proc}_${sta}_cpu.txt >> ${proc}_${sta}_cpu.raw
           mem_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_mem.raw
           awk '{ print $2 }' ${proc}_${sta}_mem.txt >> ${proc}_${sta}_mem.raw
           if [ ! -f ${sta}_dates.raw ]; then
             echo $sta > ${sta}_dates.raw
             awk '{ print $1 }' ${proc}_${sta}_cpu.txt >> ${sta}_dates.raw
           fi
           rm ${proc}_${sta}.txt ${proc}_${sta}_cpu.txt ${proc}_${sta}_mem.txt
       done
    fi
 done
 
 date_file=`ls *_dates.raw`
 paste ${date_file} > parsed_top_dates.txt

 for proc in `cat $file | grep -E "PDLS|OamCDMA" | awk '{ print $NF }'| sort | uniq`
 do
   cpu_cmd="paste"
   mem_cmd="paste"
   for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
   do
     if [ -f ${proc}_${sta}_cpu.raw ]; then
       cpu_cmd=`echo $cpu_cmd " " ${proc}_${sta}_cpu.raw`
       mem_cmd=`echo $mem_cmd " " ${proc}_${sta}_mem.raw`
     fi
   done

  grep $proc parsed_top_* > /dev/null
  if [ $? -eq 0 ]; then
     exec $cpu_cmd > nonpilot_${proc}_cpu.txt &
     sleep 1
     exec $mem_cmd > nonpilot_${proc}_mem.txt &
     sleep 1
     echo $cpu_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
     echo $mem_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
  fi
 done
    
 chmod +x delete.sh
 ./delete.sh
 rm delete.sh
 
 
 #Group process cpu and RSS data by process name and give the avg cpu/RSS.
 sort -k1 -d process_cpu.report >> rpt.cpu
 sort -k1 -d process_mem.report >> rpt.mem

 # For OAM part.
 awk 'BEGIN { printf "%9s\t%13s\t%16s\n", "Proc_Name", "OamProcAvgCpu", "OamProcAvgMem(M)" }' > oam_process.summary
 for proc in `cat rpt.cpu|awk '{if ($2 ~ /A|B/) {print $1}}'|sort|uniq`
 do
   grep $proc rpt.cpu|awk '{if ($2 ~ /A|B/) {print $0}}'|awk '{ if(max=="") max=$3; if($3>=max) max=$3;} END { printf "%-10s\t%12.1f\t", "'"$proc"'", max }' >> oam_process.summary
   grep $proc rpt.mem|awk '{if ($2 ~ /A|B/) {print $0}}'|awk '{ if(max=="") max=$3; if($3>=max) max=$3;} END { printf "%15.1f\n", max }' >> oam_process.summary
 done

cat oam_process.summary|sed -n '2,$p' |awk ' {printf("%-16s\t%-19s\t", $1_"AvgCpu", $1_"AvgMem(M)"); }' > parsed_top_process.oam
#Replace line end char "\t" to "\n"
cat parsed_top_process.oam|awk '{ print $0 }' > parsed_top_process.tmp; mv parsed_top_process.tmp parsed_top_process.oam
cat oam_process.summary|sed -n '2,$p' |awk ' {printf("%-19.1f\t%-18.1f\t", $2, $3) }' > parsed_top_process.tmp
#Replace line end char "\t" to "\n"
cat parsed_top_process.tmp | awk '{ print $0 }' >> parsed_top_process.oam

 # For Nonpilot part
 awk 'BEGIN { printf "%9s\t%18s\t%21s\n", "Proc_Name", "NonpilotProcAvgCpu", "NonpilotProcAvgMem(M)" }' > nonpilot_process.summary
 for proc in `cat rpt.cpu|awk '{if ($2 !~ /A|B/) {print $1}}'|sort|uniq`
 do
   grep $proc rpt.cpu|awk '{if ($2 !~ /A|B/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-10s\t%17.1f\t", "'"$proc"'", total/count }' >> nonpilot_process.summary
   grep $proc rpt.mem|awk '{if ($2 !~ /A|B/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-21d\n", total/count }' >> nonpilot_process.summary
 done

cat nonpilot_process.summary|sed -n '2,$p' |awk '{ printf("%-16s\t%-19s\t", $1"_AvgCpu", $1"_AvgMem(M)"); }' > parsed_top_process.non
cat parsed_top_process.non |awk '{ print $0 }' > parsed_top_process.tmp; mv parsed_top_process.tmp parsed_top_process.non
cat nonpilot_process.summary|sed -n '2,$p' |awk '{ printf("%-19.1f\t%-18.1f\t", $2, $3) }' > parsed_top_process.tmp
cat parsed_top_process.tmp|awk '{ print $0}' >> parsed_top_process.non

paste parsed_top_process.oam parsed_top_process.non > parsed_top_process.summary 
rm parsed_top_process.oam parsed_top_process.non parsed_top_process.tmp

 echo -e "Proc_Name\tStation\tAvgCpu\tMinCpu\tMinTime\t MaxCpu \tMaxTime" > process_cpu.report
 cat rpt.cpu >> process_cpu.report
 echo -e "Proc_Name\tStation\tAvgMem\tMinMem\tMinTime\t MaxMem \tMaxTime" > process_mem.report
 cat rpt.mem >> process_mem.report 
 rm rpt.cpu rpt.mem
 
#Else if configuration is BE
elif [[ "$NE" = "BE" ]]; then
 #For Pilot, the processes are GdmpServer & ndb_mgmd
 for sta in A B
 do
    ls -lrt |grep parsed_top_${sta} > /dev/null
    if [ $? -eq 0 ]; then
       file=`ls -lrt|grep parsed_top_${sta} |tail -1|awk '{print $9}'`
       for proc in GdmpServer ndb_mgmd
       do
           cat $file | filter_proc $proc > ${proc}_${sta}.txt
           cpu_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_cpu.raw 
           awk '{ print $2 }' ${proc}_${sta}_cpu.txt >> ${proc}_${sta}_cpu.raw
           mem_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_mem.raw
           awk '{ print $2 }' ${proc}_${sta}_mem.txt >> ${proc}_${sta}_mem.raw
           rm ${proc}_${sta}.txt ${proc}_${sta}_cpu.txt  ${proc}_${sta}_mem.txt
       done
    fi
 done
 
 for proc in GdmpServer ndb_mgmd
 do
    cpu_cmd="paste"
    mem_cmd="paste"
    for sta in A B
    do
       if [ -f ${proc}_${sta}_cpu.raw ]; then
         cpu_cmd=`echo $cpu_cmd " " ${proc}_${sta}_cpu.raw`  
         mem_cmd=`echo $mem_cmd " " ${proc}_${sta}_mem.raw`  
       fi
    done 
    exec $cpu_cmd > oam_${proc}_cpu.txt &
    sleep 1
    exec $mem_cmd > oam_${proc}_mem.txt &
    sleep 1
    echo $cpu_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
    echo $mem_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
 done

 if [[ "$HW" = "HP" ]] ||  [[ "$HW" = "BONO" ]]; then
   #For NonPilot, the processes on HP&BONO are GdmpServer & ndbmtd
  for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
   do
        ls -lrt |grep parsed_top_${sta} > /dev/null
   	if [ $? -eq 0 ]; then
         file=`ls -lrt|grep parsed_top_${sta} |tail -1|awk '{print $9}'`
         for proc in GdmpServer ndbmtd
         do
           cat $file | filter_proc $proc > ${proc}_${sta}.txt
           cpu_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_cpu.raw
           awk '{ print $2 }' ${proc}_${sta}_cpu.txt >> ${proc}_${sta}_cpu.raw
           mem_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_mem.raw
           awk '{ print $2 }' ${proc}_${sta}_mem.txt >> ${proc}_${sta}_mem.raw
           rm ${proc}_${sta}.txt ${proc}_${sta}_cpu.txt ${proc}_${sta}_mem.txt
         done
      fi
   done
   
 for proc in GdmpServer ndbmtd
 do
   cpu_cmd="paste"
   mem_cmd="paste"
   for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
   do
     if [ -f ${proc}_${sta}_cpu.raw ]; then
       cpu_cmd=`echo $cpu_cmd " " ${proc}_${sta}_cpu.raw`
       mem_cmd=`echo $mem_cmd " " ${proc}_${sta}_mem.raw`
     fi 
   done

   exec $cpu_cmd > nonpilot_${proc}_cpu.txt &
   sleep 1
   exec $mem_cmd > nonpilot_${proc}_mem.txt &
   sleep 1
   echo $cpu_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
   echo $mem_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
 done
   chmod +x delete.sh
   ./delete.sh
   rm delete.sh
 elif [[ "$HW" = "ROUZIC" ]]; then
   #For NonPilot, the processes on ROUZIC are GdmpServer & ndbd
  for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
   do
     ls -lrt |grep parsed_top_${sta} > /dev/null
     if [ $? -eq 0 ]; then
         file=`ls -lrt|grep parsed_top_${sta} |tail -1|awk '{print $9}'`
         for proc in GdmpServer ndbd
         do
           cat $file | filter_proc $proc > ${proc}_${sta}.txt
           cpu_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_cpu.raw
           awk '{ print $2 }' ${proc}_${sta}_cpu.txt >> ${proc}_${sta}_cpu.raw
           mem_parser_proc ${proc} ${sta}
           echo $sta > ${proc}_${sta}_mem.raw
           awk '{ print $2 }' ${proc}_${sta}_mem.txt >> ${proc}_${sta}_mem.raw
           rm ${proc}_${sta}.txt ${proc}_${sta}_cpu.txt ${proc}_${sta}_mem.txt
         done
      fi
   done  
 
 for proc in GdmpServer ndbd
 do
   cpu_cmd="paste"
   mem_cmd="paste"
   for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort`
   do
     if [ -f ${proc}_${sta}_cpu.raw ]; then
       cpu_cmd=`echo $cpu_cmd " " ${proc}_${sta}_cpu.raw`
       mem_cmd=`echo $mem_cmd " " ${proc}_${sta}_mem.raw`
     fi 
   done

   exec $cpu_cmd > nonpilot_${proc}_cpu.txt &
   sleep 1
   exec $mem_cmd > nonpilot_${proc}_mem.txt &
   sleep 1
   echo $cpu_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
   echo $mem_cmd |sed -n -e 's/paste/rm/p' >> delete.sh
 done
   chmod +x delete.sh
   ./delete.sh
   rm delete.sh
 fi
 
 #Group process cpu and RSS data by process name and give the avg cpu/RSS.
 sort -k1 -d process_cpu.report >> rpt.cpu
 sort -k1 -d process_mem.report >> rpt.mem
 
 #For OAM part:
 awk 'BEGIN { printf "%9s\t%13s\t%16s\n", "Proc_Name", "OamProcAvgCpu", "OamProcAvgMem(M)" }' > oam_process.summary
 for proc in `cat rpt.cpu|awk '{if ($2 ~ /A|B/) {print $1}}'|sort|uniq`
 do
   grep $proc rpt.cpu|awk '{if ($2 ~ /A|B/) {print $0}}'|awk '{if(max=="") max=$3;if($3>max) max=$3;} END { printf "%-10s\t%12.1f\t", "'"$proc"'",max }' >> oam_process.summary 
   grep $proc rpt.mem|awk '{if ($2 ~ /A|B/) {print $0}}'|awk '{if(max=="") max=$3;if($3>max) max=$3;} END { printf "%-16d\n", max }' >> oam_process.summary 
 done

cat oam_process.summary|sed -n '2,$p' |awk '{ printf("%-16s\t%-19s\t", $1"_AvgCpu", $1"_AvgMem(M)"); } ' > parsed_top_process.oam
cat parsed_top_process.oam|awk '{ print $0}' > parsed_top_process.tmp; mv parsed_top_process.tmp parsed_top_process.oam
cat oam_process.summary|sed -n '2,$p' |awk '{ printf("%-19.1f\t%-18.1f\t", $2, $3) } ' > parsed_top_process.tmp
cat parsed_top_process.tmp|awk '{ print $0}' >> parsed_top_process.oam
 
 #For Non-pilot part
    if [ -z "$2" ]; then
          awk 'BEGIN { printf "%9s\t%18s\t%21s\n", "Proc_Name", "NonpilotProcAvgCpu", "NonpilotProcAvgMem(M)" }' > nonpilot_process.summary
         for proc in `cat rpt.cpu|awk '{if ($2 !~ /A|B/) {print $1}}'|sort|uniq`
         do
           grep $proc rpt.cpu|awk '{if ($2 !~ /A|B/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-10s\t%-17.1f\t", "'"$proc"'", total/count }' >> nonpilot_process.summary
           grep $proc rpt.mem|awk '{if ($2 !~ /A|B/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-21d\n", total/count }' >> nonpilot_process.summary
         done
        
        cat nonpilot_process.summary|sed -n '2,$p' |awk '{printf("%-16s\t%-19s\t", $1"_AvgCpu", $1"_AvgMem(M)") }' > parsed_top_process.non
        cat parsed_top_process.non | awk '{ print $0}' > parsed_top_process.tmp ; mv parsed_top_process.tmp parsed_top_process.non
        cat nonpilot_process.summary|sed -n '2,$p' |awk '{printf("%-19.1f\t%-18.1f\t", $2, $3) }' > parsed_top_process.tmp
        cat parsed_top_process.tmp |awk '{ print $0}' >> parsed_top_process.non
        
        paste parsed_top_process.oam parsed_top_process.non > parsed_top_process.summary
        rm parsed_top_process.oam parsed_top_process.non parsed_top_process.tmp
    elif [ $2 == "BE" ]; then
        ## Station C,E-L
          awk 'BEGIN { printf "%9s\t%18s\t%21s\n", "Proc_Name", "NonpilotProcAvgCpu", "NonpilotProcAvgMem(M)" }' > nonpilot_process.summary
         for proc in `cat rpt.cpu|awk '{if ($2 !~ /A|B|D/) {print $1}}'|sort|uniq`
         do
           grep $proc rpt.cpu|awk '{if ($2 !~ /A|B|D/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-10s\t%-17.1f\t", "'"$proc"'", total/count }' >> nonpilot_process.summary
           grep $proc rpt.mem|awk '{if ($2 !~ /A|B|D/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-21d\n", total/count }' >> nonpilot_process.summary
         done    
        cat nonpilot_process.summary|sed -n '2,$p' |awk '{printf("%-16s\t%-19s\t", $1"_AvgCpu", $1"_AvgMem(M)") }' > parsed_top_process.non
        cat parsed_top_process.non | awk '{ print $0}' > parsed_top_process.tmp ; mv parsed_top_process.tmp parsed_top_process.non
        cat nonpilot_process.summary|sed -n '2,$p' |awk '{printf("%-19.1f\t%-18.1f\t", $2, $3) }' > parsed_top_process.tmp
        cat parsed_top_process.tmp |awk '{ print $0}' >> parsed_top_process.non
        paste parsed_top_process.oam parsed_top_process.non > parsed_top_process.summary
        ## Station D        
              awk 'BEGIN { printf "%9s\t%18s\t%21s\n", "Proc_Name", "NonpilotProcAvgCpu_D", "NonpilotProcAvgMem_D(M)" }' > nonpilot_process_D.summary
         for proc in `cat rpt.cpu|awk '{if ($2 !~ /A|B|C|E|F|G|H|I|J|K|L/) {print $1}}'|sort|uniq`
         do
           grep $proc rpt.cpu|awk '{if ($2 !~ /A|B|C|E|F|G|H|I|J|K|L/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-10s\t%-17.1f\t", "'"$proc"'", total/count }' >> nonpilot_process_D.summary
           grep $proc rpt.mem|awk '{if ($2 !~ /A|B|C|E|F|G|H|I|J|K|L/) {print $0}}'|awk '{ total+=$3;count+=1; } END { printf "%-21d\n", total/count }' >> nonpilot_process_D.summary
         done
        cat nonpilot_process_D.summary|sed -n '2,$p' |awk '{printf("%-16s\t%-19s\t", $1"_AvgCpu", $1"_AvgMem(M)") }' > parsed_top_process_D.non
        cat parsed_top_process_D.non | awk '{ print $0}' > parsed_top_process_D.tmp ; mv parsed_top_process_D.tmp parsed_top_process_D.non
        cat nonpilot_process_D.summary|sed -n '2,$p' |awk '{printf("%-19.1f\t%-18.1f\t", $2, $3) }' > parsed_top_process_D.tmp
        cat parsed_top_process_D.tmp |awk '{ print $0}' >> parsed_top_process_D.non   
        echo "##################################" >> parsed_top_process.summary
        echo "#### Below is Station D summary ##" >> parsed_top_process.summary
        echo "##################################" >> parsed_top_process.summary
        paste parsed_top_process.oam parsed_top_process_D.non >> parsed_top_process.summary
        rm parsed_top_process.oam parsed_top_process.non parsed_top_process.tmp parsed_top_process_D.non parsed_top_process_D.tmp
    else
        echo "Second parameter input wrong!"
        exit 1    
    fi

 echo -e "Proc_Name\tStation\tAvgCpu\tMinCpu\tMinTime\t MaxCpu \tMaxTime" > process_cpu.report
 cat rpt.cpu >> process_cpu.report
 echo -e "Proc_Name\tStation\tAvgMem\tMinMem\tMinTime\t MaxMem \tMaxTime" > process_mem.report
 cat rpt.mem >> process_mem.report
 rm rpt.cpu rpt.mem

else 
   echo "The performance tool doesn't support $CF log analysis. You can contact Baosheng for support!"
fi

if [ -z "$2" ]; then
    cat process_cpu.report process_mem.report oam_process.summary nonpilot_process.summary > parsed_top_process.report
elif [ $2 == "BE" ]; then
    cat process_cpu.report process_mem.report oam_process.summary nonpilot_process.summary nonpilot_process_D.summary > parsed_top_process.report
else
    echo "Second parameter input wrong!"
    exit 1  
fi
