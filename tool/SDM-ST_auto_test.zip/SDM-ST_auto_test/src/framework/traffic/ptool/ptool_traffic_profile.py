"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines PtoolTrafficProfile class
"""

class PtoolTrafficProfile(object):
    """
    @details This class describes a Ptool traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        PtoolTrafficProfile class constructor
        """

        self.ptoolDir = ""  # ptool location on PC lab
        self.scenario = ""
        self.FE_Key = ""
        self.tps = ""
        self.application = ""
        self.transport = ""
