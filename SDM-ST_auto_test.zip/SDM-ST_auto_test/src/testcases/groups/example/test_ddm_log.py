"""
@file test_ddm_log.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-08-25
@brief failure case to verify DDM log API work
"""

from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase

LOGGER = Logger.getLogger(__name__)

class test_ddm_log(SDMTestCase):
    """Test DDM log API and for failure case, it will collect DDM log"""

    def test_01_Just_Test_Failure(self):
        """Just an example for verify the log collection work well."""
        # This test case will fail so the DDM log will be collected and save to case log directory.
        LOGGER.info("This case will fail and DDM log should be collected")
        raise Exception

    def test_02_Just_Test_Success(self):
        """Just an example for verify the log collection work well."""
        # This test case will fail so the DDM log will be collected and save to case log directory.
        LOGGER.info("This case will pass and no DDM log should be collected")
