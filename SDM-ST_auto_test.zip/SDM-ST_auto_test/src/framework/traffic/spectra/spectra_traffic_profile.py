"""
@file
Created on July 3, 2015
@ingroup SDMSQA Automation
@author Zhao Junming
@brief Defines SpectraTrafficProfile class
"""

class SpectraTrafficProfile(object):
    """
    @details This class describes a Spectra traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        SpectraTrafficProfile class constructor
        """

        self.model = ""
        self.tps = ""
