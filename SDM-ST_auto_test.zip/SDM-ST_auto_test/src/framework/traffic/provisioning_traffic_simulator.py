'''
Created on Jan 30, 2015

@author: yohannm
'''
from framework.traffic.traffic_simulator import TrafficSimulator

class ProvisioningTrafficSimulator(TrafficSimulator):
    '''
    classdocs
    '''

    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        super(ProvisioningTrafficSimulator,self).__init__(sshManager)
        