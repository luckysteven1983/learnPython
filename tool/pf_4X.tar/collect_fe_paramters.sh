#!/bin/bash

#######################################################
#       usage: $0  <output dir> 
#######################################################  

currentpath=$(cd "$(dirname "$0")"; pwd)

if [ ! -d $1 ]
then
  echo "directory no exist! create it"
  mkdir -p $1
fi


########################################################
# Collect Version Information
#######################################################
#echo "Collect FE version information ......."
#$currentpath/check_fe_version.sh
#mv fe_version_info.result $1
#echo "Cellect FE version information done."


########################################################
# Collect Lab Status Information
#######################################################
#echo "Collect Lab Status information ......."
#pilot_number=`uname -n|awk -F "-" '{print $NF}'`
#$currentpath/check_lab_status.exp FE
#mv lab_status.result $1
#echo "Cellect Lab Status information done."
########################################################
# Collect PDLS Number Information
#######################################################
#echo "Collect PDLS Number information ......"
#$currentpath/check_pdls_number.sh
#mv check_PDLS_number.result $1
#echo "Collect PDLS Number information done."


########################################################
# Collect Backdoor Parameters Information
#######################################################
echo "Collect FE backdoor parameters ......."
$currentpath/show_fe_backdoor_port.exp
for port in `cat fe_backdoor_port.result|awk '{print $4}'|grep -v grep|sed -n -e 's/://gp'`
do
   $currentpath/check_backdoor.exp $port
   mv ${port}.result $1
done
rm fe_backdoor_port.result
echo "Collect FE backdoor parameters done."

########################################################
# Collect  Delay and Lost between FE & BE 
#######################################################
#echo "Collect wan delay information ......"
#$currentpath/check_delay_lost.sh
#mv check_delay_lost.result $1
#echo "Collect wan delay information done."

########################################################
# Collect FE Parameter Files 
#######################################################
echo "Collect FE configure file ......."
SDM_VERSION=`ls -lrt /sn/sps/*|grep ":$"|grep SDM|sed -n 's/://p'`
$currentpath/check_config.sh FE_CONFIG $1
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'`
do
  scp $sta:$SDM_VERSION/bin/data/pdlsipf_generic.cfg $1/pdlsipf_generic.cfg.$sta
  scp $sta:$SDM_VERSION/bin/data/pdlslpf_generic.cfg $1/pdlslpf_generic.cfg.$sta
  scp $sta:$SDM_VERSION/bin/data/pdlsupf_generic.cfg $1/pdlsupf_generic.cfg.$sta
done
echo "Collect FE configure file done."

########################################################
# Collect FE TCP Parameters 
#######################################################
#echo "Collect FE TCP parameters ...."
#$currentpath/collect_tcp_parameter.sh
#mv check_tcp_params.log $1

