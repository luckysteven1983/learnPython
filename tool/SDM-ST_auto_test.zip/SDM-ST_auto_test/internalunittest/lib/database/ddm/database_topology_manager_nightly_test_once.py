'''
Created on Mar 30, 2015

@author: Xia Zhao
'''
import unittest
import re
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
LOGGER = Logger.getLogger(__name__)

class database_topology_manager_nightly_test_once(SDMTestCase):

    def setUp(self):
        LOGGER.info("DatabaseTopologyManagerTest")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, self.host1 = self.testEnv.testBed.getFrontends().popitem()
        _, self.host2 = self.testEnv.testBed.getBackends().popitem()
        self.sshManager = self.sdmManager.sshManager
        self.databaseTopologyManager = self.sdmManager.databaseTopologyManager

    def tearDown(self):
        pass

    def test_1_getTopology_success(self):
        state=self.databaseTopologyManager.getTopology(self.host1)
        LOGGER.info(str(state))
        _, mppreadoutPut = self.sshManager.run(self.host1.oamIpAddress, '/usr/dhafw/bin/mppread')
        LOGGER.info(mppreadoutPut)
        for nrg in state.values():
            for nrgInfoKey in nrg.keys():
                if not isinstance(nrgInfoKey, int):
                    pattern = re.compile(nrgInfoKey + r'\s*=\s*' + nrg[nrgInfoKey])
                    if not pattern.search(mppreadoutPut):
                        raise AssertionError(nrgInfoKey + " = " + nrg[nrgInfoKey])
                else:
                    for beInfoKey in nrg[nrgInfoKey].keys():
                        if beInfoKey == 'BackEnd Id':
                            pattern = re.compile(beInfoKey + ' ' + nrg[nrgInfoKey][beInfoKey])
                        else:
                            pattern = re.compile(beInfoKey + r'\s*=\s*' + nrg[nrgInfoKey][beInfoKey])
                        if not pattern.search(mppreadoutPut):
                            raise AssertionError(beInfoKey + ' = ' + nrg[nrgInfoKey][beInfoKey])

    def test_2_getTopology_fail(self):
        self.assertRaises(BaseException, self.databaseTopologyManager.getTopology,self.host2)

    def test_3_getNRG_success(self):
        nrgNumber, nrgList=self.databaseTopologyManager.getNRG(self.host1)
        LOGGER.info(str(nrgNumber))
        LOGGER.info(str(nrgList))
        self.assertIsInstance(nrgList, list)
        self.assertIsInstance(nrgNumber, int)

    def test_4_getBE_success(self):
        beNumber, beList=self.databaseTopologyManager.getBE(self.host1, 1)
        LOGGER.info(str(beNumber))
        LOGGER.info(str(beList))
        self.assertIsInstance(beList, list)
        self.assertIsInstance(beNumber, int)

    def test_5_checkTopology_success(self):
        self.databaseTopologyManager.checkTopology(self.testEnv.testBed)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
