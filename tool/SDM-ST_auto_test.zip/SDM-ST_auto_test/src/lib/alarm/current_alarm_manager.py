"""
@file current_alarm_manager.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-10
@brief current alarm management

current alarm management with subhsl command
"""

import lib.exceptions_messages as eMsgs
from lib.alarm.alarm import Alarm
from lib.logging.logger import Logger
from lxml import etree

LOGGER = Logger.getLogger(__name__)

class CurrentAlarmManagerError(BaseException):
    """If error, raise it."""
    pass

class CurrentAlarmManager(object):
    """@verbatim Current Alarm Manager

    Usage:
        Let's take lab 135.251.83.201 as an example on how to get a
        CurrentAlarmManager instance.

        import CurrentAlarmManager
        myAlarm = CurrentAlarmManager(sshManager, subshlManager)

        So then we can use instance myAlarm to call the methods provided by this
        class. On how to call the method, please check doc string in each
        method.
    @endverbatim
    """

    alarm_xml_file = '/SMS/EMS/ActiveAlarms.xml'

    def __init__(self, sshManager, subshlManager):
        """@verbatim Init CurrentAlarmManager instance with sshManager and subshlManager.

        The user using the method is responsiblity for opening a connection to
        the remote host and initialising this class with the returned instance.
        @endverbatim

        @param subshlManager  SubshlManager object for subshl command execution
        @param sshManager  an SSH or other protocol object used for remote command execution.
        """
        self._sshManager = sshManager
        self._subShl = subshlManager

    def clearActiveAlarm(self, lab):
        """Clear existing alarms
        using subshl command :
        clr:almtbl,age=0
        @param lab  one lab object
        """
        self._subShl.run(lab, 'clr:almtbl,age=0')
        LOGGER.debug('Alarms on ' + lab.id +' have been cleared')

    def getActiveAlarmList(self, lab):
        """Return the current active alarm object list.

        Execute mCAS subshl command (op:almtable,xml) to get based xml alarm file and then parse the
        xml file to return alarm object list.

        @param lab  one lab object
        """
        if self._subShl.run(lab, 'op:almtable,xml').find('SUCCESSFULLY') == -1:
            LOGGER.error('%s: %s', lab.id, eMsgs.CURRENT_ALARM_TABLE_NOK)
            raise CurrentAlarmManagerError, eMsgs.CURRENT_ALARM_TABLE_NOK
        localFile = self._sshManager.scpGet(lab.oamIpAddress, self.__class__.alarm_xml_file)
        try:
            alarms = open(localFile).read()
            root = etree.fromstring(alarms) # pylint: disable=no-member
        except:
            LOGGER.error('%s: %s', lab.id, eMsgs.CURRENT_ALARM_PARSER_NOK)
            raise CurrentAlarmManagerError, eMsgs.CURRENT_ALARM_PARSER_NOK
        return [Alarm.getAlarmByXmlRoot(alarm) for alarm in root.iter('Alarm')]
