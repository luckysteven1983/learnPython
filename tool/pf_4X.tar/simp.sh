#!/bin/bash

#############################################
#   Usage: $0 <simp log dir>
############################################
cd $1
if [ `ls -lrt *.tar|wc -l` -gt 0 ] ; then
   for f in `ls -l *.tar | awk '{print $9}'`
   do 
     tar xf $f
   done
fi

for file in `ls -l simp.log.*|awk '{print $9}'`
do
   type=`grep result $file|tail -1|awk '{print $1}'|cut -c9`
   if [ $type = "H" ]
   then
        grep Success: $file|tail -1|awk '{print $2 $4 $6 $8 $10}'|sed -n -e 's/,/\t/gp' >> hss
        grep Total $file|tail -2|head -1|awk -F "|" '{print $9}' |awk '{print $1}'>> hss.tps
        hss_duration_time=`grep Time: $file|tail -1|awk '{print $6}'|awk '{ gsub("=",""); print $1}'` 
   else
        grep Success: $file|tail -1|awk '{print $2 $4 $6 $8 $10}'|sed -n -e 's/,/\t/gp' >> lte
        grep Total $file|tail -2|head -1|awk -F "|" '{print $9}'|awk '{print $1}' >> lte.tps 
        lte_duration_time=`grep Time: $file|tail -1|awk '{print $6}'|awk '{ gsub("=",""); print $1}'` 
   fi
done
   if [ -f hss ]; then
      paste hss hss.tps > hss.txt
      rm hss hss.tps
      awk 'BEGIN { print "Type\tSuccess    \tFailed   \tFailed3004\tFailed5012\tLost\tTPS      \tQos\t   DurationTime"} { Success += $1; Failed += $2; Failed3004 += $3; Failed5012 += $4; Lost += $5; TPS += $6; ++num; next} END { printf "%s\t%d\t%d\t%9d\t%11d\t%10d\t%8.2f\t%8.2e\t%s\n","HSS",Success,Failed,Failed3004,Failed5012,Lost,TPS,(Failed5012+Failed3004+Lost)/(Success+Failed5012+Failed3004+Lost),"'"$hss_duration_time"'"}' hss.txt > simp.result
   fi
   if [ -f lte ]; then
      paste lte  lte.tps > lte.txt
      rm lte lte.tps
      awk 'BEGIN { print "Type\tSuccess    \tFailed   \tFailed3004\tFailed5012\tLost\tTPS      \tQos\t   DurationTime"} { Success += $1; Failed += $2; Failed3004 += $3; Failed5012 += $4; Lost += $5; TPS += $6; ++num; next} END { printf "%s\t%d\t%d\t%9d\t%11d\t%10d\t%8.2f\t%8.2e\t%s\n","LTE",Success,Failed,Failed3004,Failed5012,Lost,TPS,(Failed5012+Failed3004+Lost)/(Success+Failed5012+Failed3004+Lost),"'"$lte_duration_time"'"}' lte.txt >> simp.result
   fi

   if [[ -f hss ]] && [[ -f lte ]];then
   awk 'BEGIN { print "Type\tSuccess    \tFailed   \tFailed3004\tFailed5012\tLost\tTPS      \tQos\t   DurationTime"} { Success += $1; Failed += $2; Failed3004 += $3; Failed5012 += $4; Lost += $5; TPS += $6; ++num; next} END { printf "%s\t%d\t%d\t%9d\t%11d\t%10d\t%8.2f\t%8.2e\n","Total",Success,Failed,Failed3004,Failed5012,Lost,TPS,(Failed5012+Failed3004+Lost)/(Success+Failed5012+Failed3004+Lost)}' hss.txt lte.txt >> simp.result
  fi

   if [ -f hss ];then
    rm hss.txt
   elif [ -f lte ]; then
    rm lte.txt
   fi
