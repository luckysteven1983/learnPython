'''
Created on Mar 24, 2015

@author: Xia Zhao
'''
import unittest
import paramiko
from framework.asserts.platform_asserts import PlatformAsserts
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class platform_asserts_test_once(SDMTestCase):
    '''Class for PlatformAssertTest.
    To run daily
    '''

    def setUp(self):
        LOGGER.info("Test Once PlatformAssertTest")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, self.frontend = self.testEnv.testBed.getFrontends().popitem()
        _, self.backend = self.testEnv.testBed.getBackends().popitem()
        self.host=self.backend.oamIpAddress
        self._mcasSSH = self.sdmManager.sshManager
        self.client=self.sdmManager.sshManager.getClient(self.host)

        if not self.client.get_transport().is_alive():
            LOGGER.error('Connection to ' + self.host + ' no longer exists.')
            raise paramiko.SSHException

        self.timeout=10
        self._pa=PlatformAsserts(self._mcasSSH)

    def tearDown(self):
        pass

    def test_1_assertProcessAlive_sucess(self):
        '''
        To test if assertProcessAlive_sucess is ok
        '''
        LOGGER.info("PlatformAssertTest Once assertProcessAlive_sucess")
        process="GdmpServer"
        self._pa.assertProcessAlive(self.backend,process,self.timeout)

    def test_2_assertProcessAlive_Fail(self):
        '''
        To test if assertProcessAlive_Fail is ok
        '''
        LOGGER.info("PlatformAssertTest Once assertProcessAlive_Fail")
        process="GdmpServerABC"
        self.assertRaises(BaseException, self._pa.assertProcessAlive,
                                self.backend, process, self.timeout)


    def test_3_assertProcessAliveOnStations_sucess(self):
        '''
        To test if assertProcessAliveOnStations_sucess is ok
        '''
        LOGGER.info("PlatformAssertTest Once assertProcessAliveOnStations_sucess")
        process="GdmpServer"
        station=["0-0-1","0-0-2","0-0-3"]
        self._pa.assertProcessAliveOnStations(self.backend,process,station,self.timeout)

    def test_4_assertProcessAliveOnStations_fail(self):
        '''
        To test if assertProcessAliveOnStations_fail is ok
        '''
        LOGGER.info("PlatformAssertTest Once assertProcessAliveOnStations_fail")
        process="GdmpServerABC"
        station=["0-0-1","0-0-2","0-0-3"]
        self.assertRaises(BaseException, self._pa.assertProcessAliveOnStations,
                                self.backend,process,station,self.timeout, 2)


    def test_5_assertFileContainsExpectedContents_success(self):
        '''
        To test if assertFileContainsExpectedContents_sucess is  ok
        '''
        LOGGER.info("PlatformAssertTest Once assertFileContainsExpectedContents_sucess")

        # Create test file for assertFileContainsExpectedContents
        tempLogFile = "/tmp/assertFileContentTestFile.log"
        createCmd = "echo 'Test check log content file:content_A, content_B' > " + tempLogFile
        createResult = self._mcasSSH.run(self.host, createCmd)
        if createResult[0]:
            createFileErrorMsg = "Can not create test file for assertFileContainsExpectedContents"
            LOGGER.error(createFileErrorMsg)
            raise Exception, createFileErrorMsg

        contentA = "content_A"
        contentB = "content_B"
        self._pa.assertFileContainsExpectedContents(self.host, tempLogFile, contentA)
        self._pa.assertFileContainsExpectedContents(self.host, tempLogFile, contentA, contentB)

        # Delete the temp log file
        deleteCmd = "rm -rf " + tempLogFile
        deleteResult = self._mcasSSH.run(self.host, deleteCmd)
        if deleteResult[0]:
            deleteFileErrorMsg = "Delete temp log file /tmp/assertFileContentTestFile.log fail"
            LOGGER.error(deleteFileErrorMsg)
            raise Exception, deleteFileErrorMsg

    def test_6_assertFileContainsExpectedContents_fail(self):
        '''
        To test if assertFileContainsExpectedContents_fail is ok
        '''
        LOGGER.info("PlatformAssertTest Once assertFileContainsExpectedContents_fail")

        # Create test file for assertFileContainsExpectedContents
        tempLogFile = "/tmp/assertFileContentTestFile.log"
        createCmd = "echo 'Test check log content file:content_A, content_B' > " + tempLogFile
        createResult = self._mcasSSH.run(self.host, createCmd)
        if createResult[0]:
            createFileErrorMsg = "Can not create test file for assertFileContainsExpectedContents"
            LOGGER.error(createFileErrorMsg)
            raise Exception, createFileErrorMsg

        contentNotExist = "content_NotExist"
        self.assertRaises(BaseException, self._pa.assertFileContainsExpectedContents,
                          self.host, tempLogFile, contentNotExist)

        # Delete the temp log file
        deleteCmd = "rm -rf " + tempLogFile
        deleteResult = self._mcasSSH.run(self.host, deleteCmd)
        if deleteResult[0]:
            deleteFileErrorMsg = "Delete temp log file /tmp/assertFileContentTestFile.log fail"
            LOGGER.error(deleteFileErrorMsg)
            raise Exception, deleteFileErrorMsg


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
