"""Define variables associated with framekwork directory structure."""

BASEDIR = "src"
CASEDIR = "testcases"
SUITEDIR = "suites"
RESULT_DIR = 'internalunittest-reports'
DISCOVER_DIR = 'internalunittest/'
PYTHONSUFFIX = '.py'
SU_PACKAGES_DIR = "/home/jenkins/deliveries/SDM_MCAS"
DDM_PACKAGES_DIR = "/home/jenkins/deliveries/ddm"
OAMSCRIPT_PACKAGES_DIR = "/home/jenkins/deliveries/mcas/oamscripts"
OAM_PACKAGES_DIR = "/home/jenkins/deliveries/mcas"
SDM_PACKAGES_DIR = "/home/jenkins/deliveries/sdm"
DELIV_PACKAGES_DIR = "/home/jenkins/deliveries"
