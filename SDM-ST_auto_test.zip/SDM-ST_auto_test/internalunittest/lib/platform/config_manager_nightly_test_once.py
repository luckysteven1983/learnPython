'''
Created on Nov 17, 2015

@author: Cassandra Lajeunie
'''
import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
LOGGER = Logger.getLogger(__name__)
from lib.platform.config_manager import REMOTE_PATH_CONFIG

class config_manager_nightly_test_once(SDMTestCase):

    def setUp(self):
        """Setup env"""
        LOGGER.info("config manager nightly test once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.configManager = self.sdmManager.configManager

    def test_01_config_ini_paramter_equal_to_success(self):
        """
        find if parameter in config.ini file is equal to given value
        """
        LOGGER.info("Test 01: find if parameter NODE-CONFIGURATION in config.ini file is equal some values")
        result1 = self.configManager.getIniFileParameter(self.be, REMOTE_PATH_CONFIG, "NODE", "CONFIGURATION")
        LOGGER.info("NODE-CONFIGURATION parameter is set to the value 'other' : " + str(result1 == "other"))

        LOGGER.info("NODE-CONFIGURATION parameter is set to the value 'bla' : " + str(result1 == "bla"))

    def test_02_config_ini_paramter_equal_to_fail(self):
        """
        fail to find parameter in config.ini file
        """
        LOGGER.info("Test 02: fail to find parameter NODE-BLA in config.ini file")
        self.assertRaises(Exception, self.configManager.getIniFileParameter,self.be, REMOTE_PATH_CONFIG, "NODE", "BLA")

    def test_03_SDM_general_data_find_parameter_success(self):
        """
        find the value for the given parameter in SDM_General_Data.xml
        """
        LOGGER.info("Test 03: find the value for the given parameter in SDM_General_Data.xml")
        result = self.configManager.getSdmGeralDataParameter(self.be, "General", "Common", "CONFIGURATION")
        if result != "":
            LOGGER.info("parameter General-Common-CONFIGURATION is set to : " + result)
        else:
            LOGGER.info("parameter General-Common-CONFIGURATION is set to an empty value")

    def test_04_SDM_general_data_find_parameter_fail(self):
        """
        fail to find the value for the given parameter in SDM_General_Data.xml
        """
        LOGGER.info("Test 04: fail to find the value for the given parameter in SDM_General_Data.xml")
        self.assertRaises(Exception, self.configManager.getSdmGeralDataParameter, self.be, "General", "Common", "truc")