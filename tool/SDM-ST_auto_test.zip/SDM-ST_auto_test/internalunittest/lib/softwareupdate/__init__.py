"""Include software upgrade UT cases.
"""
