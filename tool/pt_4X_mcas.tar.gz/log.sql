update cr_dest set num_of_logs=10 where dest='MEASLOG';
update cr_dest set num_of_logs=10 where dest='SNMPLOG';
update cr_dest set num_of_logs=20 where dest='DEBUGLG';
update cr_dest set num_of_logs=10 where dest='OMlog';

