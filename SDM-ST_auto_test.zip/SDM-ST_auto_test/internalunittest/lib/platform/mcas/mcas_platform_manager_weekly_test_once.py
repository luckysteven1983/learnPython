'''
Created on Nov 4, 2015

@author: Tangi Lavanant

'''

import random
import time
import unittest

from framework.asserts.common_asserts import CommonAssert
from framework.sdm_test_case import SDMTestCase
from lib.health_check.health_check_manager import HEALTH_CHECK_ASSERT_TIME_INTERVAL
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_platform_manager import  MCAS_RESTART_PF_BEFORE_CHECK_TIMER, MCAS_RESTART_PF_TIMEOUT, \
    MCAS_ASTART_TIMEOUT


LOGGER = Logger.getLogger(__name__)
MCAS_INTERVAL_CHECK = 30

class mcas_platform_manager_weekly_test_once(SDMTestCase):
    '''
    Test for McasPlatformManager
    '''

    def setUp(self):
        LOGGER.info("Test for McasPlatformManager")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.mcasPlatformManager = self.sdmManager.mcasPlatformManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts

    def tearDown(self):
        pass

    def test_01_runfw_pfboot_success(self):
        '''
        This is a test once for fw pfboot on a lab
        '''
        LOGGER.info("test_01_restartPlarestartPlatformByPfboottform_success")
        self.mcasPlatformManager.restartPlatformByPfboot(self.fe)
        LOGGER.info("Waiting %i seconds for node %s to be reachable", MCAS_RESTART_PF_BEFORE_CHECK_TIMER, self.fe.id)
        time.sleep(MCAS_RESTART_PF_BEFORE_CHECK_TIMER)
        CommonAssert.timedAssert(MCAS_RESTART_PF_TIMEOUT, HEALTH_CHECK_ASSERT_TIME_INTERVAL,
                                  self.sdmManager.healthCheckManager.runCheckAll, self.fe)

        LOGGER.info("test_01_nodefwPfBoot OK")

    def test_02_runAstopAll_success(self):
        '''
        This is a test once for Astop/Astart on all boards
        '''
        LOGGER.info("test_02_runAstopAll_success")
        self.mcasPlatformManager.runAstop(self.fe, 'all')
        self.mcasPlatformManager.runAstart(self.fe, 'all')
        for blade in self.fe.stations:
            CommonAssert.timedAssert(MCAS_ASTART_TIMEOUT, MCAS_INTERVAL_CHECK, self.testEnvAsserts.assertStationOK,
                                      self.fe, blade, 'COMPL', 'debug')

    def test_03_runAstart_AstopBlade_success(self):
        '''
        This is a test once for Astop/Astart local
        '''
        LOGGER.info("test_03_runAstart_AstopBlade_success")
        LOGGER.info("runAstop and then Astart on local")
        self.mcasPlatformManager.runAstop(self.fe, 'local')
        self.mcasPlatformManager.runAstart(self.fe, 'local')
        for blade in self.fe.stations:
            CommonAssert.timedAssert(MCAS_ASTART_TIMEOUT, MCAS_INTERVAL_CHECK, self.testEnvAsserts.assertStationOK,
                                  self.fe, blade, 'COMPL', 'debug')

    def test_04_runAstart_AstopBlade_fails(self):
        LOGGER.info("test_04_runAstart_AstopBlade_fails")
        self.assertRaises(BaseException, self.mcasPlatformManager.runAstart, self.fe, '0-0-2')

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
