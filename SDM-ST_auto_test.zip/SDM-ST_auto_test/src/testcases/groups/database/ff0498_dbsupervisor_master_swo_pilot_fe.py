'''
Created on Dec 1, 2015

@author: xzhao015
'''

import os
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.database.ddm.database_manager import SCRIPT_DBSUPERVISOR, PROCESS_DBSUPERVISOR,\
    DB_CMD_RESTART

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0498_dbsupervisor_master_swo_pilot_fe(SDMTestCase):
    """restart DbSupervisor on BE MASTER and swo control pilot on FE
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.multiTasksManager = self.sdmManager.multiTasksManager

    def test_dbsupervisor_master_swo_pilot_fe(self):
        """
        restart DbSupervisor on BE MASTER and swo control pilot on FE
        """
        self._precheck()
        startTime, fe = self._runTestCase()
        self._postcheck(startTime, fe)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _restartDbsupervisor(self, lab):
        """restart dbsupervisor on lab"""
        LOGGER.debug("restart dbsupervisor on BE %s", lab.id)

        LOGGER.debug("check the dbsupervisor process on the stations is alive")
        self.sdmManager.platformAsserts.assertProcessAlive(lab, PROCESS_DBSUPERVISOR)

        LOGGER.debug("restart dbsupervisor on the stations")
        self.sdmManager.databaseManager.runScriptOperation(lab, SCRIPT_DBSUPERVISOR,\
                                                           ddmOperation=DB_CMD_RESTART)

        LOGGER.debug("check the dbsupervisor process on the stations can be recover")
        self.sdmManager.platformAsserts.assertProcessAlive(lab, PROCESS_DBSUPERVISOR)

    def _swoPilot(self, lab):
        """swo control pilot on lab"""
        self.assertTrue(self.sdmManager.mcasMachineManager.pilotSwitchover(lab))

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case")

        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(self.allBEs)[0]
        fe = self.allFEs[0]

        threadName = self.multiTasksManager.register(self._restartDbsupervisor, masterBE)
        LOGGER.info("restart dbsupervisor on master BE '%s' in progress -> thread ID '%s'", masterBE.id, threadName)

        threadName = self.multiTasksManager.register(self._swoPilot, fe)
        LOGGER.info("pilot switch-over on Lab '%s' in progress -> thread ID '%s'", fe.id, threadName)

        if not self.multiTasksManager.runMultiTasks():
            LOGGER.error("test_dbsupervisor_master_swo_pilot_fe failure")
            raise Exception("test_dbsupervisor_master_swo_pilot_fe failure")

        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime, fe

    def _postcheck(self, startTime, fe):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        try:
            labs = [lab for lab in self.testEnv.testBed.labs.values() if lab is not fe]
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
