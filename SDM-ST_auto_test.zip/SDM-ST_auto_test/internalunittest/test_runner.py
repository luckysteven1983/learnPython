'''
Goal of this is to run all internal test and to get XML reports

Created on Mar 13, 2015

@author: Tangi Lavanant


'''

import unittest
import xmlrunner

if __name__ == '__main__':
    TESTLIST = unittest.TestLoader().discover('internalunittest/', pattern = "*_test.py",top_level_dir='.')
    TESTRUNNER = xmlrunner.XMLTestRunner(output='internalunittest-reports')
    TESTRUNNER.run(TESTLIST)
    