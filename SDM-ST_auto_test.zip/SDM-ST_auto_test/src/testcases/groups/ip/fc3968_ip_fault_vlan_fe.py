"""
Created on Nov 2, 2015

@author: Claude LE DU
# No test sheet found
"""

import os
import time

from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

GDMP_FLOW = "GDMP"
TIMER_DISABLE_VLAN = 1  # second

class fc3968_ip_fault_vlan_fe(SDMTestCase):
    """ IP fault: connection/deconnection of GDMP vlan on FE's edge router """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.multiTasksManager = self.sdmManager.multiTasksManager
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.connection = None
        self.router = None
        self.vlan = None
        for aConnection in self.fe.connections:
            if aConnection.flow == GDMP_FLOW:
                self.connection = aConnection
                self.router = aConnection.router
                self.vlan = aConnection.vlan
                break
        if not self.router:
            msg = "Requires router definition with GDMP flow for " + self.fe.id
            LOGGER.info(msg)
            self.skipTest(msg)
        self.exceptMsg = ""
        self.success = True


    def test_fc3968_ip_fault_vlan_fe(self):
        """ Enable/disable GDMP vlan on FE's edge router """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)


    def _precheck(self):
        """Test case precheck - Returns current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        """ Execute test case """
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)

        LOGGER.info("GDMP vlan (" + str(self.vlan) + ") will be disabled/enabled 50 times on " + self.fe.id)
        i = 0
        while i <= 50 :
            self.router.disableVlan(self.vlan)
            time.sleep(TIMER_DISABLE_VLAN)
            self.router.enableVlan(self.vlan)
            i += 1

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", self.fe.id)
        return startTime


    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        LOGGER.debug("Check the end status of the test env")
        if self.exceptMsg:
            LOGGER.warning(self.exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
