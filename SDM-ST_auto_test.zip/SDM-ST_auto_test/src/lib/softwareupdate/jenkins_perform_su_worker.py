"""
@file jenkins_worker_su.py
@ingroup SDMSQA
@author Frank Zhang
@date 2015-06-25
@brief automatically perform SDM SU
@detail
Jira ticket: SDMSQA-813
automatically perform SDM SU
"""
import os.path
import argparse

from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
import lib.exceptions_messages as eMsgs
from framework.testenv.test_env import TestEnv
from framework.testenv.lab import Lab
from framework.testenv.test_bed import TestBed
from framework.version_manager import VersionManager
from framework.env_checker import EnvChecker
from framework.configuration import Configuration
from lib.softwareupdate.sdm_su_manager import SdmSuManager
from lib.softwareupdate.sdm_su_constants import SdmSuConst
from lib.softwareupdate.sdm_su_common_func import SdmSuUtils
from lib.common.multi_tasks_manager import MultiTasksManager

LOGGER = Logger.getLogger(__name__)

class JenkinsPerformSuWorkerError(BaseException):
    """If error, raise it."""
    pass

class JenkinsPerformSuWorker(object):
    """
    framework main class.
    """

    def __init__(self, params):
        '''
        Constructor
        '''
        self.testenv = params.testenv
        self.testLabs = params.testlabs
        sshGateway = os.getenv("SSH_GATEWAY")
        sshGwUser = os.getenv("SSH_GATEWAY_USER")
        sshGwPassword = os.getenv("SSH_GATEWAY_PASSWORD")
        self.sshManager = SshManager(sshGateway, sshGwUser, sshGwPassword)
        self.versionManager = VersionManager(self.sshManager)
        self.args = params
        self.multiTasksManager = MultiTasksManager()

    def _connectLabs(self, testEnv):
        """
        invoke getClient first time to really connect labs.
        """
        for lab in testEnv.testBed.labs.values():
            LOGGER.debug("get ssh client for " + lab.id + " as root")
            self.sshManager.getClient(lab.oamIpAddress)

        # If test modes include prerequisite, SSH client for rmtadm is created in prerequisite.
        # if not, get ssh client for rmtadm here
        if SdmSuConst.PREREQUISITE not in self.args.testmode:
            if self.testLabs:
                for labId in self.testLabs:
                    LOGGER.debug("get ssh client for " + labId + " as rmtadm")
                    self.sshManager.getClient(testEnv.testBed.labs[labId].oamIpAddress, \
                        SdmSuConst.SU_USER, SdmSuConst.SU_USER_PASSWD)
            else:
                for lab in testEnv.testBed.labs.values():
                    LOGGER.debug("get ssh client for " + lab.id + " as rmtadm")
                    self.sshManager.getClient(lab.oamIpAddress, SdmSuConst.SU_USER, SdmSuConst.SU_USER_PASSWD)

        LOGGER.debug("client for OAM IP addresses are connected for testEvn %s", testEnv.id)

    def _initTestEnv(self):
        """initial test env"""
        testEnv = TestEnv()
        testEnv.id = 'SU_Lab'
        testBed = TestBed()
        testEnv.testBed = testBed

        lstLabs = [labIp.strip() for labIp in self.args.testlabs]

        for labIp in lstLabs:
            lab = Lab()
            self.sshManager.getClient(labIp)
            self.sshManager.getClient(labIp, SdmSuConst.SU_USER, SdmSuConst.SU_USER_PASSWD)
            lab.id = SdmSuUtils.getNEHostName(self.sshManager, labIp)
            lab.oamIpAddress = labIp
            testBed.labs[lab.id] = lab

        envChecker = EnvChecker(self.sshManager, self.versionManager, self.multiTasksManager)
        envChecker.checkInitialState(testEnv)
        return testEnv

    def _parseConfigFile(self):
        """Parse configuration xml"""
        configuration = Configuration()
        configuration.load(self.sshManager)
        try:
            testEnv = configuration.testEnvs[self.testenv]
        except KeyError:
            raise Exception("testenv " + self.testenv + " not found in config file")
        self._connectLabs(testEnv)

        envChecker = EnvChecker(self.sshManager, self.versionManager, self.multiTasksManager)
        envChecker.checkInitialState(testEnv)

        return testEnv

    def _createSdmSuManager(self):
        """Create SDM SU Manager"""
        sdmSuManager = SdmSuManager(self.sshManager)
        return sdmSuManager

    def _verifyLabs(self, testEnv):
        """Verify whehter the given labs exists in the current test env.
        """
        allLabs = testEnv.testBed.labs.keys()
        if not set(self.testLabs).issubset(set(allLabs)):
            # labs in subTestEnv can't be found in testEnv got from configuration.xml
            errorMsg = "%s: %s not in %s" %(eMsgs.LABS_NOT_FOUND, str(self.testLabs), str(allLabs))
            LOGGER.error(errorMsg)
            self.sshManager.closeAllClients()
            raise JenkinsPerformSuWorkerError, errorMsg

    def start(self):
        """
        Start to perform SU.
        """
        sdmSuManager = self._createSdmSuManager()
        testEnv = self._parseConfigFile()
        if self.testLabs:
            self._verifyLabs(testEnv)

        if self.args.testmode:
            suRst = sdmSuManager.performSu(self.args, testEnv)
            if suRst != SdmSuConst.RST_SUCCESS:
                self.sshManager.closeAllClients()
                raise JenkinsPerformSuWorkerError, "jobs is not completed"
        else:
            LOGGER.error("no test modes is avaiable")

        self.sshManager.closeAllClients()

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="run test cases based on"
                                     "hosts list, list of test cases and an "
                                     "optional configuration file")
    parser.add_argument("--testenv",
                        help="name of test environment (required)",
                        required=True)

    parser.add_argument("--testmode", help="SU mode, including prerequisite, download, apply, commit or backout."
                        "some of download, apply and commit can be combined, but backout can't. multiple"
                        "modes should be separated by space character, like download apply",
                        nargs="+",
                        required=True)
    parser.add_argument("--testlabs",
                        help="the lab names on which SU will be performed. this is optional,"
                        "if it is none, the target is all labs in the testenv ,or else the target is the list here"
                        "separated by space character if there are multiple labs,"
                        "like 135.1.12.1 or 135.1.12.1 135.1.12.2.",
                        type=str,
                        nargs="+",
                        default=[],
                        required=False)
    parser.add_argument("--load_server",
                        help="the ip address of the load server",
                        type=str,
                        required=False)
    parser.add_argument("--load_server_login",
                        help="the login of the load server",
                        type=str,
                        required=False)
    parser.add_argument("--load_server_password",
                        help="the password of the load server. needed for SU pre check mode",
                        type=str,
                        required=False)
    parser.add_argument("--be_load_dir",
                        help="the directory of BE SU load on the server",
                        type=str,
                        required=False)
    parser.add_argument("--fe_load_dir",
                        help="the directory of FE SU load on the server",
                        type=str,
                        required=False)
    parser.add_argument("--pfe_load_dir",
                        help="the directory of PFE SU load on the server",
                        type=str,
                        required=False)
    parser.add_argument("--oamscripts_dir",
                        help="the directory of OAMScripts on the server",
                        type=str,
                        required=False)
    parser.add_argument("--platformonlysu",
                        help="only upgrade platform including mCAS, DDM or other thirdparty, exclude SDM."
                        "please note that the SDM upgrade tool should not be installed in this case,",
                        required=False, action="store_true")
    parser.add_argument("--efx_apply_ne_type",
                        help="which type of NE will be applied emergency patches in the soaking phase."
                        "the options include BE, FE or PFE."
                        "if it is none, all types of NEs are applicable."
                        "separated by space character if more than one type, for example; BE FE",
                        type=str,
                        nargs="+",
                        default=[],
                        required=False)
    parser.add_argument("--efx_apply_patch_dir",
                        help="the directory of efx patches on the software server",
                        type=str,
                        required=False)

    args = parser.parse_args()
    LOGGER.info("test environment: " + args.testenv)
    LOGGER.info("selected labs are: %s", str(args.testlabs))
    LOGGER.info("sdm su mode: %s", args.testmode)
    LOGGER.info("load server: %s", args.load_server)
    LOGGER.info("load server login: %s", args.load_server_login)
    LOGGER.info("load server password: %s", args.load_server_password)
    LOGGER.info("BE load directory: %s", args.be_load_dir)
    LOGGER.info("FE load directory: %s", args.fe_load_dir)
    LOGGER.info("PFE load directory: %s", args.pfe_load_dir)
    LOGGER.info("oamScripts directory: %s", args.oamscripts_dir)
    LOGGER.info("platform(mCAS+DDM+thirdparty) upgraded only: %s", args.platformonlysu)
    LOGGER.info("NE type to apply emergency patches on : %s", args.efx_apply_ne_type)
    LOGGER.info("the locatioon of efx patches on the software server: %s", args.efx_apply_patch_dir)

    performSuJenkins = JenkinsPerformSuWorker(args)
    performSuJenkins.start()

if __name__ == '__main__':
    main()
