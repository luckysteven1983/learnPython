'''
Created on Mar 24, 2015

@author: Xia Zhao
'''

from lib.platform.linux_process_manager import LinuxProcessManager as PM
import lib.exceptions_messages as msgs
import time
from lib.logging.logger import Logger

logger = Logger.getLogger(__name__)

class PlatformAsserts(object):
    '''
    classdocs
    '''

    def __init__(self, sshManager):
        '''
        Constructor
        '''
        self.sshManager = sshManager

    def assertProcessAlive(self, lab, processName, timeout=300, interval=5):
        '''
        Assert Process is alive on active pilot.
        using "ps -ef | grep ProcessName" to check the process is alive or not.
        Every a certain interval, this method will check the process is alive or not,
            when timeout reached, if process still not alive, raise an exception
        @param lab: lab object on which we check processes
        @param processName: string, the name of the process
        @param timeout: int, unit is second, default is 300
        @param interval: int, unit is second, value range >0, default is 5

        PA=PlatformAsserts(...)
        PA.assertProcessAlive(host,processName,timeout)
        if process is alive, No exception raised;
            otherwise, raise an exception
        '''

        myPM = PM(self.sshManager)
        logger.debug("check "+processName+" is Alive on active pilot, timeout is "+str(timeout))
        count = 0
        while count <= timeout/interval:
            try:
                myPM.isAlive(lab, ".", processName, logLevel="debug")
            except BaseException:
                count += 1
                time.sleep(interval)
            else:
                logger.debug(processName+" is Alive on active pilot\n")
                break
        else:
            logger.error(processName+" is not Alive on active pilot\n")
            raise AssertionError(msgs.ASSERT_PROCESS_ALIVE_PILOT_FAIL)

    def assertProcessAliveOnStations(self, lab, processName, station, timeout=300, interval=5):
        '''
        Assert Process is alive the stations.
        using "ps -ef | grep ProcessName" to check the process is alive or not.
        Every a certain interval, this method will check the process is alive or not,
            when timeout reached, if process still not alive, raise an exception
        @param lab: lab object on which we check processes
        @param processName: string, the name of the process
        @param station: list, the station list, eg ["0-0-1", "0-0-2"]
        @param timeout: int, unit is second, default is 300
        @param interval: int, unit is second, value range >0, default is 5

        PA=PlatformAsserts(...)
        PA.assertProcessAlive(host,processName,station,timeout)
        if process is alive, No exception raised;
            otherwise, raise an exception
        '''

        logger.debug("check "+processName+" is Alive on all stations, timeout is "+str(timeout))
        myPM = PM(self.sshManager)
        count = 0
        while count <= timeout/interval:
            try:
                myPM.isAlive(lab, ".", processName, station, logLevel="debug")
            except BaseException:
                count += 1
                time.sleep(interval)
            else:
                logger.debug(processName+" is Alive on all stations\n")
                break
        else:
            logger.error(processName+" is not Alive on all stations\n")
            raise AssertionError(msgs.ASSERT_PROCESS_ALIVE_ALL_STATION_FAIL)

    def assertFileContainsExpectedContents(self, labOAMIP, logFile, *expectedContents):
        """@verbatim
        Check whether the log file contains contents which are specified
        if log file contains specified contents, No exception raised;
            otherwise, raise an exception
        @endverbatim

        @param labOAMIP: The Lab's OAM IP
        @param logFile: The log file which will be checked, it should provided with full path.
        @param expectedContents: Contents which should contained by the log file, it can be multiple.

        @verbatim
        Usage:
            PA=PlatformAsserts(...)
            PA.assertFileContainsExpectedContents(labOAMIP, logFile, expectedContents)
        @endverbatim
        """

        for content in expectedContents:
            cmd = "grep -l '" + content + "' " + logFile
            grepResult = self.sshManager.run(labOAMIP, cmd)
            if grepResult[0]:
                logger.error(msgs.ASSERT_LOG_CONTAIN_CONTENT_FAIL)
                raise AssertionError(msgs.ASSERT_LOG_CONTAIN_CONTENT_FAIL)