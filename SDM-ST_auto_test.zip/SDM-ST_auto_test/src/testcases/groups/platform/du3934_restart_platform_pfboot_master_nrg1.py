'''
Created on Nov 05, 2015

@author: Serge Beaufils
'''


import os
import time
import unittest

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_state_manager import DDM_DB_NDB_WAIT_REACHEABLE, \
    DDM_DB_SYNCHRO_TIMEOUT
from lib.health_check.health_check_manager import HEALTH_CHECK_ASSERT_TIME_INTERVAL
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class du3934_restart_platform_pfboot_master_nrg1(SDMTestCase):
    '''test restart platform on master be or NRG1 '''


    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()
        belist = self.testEnv.testBed.getLabsInNRG("1")
        self.masterBE = self.sdmManager.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is " + self.masterBE.id)


    def test_pfboot_master_BE(self):
        """restart by pfboot on master BE """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        '''test restart Platform on master be of NRG1'''

        LOGGER.info("start to restart Platform  on master BE of NRG1")

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.masterBE)
        LOGGER.debug("Start to restart Platform on master BE at: " + startTime)

        LOGGER.info("restarting Platform ...")
        self.sdmManager.mcasPlatformManager.restartPlatformByPfboot(self.masterBE)
        LOGGER.info("Platform restarted. Waiting 10 min (NDB state not accessible)")

        # wait 10 min as we can not assert NDB state during this time
        time.sleep(DDM_DB_NDB_WAIT_REACHEABLE)

        # We need to wait all NDB become started and lab OK.

        LOGGER.info("Now waiting for NDBs and SPAs to be recovered (max %s)", DDM_DB_SYNCHRO_TIMEOUT)
        CommonAssert.timedAssert(DDM_DB_SYNCHRO_TIMEOUT, HEALTH_CHECK_ASSERT_TIME_INTERVAL,
                                  self.sdmManager.healthCheckManager.runCheckAll, \
                                        self.masterBE, logLevel="debug")

        return startTime


    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check : %s", self.__class__.__name__)
        time.sleep(10)
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        try:
            labs = [lab for lab in self.testEnv.testBed.labs.values() if lab is not self.masterBE]
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)

        LOGGER.debug("%s success!\n", self.__class__.__name__)



if __name__ == "__main__":
    unittest.main()

