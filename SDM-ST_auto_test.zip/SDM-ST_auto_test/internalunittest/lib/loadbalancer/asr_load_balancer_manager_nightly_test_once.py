'''
Created on Aug 3, 2015
Amended on Sept 1, 2015 by Tangi Lavanant (VMMHI support)

@author: xzhao015
'''
import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
LOGGER = Logger.getLogger(__name__)

class asr_load_balancer_manager_nightly_test_once(SDMTestCase):
    """
    This class is use to test lib.loadbalancer.asr_load_balancer_manager
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        LOGGER.info("Load Balancer Manager Nightly Test")
        _, self.lab = self.testEnv.testBed.getFrontends().popitem()
        self.asrloadbalancerManager = self.sdmManager.asrloadbalancerManager

    def tearDown(self):
        pass


    def test_2_getActiveLB_success(self):
        """
        This function is used to ensure we are able to retrieve the board running Load Balancing processes
        """
        LOGGER.info('test_2_getActiveLB_success')
        if self.lab.hardware in ['HPG6', 'HPG8', 'BONO24', 'BONO48']:
            activeLBboard = self.asrloadbalancerManager.getActiveLB(self.lab)
            self.assertIn(activeLBboard, ['0-0-3', '0-0-11'])
        elif self.lab.hardware in ['VMMHI']:
            activeLBboard = self.asrloadbalancerManager.getActiveLB(self.lab)
            self.assertIn(activeLBboard, ['0-0-2', '0-0-10'])
        else:
            LOGGER.debug("lab hardware is " + self.lab.hardware + " skip this UT")

    def test_3_restartLBProcess_success(self):
        """
        This function is used to ensure Load Balancing processes can be correctly restarted
        """
        LOGGER.info('test_3_restartLBProcess_success')
        if self.lab.hardware in ['HPG6', 'HPG8', 'BONO24', 'BONO48', 'VMMHI']:
            self.asrloadbalancerManager.restartLBProcess(self.lab)
        else:
            LOGGER.debug("lab hardware is " + self.lab.hardware + " skip this UT")

    def test_4_restartLBProcess_fail(self):
        """
        This function is used to ensure the Framework correctly raise errors when LB restart process fails
        """
        LOGGER.info('test_4_restartLBProcess_fail')
        if self.lab.hardware in ['HPG6', 'HPG8', 'BONO24', 'BONO48', 'VMMHI']:
            self.assertRaises(BaseException, self.asrloadbalancerManager.restartLBProcess, self.lab, processName='ABCD')
            self.assertRaises(BaseException, self.asrloadbalancerManager.restartLBProcess, self.lab, '0-0-1')
        else:
            LOGGER.debug("lab hardware is " + self.lab.hardware + " skip this UT")

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.test_1_restartProcess_pilot_success']
    unittest.main()
