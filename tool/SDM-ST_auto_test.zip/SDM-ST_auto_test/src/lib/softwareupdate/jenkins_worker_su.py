"""
@file jenkins_worker_su.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-06-15
@brief jenkins worker for SU automation

Jekins worker fo SU test case automtion
"""

import ConfigParser
import argparse
import importlib
from unittest.loader import defaultTestLoader
from framework.common import Utils
from framework import arch
from framework.configuration import Configuration
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
import xmlrunner
import lib.exceptions_messages as eMsgs
import os.path
from framework.sdm_manager import SdmManager
from lib.softwareupdate.sdm_su_manager import SdmSuManager

LOGGER = Logger.getLogger(__name__)

def findTestModule(fileName):
    """Return test items by file name."""
    pathName = arch.BASEDIR + os.sep + arch.CASEDIR
    # add '.py'
    fileName = fileName + arch.PYTHONSUFFIX
    testModule = Utils.findFile(pathName, fileName)
    if not testModule:
        LOGGER.error('Not find %s in %s and its subdir', fileName, pathName)
    else:
        # remove '.py'
        testModule = testModule[:- len(arch.PYTHONSUFFIX)]
    return testModule

def verifyFileExist(testItems):
    """Verify all test file in testItem exists."""
    for testItem in testItems:
        if not os.path.isfile(testItem + arch.PYTHONSUFFIX):
            raise JenkinsWorkerSuException, '%s: %s' %(eMsgs.TEST_ITEM_NOK, testItem)

def testSuiteInit(testItem):
    """
    Returns a testSuite class loaded from a test case
    """
    if testItem.startswith(arch.BASEDIR + os.sep): # remove 'src/'
        testItem = testItem[len(arch.BASEDIR + os.sep):]
    testItem = testItem.replace(os.sep, '.')
    shortClassName = testItem.split('.')[-1]
    module = importlib.import_module(testItem)
    testClass = getattr(module, shortClassName)
    return (shortClassName, defaultTestLoader.loadTestsFromTestCase(testClass))

class JenkinsWorkerSuException(BaseException):
    """If error, raise it."""
    pass

class JenkinsWorkerSu(object):
    """
    framework main class.
    """

    def __init__(self, params):
        '''
        Constructor
        '''
        self.testenv = params.testenv
        self.testItems = params.testitems
        self.testLabs = params.testlabs
        self.configParser = self.__class__.parserParamFile(params.paramfile)
        sshGateway = os.getenv("SSH_GATEWAY")
        sshUser = os.getenv("SSH_GATEWAY_USER")
        sshPassword = os.getenv("SSH_GATEWAY_PASSWORD")
        self.sshManager = SshManager(sshGateway, sshUser, sshPassword)
        self.stopOnFirstFailedTC = False
        if params.stopOnFirstFailedTC:
            self.stopOnFirstFailedTC = True

    @staticmethod
    def parserParamFile(paramFile):
        """Parser parameter file"""
        configParser = ConfigParser.ConfigParser()
        configParser.readfp(open(paramFile))
        return configParser

    def _getSectionParameters(self, className):
        """Get test case parameters"""
        sections = self.configParser.sections()
        section = className if className in sections else 'DEFAULT'
        parameters = dict()
        for (param, value) in self.configParser.items(section):
            LOGGER.debug("Section %s: %s = %s", section, param, value)
            parameters[param] = value
        return parameters

    def _setAttributesOnTestCases(self, testEnv, sdmManager, testSuite, className):
        """
        trick to set attributes on test cases.

        This trick is used because test case instantiation is done by unittest
        not by the framework.
        """
        for test in testSuite._tests:  # pylint: disable=protected-access
            if not isinstance(test, SDMTestCase):
                self._setAttributesOnTestCases(testEnv, sdmManager, test, className)
            else:
                test.testEnv = testEnv
                test.testLabs = self.testLabs
                test.testParams = self._getSectionParameters(className)
                test.sdmManager = sdmManager

    def _connectLabs(self, testEnv):
        """
        invoke getClient first time to really connect labs.
        """
        for lab in testEnv.testBed.labs.values():
            LOGGER.debug("testEnv " + testEnv.id + " lab: " + lab.id)
            self.sshManager.getClient(lab.oamIpAddress)

    def _buildTestItems(self):
        """Build test items"""
        testItems = []
        for testItem in self.testItems:
            # full name
            if os.sep in testItem:
                if arch.SUITEDIR in testItem:
                    if testItem.startswith(arch.BASEDIR + os.sep): # remove 'src/'
                        testItem = testItem[len(arch.BASEDIR + os.sep):]
                    module = importlib.import_module(testItem.replace(os.sep, '.'))
                    testItems.extend(module.TEST_ITEMS)
                else:
                    testItems.append(testItem)
                continue
            # Need to search the test module
            testModule = findTestModule(testItem)
            if not testModule:
                raise JenkinsWorkerSuException, '%s: %s' %(eMsgs.TEST_ITEM_NOK, testItem)
            LOGGER.debug("testModule: " + testModule)
            if arch.SUITEDIR in testModule:
                if testModule.startswith(arch.BASEDIR + os.sep): # remove 'src/'
                    testModule = testModule[len(arch.BASEDIR + os.sep):]
                module = importlib.import_module(testModule.replace(os.sep, '.'))
                testItems.extend(module.TEST_ITEMS)
            else:
                testItems.append(testModule)
        return testItems

    def _runTestCases(self, testEnv, sdmManager):
        """Run test cases"""
        testRunner = xmlrunner.XMLTestRunner(output="test-reports")
        for testItem in self.testItems:
            (className, testSuite) = testSuiteInit(testItem)
            self._setAttributesOnTestCases(testEnv, sdmManager, testSuite, className)
            for testCase in testSuite._tests: # pylint: disable=protected-access
                LOGGER.info("*** run " + str(testCase) + " ***")
                result = testRunner.run(testCase)
                if not result.wasSuccessful()and self.stopOnFirstFailedTC:
                    # <Debug mode> stopping testsuite at first failed testcase
                    LOGGER.error(eMsgs.STOP_ON_FAILED_TC)
                    raise JenkinsWorkerSuException(eMsgs.STOP_ON_FAILED_TC)

    def _parseConfigFile(self):
        """Parse configuration xml"""
        configuration = Configuration()
        configuration.load(self.sshManager)
        try:
            testEnv = configuration.testEnvs[self.testenv]
        except KeyError:
            raise Exception("testenv " + self.testenv + " not found in config file")
        self._connectLabs(testEnv)
        return testEnv

    def _createSdmManager(self):
        """Create SDM Manager"""
        sdmManager = SdmManager()
        sdmManager.sdmSuManager = SdmSuManager(self.sshManager)
        return sdmManager

    def _verifyLabs(self, testEnv):
        """Verify whehter the given labs exists in the current test env.
        """
        allLabs = testEnv.testBed.labs.keys()
        if not set(self.testLabs).issubset(set(allLabs)):
            # labs in subTestEnv can't be found in testEnv got from configuration.xml
            errorMsg = "%s: %s not in %s" %(eMsgs.LABS_NOT_FOUND, str(self.testLabs), str(allLabs))
            LOGGER.error(errorMsg)
            raise JenkinsWorkerSuException, errorMsg

    def start(self):
        """Start to run test cases.
        """
        testEnv = self._parseConfigFile()
        self.testItems = self._buildTestItems()
        LOGGER.info("Test cases: \n" + "\n".join(self.testItems) + "\n")
        verifyFileExist(self.testItems)
        if self.testLabs:
            self._verifyLabs(testEnv)
        sdmManager = self._createSdmManager()
        self._runTestCases(testEnv, sdmManager)
        self.sshManager.closeAllClients()

def main():
    """Main function"""
    parser = argparse.ArgumentParser(description="run test cases based on"
                                     "hosts list, list of test cases and an "
                                     "optional configuration file")
    parser.add_argument("--testenv",
                        help="name of test environment (required)",
                        required=True)
    parser.add_argument("--paramfile",
                        help="parameter file with the ini format. The default one is "
                        "conf/test_case_parameter.ini. If needed, you can specify your"
                        "file like --paramfile /yourfiledir/yourfile",
                        required=False,
                        type=str,
                        default="conf/test_case_parameter.ini")
    parser.add_argument("--testlabs",
                        help="name of labs if needed (optional). This should be a lab list"
                        " like HP25 or HP25 HP26. And the lab name can be defined in"
                        "configuration.xml file",
                        type=str,
                        nargs="+",
                        default=[],
                        required=False)
    parser.add_argument("--testitems", help="provide a list of individual test"
                        " cases, group of testcases or test suites. This "
                        "parameter is required.", nargs="+", required=True)
    parser.add_argument("--stopOnFirstFailedTC", help="stop sanity at first failed testcase", \
                        required=False, action="store_true")
    args = parser.parse_args()
    LOGGER.info("test environment: " + args.testenv)
    LOGGER.info("sub test environment: %s", str(args.testlabs))
    LOGGER.info("test case parameter file: '%s'", args.paramfile)
    LOGGER.info("test items: " + ", ".join(args.testitems))
    jenkinsWorkerSu = JenkinsWorkerSu(args)
    jenkinsWorkerSu.start()

if __name__ == '__main__':
    main()

