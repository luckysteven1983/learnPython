#!/bin/bash
############################################
#### Version 0.2
#### Add BE option 
#### Nov. 4th, 2015
############################################
if [ ! -x "$1" ];then
    echo "Done data path: $1 does not exist!"
    exit 1
else
    cd $1
fi
rm -f Sta_*_mem.txt oam_mem.summary nonpilot_mem.summary nonpilot_mem_D.summary parsed_top_mem.summary parsed_top_mem.report
function mem_filter {
gawk '
$0 ~ /top -/ {Time=$3;}
$0 ~ /Mem:/ { gsub("k","");Mem=$0;}
$0 ~ /Swap:/ { gsub("k",""); printf("Time: %s\t%s\t%s\n",Time,Mem,$0); }
'
}
echo -e "Station\t AvgMem(M) \t MinMem(M) \t MaxMem(M) \t MaxTime" > parsed_top_mem.report
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|sort`
do
  ls -lrt |grep parsed_top_${sta} > /dev/null
  if [ $? -eq 0 ]; then
     file=`ls -lrt|grep parsed_top_${sta}|tail -1|awk '{print $9}'`
     cat $file | mem_filter |awk 'BEGIN {printf("%8s\t%10s\t%10s\t%10s\t%10s\t%8s\t%8s\t%8s\t%8s\t%8s\n","Time","MemTotal","MemUsed","MemFree","MemBuff","SwapTotal","SwapUsed","SwapFree","SwapCached","RealUsedMem")} { printf("%8s\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\n",$2,$4/1024,$6/1024,$8/1024,$10/1024,$13/1024,$15/1024,$17/1024,$19/1024,($6-$10-$19)/1024);}' > Sta_${sta}_mem.txt
     cat Sta_${sta}_mem.txt|awk '{print $1, $10}' |grep -v Time > tmp
     awk '{ if(min=="") {min=max=$2}; if($2>=max) {max=$2;Time=$1;}; if($2<=min) {min=$2}; total+=$2; count+=1;} END { printf("%7s\t%8.2f\t%8.2f\t%8.2f\t%8s\n", "'"$sta"'", total/count, min, max, Time);}' tmp >> parsed_top_mem.report
     rm tmp
  fi
done


echo -e "OAM_AVG_MEM(M)" > oam_mem.summary
cat parsed_top_mem.report|awk '{ if ($1 ~/A|B/) { print $0 } }' > oam_mem.tmp
awk '{ if(avg=="") avg=$2; if ($2 >= avg) avg=$2 } END { print avg } ' oam_mem.tmp >> oam_mem.summary
rm oam_mem.tmp

if [ -z "$2" ]; then
    echo "NONPILOT_AVG_MEM(M)" > nonpilot_mem.summary
    awk '{ if($1 !~ /A|B|Station/) { total+=$2; count+=1;} } END { printf("%8.2f\n", total/count) } ' parsed_top_mem.report >> nonpilot_mem.summary 
    
    paste oam_mem.summary nonpilot_mem.summary > parsed_top_mem.summary
    cat parsed_top_mem.summary >> parsed_top_mem.report
elif [ $2 == "BE" ]; then
    echo "NONPILOT_AVG_MEM(M)" > nonpilot_mem.summary
    awk '{ if($1 !~ /A|B|D|Station/) { total+=$2; count+=1;} } END { printf("%8.2f\n", total/count) } ' parsed_top_mem.report >> nonpilot_mem.summary 
    echo "NONPILOT_AVG_MEM_D(M)" > nonpilot_mem_D.summary
    awk '{ if($1 !~ /A|B|C|E|F|G|H|I|J|K|L|Station/) { total+=$2; count+=1;} } END { printf("%8.2f\n", total/count) } ' parsed_top_mem.report >> nonpilot_mem_D.summary 
    paste oam_mem.summary nonpilot_mem.summary nonpilot_mem_D.summary > parsed_top_mem.summary
    cat parsed_top_mem.summary >> parsed_top_mem.report
else
    echo "Second parameter input wrong!"
    exit 1
fi
