#!/bin/bash
#######################################################
#       usage: $0 <PT tool logs directory>
#       $LOG_DIR=<PT tool logs directory>
#######################################################  

currentpath=$(cd "$(dirname "$0")"; pwd)
hostname=`hostname|awk -F"-" '{print $1}'`
NE_TYPE=`grep 'name="CONFIGURATION"' /cust_use/SDM/SDM_tools/cfg/SDM_General_Data.xml|awk -F[\'\"] '{ print $4 }'`

cd $1
################################################################
# The tool will save the result under directory $LOG_DIR/oamResult.
################################################################
if [ -d $1/oamResult ]
then
  rm -r $1/oamResult;mkdir $1/oamResult
else
  mkdir -p $1/oamResult
fi

echo Hostname > $1/oamResult/oam_${hostname}_report.xls
echo `hostname|awk -F"-" '{print $1}'` >> $1/oamResult/oam_${hostname}_report.xls

cd $1/Done
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
echo "                     Oam CPU Statistics  oamResult                               ">>$1/oamResult/report_${hostname}
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
cat oam_cpu.report oam_cpu.summary >> $1/oamResult/report_${hostname}
paste $1/oamResult/oam_${hostname}_report.xls oam_cpu.summary > $1/oamResult/oam_${hostname}_report.tmp
mv $1/oamResult/oam_${hostname}_report.tmp $1/oamResult/oam_${hostname}_report.xls
echo "Parsing pilot cpu data done."

echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
echo "             Oam Memory Statistics  oamResult                                    ">>$1/oamResult/report_${hostname}
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
cat top_mem.report |sed -n '1p' >> $1/oamResult/report_${hostname}
cat top_mem.report |sed -n '2,$p' |awk ' { if($1 == "A" || $1 == "B") print $0 }' >> $1/oamResult/report_${hostname}
cat oam_mem.summary >> $1/oamResult/report_${hostname}
paste $1/oamResult/oam_${hostname}_report.xls oam_mem.summary > $1/oamResult/oam_${hostname}_report.tmp
mv $1/oamResult/oam_${hostname}_report.tmp $1/oamResult/oam_${hostname}_report.xls

echo "Parsing pilot memory data done."

echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
echo "             Oam Run Queue Statistics  oamResult                                 ">>$1/oamResult/report_${hostname}
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
echo "Parsing pilot run queue data ......"
$currentpath/pilot_vmstat.sh
cat runque.xls >> $1/oamResult/report_${hostname}
paste $1/oamResult/oam_${hostname}_report.xls runque.xls > $1/oamResult/oam_${hostname}_report.tmp
mv $1/oamResult/oam_${hostname}_report.tmp $1/oamResult/oam_${hostname}_report.xls
rm runque.xls
echo "Parsing pilot run que data done."

###############################################################
#  Oam Process Statistics oamResult 
###############################################################
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
echo "             Oam Processes Statistics  oamResult                                 ">>$1/oamResult/report_${hostname}
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
cat process_cpu.report |sed -n '1p' >> $1/oamResult/report_${hostname}
cat process_cpu.report |sed -n '2,$p' | awk '{ if($2 ~ /A|B/) print $0 }' >> $1/oamResult/report_${hostname}
cat process_mem.report |sed -n '1p' >> $1/oamResult/report_${hostname}
cat process_mem.report |sed -n '2,$p' | awk '{ if($2 ~ /A|B/) print $0 }' >> $1/oamResult/report_${hostname}
cat oam_process.summary >> $1/oamResult/report_${hostname}

cat oam_process.summary|sed -n '2,$p' |awk '{ printf("%-16s\t%-19s\t", $1"_AvgCpu", $1"_AvgMem(M)"); } ' > top_process.oam
cat top_process.oam|awk '{ print $0}' > top_process.tmp; mv top_process.tmp top_process.oam
cat oam_process.summary|sed -n '2,$p' |awk '{ printf("%-19.1f\t%-18.1f\t", $2, $3) } ' > top_process.tmp
cat top_process.tmp|awk '{ print $0 }' >> top_process.oam
paste $1/oamResult/oam_${hostname}_report.xls top_process.oam > $1/oamResult/oam_${hostname}_report.tmp
mv $1/oamResult/oam_${hostname}_report.tmp $1/oamResult/oam_${hostname}_report.xls
rm top_process.oam
echo "Parsing oam process data done."


##############################################################
#OAM bandwidth statistics
##############################################################
echo "Parsing bandwidth data ......"
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
echo "          Oam Bandwidth Statistics  oamResult                                    ">>$1/oamResult/report_${hostname}
echo "---------------------------------------------------------------------------------">>$1/oamResult/report_${hostname}
cat bandwidth.report|sed -n '1p' >> $1/oamResult/report_${hostname}
cat bandwidth.report|sed -n '2,$p' |awk '{ if($1 ~ /OAM/) print $0 }'  >> $1/oamResult/report_${hostname}
cat bandwidth.summary |awk '{ printf("%19s\t%19s\n", $1, $2) }' > oam_bandwidth.summary
paste $1/oamResult/oam_${hostname}_report.xls oam_bandwidth.summary > $1/oamResult/oam_${hostname}_report.tmp
mv $1/oamResult/oam_${hostname}_report.tmp $1/oamResult/oam_${hostname}_report.xls
echo "Parsing bandwidth  data done."


echo "pt_stoplog_finished" >> $1/oamResult/report_${hostname}
cat  $1/oamResult/report_${hostname}

