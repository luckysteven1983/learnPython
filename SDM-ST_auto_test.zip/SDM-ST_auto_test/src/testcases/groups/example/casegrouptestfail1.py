'''
Created on Oct. 19, 2015

@author: Andy SUN
'''
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class casegrouptestfail1(SDMTestCase):
    '''This class defines one failure test'''

    def setUp(self):
        LOGGER.debug("setUp")

    def tearDown(self):
        LOGGER.debug("tearDown")

    def test_case(self):
        ''' This is a basic failuer test'''
        LOGGER.info("case in casegrouptestfail1")
        raise Exception("test case failure")
