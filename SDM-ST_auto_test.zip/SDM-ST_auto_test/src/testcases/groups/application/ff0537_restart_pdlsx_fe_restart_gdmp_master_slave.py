'''
Created on Aug 24, 2015

@author: xzhao015
'''
import os
import random
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0537_restart_pdlsx_fe_restart_gdmp_master_slave(SDMTestCase):
    '''test kill all PDLSx processes on one FE of the testbed
    and restart gdmp process on MASTER & SLAVE '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.success = True
        self.exceptMsg = ""
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.multiTasksManager = self.sdmManager.multiTasksManager

    def test_restartpdlsx_restartGDMP(self):
        """ test kill PDLSx processes on one FE of the testbed
        and restart gdmp process on MASTER & SLAVE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("Test case post-check")
        exceptMsg = str()
        expectedAlarmsBE = []
        acceptedAlarmsBE = []
        expectedAlarmsFE = []
        acceptedAlarmsFE = []
        myAlarmsConfigFE = AlarmsConfig(expectedAlarmsFE, acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(expectedAlarmsBE, acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])

    def _restartPDLS(self, lab):
        '''restart PDLSx on all RT blade of the lab'''
        LOGGER.debug("Call LinuxProcessManager.advancedKillProcess")

        # Kill one PDLS
        pdlsList = ["PDLSU1", "PDLSI1", "PDLSL1", "PDLSM1"]
        foundProcess = None
        for plds in pdlsList:
            processOnblades = self.sdmManager.linuxProcessManager.getProcessPids(lab, plds)
            if processOnblades:
                LOGGER.debug("Found process %s", plds)
                foundProcess = plds
                break
        else:
            raise BaseException, "No PDLS available"
        self.sdmManager.linuxProcessManager.advancedKillWaitProcess(lab, foundProcess, processOnblades.keys(),
                                                                    logLevel='debug')

        LOGGER.debug("Call mcasApplicationManager.assertSPAState to check spa status on all blades")
        CommonAssert.timedAssert(1800, 10, self.sdmManager.mcasApplicationManager.assertSPAStateOnStations,
                                 lab, "SDM", "IS", lab.getStationListbyProductRole('RT').values(), 'debug')
        LOGGER.debug("Call mcasMachineManager.checkMachineStatus to check op:status,machine=all is COMPL")
        CommonAssert.timedAssert(1800, 30, self.sdmManager.mcasMachineManager.checkMachineStatus, lab, logLevel='debug')

    def _restartGdmp(self, be):
        '''restart gdmp on all blades of the be'''
        gdmpProcess = "GdmpServer"
        gdmpProcessRestart = "Gdmps"
        LOGGER.info("%s: restart gdmp process on all stations", be.id)
        stations = be.getAllBlade().keys()
        self.sdmManager.platformAsserts.assertProcessAliveOnStations(be, gdmpProcess, stations)
        LOGGER.debug("restart gdmps on all stations")
        self.sdmManager.databaseManager.runScriptOperation(be, gdmpProcessRestart, ddmOperation='restart', 
                                                           station=stations)
        LOGGER.debug("check the gdmps process on all stations can be recover")
        self.sdmManager.platformAsserts.assertProcessAliveOnStations(be, gdmpProcess, stations)

    def _runTestCase(self):
        ''' test restart PDLSx and restart GDMP process on all BE '''

        LOGGER.debug("Start to choose one FE to test this case")
        fe = random.choice(self.allFEs)

        LOGGER.info("Kill PDLSx process on FE and restart gdmp process on BEs in progress")
        threadName = self.multiTasksManager.register(self._restartPDLS, fe)
        LOGGER.info("Kill PDLSx process on Lab '%s' in progress -> thread ID '%s'", fe.id, threadName)
        for be in self.allBEs:
            threadName = self.multiTasksManager.register(self._restartGdmp, be)
            LOGGER.info("Restart gdmp process on Lab '%s' in progress -> thread ID '%s'", be.id, threadName)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.info("Wait kill PDLSx and restart gdmp process complete")
        if not self.multiTasksManager.runMultiTasks():
            raise Exception("Killing PDLSx process or restart gdmp on BE failure")

        LOGGER.info("Restart traffics if needed")
        try:
            self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)
            LOGGER.error("%s: traffic can not recover", fe.id)
        return startTime
