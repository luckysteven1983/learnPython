"""
Created on July 3, 2015

@author: Andy SUN
"""

import os

from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import SPA_TIMEOUT_SMALL


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fc3952_restart_spas_fe_swo_mated_pair(SDMTestCase):
    """Blade SW fault: remove the spa on FE and swo manual Mated pair on SLAVE"""

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.multiTasksManager = self.sdmManager.multiTasksManager

    def test_restart_spas_fe_swo_mated_pair(self):
        """restart the spa on FE and swo manual Mated pair on SLAVE.

        Procedure:
        1. restart OAM SPA on the FE and meanwhile do BE switch-over on slave BE.
        2. restart SDM SPA on the FE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check and return current active alarm list"""
        LOGGER.debug("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        # Get BE list
        LOGGER.debug("run test case ...")
        # Try to BE switch-over on NRG 1
        beObjs = self.testEnv.testBed.getLabsInNRG()
        beStates = dict((beObj.id, self.databaseStateManager.getState(beObj)) for beObj in beObjs)
        LOGGER.debug("BE states before: %s", str(beStates))
        # Get a FE
        feObj = self.allFEs[0]
        LOGGER.debug("FE name: %s", feObj.id)

        # Run multiple tasks: restart OAM SPA (with 5min timeout as OAM is restarted without OAMBE)
        # and BE switch-over
        LOGGER.info("Restart SPA and Be switch-over in progress")
        threadName = self.multiTasksManager.register(self.mcasApplicationManager.restartSPA,
                                                      feObj, "OAM", SPA_TIMEOUT_SMALL)
        LOGGER.info("Restart SPA on Lab '%s' in progress -> thread ID '%s'", feObj.id, threadName)
        threadName = self.multiTasksManager.register(self.databaseManager.matedPairSwo, beObjs)
        LOGGER.info("Be switch-over on Labs '%s' in progress -> thread ID '%s'", [lab.id for lab in beObjs], threadName)
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, beObjs[0])
        LOGGER.info("Wait restart SPA and Be switch-over complete")
        if not self.multiTasksManager.runMultiTasks():
            raise Exception("Restart OAM SPA or BE switch-over failure")

        LOGGER.info("Restarting SDM SPA on %s", feObj.id)
        self.mcasApplicationManager.restartSPA(feObj, 'SDM')
        # Here we need to make sure the other BE status can't be changed
        newStates = dict((beObj.id, self.databaseStateManager.getState(beObj)) for beObj in beObjs)
        LOGGER.debug("BE states after: %s", str(newStates))
        self.assertEqual(beStates.values().sort(), newStates.values().sort(),
                         "Other BE states are changed!")
        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post check")

        expectedAlarmsSpecific = []
        acceptedAlarmsSpecific = []
        expectedAlarms4BE = []
        acceptedAlarms4BE = []
        expectedAlarms4FE = []
        acceptedAlarms4FE = []
        exceptMsg = str()
        myAlarmsConfig4FE = AlarmsConfig(expectedAlarms4FE, acceptedAlarms4FE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4FE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep
        masterBE = self.databaseStateManager.getMasterBE(self.allBEs)
        for labIndex in self.allBEs:
            # if labIndex.id in masterBENames:
            if labIndex in masterBE:
                myAlarmsConfig4BE = AlarmsConfig(expectedAlarmsSpecific, acceptedAlarmsSpecific, startTime)
            else:
                myAlarmsConfig4BE = AlarmsConfig(expectedAlarms4BE, acceptedAlarms4BE, startTime)
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE, logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep


        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
