"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le Du
@brief Defines PtoolDiameterTraffic Class
"""

import os
import re
from threading import Thread
import time

from framework.traffic.traffic import Traffic, BadQosException
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.platform.linux_process_manager import LinuxProcessManagerError


logger = Logger.getLogger(__name__)
PURRESET_TIMEOUT = 300

# name of RESET PUR script
RESET_SCRIPT = "reset_sequence_number_jenkins.sh"
RESET_FILES_PREFIX = "reset_sequence_number"
RESET_FILES_DIR = "src/framework/traffic/ptool"
BUILD_TAG = os.getenv("BUILD_TAG", "build tag default")
BUILD_ID = os.getenv("BUILD_ID", "12345")
JOB_NAME = os.getenv("JOB_NAME", "job_name")
NODE_NAME = os.getenv("NODE_NAME", "jenkins_slave")
DIR_LOG_LOCAL = "log"
DIR_JOB_WORKSPACE = "/home/jenkins/workspace"


class PtoolDiameterTraffic(Traffic):
    """
    @details This class provides the commands to control a ptool simulator.
    """

    def __init__(self, ptoolTrafficProfile, ptoolDiameterTrafficSimulator, testBed, databaseStateManager,
                 linuxProcessManager):
        """ PtoolDiameterTraffic class constructor """

        super(PtoolDiameterTraffic, self).__init__()
        self.ptoolTrafficProfile = ptoolTrafficProfile
        self.testBed = testBed
        self.ptoolDir = ptoolTrafficProfile.ptoolDir
        self.scenario = ptoolTrafficProfile.scenario
        self.myFEPrefix = ""
        self.server = ""  # for compatibility with tgen attributes
        self.bes = []
        self.trafficType = ptoolTrafficProfile.application
        self.toolName = "Ptool"
        self.qos = ""
        self.previousQos = ""
        self.errors = 0
        self.previousErrors = 0
        # nbRequestsStart/End and nbErrorsStart/End store values from last and last but one getRequestsAndErrors
        self.nbRequestsStart = 0
        self.nbRequestsEnd = 0
        self.nbErrorsStart = 0
        self.nbErrorsEnd = 0
        self.failed = 0
        self.previousFailed = 0
        self.requests = 0
        self.account = ptoolDiameterTrafficSimulator.account
        self.toolIpAddress = ptoolDiameterTrafficSimulator.toolIpAddress
        self.sshManager = ptoolDiameterTrafficSimulator.sshManager
        # getClient is called because for traffic PCs, the connection is not done in jenkins_worker
        self.sshManager.getClient(self.toolIpAddress, user=self.account.login, pw=self.account.password)
        self.tps = ptoolTrafficProfile.tps
        self.trafficInfo = ""
        self.databaseStateManager = databaseStateManager
        self.linuxProcessManager = linuxProcessManager
        self.simplog = ""

    def _load(self, ptoolTrafficProfile):
        """ Private method that loads data into the class attributes
        @exception Exception if scenario name contains no NRG string
        @exception Exception if scenario file does not exist on PC lab """

        for lab in self.testBed.getFrontends().values():
            if lab.productRole.FE_Key == ptoolTrafficProfile.FE_Key:
                self.myFEPrefix = lab.id
                self.server = self.myFEPrefix
                break

        self.trafficInfo = "Ptool " + str(self.trafficType) + " traffic on " + self.toolIpAddress + \
                            " - FE: " + str(self.myFEPrefix) + " scenario: " + str(self.scenario)

        # Getting #NRG from scenario name
        match = re.search("NRG([0-9])", self.scenario)
        nrgKey = match.group(1)
        if not nrgKey:
            logger.error(msgs.PTOOL_SCENARIO_NO_NRG_IN_NAME + " for " + self.trafficInfo)
            raise PtoolTrafficException(msgs.PTOOL_SCENARIO_NO_NRG_IN_NAME + " for " + self.trafficInfo)

        for lab in self.testBed.getBackends().values():
            if lab.productRole.networkReplicatedGroup == nrgKey:
                if lab not in self.bes:                           # SDMSQA-1142: add lab if not already in list
                    self.bes.append(lab)

        # Checking if scenario exists
        cmd = "bash -c 'ls " + self.ptoolDir + "/" + self.scenario + "'"
        rc, _ = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        if rc != 0:
            logger.error(msgs.PTOOL_SCENARIO_NOT_FOUND + " for " + self.trafficInfo)
            raise PtoolTrafficException(msgs.PTOOL_SCENARIO_NOT_FOUND + " for " + self.trafficInfo)


    def _getPid(self):
        """ Check if a given ptool traffic is running
        @return pid the pid of simp (ptool) process """

        cmd = "bash -c 'ps -ef | grep -w " + self.ptoolDir + "/simp | grep -v grep | grep " + self.scenario \
            + " | grep " + self.myFEPrefix + " | tr -s \" \" | cut -d \" \" -f2'"
        _, stdout = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        pid = stdout
        return pid


    def _resetSequenceNumber(self):
        """ Reset the sequence number for PUR message before running HSS traffic """

        self.sshManager.getClient(self.toolIpAddress, user=self.account.login, pw=self.account.password)
        masterBE = self.databaseStateManager.getMasterBE(self.bes)[0]
        masterBEIp = masterBE.oamIpAddress
        logger.debug("Copying PUR reset scripts to pc lab")
        for myFile in os.listdir(RESET_FILES_DIR):
            if re.match(RESET_FILES_PREFIX, myFile):
                logger.debug("copy file: " + myFile + " to " + self.toolIpAddress)
                self.sshManager.scpPut(RESET_FILES_DIR + "/" + myFile, self.toolIpAddress, \
                           self.ptoolDir + "/" + myFile, user=self.account.login)
        cmd = "bash -c 'cd " + self.ptoolDir + "; chmod +x " + RESET_FILES_PREFIX + "*'"
        logger.debug("run " + cmd)
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        tries = 0
        cr = [-1]
        while tries < 3 and cr[0] != 0:
            # Try till 3 times the reset procedure (can fail for unclear reasons)
            myThread = Thread(target=self._runResetSequenceNumberScript, args=(masterBEIp, cr))
            myThread.start()
            # Wait for timeout or until thread finishes
            myThread.join(PURRESET_TIMEOUT)
            if myThread.isAlive():
                logger.debug(str(PURRESET_TIMEOUT) + "s Timeout reached " + " for reset sequence number...")
                try:
                    logger.debug("Timeout expired => reset sequence number script seems to be stuck: we kill it")
                    self.linuxProcessManager.killProcessOnServer(self.toolIpAddress, self.account.login, RESET_SCRIPT)
                except LinuxProcessManagerError:
                    pass
                break
            logger.debug("Reset sequence number: try #" + str(tries) + " => return code = " + str(cr[0]))
            tries += 1

        if cr[0] != 0:
            logger.error(msgs.PTOOL_FAILED_TO_RUN_RESET_SCRIPT + " for " + self.trafficInfo)
            raise PtoolTrafficException(msgs.PTOOL_FAILED_TO_RUN_RESET_SCRIPT + " for " + self.trafficInfo)


    def _runResetSequenceNumberScript(self, masterBEIp, cr):
        """ Run the reset sequence number (used in a thread with timeout set up) """

        logger.debug("Calling PUR reset script => may be quite long...")
        cmd = "bash -c 'cd " + self.ptoolDir + "; ./" + RESET_SCRIPT + " " + self.scenario + " " + masterBEIp + "'"
        logger.debug("run " + cmd)
        cr[0], _ = self.sshManager.run(self.toolIpAddress, cmd, self.account.login)
        logger.debug("cr = " + str(cr[0]))


    def start(self, killIfExists=False):
        """ Start a ptool traffic
        @param killIfExists the traffics must be killed and restarted if already exist
        @exception Exception if this scenario is already running
        @exception Exception if &lt;FE_Prefix&gt;.xml is not present in ptool directory
        @exception Exception if reset pur sequence script fails
        @exception Exception if traffic can not be started """

        self._load(self.ptoolTrafficProfile)
        pid = self._getPid()
        if pid and not killIfExists:
            logger.debug(msgs.PTOOL_SCENARIO_ALREADY_IN_USE + self.trafficInfo)
        else:
            if pid and killIfExists:
                logger.info(msgs.PTOOL_SCENARIO_ALREADY_IN_USE + ": " + self.trafficInfo + \
                            " => this traffic will be restarted")
                cmd = "bash -c 'kill -9 " + pid + "'"
                logger.debug("execute command on %s: %s", self.toolIpAddress, cmd)
                self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)

            logger.info("Try to start " + self.trafficInfo)
            cmd = "bash -c 'ls " + self.ptoolDir + "/" + self.myFEPrefix + ".xml'"
            logger.debug("run " + cmd + "on " + self.toolIpAddress)
            logger.debug("self.account.login ==> " + self.account.login)
            rc, _ = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
            if rc != 0:
                msgErr = msgs.PTOOL_CONFIG_FILE_NOT_FOUND + " (" + self.myFEPrefix + ".xml)"\
                         + " for " + self.trafficInfo
                logger.error(msgErr)
                raise PtoolTrafficException(msgErr)

            if self.trafficType == "HSS":
                # Reset the sequence number for PUR message before running HSS traffic
                self._resetSequenceNumber()

            # Launch the traffic with ptool
            cmd = "bash -c 'cd " + self.ptoolDir + "; export LD_LIBRARY_PATH=.; nohup " + self.ptoolDir + "/simp " + \
                   self.scenario + " " + self.myFEPrefix + ".xml > /dev/null &'"
            self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login, ignoreStdStreams=True)
            logger.debug("Waiting 20s before checking " + self.trafficType + " traffic...")
            time.sleep(20)
            pid = self._getPid()
            if not pid:
                logger.error(msgs.PTOOL_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
                raise PtoolTrafficException(msgs.PTOOL_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
            cmd = "bash -c 'cd " + self.ptoolDir + "; ls -t1 simp.log*" + pid + " | head -1 2> /dev/null'"
            _, self.simplog = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
            cmd = "bash -c 'cd " + self.ptoolDir + "; grep -c Success " + self.simplog + "'"
            rc, stdout = self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
            success = stdout
            if success == "0":
                cmd = "bash -c 'cd " + self.ptoolDir + "; kill -9 " + pid + "; rm -rf simp*." + pid + "'"
                self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
                logger.error(msgs.PTOOL_START_TRAFFIC_FAILED + " for " + self.trafficInfo)
                raise PtoolTrafficException(msgs.PTOOL_START_TRAFFIC_FAILED + " for " + self.trafficInfo)

            logger.info(self.trafficType + " traffic launched (pid=" + pid + ")...")
        # end else


    def _searchNbRequestsAndErrorsInLog(self):
        """ Get the end of ptool log and search numbers of requests and errors
        @exception Exception if this scenario is not running """

        pid = self._getPid()
        if not pid:
            logger.error(msgs.PTOOL_TRAFFIC_PROCESS_ID_NOT_FOUND + " for " + self.trafficInfo)
            raise PtoolTrafficException(msgs.PTOOL_TRAFFIC_PROCESS_ID_NOT_FOUND + " for " + self.trafficInfo)

        simlogTail = self.ptoolDir + "/" + self.simplog + "_tail"
        logger.debug("remote traffic log file on " + self.toolIpAddress + ": " + self.simplog)
        cmd = "bash -c 'tail -100 " + self.ptoolDir + "/" + self.simplog + " > " + simlogTail + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        pathToLogFile = self.sshManager.scpGet(self.toolIpAddress, simlogTail, user=self.account.login)
        logfile = pathToLogFile + "_" + BUILD_ID + "_" + BUILD_TAG.replace(" ", "_")
        os.rename(pathToLogFile, logfile)
        with open(logfile, "r") as myFile:
            for line in reversed(myFile.readlines()):
                # grep last success number in log file
                match = re.search("Success: ([0-9]+)", line)
                if match:
                    success = int(match.group(1))
                    match = re.search("Failed: ([0-9]+)", line)
                    if match:
                        # all failed requests including 3004 and 5012
                        failed = int(match.group(1))
                        match = re.search("Failed3004: ([0-9]+)", line)
                        if match:
                            # DIAMETER_TOO_BUSY a requested service cannot be provided
                            failed3004 = int(match.group(1))
                            match = re.search("Failed5012: ([0-9]+)", line)
                            if match:
                                # DIAMETER_UNABLE_TO_COMPLY the request is rejected for unspecified reasons
                                failed5012 = int(match.group(1))
                                match = re.search("Lost: ([0-9]+)", line)
                                if match:
                                    lost = int(match.group(1))
                                    break

        errors = failed3004 + failed5012 + lost
        requests = success + errors
        logger.debug("Success: " + str(success) + " Failed: " + str(failed) + " Lost: " + str(lost) + \
                     " Failed3004: " + str(failed3004) + " Failed5012: " + str(failed5012))
        return requests, errors, failed


    def getRequestsAndErrors(self):
        """ Checks the number of requests and errors, for instance
            to set a starting point from which to calculate the QoS """
        # nbRequestsStart and nbErrorsStart store values from last but one checkQoSInit
        self.nbRequestsStart = self.nbRequestsEnd
        # nbErrorsStart/1 = total ko + total timeout
        self.nbErrorsStart = self.nbErrorsEnd
        # nbRequestsEnd and nbErrorsEnd store values from last checkQoSInit
        self.nbRequestsEnd, self.nbErrorsEnd, _ = self._searchNbRequestsAndErrorsInLog()


    def checkGlobalQoS(self):
        """ Check the traffic QoS from the beginning"""

        self.previousErrors = self.errors
        self.previousQos = self.qos
        self.previousFailed = self.failed
        self.requests, self.errors, self.failed = self._searchNbRequestsAndErrorsInLog()
        # requests can be 0 because we only take into account failed3004 and 5012 but not others ("failed" counter)
        if self.requests == 0:
            self.qos = 1
        else:
            self.qos = float(self.errors) / float(self.requests)
        if self.qos not in [0, 1]:
            self.qos = "{:1.8f}".format(self.qos)
        calls = self.requests + self.failed
        logger.debug(self.trafficInfo)
        logger.debug("Requests: " + str(self.requests) + "  Calls (requests+failed): " + str(calls))
        logger.debug("Previous errors (failed3004+failed5012+lost): " + str(self.previousErrors) + \
                     " Current errors: " + str(self.errors))
        logger.debug("Previous failed (other errors): " + str(self.previousFailed) + \
                     " Current failed: " + str(self.failed))
        logger.debug("Previous QoS:" + str(self.previousQos) + " Current QoS: " + str(self.qos))
        if float(self.qos) > 0.000001:
            msg = msgs.TRAFFIC_BAD_QOS + " (" + str(self.qos) + ") for " + self.trafficInfo
            logger.error(msg)
            raise BadQosException(msg)


    def getErrorStatus(self):
        """ Returns true if number of errors or failed increased between two checkGlobalQoS """

        if self.errors > self.previousErrors or (self.failed > self.previousFailed):
            return True
        else:
            return False


    def getCountersString(self):
        """ Returns a string made of traffic counters """

        calls = self.requests + self.failed
        successes = self.requests - self.errors
        text = "QoS=" + str(self.qos) + "  Calls=" + str(calls) + "  Successes=" + str(successes) + \
                "  Errors (failed3004+5012+lost)=" + str(self.errors) + "  Failed=" + str(self.failed)
        return text


    def stop(self):
        """ Stop a ptool traffic
        @exception Exception if this scenario is not running """

        logger.info("Try to stop " + self.trafficInfo)
        pid = self._getPid()
        if not pid:
            logger.error(msgs.PTOOL_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)
            raise PtoolTrafficException(msgs.PTOOL_TRAFFIC_NOT_FOUND + " for " + self.trafficInfo)

        cmd = "bash -c 'kill -9 " + pid + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        logger.info(self.trafficType + " traffic stopped...")
        tarLog = "ptool" + "_" + self.scenario + "_pid_" + pid + ".tar.gz"
        cmd = "bash -c 'cd " + self.ptoolDir + "; tar zcvf " + tarLog + " " + self.simplog + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)
        pathToTarlog = self.sshManager.scpGet(self.toolIpAddress, self.ptoolDir + "/" + tarLog, user=self.account.login)
        ltarLog = DIR_LOG_LOCAL + "/" + tarLog
        os.rename(pathToTarlog, ltarLog)
        logger.debug("local traffic log file on " + NODE_NAME + ": " + DIR_JOB_WORKSPACE + "/" + \
                     JOB_NAME.replace(" ", "_") + "/" + ltarLog)
        logger.debug("Use 'tar xvf <filename>' to uncompress archive")
        cmd = "bash -c 'cd " + self.ptoolDir + "; rm -rf simp*" + pid + "* " + tarLog + "'"
        self.sshManager.run(self.toolIpAddress, cmd, user=self.account.login)


class PtoolTrafficException(BaseException):
    """If error, raise it."""
    pass
