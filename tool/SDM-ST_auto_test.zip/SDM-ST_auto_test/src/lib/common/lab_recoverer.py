'''
Created on May 21, 2015

@author: xzhao015
'''
import re
import time
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class LabRecoverError(BaseException):
    """If error, raise it."""
    pass

class LabRecover(object):
    '''
    classdocs
    '''

    def __init__(self, sshManager, mcasApplicationManager, mcasMachineManager):
        '''
        Constructor
        '''
        self._sshManager = sshManager
        self._mcasApplicationManager = mcasApplicationManager
        self._mcasMachineManager = mcasMachineManager

    def spaRecover(self, lab, spaName, spaStateError=False):
        '''
        recover spa
        @param lab: instance of Lab class
        @param spaName: string
        @param spaStateError: optional parameter to log if spa state is not IS

        spaRecover(lab, spaName)
        eg: spaRecover(masterBE, 'OAMBE')
        '''
        exceptionMessage = lab.id + ": " + spaName + ": spa recover fail"
        exceptionMessageAbort = lab.id + ": " + spaName + ": spa abort fail"
        LOGGER.debug("try to recover spa: %s", str(spaName))
        spaName = str(spaName.upper())
        if not re.search('[0-9]', spaName):
            version = self._mcasApplicationManager.getSPAVersion(lab, spaName)
            spaName = spaName + version
        state = self._mcasApplicationManager.getSPAStatus(lab, spaName)
        if state['SPA STATE'] == 'IS':
            LOGGER.debug("%s: %s  is IS", lab.id, str(spaName))
        else:
            # spaStateError=True is used in jenkins_worker between two test cases check
            # In this case, it is not normal to have state not IS
            if spaStateError:
                LOGGER.error("%s: %s  is %s", lab.id, str(spaName), state['SPA STATE'])
            if state['SPA STATE'] == 'MOOS':
                try:
                    self._mcasApplicationManager.restoreSPA(lab, spaName)
                except:
                    LOGGER.error(exceptionMessage)
                    raise LabRecoverError, exceptionMessage
            if state['SPA STATE'] == 'EQP':
                try:
                    self._mcasApplicationManager.abortSPA(lab, spaName)
                except BaseException:
                    LOGGER.error(exceptionMessageAbort)
                try:
                    self._mcasApplicationManager.installSPA(lab, spaName)
                    self._mcasApplicationManager.restoreSPA(lab, spaName)
                except:
                    LOGGER.error(exceptionMessage)
                    raise LabRecoverError, exceptionMessage
            if state['SPA STATE'] == 'OOS':
                try:
                    self._mcasApplicationManager.abortSPA(lab, spaName)
                except BaseException:
                    LOGGER.error(exceptionMessageAbort)
                try:
                    self._mcasApplicationManager.installSPA(lab, spaName)
                    self._mcasApplicationManager.restoreSPA(lab, spaName)
                except:
                    LOGGER.error(exceptionMessage)
                    raise LabRecoverError, exceptionMessage

            state = self._mcasApplicationManager.getSPAStatus(lab, spaName)
            LOGGER.info("%s: %s  is %s", lab.id, str(spaName), state['SPA STATE'])

    def recoverAllSpa(self, testBed, spaStateError=False):
        """
        Recover all spas on each node of a test bed
        @param testBed: test bed to recover
        @param spaStateError: optional parameter to log if spa state is not IS
        """

        for fe in testBed.getFrontends().values():
            spaList = ["SDM", "OAM"]
            for spaName in spaList:
                self.spaRecover(fe, spaName, spaStateError)

        for be in testBed.getBackends().values():
            spaList = ["OAMBE"]
            for spaName in spaList:
                self.spaRecover(be, spaName, spaStateError)


    def machineRecover(self, lab, duration=1800, interval=60):
        """If given machine is 'OOS', restore it.

        Check all machines on the target lab, if one is OOS, recover it with
        rst subhsl command.
        If the all of machines can be recovered in duration, nothing to do. Or raise exception.

        @param lab    one lab object
        @param duration    one time (unit is second) when the machine should be recovered
        @param interval    one time (unit is second) when the method will sleep before each check

            classObj.machineRecover()
            wait all machines IS in 3600 seconds, if no, raise exception.
        """
        # get OOS blade index like '0-0-1', '0-0-2'
        machines = self._mcasMachineManager.getMachineInfo(lab)
        machines = [one.split()[0] for one in machines if one.find('OOS') != -1]
        LOGGER.debug("%s: need to recover %s", lab.id, str(machines))
        for one in machines:
            # Sleep a while before restarting one machine
            time.sleep(30)
            LOGGER.debug("%s: restore %s", lab.id, one)
            self._mcasMachineManager.restoreMachine(lab, one)
        CommonAssert.timedAssert(duration, interval, self._machineAssert, lab)

    def _machineAssert(self, lab):
        """Assert all machines IS"""
        self._mcasMachineManager.checkMachineStatus(lab, logLevel="debug")
