"""
Created on Apr 16, 2015

@author: Claude Le Du
"""

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
import time

logger = Logger.getLogger(__name__)


class check_QoS_all_traffics(SDMTestCase):


    def setUp(self):
        logger.debug("setUp")
        self.logLinksPrint()  # Used to get the log links in Junit XML results


    def tearDown(self):
        logger.debug("tearDown")


    def testCheckQoSAllTraffics(self):
        logger.debug("testCheckQosAllTraffics")
        trafficManager = self.sdmManager.trafficManager

        logger.info("Waiting " + str(self.timerFirstQos) + " min...")  # pylint: disable=no-member
        timerInSec = int(self.timerFirstQos) * 60  # pylint: disable=no-member
        time.sleep(timerInSec)
        try:
            trafficManager.checkGlobalQoSAllTraffics()
        except BaseException as arg:
            logger.error(arg.message)
            raise BaseException(arg.message)
