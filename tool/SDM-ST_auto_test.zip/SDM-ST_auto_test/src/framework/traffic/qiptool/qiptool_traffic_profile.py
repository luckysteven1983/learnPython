"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines QiptoolTrafficProfile class
"""

class QiptoolTrafficProfile(object):
    """
    @details This class describes a Qiptool traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        QiptoolTrafficProfile class constructor
        """

        self.workspace = []
        self.tps = ""
