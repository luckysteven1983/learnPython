"""
@file
@ingroup SU
@author Frank Zhang
@date 2015-05-12
@brief backout the first BE after Apply1
"""
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.softwareupdate.sdm_su_constants import SdmSuConst as ct

LOGGER = Logger.getLogger(__name__)

class TestSdmSuManager(SDMTestCase):
    """Unit test for SDM SU class.
    """
    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results

    def test_ew9776_Backout(self):
        """
        backout the first BE after apply1
        """
        labIp = self.testEnv.testBed.labs.items()[0][1].oamIpAddress
        lstActions = 'BACKOUT'

        LOGGER.info("begin case ew9776: backout after apply1 on the first BE [%s]", labIp)
        rst = self.sdmManager.sdmSuManager.startSu(labIp, lstActions)

        if rst != ct.RST_SUCCESS:
            LOGGER.error("case ew9776 failed on lab [%s]", labIp)
            self.fail()
