"""
This package contains all tests cases in different directories for groups
and test suites (for nightly, weekly exeution).
"""