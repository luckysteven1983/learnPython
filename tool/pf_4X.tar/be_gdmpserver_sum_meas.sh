#!/bin/bash

file=`ls -lrt meas*|tail -1|awk '{print $9}'`

echo Time > time.txt
grep -A 1 -w   DDM_GDMPSERVER_SUM_MEAS  $file|grep -v  DDM_GDMPSERVER_SUM_MEAS |grep -v "\-\-"|awk -F ";" '{ print $1 }' | awk -F "," '{ print $2 "/" $3}'|awk -F "/" '{ print $3 "-" $1 "-" $2 "-" $4}' >> time.txt

grep -A 2 -w   ClientsConnected_SUM   $file|grep -v "\-\-"|head -1 | awk '{ print $1 "\t" $2 "\t" $3}' > sum1.txt
grep -A 2 -w   ClientsConnected_SUM   $file|grep -v "\-\-"|grep -v ClientsConnected_SUM |awk '{ print $1 "\t" $2 "\t" $3}'    >> sum1.txt

grep -A 2 -w    NbEntriesAllocated_SUM $file|grep -v "\-\-"|head -1| awk '{ print $1 }' > sum2.txt
grep -A 2 -w    NbEntriesAllocated_SUM $file|grep -v "\-\-"|grep -v   NbEntriesAllocated_SUM | awk '{print $1}' >> sum2.txt

grep -A 2 -w    NbReplyThreads_SUM   $file|grep -v "\-\-"|head -1 | awk '{ print $1 "\t" $2 }' > sum3.txt
grep -A 2 -w    NbReplyThreads_SUM   $file|grep -v "\-\-"|grep -v NbReplyThreads_SUM |awk '{ print $1 "\t" $2 }'  >> sum3.txt

paste  time.txt sum1.txt sum2.txt sum3.txt > be_gdmpserver_sum_meas.txt
rm time.txt sum1.txt sum2.txt sum3.txt

awk 'NR == 1 { print $0 "\t" "NbReplyThreadsPerConn"; next } { printf "%s\t%.1f\n", $0 , $6/$2; next }' be_gdmpserver_sum_meas.txt >> be_gdmpserver_sum_meas.xls 

echo "Max(NbReplyThreads_SUM/ClientsConnected_SUM)" > be_gdmpserver_sum_meas.result
max_NbReplyThreadsPerConn=`sort -k8 -n be_gdmpserver_sum_meas.xls|awk '{print $8}'|tail -1`
echo $max_NbReplyThreadsPerConn >> be_gdmpserver_sum_meas.result
rm be_gdmpserver_sum_meas.txt be_gdmpserver_sum_meas.xls
#cat be_gdmpserver_sum_meas.result
