"""
@file
Created on Mar 12, 2015
@ingroup SDMSQA Automation
@author Claude Le du
@brief Defines TrafficProfile class
"""

class TrafficProfile((object)):
    """
    @details This class describes a traffic profile as defined in configuration.xml.
    """

    def __init__(self):
        """
        TrafficProfile class constructor
        """

        self.id = None
        self.simulatorsTrafficProfiles = []
