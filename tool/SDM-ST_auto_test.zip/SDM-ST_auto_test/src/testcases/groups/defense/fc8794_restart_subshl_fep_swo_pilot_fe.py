'''
Created on Jun 8, 2015

@author: Xia Zhao
'''
import os
import random
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.alarm.alarm import Alarm
from framework.common import Utils
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fc8794_restart_subshl_fep_swo_pilot_fe(SDMTestCase):
    '''Blade HW fault: remove a FE non pilot blade  and swo control pilot on same FE'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms4BE = []
        self.acceptedAlarms4BE = [Alarm(419, "Major"),
                                  Alarm(954001, "Major"),
                                  Alarm(954003, "Critical")]
        self.expectedAlarms4FE = []
        self.acceptedAlarms4FE = []
        # waiting for feedback from system engineering team to define expected alarms
        self.expectedAlarmsSpecific = [
                                  #Alarm(954001, "Major"),
                                  #Alarm(917206, "Critical"),
                                  #Alarm(916103, "Major"),
                                  #Alarm(416, "Minor"),
                                  #Alarm(417, "Critical"),
                                  #Alarm(418, "Major"),
                                  #Alarm(430, "Major")
                                  ]
        self.acceptedAlarmsSpecific = [Alarm(431, "Major"),
                                       Alarm(431, "Critical"),Alarm(906065, "Minor"),
                                       Alarm(906065, "Major"),
                                       Alarm(916101, "Minor"),
                                       Alarm(917230, "Major"),
                                       Alarm(917201, "Major"),
                                       Alarm(954024, "Major")]
        self.success = True
        self.exceptMsg = ""

    def test_restart_subshl_fep_swo_pilot_fe(self):
        '''Blade HW fault: remove a FE non pilot blade  and swo control pilot on same FE'''

        self.success = True
        self.exceptMsg = ""
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.debug("Get one FE")
        _,fe = self.testEnv.testBed.getFrontends().popitem()
        LOGGER.debug("%s has been chosen ", fe.id)

        LOGGER.debug("%s: Choose one non-pilot station",fe.id)
        nonPilotStation= random.choice(self.mcasMachineManager.getMachinesNotVHost(fe))
        LOGGER.debug("%s: non-pilot station %s has been chosen",fe.id, nonPilotStation)

        LOGGER.debug("%s: check non-pilot station %s is in good status",fe.id, nonPilotStation)
        self.testEnvAsserts.assertStationOK(fe, nonPilotStation)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.info("%s: Start to restart non-pilot %s at %s", fe.id, nonPilotStation, startTime)
        self.assertTrue(self.mcasMachineManager.removeMachine(fe, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.powerOffMachine(fe, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.powerOnMachine(fe, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.restoreMachine(fe, nonPilotStation))
        CommonAssert.timedAssert(1200, 60, self.testEnvAsserts.assertStationOK, fe, nonPilotStation, 'COMPL', 'debug')

        LOGGER.info("%s: swo control pilot", fe.id)
        self.assertTrue(self.mcasMachineManager.pilotSwitchover(fe))

        LOGGER.debug("check the alarm")
        myAlarmsConfig4FE = None
        for labIndex in self.testEnv.testBed.getFrontends().values():
            if labIndex == fe:
                myAlarmsConfig4FE = AlarmsConfig(self.expectedAlarmsSpecific, self.acceptedAlarmsSpecific, startTime)
            else:
                myAlarmsConfig4FE = AlarmsConfig(self.expectedAlarms4FE, self.acceptedAlarms4FE, startTime)
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4FE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfig4BE = AlarmsConfig(self.expectedAlarms4BE, self.acceptedAlarms4BE, startTime)
        for labIndex in self.testEnv.testBed.getBackends().values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4BE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                self.exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg) + os.linesep

        if self.success:
            LOGGER.debug("fc8794_restart_subshl_fep_swo_pilot_fe success!\n")
        else:
            LOGGER.error("fc8794_restart_subshl_fep_swo_pilot_fe fail!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)
