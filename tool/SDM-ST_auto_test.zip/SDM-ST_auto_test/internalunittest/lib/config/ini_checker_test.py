#!/usr/bin/env python
"""
@file
@ingroup SDMSQA Automation
@author Xia Zhao
@date 2015-03-09
@brief Unit test for ini file parser function
"""

import unittest

from datetime import datetime
import os
import sys
from lib.logging.logger import Logger
try:
    from ConfigParser import ConfigParser 
except ImportError, e:
    sys.exit("module 'ConfigParser' not installed ?")

logger = Logger.getLogger(__name__)

class TestIniParserChecker(unittest.TestCase):
    """ Unit test for ini file parser function  """
    def setUp(self):

        self.GDMPIniFile = "internalunittest/lib/config/resource/gdmp.ini"
        self.gdmp_ipv4_network=[('cidr', '24'), ('device', 'eth0.1301/eth1.1301'), ('gateway', '192.168.226.254'), 
                                ('ip', '192.168.226.0'), ('routing_mode', 'SOURCE')]
        
    def test_1_Read(self):
        cf=ConfigParser()
        cf.read(self.GDMPIniFile)
        
        logger.debug('test read a string ')
        valueStr=cf.get('GDMP','ReplyThreadsLoadThresholds')
        self.assertEqual(valueStr,'5,65,75,85,95')
        
        logger.debug('test read int value')
        valueInt=cf.getint('GdmpsCpuMemOverload','MAX_ALLOWED_CPU')
        self.assertEqual(valueInt,70)
        
        logger.debug('test read float value')
        valueFloat=cf.getfloat('GDMP_NON_PILOTS','GDMP_RES_SIZE_LIM')
        self.assertEqual(valueFloat,8000)
        
        logger.debug('test read a item')
        valueList=cf.items('GDMP.IPV4.NETWORK')
        self.assertListEqual(valueList,self.gdmp_ipv4_network)
        
    def test_2_Update(self):
        newValue='192.168.226.1'
        oldValue='192.168.226.0'
        cf=ConfigParser()
        cf.read(self.GDMPIniFile)
        
        logger.debug('\ntest update an option ')
        logger.debug('check the ip is the oldvalue')
        self.assertEqual(cf.get('GDMP.IPV4.NETWORK','IP'),oldValue)
        
        logger.debug('update ip to new value')
        cf.set('GDMP.IPV4.NETWORK','IP',newValue)
        cf.write(open(self.GDMPIniFile,"w"))
        
        logger.debug('check the ip has been update to new value')
        self.assertEqual(cf.get('GDMP.IPV4.NETWORK','IP'),newValue)
        
        logger.debug('update ip to old value')
        cf.set('GDMP.IPV4.NETWORK','IP',oldValue)
        cf.write(open(self.GDMPIniFile,"w"))
        self.assertEqual(cf.get('GDMP.IPV4.NETWORK','IP'),oldValue)
        
    def test_3_Delete(self):
        logger.debug('\ntest delete operations')
        cf=ConfigParser()
        cf.read(self.GDMPIniFile)
        backupFile="internalunittest/lib/config/resource/gdmp.ini.bk"
        os.system('cp -f '+self.GDMPIniFile+' '+backupFile)
        
        logger.debug('check MAX_ALLOWED_CPU value is 70')
        self.assertEqual(cf.getint('GdmpsCpuMemOverload','MAX_ALLOWED_CPU'),70)
        
        logger.debug('delete option MAX_ALLOWED_CPU value')
        cf.remove_option('GdmpsCpuMemOverload','MAX_ALLOWED_CPU')
        cf.write(open(self.GDMPIniFile,"w"))
        logger.debug('check MAX_ALLOWED_CPU has been delete')
        self.assertRaises(Exception,cf.getint,'GdmpsCpuMemOverload','MAX_ALLOWED_CPU')
        
        logger.debug('#check item GDMP.IPV4.NETWORK is exist')
        self.assertListEqual(cf.items('GDMP.IPV4.NETWORK'),self.gdmp_ipv4_network)
        
        logger.debug('delete item GDMP.IPV4.NETWORK')
        cf.remove_section('GDMP.IPV4.NETWORK')
        cf.write(open(self.GDMPIniFile,"w"))
        
        logger.debug('check GDMP.IPV4.NETWORK has been delete')
        self.assertRaises(Exception,cf.items,'GDMP.IPV4.NETWORK')
        os.system('mv '+backupFile+' '+self.GDMPIniFile)  
   
if __name__ == '__main__':
    unittest.main()
