#!/bin/sh
# 5-30-2011	draft by canhua
# to lauch log.ini on the specified station

PRG="$0"

while [ -h "$PRG" ] ; do
    ls=`ls -ld "$PRG"`
    link=`expr "$ls" : '.*-> \(.*\)$'`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=`dirname "$PRG"`/"$link"
    fi
done

TOOL_DIR=`dirname "$PRG"`

help () {
	 echo "$0 station_id view_dir type [activepilot]"
	 echo "		station_id: STATION_A-L"
	 echo "		view: the view for logs"
	 echo "		type: FPAE|BE|COMCT"
	 echo "		activepilot: yes|no| : default=no"
	 echo "Sample:" 
	 echo "		$0 /MDS STATION_D COMPACT"
	 echo "		$0 /MDS/pt STATION_E FE yes"
}

if [  "$#" -lt 3 ]; then
   help
   exit 1
fi

#backup toprc and rhost is neccesary.

APPENDIX="bak.pt"
APPENDIX_NOTHING="bak.nothing"
APPENDIX_NODO="bak.nodo"

backup_and_mv_file () {
	filename=$1
	if [ -f $filename ]; then
	   if ! [ -f $filename.$APPENDIX ]; then
			mv $filename $filename.$APPENDIX
			return 0
	   else
	   	    touch 	$filename.$APPENDIX_NOTHING	   
			return 1	  
	   fi
	else
       touch 	$filename.$APPENDIX_NODO	
	fi			
}

toprc=/root/.toprc
if  [ -f $TOOL_DIR/toprc ]; then

	if backup_and_mv_file $toprc; then 
	   cp $TOOL_DIR/toprc $toprc
	fi
fi

#rhosts=/root/.rhosts

# disable the rhosts on active station
#if ! grep -i station_a $rhosts > /dev/null 2>&1  || ! grep -i station_b $rhosts > /dev/null 2>&1; then
#   	if backup_and_mv_file $rhosts; then    
#	        echo "STATION_A root" >> $rhosts
#	        echo "STATION_B root" >> $rhosts
#	fi        
#fi


sh $TOOL_DIR/_startlog.sh $@ & 
