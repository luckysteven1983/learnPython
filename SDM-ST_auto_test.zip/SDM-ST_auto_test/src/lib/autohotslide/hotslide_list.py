"""
@author: jiaxij

In order to do auto hotslide we use this tool prepare a to-do list in
which paralleled and sequential job IPs are separated by spaces and semicolons.
The order of line in lab list file is:
NonMasterBEs
MasterBEs
FEs
"""

import argparse
import os
import sys

from framework.configuration import Configuration
from framework.env_checker import EnvChecker
from framework.version_manager import VersionManager
from framework.sdm_manager import SdmManager
from framework.jenkins_worker import envTopology
from lib.logging.logger import Logger
from lib.ssh.ssh_manager import SshManager
from lib.database.ddm.database_state_manager import DatabaseStateManager
from lib.database.ddm.database_topology_manager import DatabaseTopologyManager
from lib.common.multi_tasks_manager import MultiTasksManager

LOGGER = Logger.getLogger(__name__)

def printLabListToFile(lablist, filename, mode='a'):
    """print a list of labs to a specified file with format"""
    with open(filename, mode) as filehandler:
        # filehandler.write(';'.join(lablist) + '\n')
        for labItem in lablist:
            filehandler.write(labItem.oamIpAddress + ' m;')
        filehandler.write('\n')

def getToDoList(testEnv, sshManager, args):
    """get to-do list prepared for auto hotslide"""
    allBEList = testEnv.testBed.getBackends().values()
    dtm = DatabaseTopologyManager(sshManager)
    dsm = DatabaseStateManager(sshManager, dtm)
    masterBEList = dsm.getMasterBE(allBEList)
    nonMasterBEList = list(set(allBEList) - set(masterBEList))
    allFEList = testEnv.testBed.getFrontends().values()

    printLabListToFile(nonMasterBEList, args.output, 'w')
    printLabListToFile(masterBEList, args.output, 'a')
    printLabListToFile(allFEList, args.output, 'a')

def main():
    """ main"""
    parser = argparse.ArgumentParser(description="simple demo main")
    parser.add_argument("--testenv",
                        help="name of test environment from configuration.xml (required)",
                        required=True)
    parser.add_argument("--output",
                        help="path and name of the output file(required)",
                        required=True)
    args = parser.parse_args()
    testEnvParam = args.testenv
    LOGGER.info("test environment: " + testEnvParam)

    sshGateway = os.getenv("SSH_GATEWAY")
    sshUser = os.getenv("SSH_GATEWAY_USER")
    sshPassword = os.getenv("SSH_GATEWAY_PASSWORD")
    sshManager = SshManager(sshGateway, sshUser, sshPassword)

    configuration = Configuration()
    configuration.load(sshManager)

    try:
        testEnv = configuration.testEnvs[testEnvParam]
        versionManager = VersionManager(sshManager)
        multiTasksManager = MultiTasksManager()
        envChecker = EnvChecker(sshManager, versionManager, multiTasksManager)
        envChecker.checkInitialState(testEnv)
        sdmManager = SdmManager()
        sdmManager.databaseTopologyManager = DatabaseTopologyManager(sshManager)
        envTopology(testEnv, sdmManager)

        getToDoList(testEnv, sshManager, args)

    except BaseException, e:
        LOGGER.error("Failed to generate lab list with provided testenv.")
        LOGGER.exception("Exception: %s", e)
        # raise Exception("Error in generating list of labs")
        return 1

    sshManager.closeAllClients()
    LOGGER.info("Generate lab list in hotslide_list succeeded.")
    return 0

if __name__ == '__main__':
    sys.exit(main())
