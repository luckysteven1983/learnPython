'''
Created on Mar 17, 2015

@author: Xia Zhao
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0490_restart_gdmp_master(SDMTestCase):
    '''test restart gdmps on master be'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.myDSM = self.sdmManager.databaseStateManager
        self.myDM = self.sdmManager.databaseManager
        self.myPA = self.sdmManager.platformAsserts
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []

    def test_restart_gdmp_master(self):
        '''test restart gdmps on master be'''

        process = "GdmpServer"
        processRestart = "Gdmps"
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.info("start to restart gdmpserver on master BE")
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getNRG("1")
        masterBE = self.myDSM.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.debug("Start to restart gdmps on master BE at: " + startTime)

        stations = masterBE.getAllBlade().keys()
        LOGGER.debug("the station list is: "+str(stations))

        LOGGER.debug("check the gdmps process on all stations is alive")
        self.myPA.assertProcessAliveOnStations(masterBE, process, stations)

        LOGGER.debug("restart gdmps on all stations")
        self.myDM.restartProcess(masterBE, processRestart, stations)

        LOGGER.debug("check the gdmps process on all stations can be recover")
        self.myPA.assertProcessAliveOnStations(masterBE, process, stations)

        LOGGER.debug("check the alarm")
        # Compares alarms from snmp log file to expected and accepted lists
        # but doesn't check all raised alarms are cleared
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(masterBE, myAlarmsConfig,
                                                               logFile=LOGFILE[1])

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        LOGGER.debug("ff0490 restart gdmpserver on master BE success!\n")
