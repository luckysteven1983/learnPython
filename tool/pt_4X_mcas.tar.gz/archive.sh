tar cvfz pt_4X_mcas.tar.gz dopack.sh checklab autotest.sh upload.exp upload toprc switch.ini stoplog.sh startlog.sh _startlog.sh simpWatch shunit2 runtest rexec_switch.exp rexec_switch readme.txt pt meminfo log_switch local_profile lg gmetric_pmap.sh gmetric_cpu.sh getrouter.exp getrouter fw gpackcore install.sh log.ini netstat_lb.sh netstat_rt.sh netstat_db.sh lftp lnewinstall lcores lping list_contract.exp pt_upload log.sql log_collector.sh archive.sh bkdoor fbkdoor_meas bbkdoor_meas Readme.txt

mv *.tar.gz ../

