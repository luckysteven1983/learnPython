"""
Created on Nov 24, 2015

@author: Zheng Yuan

#weblink_id=3KJ-00117-0829-QPZZA
"""
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.common import Utils
from lib.alarm.alarms_config import AlarmsConfig
import lib.exceptions_messages as msgs
import random

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class es4812_check_critical_data_in_DB(SDMTestCase):
    """
    Note:
        If the lab environment is not okay for health check tool, the TC will not run and will be skipped by Framework,\
        you can search key word 'warning_error.log' in the detailed Test Case log for more details if this happen.
    Case Description:
        Run healthcheck tool command to get DB KPI
    Automation Test Procedure:
        1. Test case pre-check
        2. Run health check tool dbkpi check command
        3. Check the output of the result of the dbkpi check command
        4. Check whether the logs have been generated
        5. Check logs content generated correctly
        6. Show the case running result
        7. Lab check and recovery: Since Health check tool won't impact the lab status, so no need to recovery Lab
    """

    def setUp(self):
        """Init the managers this case need"""
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.myHCM = self.sdmManager.healthCheckManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mySshManager = self.sdmManager.sshManager
        self.platformAsserts = self.sdmManager.platformAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.be = random.choice(self.allBEs)
        self.exceptMsg = str()
        self.expectedAlarms = []
        self.acceptedAlarms = []
        self.checkOutput = self.myHCM.runToolCmd(self.be, "dbkpi -s")
        if "nok" in self.checkOutput:
            LOGGER.warning("The lab environment is not okay for health check tool, please check the detailed Test Case \
            log for more details. Lab ID:" + self.be.id)
            grepResult = self.mySshManager.run(self.be.oamIpAddress, "cat /cust_use/healthTools/log/healthcheck/warning_error.log")
            if grepResult[0]:
                LOGGER.error(msgs.LOG_FILE_NOT_FOUND)
                raise AssertionError(msgs.LOG_FILE_NOT_FOUND)
            LOGGER.debug("HealthCheckTool warning_error.log: " + grepResult[1])
            self.skipTest("The lab environment is not okay for health check tool, please check the detailed Test Case \
            log for more details. Lab ID:" + self.be.id)

        LOGGER.debug("Test case es4812_check_critical_data_in_DB started")


    def _precheck(self):
        """Test case pre-check and return current active alarm list"""
        checkQoS = False

        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0], checkQoS)


    def test_check_critical_data_in_DB(self):
        """Use health check tool to check dbkpi of BE"""
        expectCheckOutput = ["Completed dbkpi check with status ok", "health completed"]
        toolDir = "/cust_use/healthTools"
        checkLogDir = toolDir + "/log/healthcheck"
        checkLogCommand = "ls " + checkLogDir + ";ls " + checkLogDir + "/per_module"
        checkLogs = ["all.log", "progress.log", "per_module", "dbkpi.log"]
        logContents = ["Start dbkpi -s check", "Completed dbkpi check with status ok", "health completed",
                      "dbkpi progress", "dbkpi information"]  # What contents the log should contain
        logFiles = [checkLogDir + "/all.log", checkLogDir + "/progress.log", checkLogDir + "/per_module/dbkpi.log"]
        checkQoS = False

        # Test case pre-check
        self._precheck()

        # get the start time of the TC
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.be)

        for output in expectCheckOutput:
            if output not in self.checkOutput:
                LOGGER.error(msgs.HEALTH_CHECK_TOOL_OUTPUT_NOK)
                raise Exception(msgs.HEALTH_CHECK_TOOL_OUTPUT_NOK)

        # Check whether the logs have generated
        LOGGER.debug("Check whether log files have generated")
        checkLogOutput = self.mySshManager.run(self.be.oamIpAddress, checkLogCommand)
        for logName in checkLogs:
            if logName not in checkLogOutput[1]:
                LOGGER.error(msgs.HEALTH_CHECK_TOOL_LOGS_GEN_NOK)
                raise Exception(msgs.HEALTH_CHECK_TOOL_LOGS_GEN_NOK)

        # Check logs contains the specified content
        LOGGER.debug("Check logs contains the specified content")
        try:
            self.platformAsserts.assertFileContainsExpectedContents(self.be.oamIpAddress, logFiles[0], logContents[0],
                                                                    logContents[1], logContents[2], logContents[3],
                                                                    logContents[4])
            self.platformAsserts.assertFileContainsExpectedContents(self.be.oamIpAddress, logFiles[1], logContents[0],
                                                                    logContents[1], logContents[2])
            self.platformAsserts.assertFileContainsExpectedContents(self.be.oamIpAddress, logFiles[2], logContents[0],
                                                                    logContents[1], logContents[3], logContents[4])
        except BaseException:
            LOGGER.error(msgs.HEALTH_CHECK_TOOL_LOGS_CONTENT_NOK)
            raise Exception(msgs.HEALTH_CHECK_TOOL_LOGS_CONTENT_NOK)

        # Check the alarms at the end
        LOGGER.debug("check the alarms")
        # check the alarms on ONE node, make sure that all expect alarm are raised, and no abnormal alarms, eg:
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        try:
            # Compares alarms from snmp log file to expected and accepted lists
            # but doesn't check all raised alarms are cleared (done in assertEndState)
            self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(self.be, myAlarmsConfig, logFile=LOGFILE[1])
            # LOGFILE[1] is a csv file used to save alarms raised since test case is running
        except BaseException, msg:
            # Verdict not yet based on alarms
            self.exceptMsg += str(msg)
            LOGGER.exception("%s: alarm check fail", self.be.id)

        # Check the end status of the test env
        LOGGER.debug("Check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkQoS)
        LOGGER.debug("es4812_check_critical_data_in_DB success!\n")
