'''
Created on Jul 29, 2015

@author: xzhao015
'''
import time
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
LOGGER = Logger.getLogger(__name__)
csvMeasLogFile = "log/csvLogFile.csv"

class measurement_manager_nightly_test_once(SDMTestCase):

    def setUp(self):
        LOGGER.info("measurement_manager_nightly_test_once")
        self.logLinksPrint()#Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.sshManager = self.sdmManager.sshManager
        self.measurementManager = self.sdmManager.measurementManager
        self.table = "MS_PERF_MEAS"
        self.tableToGetData= "SDM_MEAS_HSS_SH"
    def tearDown(self):
        pass

    def test_01_updateMeas_success(self):
        LOGGER.info("test_01_updateMeas_success, expect to be success")

        preconfig = self.measurementManager.getMeasConfig(self.fe, self.table)

        self.measurementManager.updateMeas(self.fe, self.table, False, 60, True)
        config = self.measurementManager.getMeasConfig(self.fe, self.table)
        self.assertEqual(config['ms_gen_file'], True, 'measurement update fail for ms_gen_file')
        self.assertEqual(config['inhibited'], False, 'measurement update fail for inhibited')
        self.assertEqual(config['ms_intvl_v'], 60, 'measurement update fail for inhibited')

        inhibited = preconfig['inhibited']
        interval = preconfig['ms_intvl_v']
        genFile = preconfig['ms_gen_file'] 
        self.measurementManager.updateMeas(self.fe, self.table, inhibited, interval, genFile)
        afterConfig = self.measurementManager.getMeasConfig(self.fe, self.table)
        self.assertEqual(preconfig['ms_gen_file'], afterConfig['ms_gen_file'], 'measurement update file for ms_gen_file')
        self.assertEqual(preconfig['inhibited'], afterConfig['inhibited'], 'measurement update file for inhibited')
        self.assertEqual(preconfig['ms_intvl_v'], afterConfig['ms_intvl_v'], 'measurement update file for inhibited')

    def test_02_updateMeas_fail(self):
        LOGGER.info("test_02_updateMeas_fail, check exception raised")
        self.assertRaises(BaseException, self.measurementManager.updateMeas, self.fe, 'abc')

    def test_03_openMeas_success(self):
        LOGGER.info("test_03_openMeas_success, expect to be success")
        self.measurementManager.openMeas(self.fe, self.table)
        config = self.measurementManager.getMeasConfig(self.fe, self.table)
        self.assertEqual(config['inhibited'], False, 'measurement update fail for inhibited')

    def test_04_openMeas_fail(self):
        LOGGER.info("test_04_openMeas_fail, check exception raised")
        self.assertRaises(BaseException, self.measurementManager.openMeas, self.fe, 'abc')

    def test_05_closeMeas_success(self):
        LOGGER.info("test_05_closeMeas_success, expect to be success")
        self.measurementManager.closeMeas(self.fe, self.table)
        config = self.measurementManager.getMeasConfig(self.fe, self.table)
        self.assertEqual(config['inhibited'], True, 'measurement update fail for inhibited')

    def test_06_closeMeas_fail(self):
        LOGGER.info("test_06_closeMeas_fail, check exception raised")
        self.assertRaises(BaseException, self.measurementManager.closeMeas, self.fe, 'abc')

    def test_07_getMeasData_success(self):
        LOGGER.info("test_07_getMeasData_success, expect to be success")
        endTime =int(time.time())
        startTime = endTime - 3600
        measData = self.measurementManager.getMeasData(self.fe, self.tableToGetData, startTime, endTime)
        LOGGER.debug("measurement data is " + str(measData))

    def test_08_getMeasData_fail(self):
        LOGGER.info("test_08_getMeasData_fail, check exception raised")
        endTime =int(time.time())
        startTime = endTime - 3600
        self.assertRaises(BaseException, self.measurementManager.getMeasData, self.fe, 'abc', startTime, endTime)

    def test_09_getMeasDataAsCsv_success(self):
        LOGGER.info("test_09_getMeasDataAsCsv_success, expect to be success")
        endTime =int(time.time())
        startTime = endTime - 3600
        measDataCavFile = self.measurementManager.getMeasDataAsCsv(self.fe, self.tableToGetData, csvMeasLogFile, startTime, endTime)
        LOGGER.info("test_09_getMeasDataAsCsv_success, file is : " + measDataCavFile)

    def test_10_getMeasDataAsCsv_fail(self):
        LOGGER.info("test_10_getMeasDataAsCsv_fail, check exception raised")
        endTime =int(time.time())
        startTime = endTime - 3600
        self.assertRaises(BaseException, self.measurementManager.getMeasDataAsCsv, 'abc.csv', self.fe, 'abc', startTime, endTime)
