#!/bin/bash
echo -e "Sta\t" "Max\t" "Core\t" "MaxAvg" > hot_sta_core
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'|awk '{ gsub("STATION_","",$0); print;}'|grep -v [AB]|sort` 
do
        #In case there are more than one top file for one station, we use the latest one.
        #top_file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'|wc -l`
        #In case there is no top file for some station, we ignore it.
        if [ `ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'|wc -l` -eq 0 ]
        then
            echo " top_${sta} doesn't exist!"
        else
            top_file=`ls -lrt|grep top_${sta}|tail -1|awk '{print $9}'`
            processor=`cat /proc/cpuinfo|grep processor|wc -l`
            cmd="paste"
            for core in `seq $processor` 
              do
                 core=`expr $core - 1`
                 grep "Cpu${core} " $top_file | awk -F, '{ print $4 $5}'|sed -n -e 's/%id//p'|sed -n -e 's/%wa//p' | awk '{ printf "%.1f\n", 100-$1-$2}' > Cpu_${core}
                 grep "Cpu${core} " $top_file | awk -F, '{ print $4 $5}'|sed -n -e 's/%id//p'|sed -n -e 's/%wa//p' | awk '{ printf "%s\t%.1f\n","'"$sta"'"_"'"$core"'", 100-$1-$2}'>> cpu.t 
                 cmd=`echo $cmd " " Cpu_${core}`
                 avg=`awk '{ cpu += $1; ++num;next } END { printf "%.1f\n", cpu/num}' Cpu_${core}`
                 echo -e ${sta}${core} "\t"  $avg >> avg_$sta
              done
                 exec $cmd > cpu_$sta.txt &
                 sleep 1
                 max=`awk -v sta=$sta  '{ max=0; for(i=1;i<=NF;i++) if(max<$i) max=$i; sum+=max; ++num; next } END {printf "%s\t%.1f", sta,sum/num}' cpu_$sta.txt`
                 rm cpu_$sta.txt Cpu_*
                 max_avg=`sort -k2 -n avg_$sta|tail -1`
                 echo -e $max "\t" $max_avg >> hot_sta_core
                 rm avg_$sta
        fi
done

hottest_cpu=`sort -n -k2 cpu.t|tail -1`
avg_cpu=`awk '{ cpu += $2; ++num;next } END { printf "%.1f\n", cpu/num}' cpu.t`
echo -e  "Sta_core\tHottestCpu\tAvgCpu" > cpu.result
echo -e "${hottest_cpu}\t${avg_cpu}" >> cpu.result
sort -k2 -n hot_sta_core >> cpu.result
rm cpu.t


