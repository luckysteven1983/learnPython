'''

Created on Jun 11, 2015

@author: S Beaufils

Modified Jul 22, 2015
Tangi Lavanant (VMMHI support)

Restart a random board of lab(s). Random board is chosen in non-pilot boards

'''
import time
import random
import unittest
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert
from lib.hardware.hardware_machine_manager import StateHW

logger = Logger.getLogger(__name__)

class hardware_machine_manager_weekly_test_once(SDMTestCase):
    '''
    test_once for restart board function
    '''

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.lab = self.testEnv.testBed.getFrontends().popitem()
        self.hardwareManager = self.sdmManager.hardwareManagerFactory.createHardwareManager(self.lab)

    def test_vmmhiPowerOffOn(self):
        '''
        Power Off/On vmmhi boards
        '''
        waitTime = 3600  # Value comming from FWv1 Only true for FE case
        if self.lab.hardware == 'VMMHI':
            logger.info("Specific test for VMMHI")
            logger.info("Power Off board 2")
            output = self.hardwareManager.powerOffBoard(self.lab, 2)
            logger.debug(output)
            output = self.hardwareManager.getHardwareState(self.lab, 2)
            logger.debug(output)
            _msg = ("Board 2 on " + self.lab.id + " is still powered on")
            CommonAssert.assertEqual(output, StateHW.BOARD_POWERED_OFF, _msg, 'error')
            logger.info("Board 2 on " + self.lab.id + " is powered off")
            logger.info("Power On board 2")
            output = self.hardwareManager.powerOnBoard(self.lab, 2)
            logger.debug(output)
            # Wait 5 seconds, so we are sure the board state is changed
            time.sleep(5)
            output = self.hardwareManager.getHardwareState(self.lab, 2)
            logger.debug(output)
            _msg = ("Board 2 on " + self.lab.id + " is  not powered on")
            CommonAssert.assertEqual(output, StateHW.BOARD_POWERED_ON, _msg, 'error')
            logger.info("Board 2 on " + self.lab.id + " is powered on")
            logger.info("Wait Station is online before next test case")
            myAssert = self.sdmManager.testEnvAsserts.assertStationOK
            CommonAssert.timedAssert(waitTime, 30, myAssert, self.lab, '0-0-2')
        else:
            logger.info("Specific test for VMMHI, not performed on " + self.lab.hardware)

# >>> CAUTION  restart board may cause failures (to avoid an unexpected restart board !)
# Depends on HW but recover time is very long (not at board level but at DB. check with fw lsndb)
# So it is done on FE

    def test_restartBoardOnLab(self):
        '''
        restart a random  non-pilot board of self.lab
        '''
        logger.info("test_restartBoardOnLab with wait time = 3600s")
        waitTime = 3600  # Value comming from FWv1 Only true for FE case
        logger.debug("Board Restart may let the board in a wrong state")
        npMach = self.sdmManager.mcasMachineManager.getMachinesNonPilot(self.lab)
        # --- choose the second one of the list : random
        boardN = npMach[random.randint(0, len(npMach) - 1)].split('-')[2]
        logger.info(' >>>> restarting board ' + boardN + ' on ' + self.lab.id)

        logger.info("Restarted board on " + self.lab.id + " OK")
        # VMMHI and HP always show active status. (No inactive show when restarting)
        if self.lab.hardware not in ['VMMHI', 'HPG6', 'HPG8']:
            _msg = ("Board on " + self.lab.id + " is still powered on")
            time.sleep(30)  # wait 30s for  HW status change
            _output = self.hardwareManager.getHardwareState(self.lab, boardN)
            CommonAssert.assertEqual(_output, StateHW.BOARD_POWERED_ON, _msg, 'error')

        # Need to wait for board being up again
        logger.info("Wait Station is online before next test case")
        myAssert = self.sdmManager.testEnvAsserts.assertStationOK
        CommonAssert.timedAssert(waitTime, 30, myAssert, self.lab, '0-0-' + boardN, logLevel='debug')

if __name__ == "__main__":

    unittest.main()
