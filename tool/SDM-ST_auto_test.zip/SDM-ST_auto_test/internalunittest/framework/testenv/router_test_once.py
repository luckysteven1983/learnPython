"""
Created on Sept 30, 2015

@author: Claude Le Du
"""
import unittest
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase

LOGGER = Logger.getLogger(__name__)

class router_test_once(SDMTestCase):
    """
    This class is to test library used to load router info
    """

    def setUp(self):
        LOGGER.info("Setup of router test once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results

    def tearDown(self):
        pass

    def test_1_show_vlan(self):
        """ Run show vlan command on 1st router from 1st found FE """
        _, fe = self.testEnv.testBed.getFrontends().popitem()
        myRouter = fe.connections[0].router
        myRouter.showVlan()

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
