'''
Created on Mar 26, 2015

@author: test
'''
import unittest
import time
from framework.asserts.common_asserts import CommonAssert
from lib.logging.logger import Logger
import lib.exceptions_messages as msgs
from framework.sdm_test_case import SDMTestCase
from lib.database.ddm.database_manager import SCRIPT_GDMP_SERVER, \
    SCRIPT_TOPOLOGY_MANAGER, SCRIPT_PLATFORM_PROXY, SCRIPT_DBSUPERVISOR
logger = Logger.getLogger(__name__)

class database_manager_nightly_test_once(SDMTestCase):


    def setUp(self):
        logger.info("DataBase Manager Nightly Test")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.client = self.testEnv.testBed.getBackends().popitem()
        self.DM = self.sdmManager.databaseManager
        self._linuxProcessManager = self.sdmManager.linuxProcessManager


    def tearDown(self):
        pass


    def test_1_restartProcess_pilot_success(self):
        self.DM.runScriptOperation(self.client, SCRIPT_GDMP_SERVER, ddmOperation='restart')


    def test_2_restartProcess_pilot_failed(self):
        self.assertRaisesRegexp(BaseException, msgs.PROCESS_RESTART_FAILED_ON_ACTIVE_PILOT, \
                                self.DM.runScriptOperation(self.client, "GdmpsABC", ddmOperation='restart'))

    def test_3_stop_start(self):
        self.DM.runScriptOperation(self.client, SCRIPT_GDMP_SERVER, ddmOperation='forceStatusOk')
        self.DM.runScriptOperation(self.client, SCRIPT_GDMP_SERVER, ddmOperation='stop')
        time.sleep(3)
        self.DM.runScriptOperation(self.client, SCRIPT_GDMP_SERVER, ddmOperation='stopForceStatusOk')
        self.DM.runScriptOperation(self.client, SCRIPT_GDMP_SERVER, ddmOperation='start')


    def test_5_restartProcess_stations_success(self):
        stations = ["0-0-1", "0-0-2"]
        self.DM.runScriptOperation(self.client, SCRIPT_GDMP_SERVER, station=stations, ddmOperation='restart')

    def test_6_restartProcess_stations_failed(self):
        stations = ["0-0-1", "0-0-2"]
        self.assertRaisesRegexp(BaseException, msgs.PROCESS_RESTART_FAILED_ON_STATIONS, \
                                self.DM.runScriptOperation(self.client, "GdmpsABC",
                                                           station=stations, ddmOperation='restart'))

    def test_7_restartPlatformProxy_pilot_success(self):
        self.DM.runScriptOperation(self.client, SCRIPT_PLATFORM_PROXY, ddmOperation='restart')

    def test_8_restartdbsup_pilot_success(self):
        self.DM.runScriptOperation(self.client, SCRIPT_DBSUPERVISOR, ddmOperation='restart')
        CommonAssert.timedAssert(300, 5, self._linuxProcessManager.isAlive, self.client, ".",
                                 '/usr/dhafw/bin/DbSupervisor', logLevel="debug")


if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.test_1_restartProcess_pilot_success']
    unittest.main()
