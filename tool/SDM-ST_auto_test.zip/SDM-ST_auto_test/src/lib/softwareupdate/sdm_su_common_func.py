'''
Created on Apr 29, 2015@aAuthor: FrankZh

the module provides common functions
'''
import os
from time import sleep

import socket
from paramiko.ssh_exception import SSHException, ChannelException

from lib.logging.logger import Logger
from lib.softwareupdate.sdm_su_constants import SdmSuConst

LOGGER = Logger.getLogger(__name__)

class SdmSuUtils(object):
    """
    SDM SU Common functions
    """
    @staticmethod
    def safeSshRun(sshMngr, hostIp, strCmd, user='root'):
        """
        add the dealing with ssh connection broken
        """
        i = 0
        bConnected = False
        while i < 6:
            try:
                #for SU, only rmtadm, ainet and root will be used
                if user == SdmSuConst.SU_USER:
                    client = sshMngr.getClient(hostIp, SdmSuConst.SU_USER, SdmSuConst.SU_USER_PASSWD)
                elif user == SdmSuConst.AINET_USER:
                    client = sshMngr.getClient(hostIp, SdmSuConst.AINET_USER, SdmSuConst.AINET_PASSWD)
                else:
                    client = sshMngr.getClient(hostIp)

                if not client:
                    LOGGER.error("can't get client for host[%s]", hostIp)
                elif not client.get_transport().is_alive():
                    LOGGER.error("the connection to host[%s] is not avaliable ", hostIp)
                    sshMngr.closeClient(hostIp, user)
                else:
                    bConnected = True

                if bConnected == True:
                    lstRst = sshMngr.run(hostIp, strCmd, user)
                    break
                else:
                    i += 1
                    sleep(SdmSuConst.RECONNECT_INTERVAL)
                    continue

            except (ChannelException, SSHException, socket.error, EOFError):
                sshMngr.closeClient(hostIp, user)
                i += 1
                sleep(SdmSuConst.RECONNECT_INTERVAL)
                continue

        if i == 6:
            lstRst = -1, ''
            LOGGER.error("can't run command [%s] on host[%s] with login[%s] due to connection broken", \
                strCmd, hostIp, user)

        return lstRst


    @staticmethod
    def getPilotFixedIpByVip(sshMngr, vip, user=SdmSuConst.SU_USER):
        """
        get the pilot-A and Pilot-B fixed IP by floating iP
        """
        strCMD = "grep IPADDR \
        /opt/config/servers/0-0-1/local/root/etc/sysconfig/network-scripts/ifcfg-oam; \
        grep IPADDR /opt/config/servers/0-0-9/local/root/etc/sysconfig/network-scripts/ifcfg-oam"
        lstPilot = ''
        #run the command
        lRst = SdmSuUtils.safeSshRun(sshMngr, vip, strCMD, user)
        if lRst[0] == 0:
            lstPilot = lRst[1].split()
            pilotA = lstPilot[0].split('=')[1].strip()
            pilotB = lstPilot[1].split('=')[1].strip()
            return [pilotA, pilotB]
        else:
            LOGGER.error("failed to get fix ip addresses of host[%s] with login[%s]", vip, user)
            return []

    @staticmethod
    def getNEHostName(sshMngr, rHost, user=SdmSuConst.SU_USER):
        """
        get host name from /opt/config/servers/0-0-1/local/opt/config/data/config_info
        """
        strCMD = "grep SystemName /opt/config/servers/0-0-1/local/opt/config/data/config_info"
        neName = ''
        #run the command
        lRst = SdmSuUtils.safeSshRun(sshMngr, rHost, strCMD, user)
        if lRst[0] == 0:
            neName = lRst[1].split()[1].strip()
        else:
            LOGGER.error("failed to get the name of host[%s] with login[%s]", rHost, user)

        return neName

    @staticmethod
    def getSoftwareSvrData():
        '''
        get SwSvrIp, SwLoc, SwSvrLogin from SU configuration file
        '''
        dictSwSvrData = {}.fromkeys(('SwSvrIp', 'SwLoc', 'SwSvrLogin'), '')
        try:
            fdConf = open(SdmSuConst.LOCAL_SU_Conf_FILE, 'r')
            for eachLine in fdConf:
                if eachLine.strip()[0] == '#':
                    continue

                if eachLine[-1] == os.linesep:
                    eachLine = eachLine[:-1]

                eachItem = eachLine.split('=')
                if eachItem[0].strip() == 'SoftwareServerIP':
                    dictSwSvrData['SwSvrIp'] = eachItem[1].strip()
                elif eachItem[0].strip() == 'SoftwareLocation':
                    dictSwSvrData['SwLoc'] = eachItem[1].strip()
                elif eachItem[0].strip() == 'SoftwareServerLogin':
                    dictSwSvrData['SwSvrLogin'] = eachItem[1].strip()
        except IOError, ex:
            LOGGER.error("failed to read software server info: %s", ex)

        if not fdConf.closed:
            fdConf.close()

        return dictSwSvrData

    @staticmethod
    def getDebugLevel():
        '''
        get debug level from the SU configuration file
        '''
        debugLevel = ''
        try:
            fdConf = open(SdmSuConst.LOCAL_SU_Conf_FILE, 'r')
            for eachLine in fdConf:
                if eachLine.strip()[0] == '#':
                    continue
                if eachLine[-1] == os.linesep:
                    eachLine = eachLine[:-1]

                eachItem = eachLine.split('=')
                if eachItem[0].strip() == 'DebugLevel':
                    debugLevel = eachItem[1].strip()
                    break
        except IOError, ex:
            LOGGER.error("failed to read debug level: %s", ex)

        if not fdConf.closed:
            fdConf.close()

        return debugLevel

    @staticmethod
    def getSoftwareInventoryData(sshMngr, labIp, user=SdmSuConst.SU_USER):
        '''
        run getSoftwareInventoryData on the destination NE;
        retrieve softwareInventory data from remote NE
        get the action state and valid actions
        the content of SoftwareInventory as below, only get the first three lines
            NE_NAME:QDATCA08oam-0-0-1
            SOFTWARE_ACTION_STATE:DOWNLOAD-FAILED
            VALID_ACTION:INSTALL_AGENT, DOWNLOAD
            RUNNING_VERSION:R3.2.8
            VALID_VERSION:R3.2.8
            DOWNLOADED_VERSION:R3.2.13
            SOFTWARE_INFORMATION:R3.2.13
        return value: dictionary including the first three lines. if its length is 0, it means failure
        '''
        dicSWInv = {}

        lRstCmd = SdmSuUtils.safeSshRun(sshMngr, labIp, SdmSuConst.CMD_SOFTWAREINVENTORY, user)

        if lRstCmd[0] == 0:
            LOGGER.debug("SoftwareInventory run on %s successfully", labIp)
        else:
            LOGGER.debug("SoftwareInventory failed on %s", labIp)
            return dicSWInv

        lstSwInv = []
        strCMD = "cat " + SdmSuConst.SOFTWARE_INVENTORY_DATA_FILE
        #run the command
        lRst = SdmSuUtils.safeSshRun(sshMngr, labIp, strCMD, user)
        if lRst[0] == 0:
            lstSwInv = lRst[1].split(os.linesep)
            for each in lstSwInv: #not retrieve software version
                swKey = each.split(':')[0].strip()
                swValue = each.split(':')[1].strip()
                dicSWInv[swKey] = swValue

                if 'SOFTWARE_INFORMATION' in each:
                    break
        else:
            LOGGER.error("failed to run softwareInventory on host[%s] with login[%s]", labIp, user)
            return []

        #print action status for check
        LOGGER.debug("software inventroy data:")
        for eKey in dicSWInv:
            LOGGER.debug("%s: %s", eKey, dicSWInv[eKey])

        return dicSWInv
    #--getSoftwareInventoryData end--

    @staticmethod
    def isValidAction(sshMngr, labIp, suAct):
        """
        check valid action list on the target NE
        """
        try:
            dicSwInv = SdmSuUtils.getSoftwareInventoryData(sshMngr, labIp, SdmSuConst.SU_USER)
            if not dicSwInv:
                LOGGER.error("exeSoftwareInventory return None")
                return [SdmSuConst.RST_FAILURE, {}]

            if suAct not in dicSwInv['VALID_ACTION']:
                LOGGER.error("SU Action [%s] is not in valid list[%s]", suAct, dicSwInv['VALID_ACTION'])
                return [SdmSuConst.RST_ACTNOTALLOWED, dicSwInv]
        except IndexError, ex:
            LOGGER.error("%s", ex)
            return [SdmSuConst.RST_FAILURE, {}]

        return [SdmSuConst.RST_SUCCESS, dicSwInv]

    #---isActionValid end---

    @staticmethod
    def getValidAction(sshMngr, labIp):
        """
        get valid action list on the target NE
        """
        try:
            dicSwInv = SdmSuUtils.getSoftwareInventoryData(sshMngr, labIp, SdmSuConst.SU_USER)

            if not dicSwInv:
                LOGGER.error("exeSoftwareInventory return None")
                return ''
        except IndexError, ex:
            LOGGER.error("%s", ex)
            return ''

        return  dicSwInv['VALID_ACTION'].strip()
    #---getValidAction end---

    @staticmethod
    def getLastActAndStatus(sshMngr, labIp):
        """
        get last action and its status on the target NE
        """
        try:
            dicSwInv = SdmSuUtils.getSoftwareInventoryData(sshMngr, labIp, SdmSuConst.SU_USER)
            if not dicSwInv:
                LOGGER.error("exeSoftwareInventory return None")
                return ''
        except IndexError, ex:
            LOGGER.error("%s", ex)
            return ''

        return  dicSwInv['SOFTWARE_ACTION_STATE']
    #---getLastActAndStatus end---

    @staticmethod
    def _listSuMarkers(sshMngr, labIp, user):
        """
        list the marker in /PLATsoftware/SU/xmc/markers
        @param labIp: the ip address of SDM labs
        @user: the login of the sdm lab
        return: list
        """
        strCMD = "ls -rt /PLATsoftware/SU/xmc/markers"
        #run the command
        LOGGER.debug("command is %s", strCMD)

        return SdmSuUtils.safeSshRun(sshMngr, labIp, strCMD, user)

    @staticmethod
    def getActionMarker(sshMngr, labIp, action, user):
        """
        retrive the marker of some action in /PLATsoftware/SU/xmc/markers
        @param labIp: the ip address of SDM labs
        @param action: SU action such as apply1, apply2 or so
        @user: the login of the sdm lab
        return: if mark exists, return like 'APPLY1_SUCCESS' or 'APPLY1_FAILED'
        """
        actionMarker = ''
        action = action.upper()
        lRst = SdmSuUtils._listSuMarkers(sshMngr, labIp, user)
        if lRst[0] == 0:
            lstMarkers = []
            if lRst[1]:
                lstMarkers = lRst[1].split('\n')

            if lstMarkers:
                for eachMark in lstMarkers:
                    if action in eachMark:
                        status = eachMark.split('_')[1].strip()
                        if status in ('SUCCESS', 'FAILED'):
                            actionMarker = eachMark
                            break
        else:
            LOGGER.error("failed to list su markers")

        return actionMarker

    @staticmethod
    def isActionMarked(sshMngr, labIp, action, user):
        """
        check if there is marker for action in /PLATsoftware/SU/xmc/markers
        @param labIp: the ip address of SDM labs
        @param action: SU action such as apply1, apply2 or so
        @user: the login of the sdm lab
        return boolean: if mark exists, return True, else False
        """
        action = action.upper()
        lRst = SdmSuUtils._listSuMarkers(sshMngr, labIp, user)
        if lRst[0] == 0:
            if lRst[1] and action in lRst[1]:
                ret = True
        else:
            LOGGER.error("failed to list su markers")

        return ret

    @staticmethod
    def getLastTwoMarkedActions(sshMngr, labIp, user):
        """
        retrive the last two marked action in /PLATsoftware/SU/xmc/markers
        @param labIp: the ip address of SDM labs
        @user: the login of the sdm lab
        return: list
        """
        listTwoActions = []
        lRst = SdmSuUtils._listSuMarkers(sshMngr, labIp, user)
        if lRst[0] == 0:
            lstMarkers = []
            if lRst[1]:
                lstMarkers = lRst[1].split('\n')
                lstMarkers.reverse()

            if lstMarkers:
                for eachMark in lstMarkers:
                    tblMarker = eachMark.rpartition('_')
                    status = tblMarker[-1].strip()
                    if status in ('SUCCESS', 'FAILED'):
                        listTwoActions.append(tblMarker[0].strip())
                        LOGGER.debug("marked action: %s", tblMarker[0].strip())

                    if len(listTwoActions) >= 2:
                        break
        else:
            LOGGER.error("failed to list su markers")

        return listTwoActions
