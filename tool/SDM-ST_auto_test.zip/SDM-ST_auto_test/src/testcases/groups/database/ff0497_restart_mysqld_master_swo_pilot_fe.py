'''
Created on Aug 20, 2015

@author: xzhao015
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0497_restart_mysqld_master_swo_pilot_fe(SDMTestCase):
    '''restart MYSQLD on BE MASTER and swo control pilot on FE'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.linuxProcessManager = self.sdmManager.linuxProcessManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []

    def test_restart_mysqld_master(self):
        '''test restart mysqld on master be and swo control pilot on FE'''

        mysqldProc = "mysqld"
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.info("start to restart mysqld on master BE")
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getNRG("1")
        masterBE = self.databaseStateManager.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        LOGGER.debug("get active pilot of the master BE")
        activePilotPre = self.mcasMachineManager.getActivePilot(masterBE)
        LOGGER.debug("%s: active pilot is %s", masterBE.id, activePilotPre)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE)
        LOGGER.debug("Start to restart mysqld on master BE at: " + startTime)

        LOGGER.debug("check the mysqld process on master is alive")
        self.linuxProcessManager.isAlive(masterBE, processName=mysqldProc)

        LOGGER.debug("set check connection interval to be 5s")
        self.sdmManager.sshManager.getClient(masterBE.oamIpAddress).get_transport().set_keepalive(5)

        LOGGER.debug("restart mysqld on active pilot")
        self.linuxProcessManager.killAllProcess(masterBE, mysqldProc)

        LOGGER.debug("%s: check connection is down", masterBE.id)
        CommonAssert.timedAssert(60, 5, self._checkConnectionDown, masterBE)

        LOGGER.debug("%s: check there is SWO pilot after kill MYSQLD")
        CommonAssert.timedAssert(60, 5, self._checkPilotSwitchOver, masterBE, activePilotPre)

        LOGGER.debug("%s: check there is all blades are OK")
        CommonAssert.timedAssert(1200, 30, self.mcasMachineManager.checkMachineStatus, masterBE, logLevel="debug")

        LOGGER.debug("Start to choose one FE to do pilot switch over")
        _, fe = self.testEnv.testBed.getFrontends().popitem()

        LOGGER.info("%s: Start to  do pilot switch over", fe.id)
        self.assertTrue(self.mcasMachineManager.pilotSwitchover(fe))

        LOGGER.debug("check the alarm")
        # Compares alarms from snmp log file to expected and accepted lists
        # but doesn't check all raised alarms are cleared
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(masterBE, myAlarmsConfig,
                                                               logFile=LOGFILE[1])

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        LOGGER.debug("ff0487 restart mysqld master swo pilot_fe success!\n")

    def _checkConnectionDown(self, lab):
        '''check lab connection is down'''
        if self.sdmManager.sshManager.getClient(lab.oamIpAddress).get_transport().is_alive():
            LOGGER.debug(lab.id + " connection is still alive")
            raise BaseException('connection is not down')
        else:
            LOGGER.debug(lab.id + " connection is down")
            self.sdmManager.sshManager.closeClient(lab.oamIpAddress)

    def _checkPilotSwitchOver(self, lab, activePilotPre):
        '''check there is pilot switch over on the lab'''
        LOGGER.debug(lab.id + " Check Pilot SwitchOver")
        activePilotAfter = self.mcasMachineManager.getActivePilot(lab)
        LOGGER.debug("%s: active pilot is %s", lab.id, activePilotAfter)
        CommonAssert.assertNotEqual(activePilotPre, activePilotAfter, "There is no pilot SwitchOver", 'debug')
