"""
Created on September 1, 2015

@author: Cassandra Lajeunie

# no test sheet found
"""
import os
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0509_swo_pilot_fe(SDMTestCase):
    "Test swo Fe pilot"

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.success = True
        self.exceptMsg = ""
        self.expectedAlarmsSpecific = []
        self.acceptedAlarmsSpecific = []
        self.expectedAlarms4FE = []
        self.acceptedAlarms4FE = []

        self.databaseManager = self.sdmManager.databaseManager
        self.databaseStateManager = self.sdmManager.databaseStateManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.allFEs = self.testEnv.testBed.getFrontends().values()

    def test_swo_pilot_fe(self):
        """
        ' Test switchover FE pilot '
        What it does : switchover the pilot on a FE of the lab
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case ...")
        # Get a FE
        feObj = self.allFEs[0]
        LOGGER.debug("FE name: %s", feObj.id)
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, feObj)
        LOGGER.info("%s: swo control pilot", feObj.id)
        CommonAssert.assertTrue(self.mcasMachineManager.pilotSwitchover(feObj), "pilot switchover failure : the pilots did not exchange roles")
        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case postcheck"""
        LOGGER.debug("test case post check")
        LOGGER.debug("check the alarm")
        exceptMsg = str()
        myAlarmsConfig4FE = AlarmsConfig(self.expectedAlarms4FE, self.acceptedAlarms4FE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfig4FE,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                self.success = False
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)
        labs = [lab for lab in self.testEnv.testBed.labs.values() if lab is not self.allFEs[0]]
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
