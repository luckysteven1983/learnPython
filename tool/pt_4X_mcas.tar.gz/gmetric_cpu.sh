#!/bin/bash

# This script is used to report the cpu information for process and cpu0/cpu1/cpu
# Usage:
#       $TOOL_DIR/gmetric_cpu.sh [-d delay] [process1 [process2 ...]]        
#  For example:
#               $TOOL_DIR/gmetric_cpu.sh Oam
#       The Oam will match processes: OamEirServer/OamNghlrServer/OamMnpServer/OamSdmhssServer
#       So totally 4 processes for Oam would be monitored.
#  You can also use the wildchar like . * [ ] which is just the same definition in grep
#               $TOOL_DIR/gmetric_cpu.sh "Oam[EM]"
#        Above script only match OamEirServer/OamMnpServer
#
#
# history
# 2009-12-8 Get the request from liu andy 
#           if the process has 1+ instance like 2 ndbd process on BE, it will not send the cpu to ganglia.

# script basename
script=`echo "$0" | sed 's:.*/::'`

usage="Usage: $script [-d delay] [process1 [process2 ...]]"
delay=300

gmetric_command=/usr/bin/gmetric
#gmetric_command=echo

while getopts :d: o
do	case "$o" in
	d) delay=$OPTARG;;
	h) echo $usage; exit 0;;
	[?]) echo >&2 $usage
		exit -1;;
	esac
done
shift $(($OPTIND - 1))

# let delay=$delay-3
if ! [ -x  $gmetric_command ]; then
        echo "Gmetric command is not executable. No ganglia pmap data generated..."
fi

while [ 1 ]
do
#      	out=`top -b -n 2 -d 3 | sed '1,/^top/d'`
      	out=`top -b -n 2 -d $delay | sed '1,/^top/d'`

        echo `date "+%F %X"`
		
	i=0
	while [ 1 ]; do
		if echo "$out"|grep Cpu$i > /dev/null; then
			cpuN=`echo "$out"|grep "Cpu$i[^0-9]"|awk -F, '{print $4" "$5}' | sed 's/%id,//'|sed 's/%wa,//'|awk '{print 100-$1-$2}'`
           		#$gmetric_command  --name="cpu$i" --value="$cpuN" --type=float --units="%"
	                echo "cpu$i $cpuN%"			
			let i=$i+1;
		else
			break;
		fi
	done 

	if [ $i -eq 0 ]; then
	      	cpu=`echo "$out"|grep Cpu|awk -F, '{print $4" "$5}' | sed 's/%id,//'|sed 's/%wa,//'|awk '{print 100-$1-$2}'`
	        #$gmetric_command  --name="cpu" --value="$cpu" --type=float --units="%"
                echo "cpu $cpu%"		
	fi
        
        output=`echo "$out"|sed '1,/COMMAND/d'`
        for process in $* 
        do      
                psnames=`echo "$output"| awk '{ print $12 }' |grep "$process" |uniq` 
                for psname in $psnames
                do 
		        cpus_p=`echo "$output"|grep "$process" |awk '{ print $12"-pid"$1" "$9"%" }'`
		        cpus_v=`echo "$output"|grep "$process" |awk '{ print $9 }'`                
        
                        number=`echo "$cpus_v" |wc -l`   
                        process_exp=`echo $psname|sed "s:/:@:g"`
                        
                        if [ "$number" -gt 1 ]; then
                             echo -e "	Warning: $process_exp include $number instances. cpu for $process_exp would not send to ganglia"
                             echo -e "	cpus_p"
                        elif [ "$number" -eq 1 ]; then
                            echo -e "	$process_exp\t${cpus_v}%"                                
			    #$gmetric_command  --name="cpu_$process_exp" --value="$cpus_v" --type=float --units="%"
                        fi                            
                done                            
        done
#        sleep $delay
done

