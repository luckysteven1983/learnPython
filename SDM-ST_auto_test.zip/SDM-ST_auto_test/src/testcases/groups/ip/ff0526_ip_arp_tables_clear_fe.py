"""
Created on Nov 9, 2015

@author: Claude LE DU
# No test sheet found
"""

import os
import time

from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from framework.testenv.omniswitch_router import GDMP_FLOW
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

TIMER_CLEAR_ARP_TABLES = 1  # second

class ff0526_ip_arp_tables_clear_fe(SDMTestCase):
    """ Clear ARP tables on FE's edge router """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.connection = None
        self.router = None
        self.vlan = None
        for aConnection in self.fe.connections:
            if aConnection.flow == GDMP_FLOW:
                self.connection = aConnection
                self.router = aConnection.router
                self.vlan = aConnection.vlan
                break
        if not self.router:
            msg = "Requires router definition with GDMP flow for " + self.fe.id
            LOGGER.info(msg)
            self.skipTest(msg)


    def test_ff0526_ip_arp_tables_clear_fe(self):
        """ Clear ARP tables on FE's edge router """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)


    def _precheck(self):
        """Test case precheck - Returns current active alarm list"""
        LOGGER.debug("test case precheck")
        # LOGFILE[0] is a csv file used to save initial active alarms before the test case
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        """ Execute test case """
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)

        LOGGER.info("ARP tables will be cleared on router " + self.router.routerIp)
        i = 0
        while i <= 50 :
            self.router.clearARPTables()
            time.sleep(TIMER_CLEAR_ARP_TABLES)
            i += 1
        return startTime


    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        exceptMsg = ""
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        LOGGER.debug("Check the end status of the test env")
        if exceptMsg:
            LOGGER.warning(exceptMsg)

        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
