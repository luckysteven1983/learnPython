'''
Created on Oct 14, 2015

@author: Tangi Lavanant
'''


import os
import time

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_NONPILOT


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fk7169_be_slave_resynchro(SDMTestCase):
    """Blade SW fault: kill cluster on BE slave
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_kill_cluster_slave(self):
        """kill cluster on slave BE

        Procedure:
        1. kill cluster on slave BE
        2. check topology on FE.
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.info("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""
        # Define Timeout
        TIMEOUT_3_HOUR = 10800

        LOGGER.info("run test case test_kill_cluster_slave")
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        # Half cluster reset on any slave BE.
        slaveBE = self.sdmManager.databaseStateManager.getSlaveBE(self.allBEs)[0]
        LOGGER.info("Kill cluster on slave BE %s", slaveBE.id)
        # Got the two nonpilots
        stations = self.allBEs[0].stations.values()
        stations = [sta.rcsHostname for sta in stations if sta.middlewareRole == MIDDLEWARE_ROLE_NONPILOT][0:2]
        for station in stations:
            LOGGER.info("Restart %s on slave BE %s", station, slaveBE.id)
            self.sdmManager.mcasMachineManager.stationfwRestartNonPilot(slaveBE, station)
        # We need to wait all NDB become started.
        LOGGER.info("Waiting NDB up on slave BE %s", slaveBE.id)
        CommonAssert.timedAssert(TIMEOUT_3_HOUR, 30, self.sdmManager.databaseStateManager.assertNdbState,
                                 slaveBE, 'started', logLevel='debug')

        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.info("test case post-check")
        time.sleep(10)
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep
        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
