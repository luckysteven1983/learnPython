'''
Created on Apr 9, 2015
@author: FrankZh

this module implements the SDM SU, provide the interface for starting SU
'''

import os
import sys
#import string
from time import sleep
import threading
import socket

from datetime import datetime
from subprocess import Popen, PIPE

from paramiko.ssh_exception import SSHException, ChannelException
from scp import SCPException

from lib.logging.logger import Logger
from lib.softwareupdate.sdm_su_agent import SdmSuAgent
from lib.softwareupdate.sdm_su_constants import SdmSuConst
from lib.softwareupdate.sdm_su_common_func import SdmSuUtils

LOGGER = Logger.getLogger(__name__)

#---CONSTANTS---
SLEEP_INTERVAL = 6
BUFF_SIZE = 8192
RELAUNCHON = False

class SdmSuRunner(object):

    '''
    the class provides the functions for SU actions
    '''

    #---private functions begin---

    def __init__(self, rHost, suAction, sshManager):
        '''
        initialization
        '''
        self.rHost = rHost
        self.suAction = suAction
        self.releaseFilePath = ''
        self.softwareServerIp = ''
        self.sftpLogin = ''
        self.sshConn = []
        self.isEnd = False
        self.dicActInfo = dict()
        self.suCommand = ''
        self.sshMngr = sshManager
        self.suUser = SdmSuConst.SU_USER
        self.suUserPasswd = SdmSuConst.SU_USER_PASSWD
        self.monitorOnly = False
        self.lAgentXmlAbsent = True
        self.nmLockFile = ''
        self.isJenkinsJob = False

        if len(self.rHost.strip()) == 0:
            LOGGER.error("host is None! rHost: %s, exit now!", self.rHost)

        if not self.sshMngr:
            LOGGER.error("sshMngr is None! exit now!")

        #create ssh Client if it doesn't exit yet
        self.sshMngr.getClient(self.rHost, self.suUser, self.suUserPasswd)
        #self.sshMngr = SshManager()
        #the name of the target NE
        self.rHostName = SdmSuUtils.getNEHostName(self.sshMngr, self.rHost, self.suUser)

        #this dir used for saving all files specific to this host
        self.localNodeDataDir = SdmSuConst.LOCAL_SU_REPOSITORY_DIR + self.rHostName

        # creates host dir if needed
        if not os.path.isdir(self.localNodeDataDir):
            LOGGER.info(self.localNodeDataDir + " directory doesn't exist, creating it")
            os.makedirs(self.localNodeDataDir)

    #--__init__ end--

    def _buildSUCommand(self):
        '''
        build SU command with the data gotten from OAMSUAgent.xml.
        return SU command with string type
        '''

        #SdmSuAgent.rmvLocalSUAgentXml(localNodeDataDir + 'OAMSUAgent.xml')

        if self.lAgentXmlAbsent:
            localXml = SdmSuAgent.getRemoteFile(self.sshMngr, self.rHost, \
                SdmSuConst.REMOTE_SUAGENT_FILE, self.localNodeDataDir, self.suUser, self.suUserPasswd)
        else:
            localXml = self.localNodeDataDir + os.sep + SdmSuConst.REMOTE_SUAGENT_FILE.split(os.sep)[-1]

        if os.path.isfile(localXml):
            LOGGER.debug("OAMSUAgent.xml exist in %s ", localXml)
        else:
            LOGGER.error("OAMSUAGENT.xml is absent on the local machine. rhost is %s, rfile is %s.", \
            self.rHost, SdmSuConst.REMOTE_SUAGENT_FILE)
            return None

        self.dicActInfo = SdmSuAgent.getActionDataWithLxml(localXml, self.suAction)

        if not self.dicActInfo:
            LOGGER.error("action data is none.")
            return None

        if not self.dicActInfo['name']:
            LOGGER.error("Action[%s] is not defined in OAMSUAgent.xml.", self.suAction)
            return None

        #print action data for check
        for eKey in self.dicActInfo:
            LOGGER.debug("action data: %s, %s", eKey, self.dicActInfo[eKey])

        strSUCmd = None
        #build su command per SU type
        if self.suAction in ('DOWNLOAD', 'INSTALL_AGENT', 'EFX_APPLY'):
            strSUCmd = self.dicActInfo['script'] + ' ' + self.releaseFilePath + ' ' \
            + self.softwareServerIp + ' ' + self.sftpLogin

        elif self.suAction == 'SOFTWARE_INVENTORY':
            strSUCmd = self.dicActInfo['script']
        else:
            strSUCmd = self.dicActInfo['script'] + ' ' + self.dicActInfo['arg']

        strSUCmd += os.linesep if strSUCmd[-1] != os.linesep else ''

        return strSUCmd
    #--_buildSUCommand end--

    def _getActionStatus(self):
        """
        the contents of actionStatus file is like following. this fucntion is to retrieve this file from NE and
        save/return them in dictionary
        RMT_ACTION_NAME               :  APPLY1
        RMT_ACTION_LOGFILE            :  QDATCA06oam-0-0-1,/PLATsoftware/SU/xmc/log/APPLY1.log
        RMT_ACTION_TIMESTAMP          :  1428906466
        RMT_ACTION_TIMEOUT            :  60
        RMT_ACTION_STATUS             :  SUCCESS
        RMT_ACTION_PERCENT_COMPLETE   :  100
        RMT_ACTION_ERROR_CODE         :
        RMT_ACTION_ERROR_TEXT         :
        NE_CMD_HOST_TIME              :  1428906466
        NE_CMD_NAME                   :  SUapply1
        NE_CMD_LOGFILE                :  QDATCA06oam-0-0-1,/PLATsoftware/SU/log/5350_R3.2.13/APPLY1.out
        NE_CMD_ERROR_CODE             :  0
        NE_CMD_ERROR_TEXT             :  Script completed successfully
        NE_OTHER_INFO                 :  1428904961

        return values: if returned dict is with 0 length, it means failure.
        """
        fLocalActST = SdmSuAgent.getRemoteFile(self.sshMngr, self.rHost, SdmSuConst.REMOTE_ACTION_STATUS_FILE, \
            self.localNodeDataDir, self.suUser, self.suUserPasswd)
        if not os.path.isfile(fLocalActST):
            LOGGER.error("failed to scp SU Action Status file from NE. rhost is %s, rfile is %s.", \
            self.rHost, SdmSuConst.REMOTE_ACTION_STATUS_FILE)
            return None

        dicActST = {}
        lstActST = []

        try:
            fdActST = open(fLocalActST)
            for eLine in fdActST:
                tplActST = eLine.strip().split(':')
                tplActST[0] = tplActST[0].strip()
                tplActST[1] = tplActST[1].strip()
                lstActST.append(tplActST)

            fdActST.close()
        except IOError, ex:
            LOGGER.error("file open error: %s", ex)
            return dicActST

        dicActST = dict(lstActST)
        #print action status for check
        #for eKey in dicActST:
        #    LOGGER.debug("action info: %s, %s", eKey, dicActST[eKey])

        return dicActST
    #--end of _getActionStatus--


    def _getNEHostNamebyIP(self, rHostIP, user=SdmSuConst.SU_USER):
        """
        get the host name of NE
        """
        strCDM = "hostname"
        sHostName = ''
        #run the command as root
        lRst = self.sshMngr.run(rHostIP, strCDM, user)
        if lRst[0] == 0:
            if '-0-0-' in lRst[1]:
                sHostName = lRst[1].rstrip()[:-6]
            else:
                sHostName = lRst[1].rstrip()

        return sHostName
    #--_getNEHostNamebyIP end--



    def _sshConnect(self, timeout=1200):
        '''
        get or create ssh connection
        '''
        suClient = self.sshMngr.getClient(self.rHost, self.suUser, self.suUserPasswd)

        if not suClient:
            LOGGER.error("failed to connect to NE [%s] as user [%s]!", self.rHost, self.suUser)
            return []

        suTransport = suClient.get_transport()

        if not suTransport.is_alive():
            self.sshMngr.closeClient(self.rHost, self.suUser)
            return []

        shl = suClient.invoke_shell()
        shl.settimeout(timeout)

        SdmSuRunner.emptyBuffers(shl)  # empty the stdout and stderr buffers

        return [suClient, suTransport, shl]
    #---_sshConnect end---

    #---public function begin---
    def createLockFile(self):
        '''
        as soon as a SU action begins, creating lock file to indicate that it is in progess.
        if the same SU action
        is triggered in this time, it will be reject
        '''
        nPid = os.getpid()
        result = False
        try:
            fdLock = open(self.nmLockFile, 'w')
            fdLock.write("%d" % nPid)
            result = True
        except IOError, ex:
            LOGGER.error("create lock file error: %s", ex)

        if not fdLock.closed:
            fdLock.close()

        return result

    def rmvLockFile(self):
        '''
        remove the lock file
        '''
        if os.path.isfile(self.nmLockFile):
            os.remove(self.nmLockFile)



    def checkProcess(self):
        '''
        check if an action lock file exists.if it exists, continue to check if the process
        with PID recorded in the file is running
        return value: if process is running, return RST_SUCCESS, or else, return RST_FAILURE.
        if exception occurs, return RST_EXCEPTION
        '''

        if not os.path.isfile(self.nmLockFile):
            return SdmSuConst.RST_FAILURE

        try:
            fdLock = open(self.nmLockFile, 'r')
            strPid = fdLock.read()
            fdLock.close()
        except IOError, ex:
            LOGGER.error("lock file error: %s", ex)
            return SdmSuConst.RST_EXCEPTION
        finally:
            if not fdLock.closed:
                fdLock.close()

        strPid = strPid.strip()
        if strPid[-1] == os.linesep:
            strPid = strPid[:-1]

        if not strPid.isdigit():
            LOGGER.error("invalid pid [%s] in lock file", strPid)
            return SdmSuConst.RST_FAILURE

        #check if the process with pid 'nPid' is running
        tp = Popen('ps p %s' % strPid, shell=True, stdout=PIPE).stdout
        #the content of tp is like following if process is running
        #PID TTY      STAT   TIME COMMAND
        #7185 pts/3    Sl+    0:00 python ./testcases/groups/softwareupdate/ssh_test2.py

        if len(tp.readlines()) < 2:
            LOGGER.debug("no process withpid [%s] now", strPid)
            self.rmvLockFile()
            return SdmSuConst.RST_FAILURE
        else:
            LOGGER.error("the same process for SDM SU with pid [%s] exists already, \
                please double check it on the local machine ", strPid)
            #LOGGER.debug("kill the previous process and the current process will exit!\
            #   please check your lab and try it later")
            #tp = Popen('kill -9 %s' % strPid, shell=True, stdout=PIPE).stdout

            return SdmSuConst.RST_SUCCESS

    #---checkProcess end---

    def _checkAndPrepare(self):
        '''
        data validation check and SU preparation
        '''
        #data valid check
        if len(self.suAction.strip()) == 0:
            LOGGER.error("su action is None! SU Action: %s, exit now!", self.suAction)
            return SdmSuConst.RST_FAILURE

        if self.suAction in ('INSTALL_AGENT', 'DOWNLOAD', 'EFX_APPLY'):
            if (self.releaseFilePath == '') or (self.softwareServerIp == '') \
                or (self.sftpLogin == ''):
                LOGGER.error("data for ftp server are not enough!")
                return SdmSuConst.RST_FAILURE

        if not self.rHostName:
            LOGGER.error("the remote host name is null, please fix it")
            return SdmSuConst.RST_FAILURE

        #establish ssh session
        self.sshConn = self._sshConnect()
        if not self.sshConn:
            LOGGER.error("failed to establish ssh connection to host[%s]: ", self.rHost)
            return SdmSuConst.RST_FAILURE

        #check valid action list on the target NE
        rst = SdmSuUtils.isValidAction(self.sshMngr, self.rHost, self.suAction)
        if rst[0] != SdmSuConst.RST_SUCCESS:
            return rst[0]

        #check if some action is in progress on the target NE
        curActState = rst[1]['SOFTWARE_ACTION_STATE'].strip().split('-')
        if curActState[1] == SdmSuConst.SUSTATE['IP'].strip():
            if curActState[0].strip() == self.suAction:
                LOGGER.info("Action [%s] is already running on %s, will monitor it", \
                curActState[0], self.rHost)
                self.monitorOnly = True
            else:
                LOGGER.error("Another action [%s] is running on %s now, will exit", \
                curActState[0], self.rHost)
                return SdmSuConst.RST_RPROCRUNNING

        #self.nmLockFile = self.localNodeDataDir + os.sep + self.suAction + '_pid'
        self.nmLockFile = self.localNodeDataDir + os.sep + SdmSuConst.SUPROCESSNAME + '_pid'

        #check if the script for this SU action is running on local machine
        cmRst = self.checkProcess()
        if cmRst == SdmSuConst.RST_EXCEPTION:
            LOGGER.error("exception occured when checking process, exit!")
            return SdmSuConst.RST_EXCEPTION
        elif cmRst == SdmSuConst.RST_SUCCESS:
            return SdmSuConst.RST_LPROCRUNNING

        #create lock flag
        self.createLockFile()

        #build SU command
        strSUCmd = self._buildSUCommand() #self.dicActInfo is filled in this call
        if strSUCmd:
            LOGGER.debug("SU command is: %s", strSUCmd)
        else:
            LOGGER.error("build SU command failure. %s", strSUCmd)
            return SdmSuConst.RST_FAILURE

        self.suCommand = strSUCmd

        #if self.dicActInfo['polling'] > 4:
        #    self.dicActInfo['polling'] = 4
        #elif not self.dicActInfo['polling']:
        #    self.dicActInfo['polling'] = 2
        #    self.dicActInfo['failedThreshold'] = 4

        return SdmSuConst.RST_SUCCESS
    #---_checkAndPrepare end---


    def _actionEndLog(self, dicCurrST):
        '''
        record the trace as soon as the action ends
        '''
        #report the finial percentage
        if dicCurrST['RMT_ACTION_STATUS'] != SdmSuConst.SUSTATE['FA']:
            LOGGER.info("status: %s, Percent: %s%%", \
                dicCurrST['RMT_ACTION_STATUS'], dicCurrST['RMT_ACTION_PERCENT_COMPLETE'])
        #report status
        LOGGER.info("job is finished with status: %s", dicCurrST['RMT_ACTION_STATUS'])
        #if SU action failed, report default error message which is defined in agent XML file
        if dicCurrST['RMT_ACTION_STATUS'] == SdmSuConst.SUSTATE['FA']:
            LOGGER.info("****%s****", self.dicActInfo['defaultErrorMsg'])

        #report job result message whatever it succeeded or failed
        if dicCurrST['RMT_ACTION_ERROR_TEXT']:
            LOGGER.info(dicCurrST['RMT_ACTION_ERROR_TEXT'])
        if dicCurrST['NE_CMD_ERROR_TEXT']:
            LOGGER.info(dicCurrST['NE_CMD_ERROR_TEXT'])
    #---_actionEndLog end---

    def _suRstReport(self):
        '''
        get SU status and report
        '''
        try:
            dicCurrST = self._getActionStatus()
        except SCPException, ex:
            LOGGER.error('when reporting result, SCP exception: %s', ex)

        if not dicCurrST:
            LOGGER.error("failed to get action status")
            return ''
        else:
            self._actionEndLog(dicCurrST)

        return dicCurrST['RMT_ACTION_STATUS']
    #---_suRstReport end---

    def _dumpTraceAndReconnect(self, fdmOut):
        '''
        write SU trace and keep ssh connection
        '''

        try:
            fdOut = open(fdmOut, 'a+')
        except IOError, ex:
            LOGGER.error("open file error: %s", ex)
            self.isEnd = True
            return

        buf = ''
        bufErr = ''
        isConnAlive = True
        nReLaunch = 0

        if not self.sshConn:
            LOGGER.error("no ssh connection to the target host: %s", self.rHost)
            self.isEnd = True
            return

        shl = self.sshConn[2]
        transport = self.sshConn[1]
        isCmdExit = False
        while True:
            try:
                if self.isEnd:
                    break

                if  isConnAlive:
                    #check connection
                    if not transport.is_alive():
                        isConnAlive = False
                        continue

                    #if action is already running, will not get trace from remote end
                    if self.monitorOnly:
                        sleep(1)
                        continue

                    if shl.exit_status_ready() and not isCmdExit:
                        exitCode = shl.recv_exit_status()
                        LOGGER.info("receive exit code [%d] from remote end", exitCode)
                        isCmdExit = True
                        #for download and install_agent, end immediately as soon as exitcode is gotten
                        #for others, not do this because lab may return exit code before rebooting. need wait it up
                        #probable it is needed to update this action list for diffrent SU path
                        if self.suAction not in ('APPLY1',):
                            self.isEnd = True


                    if shl.recv_ready():
                        buf = shl.recv(BUFF_SIZE)
                        if len(buf) > 0:
                            fdOut.write(buf)
                    else:
                        sleep(0.1) #sleep 0.1 sec if nothing receiving

                    if shl.recv_stderr_ready():
                        bufErr = shl.recv_stderr(BUFF_SIZE)
                        if len(bufErr) > 0:
                            fdOut.write(bufErr)
                else:
                    #wait for 30 sec
                    LOGGER.info("ssh connection is lost. maybe remote lab rebooted." + \
                    "will try to connect it in the interval of  %d seconds!", SdmSuConst.RECONNECT_INTERVAL)
                    sleep(SdmSuConst.RECONNECT_INTERVAL)

                    #establish ssh session
                    self.sshConn = self._sshConnect()
                    if self.sshConn:
                        LOGGER.info("********SSH connection is re-established up********")
                        transport = self.sshConn[1]
                        shl = self.sshConn[2]
                        isConnAlive = True

                        dicSwInv = SdmSuUtils.getSoftwareInventoryData(self.sshMngr, self.rHost)
                        if not dicSwInv:
                            LOGGER.error("failed to run softWareInventory")
                            continue

                        if cmp(dicSwInv['SOFTWARE_ACTION_STATE'], (self.suAction+'-'+SdmSuConst.SUSTATE['IP'])) == 0:
                            #dicActInfo['autoActionRelaunch'] > 0 means autoActionRelaunch is enabled
                            #'0<None' is False. self.dicActInfo['autoActionRelaunch'] is None by default
                            if(nReLaunch < self.dicActInfo['autoActionRelaunch']) and RELAUNCHON:
                                _, stdOut, _ = self.sshConn[0].exec_command(self.suCommand)
                                self.sshConn[2] = stdOut.channel
                                shl = self.sshConn[2]
                                #self.sshConn[2].send(self.suCommand)
                                nReLaunch += 1
                        else:
                            self.isEnd = True
                            #if cmp(dicSwInv['SOFTWARE_ACTION_STATE'],\
                            #     (self.suAction+'-'+SdmSuConst.SUSTATE['SU'])) == 0:
                            #    rstSU = SdmSuConst.RST_SUCCESS
                            LOGGER.debug("the stauts in softwareInventory is [%s]. Job is finished! ", \
                            dicSwInv['SOFTWARE_ACTION_STATE'])

            except ChannelException, ex:
                LOGGER.error('channel exception: %s', ex)
                #LOGGER.exception("channel exception: %s", ChannelException)

            except SSHException, ex:
                LOGGER.error("SSH exception: %s", ex)
                #LOGGER.exception("SSH exception: %s", SSHException)

            except socket.error, ex:
                LOGGER.error("failed to establish connection with socket error{%s}", ex)
                #LOGGER.exception("socket exception %s: ", socket.error)

            except EOFError, ex:
                LOGGER.error("EOF exception %s: ", ex)

        fdOut.close()
    #---_dumpTraceAndReconnect end---

    def _suMonitor(self):
        '''
        Monitor SU
        '''
        dt = datetime.now()
        beginTime = int(dt.strftime('%s'))
        endTime = beginTime + self.dicActInfo['timeout']*60
        deltaTm = 0

        dicLastST = {}
        dicCurrST = {}
        nFailPolling = 0
        durLostSSHConn = 0
        isReported = False
        nSleep = 0
        rstSU = SdmSuConst.RST_FAILURE
        waitFailureTimes = 0

        # --- if timeout has been reached, terminate the job
        while deltaTm <= endTime and not self.isEnd:

            if self.suAction == 'INSTALL_AGENT':
                sleep(SLEEP_INTERVAL)
                deltaTm = int(datetime.now().strftime('%s'))
                continue

            try:
                if self.sshConn and self.sshConn[1].is_alive():
                    if nSleep >= (self.dicActInfo['polling']*10): #polling triggered
                        nSleep = 0
                        try:
                            dicCurrST = self._getActionStatus()
                        except SCPException, ex:
                            LOGGER.error('SCP exception: %s', ex)

                        if not dicCurrST:
                            nFailPolling += 1
                        elif dicCurrST['RMT_ACTION_STATUS'] != SdmSuConst.SUSTATE['IP']:
                            #if succeed, wait for a while for reboot case
                            #it is possible for this tool to get the success status and end this session
                            #before lab reboot. in this case,
                            #this tool should wait lab starting up
                            if dicCurrST['RMT_ACTION_STATUS'] == SdmSuConst.SUSTATE['SU']:
                                rstSU = SdmSuConst.RST_SUCCESS
                                sleep(SLEEP_INTERVAL)
                                if not (self.sshConn and self.sshConn[1].is_alive()):
                                    continue

                            #on BONO SDM, sometimes the SU status is FAILURE, but it is not always meaning the action
                            #is finished. after a while it will be changed to SUCCESS. so is ACTIVATE. don't know why,
                            #so wait for some time when it failed
                            if self.suAction == 'ACTIVATE':
                                if dicCurrST['RMT_ACTION_STATUS'] == SdmSuConst.SUSTATE['FA'] and waitFailureTimes < 2:
                                    LOGGER.debug("action %s failed with status: %s. will fetch again",\
                                        self.suAction, dicCurrST['RMT_ACTION_STATUS'])
                                    waitFailureTimes += 1
                                    continue

                            self._actionEndLog(dicCurrST)

                            isReported = True
                            break
                        else:
                            if dicLastST:
                                if cmp(dicCurrST['RMT_ACTION_TIMESTAMP'], dicLastST['RMT_ACTION_TIMESTAMP']) == 0:
                                    nFailPolling += 1
                                    LOGGER.debug("polling failure times: %d", nFailPolling)
                                else:
                                    nFailPolling = 0

                            dicLastST = dicCurrST

                            #report progress
                            #self._showProgress(dicCurrST)
                            LOGGER.info("status: %s, Percent: %s%%", \
                                dicCurrST['RMT_ACTION_STATUS'], dicCurrST['RMT_ACTION_PERCENT_COMPLETE'])

                    durLostSSHConn = 0
                else:
                    if nSleep >= (self.dicActInfo['polling']*10):
                        nFailPolling += 1
                        nSleep = 0

                    durLostSSHConn += SLEEP_INTERVAL/60.0
                    if self.dicActInfo['lossSSHTimeout'] and (durLostSSHConn >= self.dicActInfo['lossSSHTimeout']):
                        LOGGER.error("lost ssh connection over %d minutes", durLostSSHConn)
                        break

                #if action status is not updated after polling over threshold, exit.
                #note that polling*threashold >lossSSHTimeout in xml file in general
                if nFailPolling >= self.dicActInfo['failedThreshold']:
                    LOGGER.error("SU timestamp not updated for a long time,probably terminated.")
                    break

                #sleep(self.dicActInfo['polling']*60)
                sleep(SLEEP_INTERVAL)
                nSleep += 1
                deltaTm = int(datetime.now().strftime('%s'))

            except ChannelException, ex:
                LOGGER.error('channel exception: %s', ex)
                #LOGGER.exception("channel exception: %s", ChannelException)

            except SSHException, ex:
                LOGGER.error("SSH exception: %s", ex)
                #LOGGER.exception("SSH exception: %s", SSHException)

            except socket.error, ex:
                LOGGER.error("failed to establish connection with socket error{%s}", ex)
                #LOGGER.exception("socket exception %s: ", socket.error)

            except EOFError, ex:
                LOGGER.error("EOF exception  %s: ", ex)

        if deltaTm > 0:
            if deltaTm > endTime:
                LOGGER.error("Timeout! job isn't finished in %d minutes", self.dicActInfo['timeout'])

            if self.sshConn:
                if not self.sshConn[2]:
                    SdmSuRunner.emptyBuffers(self.sshConn[2])

                if self.sshConn[1].is_alive():
                    self.exeSoftwareInventory()
                    if not isReported:
                        suStatus = self._suRstReport()
                        if suStatus == SdmSuConst.SUSTATE['SU']:
                            rstSU = SdmSuConst.RST_SUCCESS

            LOGGER.info('%s took %d seconds', self.suAction, deltaTm-beginTime)

        return rstSU

    #---_suMonitor end---

    def suActionStart(self):
        '''
        the interface for starting a SU action
        '''
        rstPreCheck = self._checkAndPrepare()
        if rstPreCheck != SdmSuConst.RST_SUCCESS:
            return rstPreCheck

        LOGGER.info("********JOB START********")
        LOGGER.info("********Action: %s********", self.dicActInfo['label'])
        LOGGER.info("********Tip: %s********", self.dicActInfo['tooltip'])

        dt = datetime.now()
        strNow = dt.strftime('%Y%m%d%H%M%S')
        fOutTrace = self.localNodeDataDir + os.sep + self.suAction + '_' + strNow + '.out'
        #fErrTrace = self.localNodeDataDir + os.sep + self.suAction + '_' + strNow + '.err'

        try:
            _, stdOut, _ = self.sshConn[0].exec_command(self.suCommand)
            self.sshConn[2] = stdOut.channel

            # send the SU command
            #self.sshConn[2].send(self.suCommand)
            LOGGER.info("*******SU Command[%s] has been sent to Pilot[%s]!*******", self.suCommand.strip(), self.rHost)
        except SSHException, ex:
            LOGGER.exception("exec command exception: %s", ex)
            return SdmSuConst.RST_FAILURE
        #start the thead for receiving the SU trace and writing them to log file.
        #And in charge of re-connect the target NE when connection is lost due to reboot or network issue
        traceThread = threading.Thread(target=self._dumpTraceAndReconnect, args=(fOutTrace,))
        traceThread.start()

        #monitor the SU status to determine if SU is finished or SU process is hung.
        #terminate if connection loss over time
        #report SU result
        rstSU = self._suMonitor()

        #notice dumpSuTrace thread to end
        self.isEnd = True

        #wait trace dumpSuTrace end
        traceThread.join()

        #remove lock file
        self.rmvLockFile()

        #self.sshMngr.closeAllClients()

        LOGGER.info("********JOB[%s] END!********", self.suAction)
        return rstSU
    #---suActionStart end---

    def exeSoftwareInventory(self):
        '''
        run softwareInventory on the destination NE;
        retrieve softwareInventory from remote NE
        get the action state and valid actions
        the content of SoftwareInventory as below, only get the first three lines
            NE_NAME:QDATCA08oam-0-0-1
            SOFTWARE_ACTION_STATE:DOWNLOAD-FAILED
            VALID_ACTION:INSTALL_AGENT, DOWNLOAD
            RUNNING_VERSION:R3.2.8
            VALID_VERSION:R3.2.8
            DOWNLOADED_VERSION:R3.2.13
            SOFTWARE_INFORMATION:R3.2.13
        return value: dictionary including the first three lines. if its length is 0, it means failure
        '''
        dicSWInv = {}
        lRstCmd = self.sshMngr.run(self.rHost, SdmSuConst.CMD_SOFTWAREINVENTORY, user=self.suUser)

        if lRstCmd[0] == 0:
            LOGGER.debug("SoftwareInventory run on %s successfully", self.rHost)
        else:
            LOGGER.debug("SoftwareInventory failed on %s", self.rHost)
            return dicSWInv

        try:
            fLocalSWInv = SdmSuAgent.getRemoteFile(self.sshMngr, self.rHost, SdmSuConst.SOFTWARE_INVENTORY_DATA_FILE, \
                self.localNodeDataDir, self.suUser, self.suUserPasswd)
        except SCPException, ex:
            LOGGER.error('getRemoteFile exception: %s', ex)
            return dicSWInv

        if not os.path.isfile(fLocalSWInv):
            LOGGER.error("failed to softwareInventory file from NE. host is %s, \
            rfile is %s.", self.rHost, SdmSuConst.REMOTE_ACTION_STATUS_FILE)
            return dicSWInv

        dicSWInv = {}
        lstSWInv = []
        tplSWInv = ()
        try:
            fdSWInv = open(fLocalSWInv)
            i = 0
            for eLine in fdSWInv:
                tplSWInv = eLine.strip().split(':')
                tplSWInv[0] = tplSWInv[0].strip()
                tplSWInv[1] = tplSWInv[1].strip()
                lstSWInv.append(tplSWInv)

                if i >= 2:
                    break
                i += 1

            fdSWInv.close()
        except IOError, ex:
            LOGGER.error("file open error: %s", ex)
            return dicSWInv

        dicSWInv = dict(lstSWInv)

        #print action status for check
        for eKey in dicSWInv:
            LOGGER.debug("action status: %s: %s", eKey, dicSWInv[eKey])

        return dicSWInv
    #--_exeSoftwareInventory end--

    @staticmethod
    def suProgress(width, percent, status):
        """
        show the procress with percentage
        """
        print "%s %d%% %s\r" % (('%%-%ds' % width) % (width * percent / 100 * '='), percent, status),
        if percent >= 100:
            print
            sys.stdout.flush()

    @staticmethod
    def setLogLevel(logLevel):
        '''
        provide the interface for outside caller to modify the log level
        '''
        LOGGER.setLevel(logLevel)

    @staticmethod
    def emptyBuffers(chann):
        '''
        Private method
        void the buffers : stdout and stderr. Useful  just before a loop with a new command
        '''
        while chann.recv_stderr_ready():
            chann.recv_stderr(BUFF_SIZE)
        while chann.recv_ready():
            chann.recv(BUFF_SIZE)

    @staticmethod
    def _showProgress(dicCurrST):
        '''
        different methods to show progress
        '''
        percent = int(dicCurrST['RMT_ACTION_PERCENT_COMPLETE'])
        #status = dicCurrST['RMT_ACTION_PERCENT_COMPLETE']
        #status = status[:-1] if status[-1] == os.linesep else status
        #print "%s %d%%\r" % ( '%-100s' % (percent * '='), percent)
        print "%s %d%%\r" %((' %%-%ds' % 100) % (100 * percent / 100 * '='), percent),
        #print "%s %d%% %s\r" % (('%%-%ds' % 100) % (percent * '='), percent, dicCurrST['RMT_ACTION_STATUS']),
        #print strProgress

    #---_showProgress end---
