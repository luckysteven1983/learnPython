'''
Created on Nov 17, 2015

@author: xzhao015
'''
import os
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils
from lib.platform.mcas.mcas_machine_manager import PILOT_RECOVER_TIMEOUT, MACHINE_STATUS_CHECK_INTERVAL
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class du3949_restart_both_pilots_fe(SDMTestCase):
    "restart both pilots on FE using SHMC / OA depending on the hardware"

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results

        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.mcasApplicationManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.multiTasksManager = self.sdmManager.multiTasksManager
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()

    def test_restart_both_pilots_fe(self):
        """
        Test restart both pilots on FE using SHMC / OA depending on the hardware
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case precheck and return current active alarm list"""
        LOGGER.debug("test case pre check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _restartPilots(self, lab, hardwareManager):
        """
        restart both pilots at the same time
        start by stand by pilot since ssh connection will be broken when restarting active pilot
        wait the pilot recover
        """
        activePilot = self.mcasMachineManager.getActivePilot(lab)
        activePilotSlot = activePilot.split('-')[2]
        standbyPilot = self.mcasMachineManager.getStandbyPilot(lab)
        standbyPilotSlot = standbyPilot.split('-')[2]

        LOGGER.info("restart slot %s on Labs '%s' in progress ", standbyPilotSlot, lab.id)
        hardwareManager.restartBoard(lab, standbyPilotSlot)
        LOGGER.info("restart slot %s on Labs '%s' in progress ", activePilotSlot, lab.id)
        hardwareManager.restartBoard(lab, activePilotSlot)
        CommonAssert.timedAssert(PILOT_RECOVER_TIMEOUT, MACHINE_STATUS_CHECK_INTERVAL,
                                 self.mcasMachineManager.checkMachineStatus,
                                 lab, logLevel='debug')
    def _runTestCase(self):
        """Execute test case"""
        LOGGER.debug("run test case ...")

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.fe)
        hardwareManager = self.sdmManager.hardwareManagerFactory.createHardwareManager(self.fe)
        self._restartPilots(self.fe, hardwareManager)

        LOGGER.info("Restart traffics if needed")
        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.debug("test case post-check")
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep
        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            labs = [lab for lab in self.testEnv.testBed.labs.values() if lab is not self.fe]
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2], checkNoPilotSwitchoverOnLabs=labs)
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
