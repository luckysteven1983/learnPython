'''
Created on May 15, 2015

@author: Andy SUN
'''

from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)

class casegroup3(SDMTestCase):
    '''This class defines tests'''

    def setUp(self):
        LOGGER.debug("setUp")
        LOGGER.debug("testEnv id: %s", self.testEnv.id)

    def tearDown(self):
        LOGGER.debug("tearDown")

    def test_case1(self):
        ''' This is a basic test'''
        LOGGER.info("case 1 in group 3")
        _, be = self.testEnv.testBed.getBackends().popitem()
        rc, stdout = self.sdmManager.sshManager.run(be.oamIpAddress, 'echo hello')
        LOGGER.debug(stdout)
        if rc:
            LOGGER.error("case 1 in group 3 failure")
        else:
            LOGGER.info("case 1 in group 3 success")

    def test_case2(self):
        ''' This is a basic test'''
        LOGGER.info("case 2 in group 3")
        _, be = self.testEnv.testBed.getBackends().popitem()
        rc, stdout = self.sdmManager.sshManager.run(be.oamIpAddress, 'echo world')
        LOGGER.debug(stdout)
        if rc:
            LOGGER.error("case 2 in group 3 failure")
        else:
            LOGGER.info("case 2 in group 3 success")
