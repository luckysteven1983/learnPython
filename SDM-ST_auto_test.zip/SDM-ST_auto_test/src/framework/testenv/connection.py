"""
Created on Sept 23, 2015
@author: Claude Le Du
"""

class Connection(object):
    """
    Defines a connection between a lab and a router
    """

    def __init__(self):
        self.router = None
        self.flow = ""
        self.vlan = ""
        self.interface = ""
