'''
Created on Oct 14, 2015

@author: Tangi Lavanant
#weblink_id=3KJ-00117-5615-QPZZA

'''


import os
import random
import time

from framework.asserts.common_asserts import CommonAssert
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from lib.database.ddm.database_state_manager import DDM_DB_INTERVAL_CHECK, \
    DDM_DB_SYNCHRO_TIMEOUT
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_machine_manager import MIDDLEWARE_ROLE_NONPILOT


LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class fk7163_be_master_blade_restart(SDMTestCase):
    """
    Goal of the test is :
    Overload at 300% of max dynamic capacity for VoLTE MixRef + restart 1 Master vBE blade - 50ms +2E-4PL
    Only restart 1 Master vBE blade is done here
    Traffic done by other tools
    """

    def setUp(self):
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.allBEs = self.testEnv.testBed.getBackends().values()

    def test_be_master_blade_restart(self):
        """Restart blade on master BE
        """
        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)

    def _precheck(self):
        """Test case pre-check"""
        LOGGER.info("test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

    def _runTestCase(self):
        """Execute test case"""

        LOGGER.info("run test case be_master_blade_restart")
        # Get a time from any one lab
        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, self.allBEs[0])
        # Restart a blade on a BE.
        masterBE = self.sdmManager.databaseStateManager.getMasterBE(self.allBEs)[0]
        LOGGER.info("Restart a blade on BE %s", masterBE.id)
        # Got the two nonpilots
        stations = self.allBEs[0].stations.values()
        stations = [sta.rcsHostname for sta in stations if sta.middlewareRole == MIDDLEWARE_ROLE_NONPILOT][0:2]
        # Choose on board
        boardN = stations[random.randint(0, len(stations) - 1)]
        LOGGER.info("Restart %s on  BE %s", boardN, masterBE.id)
        self.sdmManager.mcasMachineManager.stationfwRestartNonPilot(masterBE, boardN)
        # We need to wait all NDB become started.
        LOGGER.info("Waiting NDB up on BE %s", masterBE.id)
        CommonAssert.timedAssert(DDM_DB_SYNCHRO_TIMEOUT, DDM_DB_INTERVAL_CHECK,
                                 self.sdmManager.databaseStateManager.assertNdbState,
                                 masterBE, 'started', logLevel='debug')

        # If the traffic can't be recovered, fail the case through raising the exception in
        # startTrafficsAgainIfNeeded. We don't need to continue
        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()
        return startTime

    def _postcheck(self, startTime):
        """Test case post-check"""
        LOGGER.info("test case post-check")
        time.sleep(10)
        exceptMsg = str()
        alarmsConfig = AlarmsConfig(startingDate=startTime)
        for labIndex in self.testEnv.testBed.labs.values():
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex,
                                                                       myAlarmsConfig=alarmsConfig,
                                                                       logFile=LOGFILE[1])
            except BaseException, msg:
                exceptMsg += str(msg) + os.linesep

        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            exceptMsg += str(msg) + os.linesep
        if exceptMsg:
            LOGGER.error(exceptMsg)
            raise Exception(exceptMsg)
