'''
common class for all diameter traffic simulators.

@author: yohannm
'''
from framework.traffic.telecom_traffic_simulator import TelecomTrafficSimulator

class DiameterTrafficSimulator(TelecomTrafficSimulator):
    '''
    classdocs
    '''


    def __init__(self, sshManager=None):
        '''
        Constructor
        '''
        super(DiameterTrafficSimulator,self).__init__(sshManager)
