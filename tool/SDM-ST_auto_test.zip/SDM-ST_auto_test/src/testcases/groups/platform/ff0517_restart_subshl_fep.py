'''
Created on Oct. 23, 2015

@author: Andy SUN
'''

import random
import os
from framework.common import Utils
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.asserts.common_asserts import CommonAssert
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

TIMEOUT_3HOURS = 3*3600

class ff0517_restart_subshl_fep(SDMTestCase):
    """ Restart a board on a FE """


    def setUp(self):
        self.logLinksPrint()   # Used to get the log links in Junit XML results
        self.mcasMachineManager = self.sdmManager.mcasMachineManager
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarmsBE = []
        self.acceptedAlarmsBE = []
        self.expectedAlarmsFE = []
        self.acceptedAlarmsFE = []
        self.allBEs = self.testEnv.testBed.getBackends().values()
        self.allFEs = self.testEnv.testBed.getFrontends().values()
        self.success = True
        self.exceptMsg = ""


    def test_restart_subshl_bep_fe(self):
        """ Restart a board on a FE """

        self._precheck()
        startTime = self._runTestCase()
        self._postcheck(startTime)


    def _precheck(self):
        """Test case pre-check and return current active alarm list """

        LOGGER.debug("Test case pre-check")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])


    def _runTestCase(self):
        """ Restart a board on a FE """

        LOGGER.debug("Get a FE")
        _, fe = self.testEnv.testBed.getFrontends().popitem()
        LOGGER.debug("FE is " + fe.id)

        LOGGER.debug("%s: Choose a non-pilot station", fe.id)
        nonPilotStation = random.choice(self.mcasMachineManager.getMachinesNotVHost(fe))
        LOGGER.debug("%s: non-pilot station %s has been chosen", fe.id, nonPilotStation)

        LOGGER.debug("%s: check non-pilot station %s is in good status", fe.id, nonPilotStation)
        self.testEnvAsserts.assertStationOK(fe, nonPilotStation)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, fe)
        LOGGER.info("Restart board " + nonPilotStation + " on FE " + fe.id + " at: " + startTime)

        self.assertTrue(self.mcasMachineManager.removeMachine(fe, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.powerOffMachine(fe, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.powerOnMachine(fe, nonPilotStation))
        self.assertTrue(self.mcasMachineManager.restoreMachine(fe, nonPilotStation))

        CommonAssert.timedAssert(TIMEOUT_3HOURS, 60, self.testEnvAsserts.assertStationOK, fe, nonPilotStation,
                                 'COMPL', 'debug')

        LOGGER.info("Restart traffics if needed")
        self.sdmManager.trafficManager.startTrafficsAgainIfNeeded()

        return startTime


    def _postcheck(self, startTime):

        """ Test case post-check"""
        LOGGER.debug("Test case post-check")
        LOGGER.debug("Check the alarms")
        myAlarmsConfigFE = AlarmsConfig(self.expectedAlarmsFE, self.acceptedAlarmsFE, startTime)
        for labIndex in self.allFEs:
            try:
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigFE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        myAlarmsConfigBE = AlarmsConfig(self.expectedAlarmsBE, self.acceptedAlarmsBE, startTime)
        for labIndex in self.allBEs:
            try:
                # Compares alarms from snmp log file to expected and accepted lists
                # but doesn't check all raised alarms are cleared
                self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(labIndex, myAlarmsConfigBE, logFile=LOGFILE[1])
            except BaseException, msg:
                self.exceptMsg += str(msg) + os.linesep

        # resets a starting point for the QoS to check if the traffics have recovered
        # if the test did a traffic disturbance
        # checkQoSFinalPointAllTraffics is called in assertEndState
        try:
            self.sdmManager.trafficManager.setQoSStartingPointAllTraffics()
        except BaseException as arg:
            LOGGER.error(arg.message)

        LOGGER.debug("Check the end status of the test env")
        try:
            self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])
        except BaseException, msg:
            self.success = False
            self.exceptMsg += str(msg)

        if self.success:
            LOGGER.debug("ff0517_restart_subshl_fep success!\n")
        else:
            LOGGER.error("ff0517_restart_subshl_fep failed!\n")
            LOGGER.error(self.exceptMsg)
            raise Exception(self.exceptMsg)

