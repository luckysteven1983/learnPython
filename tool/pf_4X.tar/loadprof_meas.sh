#!/bin/bash

file=`ls -lrt meas*|tail -1|awk '{print $9}'`

grep -A 2 -w  loadprof_SUM  $file|grep -v "\-\-"|head -1 > rep1.txt
grep -A 2 -w  loadprof_SUM  $file|grep -v "\-\-"|grep -v  loadprof_SUM  >> rep1.txt

awk 'BEGIN { print "Avg(loadprof_SUM)" } NR==1 {next } { lprof += $3;  ++num;  next } END { printf "%16d\n", lprof/num}'  rep1.txt  > be_loadprof_meas.result

rm rep1.txt
