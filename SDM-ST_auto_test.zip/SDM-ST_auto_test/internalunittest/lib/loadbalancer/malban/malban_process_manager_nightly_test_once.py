'''
Created on Aug 21, 2015

@author: xzhao015
'''
import unittest
import time
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase


LOGGER = Logger.getLogger(__name__)


class malban_process_manager_nightly_test_once(SDMTestCase):


    def setUp(self):
        LOGGER.info("malban Process Manager Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.PM = self.sdmManager.malbanProcessManager
        self.loadbalancerManager=self.sdmManager.seloadbalancerManager

    def tearDown(self):
        pass

    def test_01_getPidOnMalban(self):
        if self.fe.hardware == 'ROUZIC':
            process = "diameter"
            activeLB = self.loadbalancerManager.getActiveLB(self.fe)
            self.PM.isAliveOnMalban(self.fe, activeLB, processName=process)
            pid = self.PM.getPidbyPSOnMalban(self.fe,activeLB, process)
            self.PM.killProcessOnMalban(self.fe,activeLB, process)
            time.sleep(60)
            pid2 = self.PM.getPidbyPSOnMalban(self.fe, activeLB, process)
            self.assertEqual(len(pid), len(pid2))
            self.PM.killProcessbyPidOnMalban(self.fe, activeLB, pid2)
            time.sleep(60)
            pid3 = self.PM.getPidbyPSOnMalban(self.fe, activeLB, process)
            self.assertEqual(len(pid2), len(pid3))
        else:
            LOGGER.info("lab hardware is " + self.fe.hardware + " skip this UT")

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

