'''
Created on Nov 2, 2015
@author: Tangi Lavanant
'''

import os
import time

from framework.asserts.common_asserts import CommonAssert
from lib.exceptions_messages import MCAS_ASTOP_INVALID, MCAS_ASTART_INVALID
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger
from lib.platform.mcas.mcas_application_manager import McasApplicationManagerError

LOGGER = Logger.getLogger(__name__)
MCAS_ASTART_TIMEOUT = 1200
MCAS_ASTOP_TIMEOUT = 1200  # value coming from FV1
CMD_ASTOP = '/etc/Astop ucl '
CMD_ASTART = '/etc/Astart ucl '
CMD_FW_PFBOOT = "/usr/dhafw/tools/fw pfboot "
MCAS_RESTART_PF_TIMEOUT = 7200  # 2h value coming from FV1
MCAS_RESTART_PF_BEFORE_CHECK_TIMER = 300  # 10min value coming from FV1
# Fw path
FW_PATH = "/usr/dhafw/tools/fw "
# FW commands
FW_LLSTA = "llsta"
FW_LSNDB = "lsndb"
FW_LVER = "lver"
FW_RESTART_NON_PILOT = "restartnp"
FW_RESTART_PILOT = "restart"
WAIT_TIME_ASTOP = 15  # coming from FV1

class McasPlatformManagerError(BaseException):
    """If error, raise it."""
    pass

class McasPlatformManager(object):
    '''
    McasPlatformManager is used to make Astop or Astart.
    timers are defined
    ASTART_TIMEOUT = 1200 can be used to wait for platform recover
    '''

    def __init__(self, sshManager, subshlManager, linuxProcessManager, mcasMachineManager):
        '''
        Constructor
        '''
        self._sshManager = sshManager
        self._subshl = subshlManager
        self._CA = CommonAssert
        self._linuxProcessManager = linuxProcessManager
        self._mcasMachineManager = mcasMachineManager

    def runAstop(self, lab, parameter):
        '''
        @param lab : the hostname/IP of the lab
        @param parameter : indicate which Astop we do local or all
        Usage :
        self.mcasPlatformManager.runAstop(lab, 'all')
        self.mcasPlatformManager.runAstop(lab,'local') only possible on stby pilot
        '''
        exceptionMessage = lab.id + ": " + msgs.MCAS_ASTOP_FAILS
        LOGGER.debug('Launching Astop ...')
        if parameter == 'all' :
            cmd = CMD_ASTOP + 'all'
            try:
                self._sshManager.run(lab.oamIpAddress, cmd)
            except:
                LOGGER.error(exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
        elif parameter == "local":
            cmd = CMD_ASTOP + 'local'
            standbyPilot = self._mcasMachineManager.getStandbyPilot(lab)
            rshCmd = "rsh %s %s" % (standbyPilot, cmd)
            try:
                self._sshManager.run(lab.oamIpAddress, rshCmd)
            except:
                LOGGER.error(exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
        else:
            LOGGER.error(MCAS_ASTOP_INVALID)
            raise McasApplicationManagerError, MCAS_ASTOP_INVALID
        time.sleep(WAIT_TIME_ASTOP)

    def runAstart(self, lab, parameter):
        '''
        @param lab : the hostname/IP of the lab
        @param parameter : indicate which Astart we do local or all
        Usage :
        self.mcasPlatformManager.runAstart(lab, 'all')
        self.mcasPlatformManager.runAstart(lab,'local'), only possible on stby pilot
        '''
        LOGGER.debug('Launching Astart all ...')
        exceptionMessage = lab.id + ": " + ": " + msgs.MCAS_ASTART_FAILS
        if parameter == 'all' :
            cmd = CMD_ASTART + 'all'
            try:
                self._sshManager.run(lab.oamIpAddress, cmd)
            except:
                LOGGER.error(exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
        elif parameter == "local":
            cmd = CMD_ASTART + 'local'
            standbyPilot = self._mcasMachineManager.getStandbyPilot(lab)
            rshCmd = "rsh %s %s" % (standbyPilot, cmd)
            try:
                self._sshManager.run(lab.oamIpAddress, rshCmd)
            except:
                LOGGER.error(exceptionMessage)
                raise McasApplicationManagerError, exceptionMessage
        else:
            LOGGER.error(MCAS_ASTART_INVALID)
            raise McasApplicationManagerError, MCAS_ASTART_INVALID

    def restartPlatformByPfboot(self, lab):
        '''
        this function is to restart a node ( FE or BE )
        pfboot: restart pf
        command '/usr/dhafw/tools/fw pfboot;'
        @param lab: the Lab object
        '''
        LOGGER.debug(str(lab.id) + ": restart Lab :  " + str(lab.id))
        [cmdStatus, stateOutput] = self._sshManager.run(lab.oamIpAddress, CMD_FW_PFBOOT)
        if not cmdStatus:
            LOGGER.debug(str(lab.id) + ": Restart State : " + stateOutput)
            # restart active pilot, the ssh connection will be broken
            if self._sshManager.isDead(lab.oamIpAddress):
                LOGGER.debug(str(lab.id) + " : is restarting")
            else:
                errorMsg = "Lab %s: Restart active pilot board failure (connection still alive)" % lab.id
                LOGGER.error(errorMsg)
                raise McasPlatformManagerError, \
                     "Restart Lab State not success on : " + lab.id + msgs.RESTART_PLATFORM_FAIL
        else:
            LOGGER.error("Restart Lab State : " + stateOutput)
            LOGGER.error("Restart Lab State not success on : " + lab.id + msgs.RESTART_PLATFORM_FAIL)
            raise McasPlatformManagerError, "Restart Lab State not success on : " + lab.id + msgs.RESTART_PLATFORM_FAIL

    def runFw(self, lab, cmd, cmd_parameter=""):
        '''
        this function run fw commands
        @param lab : a lab object
        @param cmd : the command to run. MUST BE a constant defined in this module
        @param cmd_paramter : the command parameter(s) if existing
        @return tuple returned by sshmanager.run()
        @verbatim
        Usage:
        self.mcasPlatformManager.runFw(lab, FW_LLSTA)
        self.mcasPlatformManager.runFw(lab, FW_RESTART_PILOT, "D")
        @endverbatim
        '''
        cmd_to_run = FW_PATH + cmd + ' ' + cmd_parameter
        exceptionMessage = lab.id + ' : ' + cmd + ' : ' + msgs.MCAS_FW_FAILS
        try:
            runResultTuple = self._sshManager.run(lab.oamIpAddress, cmd_to_run)
        except:
            LOGGER.error(exceptionMessage)
            raise McasApplicationManagerError, exceptionMessage
        return runResultTuple

    def runHelpme(self, lab, option='platform'):
        """Run HELPME on lab with option. If error, raise McasPlatformManagerError.

        @param lab    one Lab object
        @param option    one option as string for HELPME command (default 'platform')
        """
        # Run HELPME of mCAS
        cmd = '/opt/config/bin/HELPME %s' %option
        if self._sshManager.run(lab.oamIpAddress, cmd)[0]:
            msg = cmd + " NOK"
            LOGGER.error(msg)
            raise McasPlatformManagerError(msg)

    def getActivePilotInfo(self, lab):
        """Return the lab name and last boot time of active pilot of lab as a tuple

        @param lab   one lab object
        @return     one tuple with hostname and system last boot time like ('bono05-0-0-1', '2015-11-23 01:58')
        """
        response = self._sshManager.run(lab.oamIpAddress, 'hostname ; who -b')[1].split(os.linesep)
        # Get hostname
        hostname = response[0]
        # Get last boot time like '2015-11-23 01:58' from lab reponse like '  system boot  2015-11-23 01:58'
        lastBootTime = response[1].partition('boot')[2].strip()
        return (hostname, lastBootTime)

    def storeActivePilotInfo(self, lab):
        """Store the hostname and last boot time of active pilot

        @param lab   one lab object
        @return     no return value
        """
        returnValue = self.getActivePilotInfo(lab)
        lab.lastSnapshotHostnamePilot = returnValue[0]
        lab.lastBootTimeOfPilot = returnValue[1]

    def checkNoPilotSwitchover(self, lab):
        """Check no pilot switchover occurs on current lab so far. If pilot swithover occurrs, raise exception.

        This function will compare hostname and last boot time of pilot between the current values and those in
        lab object. If it is called more than one time in one test case, the user should call
        storeActivePilotInfo before calling the method because the values in lab object will only be updated at the
        begining of each test case.

        @param lab   one lab object
        @return     no return value
        @exception McasPlatformManagerError     If pilot switchover occurs
        """
        hostname, lastBootTime = self.getActivePilotInfo(lab)
        if hostname != lab.lastSnapshotHostnamePilot or lastBootTime != lab.lastBootTimeOfPilot:
            errorMsg = "Lab %s: %s" %(lab.id, msgs.PILOT_SWITCHOVER_OCCURRED)
            LOGGER.error(errorMsg)
            raise McasPlatformManagerError(errorMsg)
