'''
Created on Aug 21, 2015

@author: xzhao015
'''
import os
import re
import lib.exceptions_messages as msgs
from lib.logging.logger import Logger

LOGGER = Logger.getLogger(__name__)

class MalbanProcessManagerError(BaseException):
    """If error, raise it."""
    pass

class MalbanProcessManager(object):
    '''
    MalbanProcessManager will handle the process actions on malban
    '''

    def __init__(self, malbanManager):
        '''
        Constructor
        '''
        self.malbanManager = malbanManager

    def isAliveOnMalban(self, lab, slot, pid=".", processName=".", logLevel="error"):
        '''
        use ps -fe | grep pid | grep processName to check the process is alive
        @param lab: host ip address
        @param slot: the name of the slot, 0-0-7 or 0-0-8
        @param pid: string, the pid number of the process
                    the default value is "." meaning all pids
        @param processName: string, the name of the process,
                            default value is "." meaning all processes
        @param logLevel if "error" display as error logger message, else debug level
        '''
        exceptionMsg = lab.id +": " + slot +":process " + processName + " " + msgs.PROCESS_NOT_ALIVE
        LOGGER.debug("%s: %s: Checking process " + processName + " is alive", lab.id, slot)
        cmd = "ps -ef | grep " + pid + "| grep " + processName + " | grep -v grep"
        LOGGER.debug("%s: %s: command is %s", lab.id, slot, cmd)
        resultCode, stdout, _ = self.malbanManager.runOnMalban(lab.oamIpAddress, slot, cmd)
        LOGGER.debug("%s: %s: command result is %s", lab.id, slot, stdout)

        if resultCode:
            if logLevel.lower() == "error":
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise MalbanProcessManagerError, exceptionMsg
        else:
            processinfo = [line for line in stdout.split(os.linesep)
                           if re.search(processName, line) and not re.search('grep', line)]
            LOGGER.debug("%s: %s: process information is %s", lab.id, slot, str(processinfo))
        if not processinfo:
            if logLevel.lower() == "error":
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise MalbanProcessManagerError, exceptionMsg

    def getPidbyPSOnMalban(self, lab, slot, processName, logLevel='error'):
        '''
        use ps -fe | grep processName to get the process information
        @param lab: host ip address
        @param slot: the name of the slot, 0-0-7 or 0-0-8
        @param processName: string, the name of the process
        @param logLevel if "error" display as error logger message, else debug level

        '''
        processPid = None
        exceptionMsg = lab.id +": " + slot +":process " + processName + " " + msgs.GET_PID_FAIL
        LOGGER.debug("%s: %s: get process " + processName + " information", lab.id, slot)
        cmd = "ps -ef | grep " + processName + " | grep -v grep"
        LOGGER.debug("%s: %s: command is %s", lab.id, slot, cmd)
        resultCode, stdout, _ = self.malbanManager.runOnMalban(lab.oamIpAddress, slot, cmd)
        LOGGER.debug("%s: %s: result is %s", lab.id, slot, stdout)

        if resultCode:
            if logLevel.lower() == "error":
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise MalbanProcessManagerError, exceptionMsg
        else:
            processPid = [line.split()[1].strip() for line in stdout.split(os.linesep)\
                           if re.search(processName, line) and not re.search('grep', line)]
            LOGGER.debug("%s: %s: process Pid is %s", lab.id, slot, str(processPid))
        if not processPid:
            if logLevel.lower() == "error":
                LOGGER.error(exceptionMsg)
            else:
                LOGGER.debug(exceptionMsg)
            raise MalbanProcessManagerError, exceptionMsg
        return processPid


    def killProcessOnMalban(self, lab, slot, processName):
        '''
        use kill -9 pid to kill process
        @param lab: host ip address
        @param slot: the name of the slot, 0-0-7 or 0-0-8
        @param processName: string, the name of the process
        '''
        exceptionMsg = lab.id +": " + slot +":process " + processName + " " + msgs.KILL_PROCESS_FAIL
        pidStr = ""
        pidlist = self.getPidbyPSOnMalban(lab, slot, processName)
        LOGGER.debug("%s: %s: try to kill process, pid list is %s", lab.id, slot, str(pidlist))

        for pid in pidlist:
            pidStr = pidStr + pid + " "

        LOGGER.debug("Kill process %s on %s", processName, lab.id)
        cmd = "kill -9 " + pidStr + "; echo $?"
        LOGGER.debug("%s: %s: command is %s", lab.id, slot, cmd)
        resultCode, stdout, _ = self.malbanManager.runOnMalban(lab.oamIpAddress, slot, cmd)

        if resultCode:
            LOGGER.error(exceptionMsg)
            raise MalbanProcessManagerError, exceptionMsg
        else:
            resultCode = stdout.split(os.linesep)[-3]
            LOGGER.debug("%s: %s: result code is %s", lab.id, slot, resultCode)
            if not resultCode:
                LOGGER.error(exceptionMsg)
                raise MalbanProcessManagerError, exceptionMsg

    def killProcessbyPidOnMalban(self, lab, slot, pidList):
        '''
        use kill -9 pid to kill process
        @param lab: host ip address
        @param slot: the name of the slot, 0-0-7 or 0-0-8
        @param pidList: List, the list of the pid
        '''
        if not pidList:
            LOGGER.error("Server %s: %s: pidlist is empty!", lab.id, msgs.KILL_PROCESS_FAIL)
            raise MalbanProcessManagerError, msgs.KILL_PROCESS_FAIL
        pidStr = ""
        for pid in pidList:
            pidStr = pidStr + pid + " "
        LOGGER.debug("%s: %s: try to kill process, pid list is %s", lab.id, slot, pidStr)

        exceptionMsg = lab.id +": " + slot + " " + msgs.KILL_PROCESS_FAIL

        LOGGER.debug("Kill process on %s %s", lab.id, slot)
        cmd = "kill -9 " + pidStr + "; echo $?"
        LOGGER.debug("%s: %s: command is %s", lab.id, slot, cmd)
        resultCode, stdout, _ = self.malbanManager.runOnMalban(lab.oamIpAddress, slot, cmd)

        if resultCode:
            LOGGER.error(exceptionMsg)
            raise MalbanProcessManagerError, exceptionMsg
        else:
            resultCode = stdout.split(os.linesep)[-3]
            LOGGER.debug("%s: %s: result code is %s", lab.id, slot, resultCode)
            if not resultCode:
                LOGGER.error(exceptionMsg)
                raise MalbanProcessManagerError, exceptionMsg
