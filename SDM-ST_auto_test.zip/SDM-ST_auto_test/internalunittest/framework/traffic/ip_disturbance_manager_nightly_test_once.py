'''
Created on Apr 29, 2015

@author: Xia Zhao

'''
import unittest
import os
from framework.sdm_test_case import SDMTestCase
from framework.traffic.ip_disturbances_manager import IpDisturbancesManager
from lib.logging.logger import Logger


LOGGER = Logger.getLogger(__name__)


EMPTY_STR = ''


class ip_disturbance_manager_nightly_test_once(SDMTestCase):
    ''' Test for McasApplicationManager
    '''

    def setUp(self):
        LOGGER.info("McasApplicationManagerTest Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()
        self.maManager = self.sdmManager.mcasApplicationManager
        self.mcasMachineManager = self.sdmManager.mcasMachineManager

        self.beIpDisturb = IpDisturbancesManager(self.sdmManager.sshManager, self.be, gdmp=True)
        self.feIpDisturb = IpDisturbancesManager(self.sdmManager.sshManager, self.fe, gdmp=True)


    def tearDown(self):
        pass


    def test_01_show_disturb(self):

        # clean all IP disturb and delete them if any
        LOGGER.info("unit test: first show and clean  IP disturbance for >> " + self.fe.id)
        self.check_and_clean(self.feIpDisturb)

        LOGGER.info("unit test: show IP disturbance for >> " + self.fe.id)
        out = self.feIpDisturb.showIpDisturbance()
        LOGGER.info(os.linesep + out)
        outPurged = out.translate(None, '[]-0123456789').rstrip()  # purge headers on each line, and EOL
        self.assertEqual(outPurged, EMPTY_STR, ' UNEXPECTED OUTPUT : should be empty ')


    def test_02_set_latency(self):

        # clean all IP disturb and delete them if any
        self.check_and_clean(self.feIpDisturb)

        LOGGER.info("unit test: set IP disturbance = latency  for >> " + self.fe.id)
        self.feIpDisturb.setIpDisturbanceLatency(latency=23)
        out = self.feIpDisturb.showIpDisturbance()
        LOGGER.info(os.linesep + out)
        self.assertIn('delay 23.0ms', out, ' UNEXPECTED OUTPUT : Unexpected values for IP Disturbances = ' + out)

        self.feIpDisturb.deleteIpDisturbance()
        out = self.feIpDisturb.showIpDisturbance()
        LOGGER.info(os.linesep + out)
        outPurged = out.translate(None, '[]-0123456789').rstrip()  # purge headers on each line, and EOL
        self.assertEqual(outPurged, EMPTY_STR, ' UNEXPECTED OUTPUT : should be empty ')


    def test_03_set_latency_jitter_packetLoss(self):

        # clean all IP disturb and delete them if any
        self.check_and_clean(self.feIpDisturb)

        LOGGER.info("unit test: set IP disturbance = latency jitter paceketLoss  for >> " + self.fe.id)
        self.feIpDisturb.setIpDisturbanceLatencyJitterPacketLoss(latency=12, jitter=3, packetLoss=0.022)
        out = self.feIpDisturb.showIpDisturbance()
        self.assertIn('delay 12.0ms  3.0ms', out, ' UNEXPECTED OUTPUT : Unexpected values for IP Disturbances = ' + out)

        self.feIpDisturb.deleteIpDisturbance()
        out = self.feIpDisturb.showIpDisturbance()
        LOGGER.info(os.linesep + out)
        outPurged = out.translate(None, '[]-0123456789').rstrip()  # purge headers on each line, and EOL
        self.assertEqual(outPurged, EMPTY_STR, ' UNEXPECTED OUTPUT : should be empty ')



    def check_and_clean(self, ipDisturb):
        ''' check if some IP disturbances remains set (if exception during first test) and
            delete them
        '''
        out = self.feIpDisturb.showIpDisturbance()
        if out.translate(None, '[]-0123456789').rstrip() == '':  # purge headers on each line, and EOL, then test
            return
        for ln in out.split(os.linesep):
            if ln.translate(None, '[]-0123456789').rstrip() == '':
                continue
            LOGGER.info(' Cleaning IP disturbance : ' + ln)
            ipDisturb.deleteIpDisturbance()  # there is IP disturbances set => remove them
            break  # IP disturbances cleaned => we can exit



if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
