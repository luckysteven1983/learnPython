'''
Created on May 5, 2015
@author: FrankZh

the interface for users to run SDM SU with command lines
'''

#import os
import sys
#import unittest
import getopt
#from time import sleep

#from framework.common import Utils
from lib.logging.logger import Logger
#from lib.ssh.ssh_manager import SshManager
#from framework.sdm_test_case import SDMTestCase

from lib.softwareupdate.sdm_su_job_handler import SdmSuJobHandler
#from lib.softwareupdate.sdm_su_runner import SdmSuRunner
from lib.softwareupdate.sdm_su_constants import SdmSuConst
#from lib.softwareupdate.sdm_su_common_func import SdmSuUtils as cf

LOGGER = Logger.getLogger(__name__)

class SdmApplySu(SdmSuJobHandler):
    """
    Usage: sdm_apply_su.py -i oamIpAddress -a action_list [-l logLevel] [-s softwareServerIP] [-d softwareLocation] [-u softwareServerLogin] [-g oamSctipsLocation]

    options:
    -h, --help       show help

    -i oamIpAddress
        The floating pilot IP of the SDM lab

    -a action_list
        SU action list, separated with comma if it includes several actions of the following,
        'INSTALL_AGENT','DOWNLOAD','VERIFY','ACTIVATE','APPLY1','RESUME1','APPLY2','SOAK','COMMIT','BACKOUT','BACKOUT_SOAK','RESUME2'

    -l logLevel
        Optional. the logging level. The level includes 'NOTEST', 'DEBUG', 'INFO', \
'WARNING', 'ERROR' and 'CRITICAL' with the order of priority. the default is 'INFO'.

    -s softwareServerIP
        Optional. The software repository server IP address on which the SU software packages are stored.

    -d softwareLocation
        Optional. The directory of the SU software packages on the software server.

    -u softwareServerLogin
        Optional. The login of the software server. if softwareServerIP is set, this option is needed also.

    -g oamAgentLocation
        Optional. The directory of OAMScripts on the software server.

    -e efxPatchLocation
        Optional. The directory of emergency patches on the software server.

    """

    def __init__(self, argv):
        '''
        call parent __init__ also
        '''
        super(SdmApplySu, self).__init__()
        self.argv = argv

    def usage(self):
        '''
        print usage
        '''
        LOGGER.info(self.__doc__)

    def parseOptions(self, argv):
        '''
        parse argv
        '''
        if len(argv) == 1:
            LOGGER.error("Command format Error")
            self.usage()
            sys.exit(2)
        else:
            try:
                opts, _ = getopt.getopt(argv[1:], "i:a:l:s:d:u:g:h:e", ["help"])
            except getopt.GetoptError:
                LOGGER.error("sdm_apply_su.py getopt Error")
                self.usage()
                sys.exit(2)

        softwareServerFlag = False
        ipFlag = False
        actionFlag = False

        for opt, arg in opts:
            if opt in ("-h", "--help"):
                self.usage()
                sys.exit(2)
            elif opt.strip() == "-i":
                if not arg:
                    LOGGER.error("lab ip should not be NULL")
                    self.usage()
                    sys.exit(2)
                self.oamIpAddress = arg
                ipFlag = True
            elif opt.strip() == "-a":
                if not arg:
                    LOGGER.error("SU action should not be NULL")
                    self.usage()
                    sys.exit(2)
                self.actionList = arg.strip().split(',')
                actionFlag = True
            elif opt.strip() == "-l":
                LOGGER.setLevel(arg)
            elif opt.strip() == "-s":
                self.softwareServerIp = arg
                softwareServerFlag = True
            elif opt.strip() == "-d":
                self.releaseFilePath = arg
                softwareServerFlag = True
            elif opt.strip() == "-u":
                self.sftpLogin = arg
                softwareServerFlag = True
            elif opt.strip() == "-g":
                self.oamScriptsDir = arg
                softwareServerFlag = True
            elif opt.strip() == "-e":
                self.efxPatchesPath = arg
                softwareServerFlag = True

            if arg[0] == '-':
                LOGGER.error("wrong command format, please double check")
                self.usage()
                sys.exit(2)

        if not self.oamIpAddress:
            LOGGER.error("lab ip should not be NULL")
            self.usage()
            sys.exit(2)

        if not (actionFlag and ipFlag):
            LOGGER.error("Wrong command format. oamIpAddress  or action_list is missing, please check it")
            self.usage()
            sys.exit(2)

        #softwareServerIp, releaseFilePath and sftpLogin must be provided in together
        if softwareServerFlag and (not (self.softwareServerIp \
            and (self.releaseFilePath or self.oamScriptsDir or self.efxPatchesPath) \
            and self.sftpLogin)):
            message = "sdm_apply_su.py format error: missing \
            softwareServerIP or softwareLocation or softwareServerLogin"
            LOGGER.error(message)
            self.usage()
            sys.exit(2)

        if 'INSTALL_AGENT' in self.actionList or 'DOWNLOAD' in self.actionList:
            if not softwareServerFlag:
                message = "for INSTALL_AGENT or DOWNLOAD : softwareServerIP \
                or softwareLocation or softwareServerLogin should not be absent."
                LOGGER.error(message)
                self.usage()
                sys.exit(2)

    def startSU(self):
        """
        start SU actions
        """
        self.parseOptions(self.argv)
        return self.execJobs()

def main():
    """
    main funtion for the entry
    """
    sdmSu = SdmApplySu(sys.argv)
    suRst = sdmSu.startSU()

    sdmSu.sshMngr.closeAllClients()

    if suRst == SdmSuConst.RST_SUCCESS:
        sys.exit(0)
    else:
        sys.exit(2)

if __name__ == "__main__":
    main()


