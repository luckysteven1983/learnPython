#!/bin/bash
for sta in `cat /etc/hosts|grep -i station|awk '{print $2}'`
do
  ssh $sta 'sysctl -a | grep net.ipv4.tcp_window_scaling '
  ssh $sta 'sysctl -a | grep  net.core.rmem_default '
  ssh $sta 'sysctl -a | grep  net.core.wmem_default  '
  ssh $sta 'sysctl -a | grep  net.core.rmem_max  '
  ssh $sta 'sysctl -a | grep  net.core.wmem_max  '
  ssh $sta 'sysctl -a | grep  net.ipv4.tcp_rmem  '
  ssh $sta 'sysctl -a | grep net.ipv4.tcp_wmem'
  ssh $sta 'sysctl -a | grep net.ipv4.tcp_timestamps'
  ssh $sta 'sysctl -a | grep tcp_frto_response'
  ssh $sta 'sysctl -a | grep  net.core.netdev_max_backlog  '
  ssh $sta 'sysctl -a | grep  net.ipv4.tcp_congestion_contro'
  echo "==============$sta==============================================="
done > check_tcp_params.log
