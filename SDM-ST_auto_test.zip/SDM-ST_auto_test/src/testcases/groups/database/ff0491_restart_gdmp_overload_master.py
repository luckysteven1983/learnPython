'''
Created on Mar 17, 2015

@author: Xia Zhao
'''
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from lib.alarm.alarms_config import AlarmsConfig
from framework.common import Utils

LOGGER = Logger.getLogger(__name__)
LOGFILE = Logger.getAlarmLogFileNames(__name__)

class ff0491_restart_gdmp_overload_master(SDMTestCase):
    '''test restart gdmps on master be'''

    def setUp(self):
        self.logLinksPrint()#Used to get the log links in Junit XML results
        self.myDSM = self.sdmManager.databaseStateManager
        self.myDM = self.sdmManager.databaseManager
        self.myPA = self.sdmManager.platformAsserts
        self.testEnvAsserts = self.sdmManager.testEnvAsserts
        self.expectedAlarms = []
        self.acceptedAlarms = []

    def test_restart_gdmp_overload_master(self):
        '''test restart GDMPServerOverload on master be'''
        LOGGER.debug("check the Initial status of the test env")
        self.testEnvAsserts.assertInitialState(self.testEnv, LOGFILE[0])

        LOGGER.info("Start to restart gdmp overload on master BE")
        LOGGER.debug("Get master BE")
        belist = self.testEnv.testBed.getLabsInNRG("1")
        masterBE = self.myDSM.getMasterBE(belist)[0]
        LOGGER.debug("Master BE is "+masterBE.id)

        startTime = Utils.getCurrentLabTime(self.sdmManager.sshManager, masterBE,)
        LOGGER.debug("Start to restart GDMPServerOverload on master BE at: " + startTime)

        stations = masterBE.getAllBlade().keys()
        LOGGER.debug("the station list is: "+str(stations))

        process = "GDMPServerOverload"
        processRestart = "GdmpsOverload"

        LOGGER.debug("check the GDMPServerOverload process on all stations is alive")
        self.myPA.assertProcessAliveOnStations(masterBE, process, stations)

        LOGGER.debug("restart GDMPServerOverload on all stations")
        self.myDM.runScriptOperation(masterBE, processRestart, ddmOperation='restart', 
                                     station=stations)

        LOGGER.debug("check the GDMPServerOverload process on all stations can be recover")
        self.myPA.assertProcessAliveOnStations(masterBE, process, stations)

        LOGGER.debug("check the alarm")
        # Compares alarms from snmp log file to expected and accepted lists
        # but doesn't check all raised alarms are cleared
        myAlarmsConfig = AlarmsConfig(self.expectedAlarms, self.acceptedAlarms, startTime)
        self.sdmManager.alarmsCheckerManager.parseSnmpLogFiles(lab=masterBE,
                                                               myAlarmsConfig=myAlarmsConfig,
                                                               logFile=LOGFILE[1])


        LOGGER.debug("check the end status of the test env")
        self.testEnvAsserts.assertEndState(self.testEnv, startTime, LOGFILE[2])

        LOGGER.debug("ff0491 restart gdmp overload on master BE success!\n")
