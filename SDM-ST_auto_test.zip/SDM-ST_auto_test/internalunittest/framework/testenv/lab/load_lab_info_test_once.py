"""
Created on Aug 3, 2015

@author: Andy SUN
"""

import unittest
from lib.logging.logger import Logger
from framework.sdm_test_case import SDMTestCase
from framework.testenv.backend import Backend

LOGGER = Logger.getLogger(__name__)

class load_lab_info_test_once(SDMTestCase):
    """
    This class is to test lab class
    """

    def test_1_display_lab_info(self):
        """Just display the lab info. Need to manually check because the content is variable
        """
        labs = self.testEnv.testBed.labs.values()
        LOGGER.info("Display lab informations")
        for lab in labs:
            LOGGER.info("lab %s zone id %s", lab.id, lab.zoneId)
            if type(lab.productRole) is Backend:
                LOGGER.info("lab %s replicated address %s", lab.id,
                                                            str(lab.productRole.replicatedAddress))
                LOGGER.info("lab %s NDB address %s", lab.id, str(lab.productRole.ndbAddress))

if __name__ == "__main__":
    unittest.main()
