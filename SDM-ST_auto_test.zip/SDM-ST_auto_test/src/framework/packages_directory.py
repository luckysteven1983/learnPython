'''
Created on Jun 19, 2015

@author: Tangi Lavanant
'''
import argparse
import re
import urllib2
import logging
import subprocess
import os
import shutil
from framework import arch

formatter = logging.Formatter('%(asctime)s - %(filename)s - %(lineno)d - %(levelname)s - %(message)s')
LOG = logging.getLogger(__name__)
LOG.setLevel(logging.DEBUG)
# create console handler and set level to debug
CHANNEL = logging.StreamHandler()
CHANNEL.setLevel(logging.DEBUG)
CHANNEL.setFormatter(formatter)
# add CHANNEL to logger
LOG.addHandler(CHANNEL)


class PreparePackagesDir(object):
    '''
    this class will implement a check method with one parameter: a needed CP.
    It will creates directories if needed
    It implies antiword is installed on the used machine
    It will create directories if missing.
    It also supposes that packages have been locally downloaded before
    '''
    VER_SDM = 422
    MCAS_DIR = ""

    def __init__(self):
        '''
        Constructor
        '''
    def getPackagesManualSU(self, cp):
        '''
            To have the name of the packages mCAS to retrieve for CP
            parameter cp is the targeted CP for example 125
        '''
        # The CP can be found on page http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdmVER.html
        # VER is the SDM version
        # CP for 422 are on page 421, so we have a special test for this case
        if self.VER_SDM == 422:
            _sdmBuildsURL = "http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdm421.html"
        else:
            _sdmBuildsURL = "http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdm" \
             + self.VER_SDM + ".html"

        LOG.info("Packages will be copied for CP " + cp + " SDM Version is : " + str(self.VER_SDM))
        LOG.info("Packages Names coming from : " + _sdmBuildsURL)
        # directory CPXXX has to be created if needed
        _cpdir = arch.DELIV_PACKAGES_DIR + '/CP' + cp
        if not os.path.isdir(_cpdir) :
            os.makedirs(_cpdir)
            LOG.info(_cpdir + " Created")
        else:
            LOG.critical(_cpdir + " already exist ! Work probably already done Exiting...")
            return

        _sdmCPPage = urllib2.urlopen(_sdmBuildsURL)

        # on the HTML page there is a link to a doc word.
        # Lets get it !
        for line in _sdmCPPage:
            if 'CP.' + str(cp) in line:
                _CP = re.search('(http.*tar)(.*href=")(.*doc)', line)
                LOG.debug("Delivery Note used is : ")
                LOG.debug(_CP.group(3))
                break

        # file will be saved in order to be parsed
        fh = open("DelNote.doc", 'wb')
        fh.write(urllib2.urlopen(_CP.group(3)).read())
        fh.close()
        cmd = 'LANG="bs_BA" antiword ' + "DelNote.doc"
        _delivNotesText = subprocess.check_output(cmd, shell=True)

        # Retrieviong OAM Scripts

        _mCASScriptsFileName = re.search('(OAMscripts_MCAS_)([0-9]+.[0-9]+)', _delivNotesText)
        LOG.info("MCAS_Scripts_File_Name : " + _mCASScriptsFileName.group(0) + '.tar.gz')

        shutil.copy(arch.OAMSCRIPT_PACKAGES_DIR + '/' + _mCASScriptsFileName.group(0) + '.tar.gz', \
                     _cpdir + '/' + _mCASScriptsFileName.group(0) + '.tar.gz')

        # Get DDM file
        _DDMFileName = re.search('(DDMr[0-9].*.tar.gz)', _delivNotesText)
        LOG.info('DDM File name is : ' + _DDMFileName.group(0))
        shutil.copy(arch.DDM_PACKAGES_DIR + '/' + _DDMFileName.group(0) , \
                     _cpdir + '/' + _DDMFileName.group(0))

        # Now retrieving DataModel. Not used for the moment
        _dataModel = re.search(r'(DATAMODEL_DEV.*\b)', str(_delivNotesText))
        _dataModel = _dataModel.group(0)
        LOG.info('DataModel is : ' + _dataModel)

        # Get Mcas Packages
        _mCASVer = re.search('(mCAS)(.*)(R[0-9]+.[0-9]+.[0-9]+)', _delivNotesText)
        _mCASVer = _mCASVer.group(1) + _mCASVer.group(3)
        LOG.debug('mCAS Version is : ' + _mCASVer)

        mCAS_SourceDir = re.search(r"(CCMS.*)(IAS/)(.*/)(.*\b)", _delivNotesText)
        mCAS_SourceDir = arch.OAM_PACKAGES_DIR + '/' + mCAS_SourceDir.group(3) + mCAS_SourceDir.group(4) + '/Upgrade'
        LOG.info('mCAS packages will be retrieved from : ' + mCAS_SourceDir)
        src_files = os.listdir(mCAS_SourceDir)
        for file_name in src_files:
            full_file_name = os.path.join(mCAS_SourceDir, file_name)
            LOG.info('mCAS packages retrieved  : ' + full_file_name)
            shutil.copy(full_file_name , _cpdir + '/')

        _dateSDM = re.search(r"(8650SDM-)(.*)(-SDM)", _delivNotesText)
        _sdm421dir = arch.SDM_PACKAGES_DIR + '/421'
        LOG.debug('SDM packages with date : ' + _dateSDM.group(2) + " will be retrieved from : " + _sdm421dir)
        for _sdmpackages in os.listdir(_sdm421dir) :
            if _dateSDM.group(2) in  _sdmpackages :
                LOG.info('SDM packages retrieved  : ' + _sdm421dir + '/' + _sdmpackages)
                shutil.copy(_sdm421dir + '/' + _sdmpackages  , _cpdir + '/')

        LOG.info("Packages copied in : " + _cpdir)

    def getPackages(self, cp):
        '''
            To have the name of the packages mCAS to retrieve for CP
            THIS METHOD IS NOT USEABLE YET
            THIS IS for automatic SU and is NOT ready now.
        '''
        # The CP can be found on page http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdmVER.html
        # VER is the SDM version
        # CP for 422 are on page 421, so we have a special test for this case
        if self.VER_SDM == 422:
            _sdmBuildsURL = "http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdm421.html"
        else:
            _sdmBuildsURL = "http://bl1245.cn.alcatel-lucent.com:8650/job/webpage/ws/sdm" \
             + self.VER_SDM + ".html"

        LOG.info("Version is : " + str(self.VER_SDM))
        LOG.info("Packages Names coming from" + _sdmBuildsURL)
        # directory SDM422 has to be created if needed
        if not os.path.isdir(arch.SU_PACKAGES_DIR) :
            os.makedirs(arch.SU_PACKAGES_DIR)
            LOG.info(arch.SU_PACKAGES_DIR + " Created")
        else :
            LOG.info(arch.SU_PACKAGES_DIR + " already exist")

        _sdmCPPage = urllib2.urlopen(_sdmBuildsURL)

        # on the HTML page there is a link to a doc word.
        # Lets get it !
        for line in _sdmCPPage:
            if 'CP.' + str(cp) in line:
                _CP = re.search('(http.*tar)(.*href=")(.*doc)', line)
                LOG.debug("Delivery Note used is : ")
                LOG.debug(_CP.group(3))
                break

        # file will be saved in order to be parsed
        fh = open("DelNote.doc", 'wb')
        fh.write(urllib2.urlopen(_CP.group(3)).read())
        fh.close()
        cmd = 'LANG="bs_BA" antiword ' + "DelNote.doc"
        _delivNotesText = subprocess.check_output(cmd, shell=True)

        # mCAS packages have to be stored in a directory called for example mCAS3213
        _mCASdir = re.search('(mCAS)(.*)(R)([0-9]+)(.)([0-9]+)(.)([0-9]+)', _delivNotesText)
        _mCASdir = '/' + _mCASdir.group(1) + _mCASdir.group(4) + _mCASdir.group(6) + _mCASdir.group(8)
        self.MCAS_DIR = _mCASdir
        LOG.debug('MCAS Directory is: ' + _mCASdir)

        # Must be created if not exit
        if not os.path.isdir(arch.SU_PACKAGES_DIR + _mCASdir) :
            os.makedirs(arch.SU_PACKAGES_DIR + _mCASdir)
            LOG.info(arch.SU_PACKAGES_DIR + _mCASdir + " Created")
        else :
            LOG.info(arch.SU_PACKAGES_DIR + _mCASdir + " already exist")
        # Also CP Dir must be created
        _cpdir = arch.SU_PACKAGES_DIR + _mCASdir + '/CP' + str(cp)
        if not os.path.isdir(_cpdir) :
            os.makedirs(_cpdir)
            LOG.info(_cpdir + " Created")
        else :
            LOG.info(_cpdir + " already exist")
        # Also CPXXX/BE and FE and PFE Dir must be created
        if not os.path.isdir(_cpdir + '/BE') :
            os.makedirs(_cpdir + '/BE')
            LOG.info(_cpdir + '/BE' + " Created")
        else :
            LOG.info(_cpdir + '/BE' + " already exist")
        if not os.path.isdir(_cpdir + '/FE') :
            os.makedirs(_cpdir + '/FE')
            LOG.info(_cpdir + '/FE' + " Created")
        else :
            LOG.info(_cpdir + '/FE' + " already exist")
        if not os.path.isdir(_cpdir + '/PFE') :
            os.makedirs(_cpdir + '/PFE')
            LOG.info(_cpdir + '/PFE' + " Created")
        else :
            LOG.info(_cpdir + '/PFE' + " already exist")

        # Retrieviong OAM Scripts

        _mCASScriptsFileName = re.search('(OAMscripts_MCAS_)([0-9]+.[0-9]+)', _delivNotesText)
        LOG.info("MCAS_Scripts_File_Name : " + _mCASScriptsFileName.group(0) + '.tar.gz')
        _oamscriptsdir = arch.SU_PACKAGES_DIR + '/OAMScripts/' + _mCASScriptsFileName.group(2)
        if not os.path.isdir(_oamscriptsdir) :
            os.makedirs(_oamscriptsdir)
            LOG.info(_oamscriptsdir + " Created")
        else:
            LOG.info(_oamscriptsdir + " already exist")
        shutil.copy(arch.OAMSCRIPT_PACKAGES_DIR + '/' + _mCASScriptsFileName.group(0) + '.tar.gz', \
                     _oamscriptsdir + '/' + _mCASScriptsFileName.group(0) + '.tar.gz')

        # Get DDM file
        _DDMFileName = re.search('(DDMr[0-9].*.tar.gz)', _delivNotesText)
        LOG.info('DDM File name is : ' + _DDMFileName.group(0))
        shutil.copy(arch.DDM_PACKAGES_DIR + '/' + _DDMFileName.group(0) , \
                     arch.SU_PACKAGES_DIR + _mCASdir + '/thirdParty.DDM.tar.gz')

        # Now retrieving DataModel. Not used for the moment
        _dataModel = re.search(r'(DATAMODEL_DEV.*\b)', str(_delivNotesText))
        _dataModel = _dataModel.group(0)
        LOG.info('DataModel is : ' + _dataModel)

        # Get Mcas Packages
        _mCASVer = re.search('(mCAS)(.*)(R[0-9]+.[0-9]+.[0-9]+)', _delivNotesText)
        _mCASVer = _mCASVer.group(1) + _mCASVer.group(3)
        LOG.debug('mCAS Version is : ' + _mCASVer)

        mCAS_SourceDir = re.search(r"(CCMS.*)(IAS/)(.*/)(.*\b)", _delivNotesText)
        mCAS_SourceDir = arch.OAM_PACKAGES_DIR + '/' + mCAS_SourceDir.group(3) + mCAS_SourceDir.group(4) + '/Upgrade'
        LOG.info('mCAS packages will be retrieved from : ' + mCAS_SourceDir)
        src_files = os.listdir(mCAS_SourceDir)
        for file_name in src_files:
            full_file_name = os.path.join(mCAS_SourceDir, file_name)
            LOG.info('mCAS packages retrieved  : ' + full_file_name)
            shutil.copy(full_file_name , arch.SU_PACKAGES_DIR + _mCASdir + '/')

        _dateSDM = re.search(r"(8650SDM-)(.*)(-SDM)", _delivNotesText)
        LOG.debug('SDM packages with date : ' + _dateSDM.group(2) + " will be retrieved")
        _sdm421dir = arch.SDM_PACKAGES_DIR + '/421'
        for _sdmpackages in os.listdir(_sdm421dir) :
            if _dateSDM.group(2) in  _sdmpackages :
                if 'BE' in _sdmpackages :
                    LOG.info('SDM Pkg = ' + _sdm421dir + '/' + _sdmpackages)
                    shutil.copy(_sdm421dir + '/' + _sdmpackages  , \
                                 arch.SU_PACKAGES_DIR + _mCASdir + '/CP' + str(cp) + '/BE/')
                elif 'FE' in _sdmpackages :
                    LOG.info('SDM Pkg = ' + _sdm421dir + '/' + _sdmpackages)
                    shutil.copy(_sdm421dir + '/' + _sdmpackages  , \
                                 arch.SU_PACKAGES_DIR + _mCASdir + '/CP' + str(cp) + '/FE')
                elif 'iLB' in _sdmpackages :
                    LOG.info('SDM Pkg = ' + _sdm421dir + '/' + _sdmpackages)
                    shutil.copy(_sdm421dir + '/' + _sdmpackages  , \
                                arch.SU_PACKAGES_DIR + _mCASdir + '/CP' + str(cp) + '/FE')
                elif 'PROXY' in _sdmpackages :
                    LOG.info('SDM Pkg = ' + _sdm421dir + '/' + _sdmpackages)
                    shutil.copy(_sdm421dir + '/' + _sdmpackages  , \
                                 arch.SU_PACKAGES_DIR + _mCASdir + '/CP' + str(cp) + '/PFE/')
                else :
                    LOG.info('SDM Pkg = ' + _sdm421dir + '/' + _sdmpackages)
                    shutil.copy(_sdm421dir + '/' + _sdmpackages  , \
                                 arch.SU_PACKAGES_DIR + _mCASdir + '/CP' + str(cp) + '/')

    def updateFiles(self, cp):
        '''
        Used to do some renaming and MD5SUM calculation in order to have files ready for Manual SU
        '''
        LOG.info ("Updates files content")
        _cpdir = arch.DELIV_PACKAGES_DIR + '/CP' + cp
        LOG.info("Working Directory is : " + _cpdir)
        _filelist = os.listdir(_cpdir)
        # List the files in the directory
        if 'thirdParty.DDM.tar.gz' in _filelist :
            LOG.critical('thirdParty.DDM.tar.gz already exist ! Work probably already done Exiting...')
            return
        LOG.info("Content and MD5SUM of Working Directory is : ")
        for _filename in _filelist :
            _fileMD5SUM = subprocess.check_output('md5sum ' + _cpdir + '/' + _filename , shell=True)
            LOG.info(_fileMD5SUM)
            if 'DDM' in _filename :
                _ddmpkgname = _filename[3:-7]
                os.rename(_cpdir + '/' + _filename, _cpdir + '/thirdParty.DDM.tar.gz')
                _ddmMD5SUM = subprocess.check_output('md5sum ' + _cpdir + '/' + 'thirdParty.DDM.tar.gz', shell=True)
                LOG.info("Renaming " + _cpdir + '/' + _filename + ' to ' + _cpdir + '/thirdParty.DDM.tar.gz')

        # file will be saved in order to be parsed
        LOG.info ("Openning file : " + _cpdir + "/SU_3.2.13.data")
        fh = open(_cpdir + "/SU_3.2.13.data", 'r')
        file_content = fh.read()
        fh.close()
        _ddmpkgname_string = (re.sub('DDM_NAME=.*', 'DDM_NAME=' + _ddmpkgname , file_content))
        _ddmpkgname_string = (re.sub('DDMSOAKTYPE=.*', 'DDMSOAKTYPE=FULLSOAK' , _ddmpkgname_string))
        LOG.info('SU_3.2.13.data content is : \n' + _ddmpkgname_string)

        fh = open(_cpdir + "/SU_3.2.13.data", 'w')
        fh.write(_ddmpkgname_string)
        fh.close()

        # Also need to do some changes in catalog_3.2.13
        _su_dataMD5SUM = subprocess.check_output('md5sum ' + _cpdir + '/' + 'SU_3.2.13.data', shell=True)
        LOG.info ("Openning file : " + _cpdir + "/catalog_3.2.13")
        fh = open(_cpdir + "/catalog_3.2.13", 'r')
        file_content = fh.read()
        fh.close()
        _ddmMD5SUMandName = _ddmMD5SUM.split(' ', 1)[0] + '  ' + _ddmMD5SUM.rsplit('/', 1)[1]
        _ddmMD5SUMandName = _ddmMD5SUMandName[:-1]
        _ddmpkgname_string = (re.sub('.*thirdParty.DDM.tar.gz' , _ddmMD5SUMandName  , file_content))
        _sudataMD5SUMandName = _su_dataMD5SUM.split(' ', 1)[0] + '  ' + _su_dataMD5SUM.rsplit('/', 1)[1]
        _sudataMD5SUMandName = _sudataMD5SUMandName[:-1]
        _ddmpkgname_string = (re.sub('.*SU_3.2.13.data', _sudataMD5SUMandName , file_content))

        LOG.info('catalog_3.2.13 content is now : \n' + _ddmpkgname_string)
        fh = open(_cpdir + "/catalog_3.2.13", 'w')
        fh.write(_ddmpkgname_string)
        fh.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="get all needed packages"
                                     "for an SU")
    parser.add_argument("--cp",
                        help="number of the CP (required)",
                        required=True)
    args = parser.parse_args()
    LOG.info('CP : ' + args.cp)
    PREPPACK = PreparePackagesDir()
    PREPPACK.getPackagesManualSU(args.cp)
    # PREPPACK.getPackages(args.cp)
    PREPPACK.updateFiles(args.cp)
    for _dir in os.listdir(arch.DELIV_PACKAGES_DIR):
        if  'CP' in _dir:
            LOG.info('Packages already available for : ' + _dir)
