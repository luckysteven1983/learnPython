"""
@file health_check_weekly_test_once.py
@ingroup SDMSQA
@author Andy SUN
@date 2015-04-14
@brief health check for system
"""

import unittest
import time
import lib.exceptions_messages as eMsgs
from lib.health_check.health_check_manager import HealthCheckManagerError
from framework.sdm_test_case import SDMTestCase
from lib.logging.logger import Logger
from framework.asserts.common_asserts import CommonAssert

LOGGER = Logger.getLogger(__name__)

class health_check_weekly_test_once(SDMTestCase):
    """Unit test for HealthCheck class.
    """

    def setUp(self):
        self.logLinksPrint()
        LOGGER.info("TestHealthCheckManager Test Once")
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        _, self.be = self.testEnv.testBed.getBackends().popitem()

    def test_01_Check_Failure(self):
        """Health Check Failure
        """
        LOGGER.info('[Test case 01] Health Check Failure')

        LOGGER.debug("remove one machine on BE and check the status again")
        # the blade will be recovered in tearDown
        self.sdmManager.mcasMachineManager.removeMachine(self.be, '0-0-2')
        time.sleep(30)

        # Machine
        self.assertRaisesRegexp(HealthCheckManagerError, eMsgs.HEALTH_CHECK_MACHINE_NOK,
                                self.sdmManager.healthCheckManager.runCheckMachine,
                                self.be)

        # Station
        self.assertRaisesRegexp(HealthCheckManagerError, eMsgs.HEALTH_CHECK_STATION_NOK,
                                self.sdmManager.healthCheckManager.runCheckStation,
                                self.be)

    def test_02_Wait_NDB_Recover(self):
        """Wait NDB Recover
        """
        LOGGER.info('[Test case 02] Wait NDB Recover')
        CommonAssert.timedAssert(7200, 60, self.sdmManager.healthCheckManager.runCheckNdb, self.be)

    def tearDown(self):
        """Lab Recovery"""
        # recover lab in case of the lab is broken by test case.
        LOGGER.info('Recover lab if necessary')
        self.sdmManager.labRecover.machineRecover(self.be)

if __name__ == "__main__":
    unittest.main()

