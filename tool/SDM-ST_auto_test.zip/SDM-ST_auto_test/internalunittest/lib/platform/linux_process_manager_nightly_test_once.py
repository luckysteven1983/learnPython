'''
Created on Mar 24, 2015

@author: Xia Zhao
'''
import unittest
from lib.logging.logger import Logger
from lib.platform.linux_process_manager import LinuxProcessManagerError
import lib.exceptions_messages as msgs
from framework.sdm_test_case import SDMTestCase
from framework.traffic.ptool.ptool_diameter_traffic_simulator import PtoolDiameterTrafficSimulator
from framework.traffic.tgen.tgen_ldap_traffic_simulator import TgenLDAPTrafficSimulator

LOGGER = Logger.getLogger(__name__)


class linux_process_manager_test_once(SDMTestCase):


    def setUp(self):
        LOGGER.info("Linux Process Manager Test Once")
        self.logLinksPrint()  # Used to get the log links in Junit XML results
        _, self.client = self.testEnv.testBed.getBackends().popitem()
        _, self.fe = self.testEnv.testBed.getFrontends().popitem()
        self.PM = self.sdmManager.linuxProcessManager
        self.serverIp = None
        self.account = None
        for myTrafficSimulator in self.testEnv.trafficSimulators:
            if isinstance(myTrafficSimulator, PtoolDiameterTrafficSimulator) \
                     or isinstance(myTrafficSimulator, TgenLDAPTrafficSimulator):
                self.serverIp = myTrafficSimulator.toolIpAddress
                self.account = myTrafficSimulator.account
                break
        if not self.serverIp:
            LOGGER.info("No ptool or tgen simulator found: will not try some ssh connections...")

    def tearDown(self):
        pass

    def test_01_isAlive_on_pilot(self):
        LOGGER.info("test_01_isAlive_on_pilot")
        proName = "GdmpServer"
        self.PM.isAlive(self.client, processName=proName)

    def test_02_isAlive_on_stations(self):
        LOGGER.info("test_02_isAlive_on_stations")
        proName = "GdmpServer"
        stations = ["0-0-2", "0-0-1", "0-0-9"]
        self.PM.isAlive(self.client, processName=proName, station=stations)

    def test_03_isNotAlive_on_pilot(self):
        LOGGER.info("test_03_isNotAlive_on_pilot")
        proName = "GdmpServerABC"
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.PROCESS_NOT_ALIVE, self.PM.isAlive, self.client, processName=proName)

    def test_04_isNotAlive_on_stations(self):
        LOGGER.info("test_04_isNotAlive_on_stations")
        proName = "GdmpServerABC"
        stations = ["0-0-2", "0-0-1", "0-0-9"]
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.PROCESS_NOT_ALIVE, self.PM.isAlive, self.client, processName=proName, station=stations)

    def test_05_getPid_on_pilot_success(self):
        LOGGER.info("test_05_getPid_on_pilot_success")
        proName = "sshd"
        pids = self.PM.getPid(self.client, proName)
        LOGGER.debug(pids)

    def test_06_getPid_on_pilot_failed(self):
        LOGGER.info("test_06_getPid_on_pilot_failed")
        proName = "GdmpServerABC"
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.GET_PID_FAIL, self.PM.getPid, self.client, proName)

    def test_07_getPid_on_blade_success(self):
        LOGGER.info("test_07_getPid_on_blade_success")
        proName = "GdmpServer"
        station = "0-0-2"
        pids = self.PM.getPid(self.client, proName, station)
        LOGGER.debug(pids)

    def test_08_getPid_on_blade_failed(self):
        LOGGER.info("test_08_getPid_on_blade_failed")
        proName = "GdmpServerABC"
        station = "0-0-2"
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.GET_PID_FAIL, self.PM.getPid, self.client, proName, station)

    def test_09_getPidbyPS_on_pilot_success(self):
        LOGGER.info("test_09_getPidbyPS_on_pilot_success")
        proName = "sshd"
        pids = self.PM.getPidbyPS(self.client, proName)
        LOGGER.debug(pids)

    def test_10_getPidbyPS_on_pilot_failed(self):
        LOGGER.info("test_10_getPidbyPS_on_pilot_failed")
        proName = "GdmpServerABC"
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.GET_PID_FAIL, self.PM.getPidbyPS, self.client, proName)

    def test_11_getPidbyPS_on_blade_success(self):
        LOGGER.info("test_11_getPidbyPS_on_blade_success")
        proName = "/usr/mysql/bin/ndb"
        station = "0-0-2"
        pids = self.PM.getPidbyPS(self.client, proName, station)
        LOGGER.debug(pids)

    def test_12_getPidbyPS_on_blade_failed(self):
        LOGGER.info("test_12_getPidbyPS_on_blade_failed")
        proName = "GdmpServerABC"
        station = "0-0-2"
        self.assertRaisesRegexp(LinuxProcessManagerError, msgs.GET_PID_FAIL, self.PM.getPidbyPS, self.client, proName, station)

    def createProcessOnServer(self, client, processName):
        cmd = "cd /tmp; echo '#!/bin/bash' > " + processName + "; echo 'sleep 60' >> " + processName \
              + "; chmod +x " + processName + "; nohup ./" + processName + " > /dev/null &"
        self.sdmManager.sshManager.run(self.serverIp, cmd, self.account.login, ignoreStdStreams=True)

    def test_13_getPidOnServer(self):
        processName = "test_automation.sh"
        client = self.sdmManager.sshManager.getClient(self.serverIp, self.account.login, self.account.password)
        self.createProcessOnServer(client, processName)
        self.PM.getPidbyPSOnServer(self.serverIp, self.account.login, processName)
        self.PM.isAliveOnServer(self.serverIp, self.account.login, ".", processName, "error")
        self.PM.killProcessOnServer(self.serverIp, self.account.login, processName, getPidtype=1)
        self.createProcessOnServer(client, processName)
        pid = self.PM.getPidbyPSOnServer(self.serverIp, self.account.login, processName)
        pidList = list(pid)
        self.PM.killProcessbyPidOnServer(self.serverIp, self.account.login, pidList)

if __name__ == "__main__":
    # import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

